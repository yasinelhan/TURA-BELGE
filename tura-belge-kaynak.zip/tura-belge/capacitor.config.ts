// Tura Belge — mobil uygulama (Android, iPhone/iPad) ayarları
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nahle.turabelge',
  appName: 'Tura Belge',
  // "npm run mobil:hazirla" önce web uygulamasını bu klasöre derler
  webDir: 'dist-native',
  android: {
    // Tura Asistan: aynı Wi-Fi'deki bilgisayarda çalışan modele (ör. http://192.168.1.20:11434) bağlanabilmek için
    allowMixedContent: true,
  },
  ios: {
    contentInset: 'never',
  },
};

export default config;
