# Üçüncü taraf bileşenler

Tura Belge aşağıdaki açık kaynak projeleri kullanır. Hepsinin lisansı AGPL-3.0 ile uyumludur.

| Bileşen | Ne için | Lisans |
|---|---|---|
| [EmbedPDF](https://github.com/embedpdf/embed-pdf-viewer) (`@embedpdf/*`) | PDF görüntüleyici, not alma, imza, karartma | MIT |
| [PDFium](https://pdfium.googlesource.com/pdfium/) (EmbedPDF içinde, WebAssembly) | PDF motoru | BSD-3-Clause / Apache-2.0 |
| [Noto Sans](https://fonts.google.com/noto/specimen/Noto+Sans) (`@embedpdf/fonts-latin`) | Yedek yazı tipi, Türkçe metin kutuları | SIL Open Font License 1.1 (`public/vendor/fonts/OFL.txt`) |
| [pdf-lib](https://github.com/Hopding/pdf-lib), [@pdf-lib/fontkit](https://github.com/Hopding/fontkit) | PDF araçları, metin katmanı, vektör sayfalar | MIT |
| [OpenCV.js](https://opencv.org) (`@techstark/opencv-js`) | Belge tarama: kenar bulma, perspektif, filtreler; vektörleştirmede kenar çıkarma | Apache-2.0 (`public/vendor/opencv/LICENSE.txt`) |
| [Tesseract.js](https://github.com/naptha/tesseract.js), `tesseract.js-core` | Yazı tanıma (OCR) | Apache-2.0 (`public/vendor/tesseract/LICENSE.txt`) |
| [Tesseract](https://github.com/tesseract-ocr/tesseract) dil verileri (`tessdata_best`, tamsayı; `@tesseract.js-data/tur`, `@tesseract.js-data/eng`) | Türkçe ve İngilizce tanıma modelleri | Apache-2.0 (paketler MIT) |
| [wasm-feature-detect](https://github.com/GoogleChromeLabs/wasm-feature-detect) (Tesseract.js içinde) | Uygun WASM çekirdeğini seçme | Apache-2.0 |
| [BusyTeX](https://github.com/busytex/busytex) / [texlyre-busytex](https://github.com/TeXlyre/texlyre-busytex) | Tarayıcıda LaTeX derleyici (pdfLaTeX, XeLaTeX, LuaLaTeX) | AGPL-3.0-or-later |
| [TeX Live](https://tug.org/texlive/) paketleri (BusyTeX içinde) | LaTeX sınıfları ve paketleri | Çeşitli özgür lisanslar (çoğunlukla LPPL 1.3c, GPL, public domain); ayrıntı: TeX Live `LICENSE.TL` |
| [CodeMirror 6](https://codemirror.net) (`codemirror`, `@codemirror/*`, `@lezer/highlight`) | LaTeX kod düzenleyicisi | MIT |
| [Capacitor](https://capacitorjs.com) (`@capacitor/core`, `cli`, `android`, `ios`) | Android ve iOS uygulaması | MIT |
| [perfect-freehand](https://github.com/steveruizok/perfect-freehand) | Tura Kalem: basınca göre değişen kalınlıkta kalem izi | MIT |
| [marked](https://github.com/markedjs/marked) | Markdown okuma ve önizleme | MIT |
| [KaTeX](https://katex.org) | Notlarda ve asistan cevaplarında formül çizimi (yazı tipleri dahil; `public/vendor/katex`) | MIT |
| [pdfmake](https://github.com/bpampuch/pdfmake) (içinde [PDFKit](https://github.com/foliojs/pdfkit), fontkit, linebreak) | Markdown → PDF (vektör, gömülü yazı tipi) | MIT |
| [docx](https://github.com/dolanmiu/docx) | Word (.docx) olarak kaydetme | MIT |
| [Noto Sans Mono](https://fonts.google.com/noto/specimen/Noto+Sans+Mono) (`@expo-google-fonts/noto-sans-mono`) | Kod blokları (PDF/Word) | SIL Open Font License 1.1 |
| [fflate](https://github.com/101arrowz/fflate) | ZIP indirme | MIT |
| [idb-keyval](https://github.com/jakearchibald/idb-keyval) | Cihazda belge saklama | Apache-2.0 |
| [React](https://react.dev) | Arayüz | MIT |
| [Vite](https://vite.dev), [vite-plugin-pwa](https://github.com/vite-pwa/vite-plugin-pwa) | Derleme, PWA | MIT |

Vektörleştirmedeki eğri oturtma yöntemi Peter Selinger'in yayımladığı Potrace algoritmasına (2003) dayanır; kod bu proje için sıfırdan yazılmıştır, Potrace kaynak kodu kullanılmamıştır.

Uzak kaynaktan yüklenenler: Montserrat ve Open Sans (arayüz) ile Caveat, Dancing Script, Great Vibes, Pacifico (yazılı imza) Google Fonts'tan gelir; hepsi SIL Open Font License 1.1 lisanslıdır. "İnternette ara" düğmesi ve asistan panelindeki "Google Çeviri’de aç" bağlantısı seçili metni yalnızca kullanıcı tıkladığında Google Arama / Google Çeviri'de yeni sekmede açar ("Çevir" önce tarayıcının cihaz içi çevirmenini, yoksa kullanıcının bağladığı modeli kullanır).

## Tura Asistan’ın bağlanabildiği servisler ve programlar

Tura Belge bunların hiçbirini içermez ve dağıtmaz; yalnızca ağ üzerinden (HTTP API) bağlanır. İnternet servisleri (Google Gemini, Groq, OpenRouter, OpenAI, Anthropic, DeepSeek) kullanıcının kendi hesabı ve API anahtarıyla, kendi kullanım koşullarına göre çalışır; Tura Belge bu servislerle bağlantılı değildir. claude.ai içindeki Claude, kullanıcının kendi Claude hesabıyla çalışır. Kullanıcının kendi bilgisayarında kurduğu programlar: [Ollama](https://ollama.com) (MIT), [LM Studio](https://lmstudio.ai), [Open WebUI](https://openwebui.com), [AnythingLLM](https://anythingllm.com) (MIT), [Jan](https://jan.ai) (Apache-2.0). İndirilen yapay zeka modellerinin (ör. Gemma, Qwen) kendi lisansları vardır.
