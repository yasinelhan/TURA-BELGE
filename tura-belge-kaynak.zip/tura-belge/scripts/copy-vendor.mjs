// Tura Belge — Latin yedek yazı tiplerini (Noto Sans) ve tarama motorunu (OpenCV.js)
// public/vendor klasörüne kopyalar. Böylece uygulama çevrimdışı çalışır ve hiçbir CDN'e istek atmaz.
// (PDFium WASM dosyasını Vite kendisi paketler. OpenCV ise paketlenmez: 13 MB'lık dosya
// klasik <script> olarak yalnızca tarama açılınca yüklenir ve ayrı önbelleğe alınır.)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { cpSync, mkdirSync, existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const nm = join(root, 'node_modules', '@embedpdf');
const out = join(root, 'public', 'vendor');
mkdirSync(join(out, 'fonts'), { recursive: true });
mkdirSync(join(out, 'opencv'), { recursive: true });
mkdirSync(join(out, 'tesseract', 'core'), { recursive: true });
mkdirSync(join(out, 'tesseract', 'lang'), { recursive: true });
const cv = join(root, 'node_modules', '@techstark', 'opencv-js');
const ts = join(root, 'node_modules', 'tesseract.js');
const tsCore = join(root, 'node_modules', 'tesseract.js-core');
const tsData = join(root, 'node_modules', '@tesseract.js-data');

const files = [
  ...['Regular', 'Bold', 'Italic', 'BoldItalic'].map((w) => [
    join(nm, 'fonts-latin', 'fonts', `NotoSans-${w}.ttf`),
    join(out, 'fonts', `NotoSans-${w}.ttf`),
  ]),
  // SIL Open Font License metni yazı tipleriyle birlikte dağıtılmalı
  [join(nm, 'fonts-latin', 'LICENSE'), join(out, 'fonts', 'OFL.txt')],
  // Eş aralıklı yazı tipi (Markdown → PDF/Word kod blokları), OFL
  [
    join(root, 'node_modules', '@expo-google-fonts', 'noto-sans-mono', '400Regular', 'NotoSansMono_400Regular.ttf'),
    join(out, 'fonts', 'NotoSansMono-Regular.ttf'),
  ],
  // OpenCV.js (Apache-2.0) ve lisansı
  [join(cv, 'dist', 'opencv.js'), join(out, 'opencv', 'opencv.js')],
  [join(cv, 'LICENSE'), join(out, 'opencv', 'LICENSE.txt')],
  // Tesseract.js (Apache-2.0): işçi, WASM çekirdeği (yalnızca LSTM; tarayıcı uygun olanı seçer) ve dil verileri
  [join(ts, 'dist', 'worker.min.js'), join(out, 'tesseract', 'worker.min.js')],
  [join(ts, 'LICENSE.md'), join(out, 'tesseract', 'LICENSE.txt')],
  ...['lstm', 'simd-lstm', 'relaxedsimd-lstm'].map((v) => [
    join(tsCore, `tesseract-core-${v}.wasm.js`),
    join(out, 'tesseract', 'core', `tesseract-core-${v}.wasm.js`),
  ]),
  // "best_int": hızlı ve doğru (tessdata_best'in tamsayı sürümü)
  ...['tur', 'eng'].map((l) => [
    join(tsData, l, '4.0.0_best_int', `${l}.traineddata.gz`),
    join(out, 'tesseract', 'lang', `${l}.traineddata.gz`),
  ]),
];

for (const [from, to] of files) {
  if (!existsSync(from)) {
    console.error(`[copy-vendor] eksik dosya: ${from} — önce "npm install" çalıştırın.`);
    process.exit(1);
  }
  cpSync(from, to);
}

// KaTeX (MIT): asistan cevaplarındaki ve notlardaki formüller. Yalnızca woff2 yazı tipleri kopyalanır
// ve CSS buna göre sadeleştirilir (eski tarayıcılar için woff/ttf gerekmez).
const kx = join(root, 'node_modules', 'katex');
if (!existsSync(join(kx, 'dist', 'katex.min.css'))) {
  console.error('[copy-vendor] eksik dosya: katex — önce "npm install" çalıştırın.');
  process.exit(1);
}
mkdirSync(join(out, 'katex', 'fonts'), { recursive: true });
const woff2 = readdirSync(join(kx, 'dist', 'fonts')).filter((f) => f.endsWith('.woff2'));
for (const f of woff2) cpSync(join(kx, 'dist', 'fonts', f), join(out, 'katex', 'fonts', f));
const css = readFileSync(join(kx, 'dist', 'katex.min.css'), 'utf8').replace(
  /src:url\((fonts\/[^)]+\.woff2)\) format\("woff2"\)(?:,url\([^)]+\) format\("[^"]+"\))*/g,
  'src:url($1) format("woff2")',
);
writeFileSync(join(out, 'katex', 'katex.min.css'), css);
cpSync(join(kx, 'LICENSE'), join(out, 'katex', 'LICENSE.txt'));

console.log(`[copy-vendor] ${files.length + woff2.length + 2} dosya public/vendor klasörüne kopyalandı.`);
