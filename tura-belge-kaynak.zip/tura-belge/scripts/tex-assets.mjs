// Tura TeX — tarayıcıda LaTeX derlemek için BusyTeX (TeX Live 2026) dosyalarını hazırlar.
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Kullanım:
//   npm run tex:indir                       # GitHub'dan indirir (yaklaşık 520 MB arşiv, bir kez)
//   npm run tex:indir -- --kaynak <klasör>  # önceden indirilmiş/açılmış busytex klasörünü kullanır
//   npm run tex:indir -- --paket genis      # temel (varsayılan) | genis | tam
//
// Paketler (her biri bağımsızdır, birini seçmek yeter):
//   temel  ~ 120 MB  pdfLaTeX/XeLaTeX/LuaLaTeX, babel (Türkçe), amsmath, graphicx, hyperref, geometry, fancyhdr…
//   genis  ~ 225 MB  + fontspec, xcolor, tikz, beamer, booktabs, caption, microtype…
//   tam    ~ 360 MB  + enumitem, titlesec, tcolorbox, moderncv, siunitx, csquotes…
//
// Not: GitHub Pages tek dosyada 100 MB sınırı koyar; "genis" ve "tam" paketlerin veri dosyası
// bunu aşar. Bu paketleri kendi sunucunuzda (ör. üniversite sunucusu, nginx) yayınlayın.
import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'public', 'tex', 'busytex');
const args = process.argv.slice(2);
const opt = (name) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : undefined;
};
const BUNDLES = { temel: 'basic', genis: 'recommended', tam: 'extra' };
const bundleKey = opt('paket') ?? 'temel';
const bundle = BUNDLES[bundleKey];
if (!bundle) {
  console.error(`[tex] bilinmeyen paket: ${bundleKey} (temel | genis | tam)`);
  process.exit(1);
}

const VERSION = '1.4.1';
const URL_ = `https://github.com/TeXlyre/texlyre-busytex/releases/download/assets-v${VERSION}/busytex-assets.tar.gz`;

let source = opt('kaynak');
let tmp = null;
if (!source) {
  tmp = mkdtempSync(join(tmpdir(), 'tura-tex-'));
  const archive = join(tmp, 'busytex-assets.tar.gz');
  console.log(`[tex] indiriliyor: ${URL_}\n      (yaklaşık 520 MB, yalnızca bir kez gerekir)`);
  const res = await fetch(URL_);
  if (!res.ok) throw new Error(`İndirme başarısız: ${res.status}`);
  const { createWriteStream } = await import('node:fs');
  const { Readable } = await import('node:stream');
  const { finished } = await import('node:stream/promises');
  await finished(Readable.fromWeb(res.body).pipe(createWriteStream(archive)));
  console.log('[tex] arşiv açılıyor…');
  execFileSync('tar', ['-xzf', archive, '-C', tmp]);
  source = join(tmp, 'busytex');
}
if (!existsSync(join(source, 'busytex.wasm'))) {
  console.error(`[tex] ${source} içinde busytex.wasm bulunamadı.`);
  process.exit(1);
}

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
const files = [
  'busytex.js',
  'busytex.wasm',
  'busytex_pipeline.js',
  'busytex_worker.js',
  'busytex_biber.js',
  `texlive-${bundle}.js`,
  `texlive-${bundle}.data`,
];
let total = 0;
for (const f of files) {
  cpSync(join(source, f), join(out, f));
  total += statSync(join(out, f)).size;
}
// Paket listesi: "şu paket bu kurulumda var mı?" sorusu için
cpSync(join(source, `texlive-${bundle}.js.providespackage.txt`), join(out, 'packages.txt'));
writeFileSync(
  join(out, 'manifest.json'),
  JSON.stringify({ version: VERSION, bundle, bundleKey, size: total, files }, null, 2),
);
if (tmp) rmSync(tmp, { recursive: true, force: true });
const big = readdirSync(out).filter((f) => statSync(join(out, f)).size > 100 * 1024 * 1024);
console.log(`[tex] hazır: public/tex/busytex (${bundleKey}, ${(total / 1048576).toFixed(0)} MB)`);
if (big.length) console.log(`[tex] uyarı: 100 MB'tan büyük dosya var (${big.join(', ')}); GitHub Pages bunu kabul etmez.`);
