// Tura Belge — İndir düğmesi ve "Farklı kaydet" menüsü (PDF, Word, Markdown, web sayfası, düz metin)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState } from 'react';
import { FORMATS, type ExportFormat } from '../convert/exporters';
import { __ } from '../i18n';

export interface SaveExtra {
  id: string;
  label: string;
  hint?: string;
}

export function SaveMenu({
  main,
  disabled,
  busy,
  onSave,
  extras = [],
  onExtra,
}: {
  /** Düğmeye doğrudan basınca kaydedilen biçim */
  main: ExportFormat;
  disabled?: boolean;
  busy?: boolean;
  onSave: (f: ExportFormat) => void;
  extras?: SaveExtra[];
  onExtra?: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: PointerEvent) => !ref.current?.contains(e.target as Node) && setOpen(false);
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('pointerdown', h);
    document.addEventListener('keydown', k);
    return () => {
      document.removeEventListener('pointerdown', h);
      document.removeEventListener('keydown', k);
    };
  }, [open]);
  const mainInfo = FORMATS.find((f) => f.id === main)!;
  return (
    <div className="savemenu" ref={ref}>
      <button className="btn btn--primary savemenu__main" onClick={() => onSave(main)} disabled={disabled || busy} title={__('{0} olarak indir', [__(mainInfo.label)])}>
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <path d="M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19h14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="hide-xs">{busy ? __('Hazırlanıyor…') : __('İndir')}</span>
      </button>
      <button
        className="btn btn--primary savemenu__more"
        aria-label={__('Farklı kaydet: biçim seç')}
        aria-haspopup="menu"
        aria-expanded={open}
        disabled={disabled || busy}
        onClick={() => setOpen((v) => !v)}
      >
        <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
          <path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      {open && (
        <div className="popmenu savemenu__pop" role="menu">
          <p className="popmenu__label">{__('Farklı kaydet')}</p>
          {FORMATS.map((f) => (
            <button
              key={f.id}
              role="menuitem"
              onClick={() => {
                setOpen(false);
                onSave(f.id);
              }}
            >
              <span className="savemenu__ext">.{f.ext}</span>
              {__(f.label)}
              {f.id === main && <small className="savemenu__note">{__('asıl biçim')}</small>}
            </button>
          ))}
          {extras.length > 0 && <hr />}
          {extras.map((x) => (
            <button
              key={x.id}
              role="menuitem"
              onClick={() => {
                setOpen(false);
                onExtra?.(x.id);
              }}
            >
              <span className="savemenu__ext">↗</span>
              <span>
                {__(x.label)}
                {x.hint && <small className="savemenu__hint">{__(x.hint)}</small>}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
