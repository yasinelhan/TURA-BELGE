// Tura Belge — belgenin üst çubuğundaki sekmeler (geniş ekranda sekme, telefonda açılır liste)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { __ } from '../i18n';

export interface DocTab {
  id: string;
  label: string;
}

export function DocTabs({ tabs, active, onPick, label }: { tabs: DocTab[]; active: string; onPick: (id: string) => void; label: string }) {
  return (
    <>
      <nav className="doctabs" aria-label={label}>
        {tabs.map((t) => (
          <button
            key={t.id}
            className={active === t.id ? 'doctabs__tab doctabs__tab--on' : 'doctabs__tab'}
            aria-current={active === t.id ? 'page' : undefined}
            onClick={() => onPick(t.id)}
          >
            {__(t.label)}
          </button>
        ))}
      </nav>
      <label className="doctabs__pick">
        <span className="sr-only">{label}</span>
        <select value={active} onChange={(e) => onPick(e.target.value)}>
          {tabs.map((t) => (
            <option key={t.id} value={t.id}>
              {__(t.label)}
            </option>
          ))}
        </select>
      </label>
    </>
  );
}
