// Tura Belge — ortak üst çubuk ve bölüm gezintisi
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { ReactNode } from 'react';
import { BrandLockup } from './Brand';
import { __, N_, setLang, useLang, type Lang } from '../i18n';

export type Section = 'belgeler' | 'araclar';
const LINKS: { id: Section; hash: string; label: string }[] = [
  { id: 'belgeler', hash: '', label: 'Belgelerim' },
  { id: 'araclar', hash: 'araclar', label: N_('PDF araçları') },
];

export function TopNav({ active, onNavigate, right }: { active: Section; onNavigate: (hash: string) => void; right?: ReactNode }) {
  return (
    <header className="topbar">
      <a
        href="#"
        className="lockup-link"
        aria-label={__('Tura Belge ana sayfa')}
        onClick={(e) => {
          e.preventDefault();
          onNavigate('');
        }}
      >
        <BrandLockup />
      </a>
      <nav className="nav" aria-label={__('Bölümler')}>
        {LINKS.map((l) => (
          <a
            key={l.id}
            href={`#${l.hash}`}
            aria-current={active === l.id ? 'page' : undefined}
            onClick={(e) => {
              e.preventDefault();
              onNavigate(l.hash);
            }}
          >
            {__(l.label)}
          </a>
        ))}
      </nav>
      <div className="topbar__right">
        {right}
        <LangSwitch />
      </div>
    </header>
  );
}

/** Dil seçimi: Türkçe / English */
export function LangSwitch() {
  const lang = useLang();
  const opts: { v: Lang; t: string; full: string }[] = [
    { v: 'tr', t: 'TR', full: 'Türkçe' },
    { v: 'en', t: 'EN', full: 'English' },
  ];
  return (
    <div className="langsw" role="radiogroup" aria-label="Dil / Language">
      {opts.map((o) => (
        <button key={o.v} role="radio" aria-checked={lang === o.v} title={o.full} lang={o.v} className={lang === o.v ? 'langsw__b langsw__b--on' : 'langsw__b'} onClick={() => setLang(o.v)}>
          {o.t}
        </button>
      ))}
    </div>
  );
}
