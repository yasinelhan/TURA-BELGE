// Tura Belge — kitaplıkta her belge için deri defter kabı (renk belgeye göre kendiliğinden seçilir)
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { CSSProperties } from 'react';

/** Deri tonları: yumuşak, birbirinden ayırt edilebilir */
/** Sırayla verilir: art arda eklenen belgeler birbirine benzemez */
const LEATHER = ['#5f9a98', '#9a5a57', '#7c8b9b', '#3d3e41', '#a37a52', '#4c5f86', '#7a4f6e', '#6f7d55', '#7d3b45', '#5b6770', '#b08d3c', '#3f6b5a'];
export const COVER_COUNT = LEATHER.length;

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}
const shade = (hex: string, f: number) => {
  const n = parseInt(hex.slice(1), 16);
  const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => Math.round(f < 1 ? v * f : v + (255 - v) * (f - 1)));
  return `rgb(${c.join(' ')})`;
};

export const notebookColor = (id: string, cover?: number) => LEATHER[(cover ?? hash(id)) % LEATHER.length];

/** Yeni belgeye sıradaki kap rengi (bu cihazda sayaç) */
export function nextCover(): number {
  try {
    const n = Number(localStorage.getItem('tura-belge:kapak') ?? Math.floor(Math.random() * LEATHER.length)) || 0;
    localStorage.setItem('tura-belge:kapak', String((n + 1) % LEATHER.length));
    return n % LEATHER.length;
  } catch {
    return Math.floor(Math.random() * LEATHER.length);
  }
}

export function Notebook({ id, cover, mini = false, label }: { id: string; cover?: number; mini?: boolean; label?: string }) {
  const c = notebookColor(id, cover);
  const style = { '--nb': c, '--nb-dark': shade(c, 0.55), '--nb-darker': shade(c, 0.38), '--nb-light': shade(c, 1.12) } as CSSProperties;
  return (
    <div className={mini ? 'nb nb--mini' : 'nb'} style={style} aria-hidden="true">
      <span className="nb__strap" />
      {label && <span className="nb__label">{label}</span>}
    </div>
  );
}
