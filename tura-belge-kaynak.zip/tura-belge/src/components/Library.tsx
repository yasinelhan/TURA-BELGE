// Tura Belge — Kitaplığım: klasörler ve kapaklı belge ızgarası
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState, type DragEvent } from 'react';
import type { DocMeta, Folder } from '../lib/storage';
import { Notebook } from './Notebook';
import { SparkIcon } from '../ai/SparkIcon';
import { __, locale } from '../i18n';

interface LibraryProps {
  /** Boş bir Markdown notu açar (açık klasör varsa oraya) */
  onNewNote: (folderId?: string) => void;
  docs: DocMeta[];
  folders: Folder[];
  storageOk: boolean | null;
  busy?: boolean;
  /** "+" kartı: PDF seç (açık klasör varsa oraya eklenir) */
  onAdd: (folderId?: string) => void;
  onDropFiles: (e: DragEvent, folderId?: string) => void;
  onOpen: (meta: DocMeta) => void;
  onDelete: (meta: DocMeta) => void;
  onMove: (docId: string, folderId: string | undefined) => void;
  onCreateFolder: (name: string) => Promise<Folder>;
  onRenameFolder: (folder: Folder, name: string) => void;
  onDeleteFolder: (folder: Folder) => void;
  onAssistant: (folderId?: string) => void;
}

const fmtDate = (t: number) => new Intl.DateTimeFormat(locale(), { day: 'numeric', month: 'short' }).format(t);
const TINTS = ['#0B7A8F', '#142C93', '#C9892F', '#7A3E8F', '#2E7D5B', '#B4475A'];
const tint = (i: number) => TINTS[i % TINTS.length];

export function Cover({ meta, className = 'cover' }: { meta: DocMeta; className?: string }) {
  return <Notebook id={meta.id} cover={meta.cover} mini={className.includes('mini')} label={meta.kind === 'md' ? __('NOT') : undefined} />;
}

function useOutside(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: PointerEvent) => !ref.current?.contains(e.target as Node) && close();
    const k = (e: KeyboardEvent) => e.key === 'Escape' && close();
    document.addEventListener('pointerdown', h);
    document.addEventListener('keydown', k);
    return () => {
      document.removeEventListener('pointerdown', h);
      document.removeEventListener('keydown', k);
    };
  }, [open, close]);
  return ref;
}

function DocCard({
  meta,
  folders,
  onOpen,
  onDelete,
  onMove,
  onNewFolderFor,
}: {
  meta: DocMeta;
  folders: Folder[];
  onOpen: () => void;
  onDelete: () => void;
  onMove: (folderId: string | undefined) => void;
  onNewFolderFor: () => void;
}) {
  const [menu, setMenu] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const ref = useOutside(menu, () => (setMenu(false), setConfirm(false)));
  return (
    <li
      className="libcard"
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('application/x-tura-doc', meta.id);
        e.dataTransfer.effectAllowed = 'move';
      }}
    >
      <button className="libcard__open" onClick={onOpen} aria-label={__('{0} belgesini aç', [meta.name])}>
        <Cover meta={meta} />
      </button>
      <div className="libcard__foot">
        <div className="libcard__text">
          <span className="libcard__name" title={meta.name}>
            {meta.name}
          </span>
          <span className="libcard__meta">
            {meta.kind === 'md' ? __('Not · ') : ''}
            {meta.linkedFile && (
              <span className="doc__link" title={__('Değişiklikler “{0}” dosyasına kaydedilir', [meta.linkedFile])}>
                <svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true">
                  <path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                {__('dosya ·')}{' '}
              </span>
            )}
            {fmtDate(meta.updatedAt)}
          </span>
        </div>
        <div className="menuwrap" ref={ref}>
          <button className="icon-btn icon-btn--mini" aria-label={__('{0}: seçenekler', [meta.name])} aria-haspopup="menu" aria-expanded={menu} onClick={() => setMenu((v) => !v)}>
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M6 12h.01M12 12h.01M18 12h.01" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            </svg>
          </button>
          {menu && (
            <div className="popmenu" role="menu">
              <p className="popmenu__label">{__('Klasöre taşı')}</p>
              {folders.map((f) => (
                <button key={f.id} role="menuitemradio" aria-checked={meta.folderId === f.id} onClick={() => (onMove(f.id), setMenu(false))}>
                  <span className="popmenu__dot" aria-hidden="true">{meta.folderId === f.id ? '●' : ''}</span>
                  {f.name}
                </button>
              ))}
              {meta.folderId && (
                <button role="menuitem" onClick={() => (onMove(undefined), setMenu(false))}>
                  <span className="popmenu__dot" aria-hidden="true" />
                  {__('Klasörden çıkar')}
                </button>
              )}
              <button role="menuitem" onClick={() => (setMenu(false), onNewFolderFor())}>
                <span className="popmenu__dot" aria-hidden="true">+</span>
                {__('Yeni klasör…')}
              </button>
              <hr />
              {confirm ? (
                <button role="menuitem" className="popmenu__danger" onClick={() => (onDelete(), setMenu(false))}>
                  <span className="popmenu__dot" aria-hidden="true" />
                  {meta.linkedFile ? __('Evet, listeden kaldır') : __('Evet, sil')}
                </button>
              ) : (
                <button role="menuitem" className="popmenu__danger" onClick={() => setConfirm(true)}>
                  <span className="popmenu__dot" aria-hidden="true" />
                  {meta.linkedFile ? __('Listeden kaldır (dosya silinmez)') : __('Sil')}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

/** Kitaplığın ilk kartı: A4 sayfa biçiminde "+"; tıkla ya da PDF'i üstüne bırak */
function AddCard({ busy, onAdd, onDrop }: { busy?: boolean; onAdd: () => void; onDrop: (e: DragEvent) => void }) {
  const [over, setOver] = useState(false);
  return (
    <li
      className={over ? 'libcard libcard--add libcard--over' : 'libcard libcard--add'}
      onDragOver={(e) => {
        if (!Array.from(e.dataTransfer.types).includes('Files')) return;
        e.preventDefault();
        e.stopPropagation();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.stopPropagation();
        setOver(false);
        onDrop(e);
      }}
    >
      <button className="libcard__open addpage" onClick={onAdd} disabled={busy} aria-label={__('Belge ekle: PDF ya da Markdown seç ya da buraya sürükleyip bırak')}>
        <span className="addpage__plus" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="34" height="34">
            <path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
          </svg>
        </span>
        <span className="addpage__title">{busy ? __('Açılıyor…') : __('Belge ekle')}</span>
        <span className="addpage__hint">
          <span className="on-mouse">{__('PDF ya da Markdown · tıkla ya da sürükleyip bırak')}</span>
          <span className="on-touch">{__('PDF ya da Markdown seç')}</span>
        </span>
      </button>
      <div className="libcard__foot" aria-hidden="true">
        <div className="libcard__text">
          <span className="libcard__name">&nbsp;</span>
          <span className="libcard__meta">&nbsp;</span>
        </div>
      </div>
    </li>
  );
}

/** Asistan kartı: klasördeki (ya da tüm) notlara dayanarak soru sorulan sayfayı açar */
function AssistantCard({ folder, count, onOpen }: { folder: Folder | null; count: number; onOpen: () => void }) {
  return (
    <li className="libcard libcard--ai">
      <button className="libcard__open aicard" onClick={onOpen} aria-label={folder ? __('{0} klasöründeki notlara sor', [folder.name]) : __('Tüm notlarına sor')}>
        <span className="aicard__icon" aria-hidden="true">
          <SparkIcon size={30} />
        </span>
        <span className="addpage__title">{__('Asistana sor')}</span>
        <span className="addpage__hint">
          {folder ? __('“{0}” klasöründeki {1} belgeye dayanarak', [folder.name, count]) : __('Kitaplığındaki {0} belgeye dayanarak', [count])}
        </span>
      </button>
      <div className="libcard__foot" aria-hidden="true">
        <div className="libcard__text">
          <span className="libcard__name">&nbsp;</span>
          <span className="libcard__meta">&nbsp;</span>
        </div>
      </div>
    </li>
  );
}

function FolderCard({
  folder,
  docs,
  index,
  onOpen,
  onDropDoc,
}: {
  folder: Folder;
  docs: DocMeta[];
  index: number;
  onOpen: () => void;
  onDropDoc: (docId: string) => void;
}) {
  const [over, setOver] = useState(false);
  return (
    <li
      className={over ? 'libcard libcard--folder libcard--over' : 'libcard libcard--folder'}
      onDragOver={(e) => {
        if (!e.dataTransfer.types.includes('application/x-tura-doc')) return;
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        const id = e.dataTransfer.getData('application/x-tura-doc');
        if (id) onDropDoc(id);
      }}
    >
      <button className="libcard__open" onClick={onOpen} aria-label={__('{0} klasörünü aç', [folder.name])}>
        <div className="collage" style={{ background: tint(index) }}>
          {docs.slice(0, 4).map((d) => (
            <Cover key={d.id} meta={d} className="cover cover--mini" />
          ))}
          {docs.length === 0 && <span className="collage__empty">{__('Boş klasör')}</span>}
        </div>
      </button>
      <div className="libcard__foot">
        <div className="libcard__text">
          <span className="libcard__name">{folder.name}</span>
          <span className="libcard__meta">{docs.length} {__('belge')}</span>
        </div>
      </div>
    </li>
  );
}

export function Library(props: LibraryProps) {
  const { docs, folders } = props;
  // Asistan sayfasından ya da bir belgeden dönünce aynı klasör açık kalsın (bu oturum boyunca)
  const [active, setActiveRaw] = useState<string>(() => {
    try {
      return sessionStorage.getItem('tura-belge:klasor') ?? 'all';
    } catch {
      return 'all';
    }
  });
  const setActive = (id: string) => {
    setActiveRaw(id);
    try {
      sessionStorage.setItem('tura-belge:klasor', id);
    } catch {
      /* depolama kapalı olabilir */
    }
  };
  const [naming, setNaming] = useState<{ forDoc?: string; rename?: Folder } | null>(null);
  const [nameText, setNameText] = useState('');
  const [confirmFolderDelete, setConfirmFolderDelete] = useState(false);
  const activeFolder = folders.find((f) => f.id === active) ?? null;

  useEffect(() => {
    if (active !== 'all' && !activeFolder && folders.length) setActive('all');
  }, [active, activeFolder, folders.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const inFolder = (id: string) => docs.filter((d) => d.folderId === id);
  const loose = docs.filter((d) => !d.folderId || !folders.some((f) => f.id === d.folderId));
  const shown = activeFolder ? inFolder(activeFolder.id) : loose;

  const submitName = async () => {
    const name = nameText.trim();
    if (!name || !naming) return;
    if (naming.rename) props.onRenameFolder(naming.rename, name);
    else {
      const f = await props.onCreateFolder(name);
      if (naming.forDoc) props.onMove(naming.forDoc, f.id);
    }
    setNaming(null);
    setNameText('');
  };

  const addCard = (
    <AddCard busy={props.busy} onAdd={() => props.onAdd(activeFolder?.id)} onDrop={(e) => props.onDropFiles(e, activeFolder?.id)} />
  );

  if (props.storageOk === false) {
    return (
      <section className="band band--library" aria-labelledby="lib-title">
        <h1 id="lib-title" className="lib__title">
          {__('Kitaplığım')}
        </h1>
        <ul className="lib__grid">{addCard}</ul>
        <p className="muted">
          {__('Bu görünümde tarayıcı depolaması kapalı; belgeler kitaplıkta saklanamıyor. Açtığın PDF’i düzenledikten sonra “İndir” ile cihazına kaydedebilirsin.')}
        </p>
      </section>
    );
  }

  return (
    <section className="band band--library" aria-labelledby="lib-title">
      <div className="lib__head">
        <h1 id="lib-title" className="lib__title">
          {__('Kitaplığım')}
        </h1>
        <div className="lib__chips" role="tablist" aria-label={__('Klasörler')}>
          <button role="tab" aria-selected={active === 'all'} className={active === 'all' ? 'libchip libchip--on' : 'libchip'} onClick={() => setActive('all')}>
            {__('Tümü')} <small>{docs.length}</small>
          </button>
          {folders.map((f, i) => (
            <button
              key={f.id}
              role="tab"
              aria-selected={active === f.id}
              className={active === f.id ? 'libchip libchip--on' : 'libchip'}
              onClick={() => setActive(f.id)}
              onDragOver={(e) => e.dataTransfer.types.includes('application/x-tura-doc') && e.preventDefault()}
              onDrop={(e) => {
                const id = e.dataTransfer.getData('application/x-tura-doc');
                if (id) props.onMove(id, f.id);
              }}
            >
              <i style={{ background: tint(i) }} aria-hidden="true" />
              {f.name} <small>{inFolder(f.id).length}</small>
            </button>
          ))}
          <button className="libchip libchip--add" onClick={() => (setNaming({}), setNameText(''))}>
            {__('+ Yeni klasör')}
          </button>
          <button className="libchip libchip--add" onClick={() => props.onNewNote(activeFolder?.id)}>
            {__('+ Yeni not')}
          </button>
        </div>
      </div>

      {naming && (
        <form
          className="lib__name"
          onSubmit={(e) => {
            e.preventDefault();
            void submitName();
          }}
        >
          <label className="field">
            <span className="field__label">{naming.rename ? __('Klasörün yeni adı') : __('Yeni klasörün adı')}</span>
            <input
              className="input"
              autoFocus
              value={nameText}
              maxLength={40}
              placeholder={__('ör. Ders notları, Hikâye kitapları')}
              onChange={(e) => setNameText(e.target.value)}
            />
          </label>
          <button className="btn btn--primary" type="submit" disabled={!nameText.trim()}>
            {naming.rename ? __('Kaydet') : __('Oluştur')}
          </button>
          <button className="btn btn--ghost" type="button" onClick={() => setNaming(null)}>
            {__('Vazgeç')}
          </button>
        </form>
      )}

      {activeFolder && (
        <div className="lib__folderbar">
          <button className="btn btn--ghost btn--sm" onClick={() => setActive('all')}>
            {__('← Tümü')}
          </button>
          <b>{activeFolder.name}</b>
          <span className="lib__spacer" />
          <button className="btn btn--ghost btn--sm" onClick={() => (setNaming({ rename: activeFolder }), setNameText(activeFolder.name))}>
            {__('Yeniden adlandır')}
          </button>
          {confirmFolderDelete ? (
            <button className="btn btn--danger btn--sm" onClick={() => (props.onDeleteFolder(activeFolder), setConfirmFolderDelete(false))}>
              {__('Klasörü sil (belgeler kalır)')}
            </button>
          ) : (
            <button className="btn btn--ghost btn--sm" onClick={() => setConfirmFolderDelete(true)}>
              {__('Klasörü sil')}
            </button>
          )}
        </div>
      )}

      <ul className="lib__grid">
        {addCard}
        {(activeFolder ? shown.length > 0 : docs.length > 0) && (
          <AssistantCard folder={activeFolder} count={activeFolder ? shown.length : docs.length} onOpen={() => props.onAssistant(activeFolder?.id)} />
        )}
        {!activeFolder &&
          folders.map((f, i) => (
            <FolderCard key={f.id} folder={f} index={i} docs={inFolder(f.id)} onOpen={() => setActive(f.id)} onDropDoc={(id) => props.onMove(id, f.id)} />
          ))}
        {shown.map((d) => (
          <DocCard
            key={d.id}
            meta={d}
            folders={folders}
            onOpen={() => props.onOpen(d)}
            onDelete={() => props.onDelete(d)}
            onMove={(fid) => props.onMove(d.id, fid)}
            onNewFolderFor={() => (setNaming({ forDoc: d.id }), setNameText(''))}
          />
        ))}
      </ul>
      {docs.length === 0 && (
        <p className="muted">
          {__('Henüz belge yok. “+” ile bir PDF ekle ya da sürükleyip bırak; açtığın PDF’ler burada kapaklarıyla görünür ve klasörlere ayırabilirsin. Dosyaların cihazından çıkmaz.')}
        </p>
      )}
      {activeFolder && shown.length === 0 && (
        <p className="muted">{__('Bu klasör boş. “+” ile PDF ekleyebilir ya da bir belgenin ⋯ menüsünden “Klasöre taşı” ile buraya alabilirsin.')}</p>
      )}
    </section>
  );
}
