// Tura Belge — belge içinden "Sayfa ekle" ve "Sayfa sil" pencereleri
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useMemo, useState, type ReactElement } from 'react';
import { isDark, type BlankPageOptions, type PagePattern, type PageSize } from '../lib/pageEdit';
import { parseRanges } from '../tools/lib/pageRanges';
import { Field, Seg } from '../tools/ui';
import { __, N_ } from '../i18n';

const PAGE_COLORS: { c: string; t: string }[] = [
  { c: '#FFFFFF', t: N_('Beyaz') },
  { c: '#FFF8E7', t: N_('Krem') },
  { c: '#FFF4BF', t: N_('Açık sarı') },
  { c: '#E6F4EA', t: N_('Açık yeşil') },
  { c: '#E3F0FB', t: N_('Açık mavi') },
  { c: '#FCE8EF', t: N_('Açık pembe') },
  { c: '#EFEAF8', t: N_('Lila') },
  { c: '#EEEEEE', t: N_('Gri') },
  { c: '#1F3B2D', t: N_('Yeşil tahta') },
  { c: '#1E1E24', t: N_('Kara tahta') },
];

const PATTERNS: { v: PagePattern; t: string }[] = [
  { v: 'duz', t: N_('Düz') },
  { v: 'cizgili', t: N_('Çizgili') },
  { v: 'kareli', t: N_('Kareli') },
  { v: 'noktali', t: N_('Noktalı') },
];

/** Desen önizlemesi (küçük bir sayfa) */
function PatternPreview({ pattern, color }: { pattern: PagePattern; color: string }) {
  const dark = isDark(color);
  const ink = dark ? 'rgb(255 255 255 / .35)' : 'rgb(92 128 184 / .55)';
  const lines: ReactElement[] = [];
  if (pattern === 'cizgili') {
    for (let y = 14; y < 70; y += 7) lines.push(<line key={y} x1="5" x2="47" y1={y} y2={y} stroke={ink} strokeWidth=".7" />);
    lines.push(<line key="m" x1="12" x2="12" y1="0" y2="74" stroke="rgb(220 90 90 / .55)" strokeWidth=".7" />);
  } else if (pattern === 'kareli') {
    for (let x = 3; x < 52; x += 5) lines.push(<line key={`x${x}`} x1={x} x2={x} y1="0" y2="74" stroke={ink} strokeWidth=".4" />);
    for (let y = 2; y < 74; y += 5) lines.push(<line key={`y${y}`} x1="0" x2="52" y1={y} y2={y} stroke={ink} strokeWidth=".4" />);
  } else if (pattern === 'noktali') {
    for (let x = 3; x < 52; x += 5) for (let y = 2; y < 74; y += 5) lines.push(<circle key={`${x}-${y}`} cx={x} cy={y} r=".6" fill={ink} />);
  }
  return (
    <svg viewBox="0 0 52 74" className="pgdlg__thumb" aria-hidden="true">
      <rect width="52" height="74" fill={color} />
      {lines}
    </svg>
  );
}

export function AddPageDialog({
  current,
  total,
  onCancel,
  onSubmit,
}: {
  current: number;
  total: number;
  onCancel: () => void;
  onSubmit: (o: BlankPageOptions) => void;
}) {
  const [where, setWhere] = useState<'sonra' | 'once' | 'son'>('sonra');
  const [size, setSize] = useState<PageSize>('ayni');
  const [pattern, setPattern] = useState<PagePattern>('duz');
  const [color, setColor] = useState('#FFFFFF');
  const [count, setCount] = useState(1);
  const at = where === 'sonra' ? current : where === 'once' ? current - 1 : total;

  return (
    <div className="dialog-veil" role="presentation" onClick={onCancel}>
      <div className="dialog pgdlg" role="dialog" aria-modal="true" aria-labelledby="pgadd-title" onClick={(e) => e.stopPropagation()}>
        <h2 id="pgadd-title">{__('Sayfa ekle')}</h2>
        <div className="pgdlg__body">
          <Field label={__('Nereye')} group>
            <Seg
              label={__('Nereye')}
              value={where}
              onChange={setWhere}
              options={[
                { v: 'sonra', t: __('{0}. sayfadan sonra', [current]) },
                { v: 'once', t: __('{0}. sayfadan önce', [current]) },
                { v: 'son', t: 'En sona' },
              ]}
            />
          </Field>
          <Field label={__('Kâğıt')} group>
            <Seg
              label={__('Kâğıt')}
              value={size}
              onChange={setSize}
              options={[
                { v: 'ayni', t: 'Bu sayfa gibi' },
                { v: 'a4', t: 'A4' },
                { v: 'a4-yatay', t: 'A4 yatay' },
                { v: 'a5', t: 'A5' },
              ]}
            />
          </Field>
          <Field label={__('Desen')} group>
            <div className="pgdlg__patterns" role="radiogroup" aria-label={__('Desen')}>
              {PATTERNS.map((p) => (
                <button
                  key={p.v}
                  role="radio"
                  aria-checked={pattern === p.v}
                  className={pattern === p.v ? 'pgdlg__pattern pgdlg__pattern--on' : 'pgdlg__pattern'}
                  onClick={() => setPattern(p.v)}
                >
                  <PatternPreview pattern={p.v} color={color} />
                  <span>{__(p.t)}</span>
                </button>
              ))}
            </div>
          </Field>
          <Field label={__('Sayfa rengi')} group>
            <div className="swatches" role="radiogroup" aria-label={__('Sayfa rengi')}>
              {PAGE_COLORS.map((p) => (
                <button
                  key={p.c}
                  role="radio"
                  aria-checked={color.toUpperCase() === p.c}
                  aria-label={__(p.t)}
                  title={__(p.t)}
                  className="swatch"
                  style={{ background: p.c }}
                  onClick={() => setColor(p.c)}
                />
              ))}
              <label className="swatch swatch--custom" title={__('Başka renk')}>
                <span className="sr-only">{__('Başka renk')}</span>
                <input type="color" value={color} onChange={(e) => setColor(e.target.value.toUpperCase())} />
              </label>
            </div>
          </Field>
          <Field label={__('Kaç sayfa')}>
            <input
              className="input pgdlg__count"
              type="number"
              min={1}
              max={50}
              value={count}
              onChange={(e) => setCount(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
            />
          </Field>
        </div>
        <div className="dialog__actions">
          <button className="btn btn--ghost" onClick={onCancel}>
            {__('Vazgeç')}
          </button>
          <button className="btn btn--primary" onClick={() => onSubmit({ at, count, size, like: current - 1, color, pattern })}>
            {count > 1 ? __('{0} sayfa ekle', [count]) : __('Sayfayı ekle')}
          </button>
        </div>
      </div>
    </div>
  );
}

export function DeletePageDialog({
  current,
  total,
  onCancel,
  onSubmit,
}: {
  current: number;
  total: number;
  onCancel: () => void;
  onSubmit: (indices: number[]) => void;
}) {
  const [mode, setMode] = useState<'bu' | 'secili'>('bu');
  const [text, setText] = useState(String(current));
  const plan = useMemo(() => {
    if (mode === 'bu') return { pages: [current - 1] };
    const r = parseRanges(text, total);
    if (r.error) return { pages: [], error: r.error };
    const pages = [...new Set(r.groups.flat())];
    if (pages.length >= total) return { pages, error: __('Belgede en az bir sayfa kalmalı.') };
    return { pages };
  }, [mode, text, current, total]);
  const only = total <= 1;

  return (
    <div className="dialog-veil" role="presentation" onClick={onCancel}>
      <div className="dialog pgdlg" role="dialog" aria-modal="true" aria-labelledby="pgdel-title" onClick={(e) => e.stopPropagation()}>
        <h2 id="pgdel-title">{__('Sayfa sil')}</h2>
        {only ? (
          <p>{__('Belgede tek sayfa var; en az bir sayfa kalmalı.')}</p>
        ) : (
          <div className="pgdlg__body">
            <Seg
              label={__('Silinecek sayfalar')}
              value={mode}
              onChange={setMode}
              options={[
                { v: 'bu', t: `Bu sayfa (${current})` },
                { v: 'secili', t: 'Sayfa aralığı' },
              ]}
            />
            {mode === 'secili' && (
              <Field label={__('Sayfalar (belge {0} sayfa)', [total])} hint={__('ör. 2, 5-7 ya da 9-son')}>
                <input className="input" autoFocus value={text} onChange={(e) => setText(e.target.value)} />
              </Field>
            )}
            {plan.error ? (
              <p className="alert" role="alert">
                {plan.error}
              </p>
            ) : (
              <p className="muted">
                {plan.pages.length === 1 ? __('{0}. sayfa silinecek.', [plan.pages[0] + 1]) : __('{0} sayfa silinecek.', [plan.pages.length])} {__('Notlar ve çizimler de o sayfalarla birlikte gider.')}
              </p>
            )}
          </div>
        )}
        <div className="dialog__actions">
          <button className="btn btn--ghost" onClick={onCancel}>
            {__('Vazgeç')}
          </button>
          {!only && (
            <button className="btn btn--danger" disabled={!!plan.error || !plan.pages.length} onClick={() => onSubmit(plan.pages)}>
              {__('Sil')}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
