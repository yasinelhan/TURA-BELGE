// Tura Belge — ana ekran: Kitaplığım (en üstte) ve "+" ile PDF ekleme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useRef, useState, type DragEvent } from 'react';
import type { DocMeta, Folder } from '../lib/storage';
import { Library } from './Library';
import { NahleCredit } from './Brand';
import { TopNav } from './TopNav';
import { APP_VERSION, SOURCE_URL } from '../config';
import { __ } from '../i18n';

interface HomeProps {
  docs: DocMeta[];
  storageOk: boolean | null;
  busy: boolean;
  error: string | null;
  onOpenFile: (file: File, folderId?: string) => void;
  onNewNote: (folderId?: string) => void;
  /** Birden çok PDF: hepsi kitaplığa eklenir */
  onAddFiles: (files: File[], folderId?: string) => void;
  /** Tarayıcı destekliyorsa: dosyayı bağlı aç (değişiklikler aynı dosyaya yazılır) */
  onPickFile?: (folderId?: string) => void;
  onDropHandle?: (handle: FileSystemFileHandle, folderId?: string) => void;
  onOpenStored: (meta: DocMeta) => void;
  onDelete: (meta: DocMeta) => void;
  onNavigate: (hash: string) => void;
  folders: Folder[];
  onMove: (docId: string, folderId: string | undefined) => void;
  onCreateFolder: (name: string) => Promise<Folder>;
  onRenameFolder: (folder: Folder, name: string) => void;
  onDeleteFolder: (folder: Folder) => void;
  /** Klasörün (ya da tüm kitaplığın) asistan sayfası */
  onAssistant: (folderId?: string) => void;
}

const isDoc = (f: File) => /pdf$/i.test(f.type) || /\.(pdf|md|markdown)$/i.test(f.name) || /^text\/(x-)?markdown/.test(f.type);
const hasFiles = (e: DragEvent) => Array.from(e.dataTransfer.types).includes('Files');
type HandleItem = { getAsFileSystemHandle?: () => Promise<FileSystemHandle | null> };

export function Home(props: HomeProps) {
  const { docs, storageOk, busy, error } = props;
  const input = useRef<HTMLInputElement>(null);
  const folderRef = useRef<string | undefined>(undefined);
  const [dragging, setDragging] = useState(false);

  const pick = (folderId?: string) => {
    folderRef.current = folderId;
    if (props.onPickFile) props.onPickFile(folderId);
    else input.current?.click();
  };

  /** Bırakılan PDF'ler: tek dosya açılır, birden çoksa hepsi kitaplığa eklenir */
  const drop = (e: DragEvent, folderId?: string) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(isDoc);
    if (!files.length) return;
    if (files.length > 1) {
      props.onAddFiles(files, folderId);
      return;
    }
    const file = files[0];
    // Chrome/Edge: bırakılan dosyanın tutamacı alınır, böylece değişiklikler aynı dosyaya yazılır.
    // Tutamaç olay sırasında, beklemeden istenmeli.
    const items = Array.from(e.dataTransfer.items).filter((i) => i.kind === 'file') as unknown as HandleItem[];
    if (props.onDropHandle && typeof items[0]?.getAsFileSystemHandle === 'function') {
      Promise.all(items.map((i) => i.getAsFileSystemHandle!()))
        .then((hs) => {
          const h = hs.find((x) => x?.kind === 'file' && /\.(pdf|md|markdown)$/i.test(x.name)) as FileSystemFileHandle | undefined;
          if (h) props.onDropHandle!(h, folderId);
          else props.onOpenFile(file, folderId);
        })
        .catch(() => props.onOpenFile(file, folderId));
      return;
    }
    props.onOpenFile(file, folderId);
  };

  return (
    <div
      className="home"
      onDragOver={(e) => {
        if (!hasFiles(e)) return;
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={(e) => {
        if (e.currentTarget === e.target || !e.relatedTarget) setDragging(false);
      }}
      onDrop={(e) => drop(e)}
    >
      <TopNav active="belgeler" onNavigate={props.onNavigate} />

      <main className="home__lib">
        {error && (
          <p className="alert" role="alert">
            {error}
          </p>
        )}
        <Library
          docs={docs}
          folders={props.folders}
          storageOk={storageOk}
          busy={busy}
          onAdd={pick}
          onDropFiles={drop}
          onNewNote={props.onNewNote}
          onOpen={props.onOpenStored}
          onDelete={props.onDelete}
          onMove={props.onMove}
          onCreateFolder={props.onCreateFolder}
          onRenameFolder={props.onRenameFolder}
          onDeleteFolder={props.onDeleteFolder}
          onAssistant={props.onAssistant}
        />
        <input
          ref={input}
          type="file"
          accept="application/pdf,.pdf,.md,.markdown,text/markdown"
          multiple
          hidden
          onChange={(e) => {
            const files = Array.from(e.target.files ?? []);
            e.target.value = '';
            if (files.length > 1) props.onAddFiles(files, folderRef.current);
            else if (files[0]) props.onOpenFile(files[0], folderRef.current);
          }}
        />
      </main>

      <footer className="footer">
        <NahleCredit />
        <span className="footer__sep" aria-hidden="true">
          ·
        </span>
        <span>{__('Tura ailesinin ilk uygulaması')}</span>
        <span className="footer__sep" aria-hidden="true">
          ·
        </span>
        {SOURCE_URL ? (
          <a className="footer__link" href={SOURCE_URL} target="_blank" rel="noreferrer">
            {__('Açık kaynak (AGPL-3.0) · kaynak kodu')}
          </a>
        ) : (
          <span>{__('Açık kaynak, AGPL-3.0')}</span>
        )}
        <span className="footer__sep" aria-hidden="true">
          ·
        </span>
        <span>{__('Sürüm')} {APP_VERSION}</span>
      </footer>
      {dragging && <div className="dropveil" aria-hidden="true" />}
    </div>
  );
}
