// Tura Belge — PDF düzenleyici: görüntüleme, not alma, imza, otomatik kayıt, asıl dosyaya geri yazma
// SPDX-License-Identifier: AGPL-3.0-or-later
import { isNative, nativeShare } from '../lib/native';
import { PenLayer } from '../pen/PenLayer';
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  PDFViewer,
  type AnnotationEvent,
  type AnnotationPlugin,
  type ExportCapability,
  type ExportPlugin,
  type HistoryPlugin,
  type CommandsPlugin,
  type PluginRegistry,
  type ScrollPlugin,
  type UIPlugin,
  type SignaturePlugin,
  deserializeEntries,
  serializeEntries,
} from '@embedpdf/react-pdf-viewer';
import { buildViewerConfig, type ViewerDoc } from '../lib/viewerConfig';
import { downloadPdf, isEmbedded, pdfFileName } from '../lib/download';
// (biçim dönüştürme: ../convert/exporters)
import { ensurePermission, handleModified, writeHandle } from '../lib/fileLink';
import { fixTurkishFreeText } from '../lib/turkishText';
import { addSelectionActions } from '../lib/viewerExtras';
import { setupDocumentUi, styleViewer, type DocActions } from '../lib/viewerTools';
import { deletePages, insertBlankPages, type BlankPageOptions } from '../lib/pageEdit';
import { ToolError } from '../tools/lib/pdfOps';
import { AddPageDialog, DeletePageDialog } from './PageDialogs';
import { DocTabs } from './DocTabs';
import { SaveMenu } from './SaveMenu';
import { NoTextError, exportPdfAs, formatInfo, pdfToMd, type ExportFormat } from '../convert/exporters';
import { downloadFile, safeFileName } from '../lib/download';
import { getMeta, listFolders } from '../lib/storage';
import type { SelectionHandlers } from '../lib/viewerExtras';
import { SparkIcon } from '../ai/SparkIcon';
import type { AskRequest, CurrentDoc, JumpTarget } from '../ai/AssistantPanel';

// Asistan paneli (formül çizimi dahil) yalnızca açılınca yüklenir
const AssistantPanel = lazy(() => import('../ai/AssistantPanel').then((m) => ({ default: m.AssistantPanel })));

const MODES = [
  { id: 'mode:view', label: N_('Görüntüle') },
  { id: 'mode:annotate', label: N_('Not al') },
  { id: 'mode:shapes', label: 'Sayfalar' },
  { id: 'mode:insert', label: N_('PDF araçları') },
];

import { BrandMark } from './Brand';
import { __, N_ } from '../i18n';

type SaveState = 'clean' | 'dirty' | 'saving' | 'saved' | 'error' | 'off';
/** Asıl dosyayla bağlantının durumu */
type Link = 'none' | 'ok' | 'need' | 'conflict' | 'external' | 'readonly';

interface EditorProps {
  doc: ViewerDoc;
  storageOk: boolean;
  author: string;
  onPersist: (doc: ViewerDoc, bytes: ArrayBuffer, fileModified?: number) => Promise<void>;
  onRename: (name: string) => void;
  onClose: () => void;
  onOrganize: (doc: ViewerDoc, bytes: ArrayBuffer, tool?: string) => void;
  /** Belgenin yeni hâlini (ör. sayfa eklenmiş) aynı belge olarak yeniden açar */
  onReplace: (doc: ViewerDoc, bytes: ArrayBuffer) => Promise<void>;
  /** PDF'ten çıkarılan Markdown'ı yeni not olarak açar */
  onOpenMarkdown: (name: string, text: string) => Promise<void>;
  /** Asıl dosyanın güncel hâlini yeniden yükler */
  onReloadFromFile: (doc: ViewerDoc) => void;
  /** Asistanın gösterdiği kaynağı (başka bir belgeyi) o sayfada açar */
  onOpenDocAt: (t: JumpTarget) => void;
  /** Asistan sohbetini Markdown notu olarak kitaplığa ekler */
  onSaveNote: (name: string, text: string, folderId?: string) => Promise<void>;
}

const AUTOSAVE_MS = 1500;
const SIGNATURE_KEY = 'tura-belge:imzalar';

export function Editor({ doc, storageOk, author, onPersist, onRename, onClose, onOrganize, onReplace, onOpenMarkdown, onReloadFromFile, onOpenDocAt, onSaveNote }: EditorProps) {
  const handle = doc.handle;
  const canSave = storageOk || !!handle;
  // Görüntüleyici yalnızca belge değişince yeniden kurulur.
  const config = useMemo(() => buildViewerConfig(doc, author), [doc.id, doc.rev]); // eslint-disable-line react-hooks/exhaustive-deps
  const [registry, setRegistry] = useState<PluginRegistry | null>(null);
  const viewerRef = useRef<HTMLDivElement>(null);
  const exportApi = useRef<ExportCapability | null>(null);
  const timer = useRef<number | undefined>(undefined);
  const savingRef = useRef<Promise<void> | null>(null);
  const known = useRef<number | undefined>(doc.fileModified);
  const unsynced = useRef(false); // asıl dosyaya henüz yazılmamış değişiklik var mı
  const [state, setState] = useState<SaveState>(canSave ? 'clean' : 'off');
  const stateRef = useRef(state);
  stateRef.current = state;
  const [link, setLink] = useState<Link>(handle ? 'need' : 'none');
  const linkRef = useRef(link);
  linkRef.current = link;
  const [name, setName] = useState(doc.name);
  const [toast, setToast] = useState<string | null>(null);
  const [confirmLeave, setConfirmLeave] = useState(false);
  const [ready, setReady] = useState(false);
  const [pageDlg, setPageDlg] = useState<{ kind: 'add' | 'delete'; current: number; total: number } | null>(null);
  const [pageBusy, setPageBusy] = useState(false);
  const [convBusy, setConvBusy] = useState<string | null>(null);
  const actionsRef = useRef<DocActions | null>(null);
  const [mode, setMode] = useState('mode:view');
  const [aiOpen, setAiOpen] = useState(false);
  const [aiReq, setAiReq] = useState<AskRequest | null>(null);
  const [folder, setFolder] = useState<{ id: string; name: string } | undefined>(undefined);
  const selRef = useRef<SelectionHandlers | null>(null);

  // Belgenin klasörü: asistan önce o klasördeki notlara dayanır
  useEffect(() => {
    if (!storageOk) return;
    let live = true;
    void (async () => {
      const meta = await getMeta(doc.id).catch(() => undefined);
      if (!meta?.folderId) return;
      const f = (await listFolders().catch(() => [])).find((x) => x.id === meta.folderId);
      if (live && f) setFolder({ id: f.id, name: f.name });
    })();
    return () => {
      live = false;
    };
  }, [doc.id, storageOk]);

  // Üst çubuktaki sekmeler görüntüleyicinin kipini izler
  useEffect(() => {
    const commands = registry?.getPlugin<CommandsPlugin>('commands')?.provides();
    if (!commands) return;
    const read = () => {
      try {
        setMode(MODES.find((m) => commands.resolve(m.id, doc.id).active)?.id ?? 'mode:view');
      } catch {
        /* belge henüz yüklenmedi */
      }
    };
    read();
    return commands.onCommandStateChanged((e) => {
      if (e.commandId.startsWith('mode:') && e.changes.active !== undefined) read();
    });
  }, [registry, doc.id]);
  const pickMode = (id: string) => {
    try {
      registry?.getPlugin<CommandsPlugin>('commands')?.provides().execute(id, doc.id);
    } catch {
      /* belge henüz yüklenmedi */
    }
  };

  const flash = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((t) => (t === msg ? null : t)), 3200);
  };

  // Açılışta yazma izni zaten verilmiş mi?
  useEffect(() => {
    if (!handle) return;
    ensurePermission(handle, 'readwrite', false).then((ok) => setLink(ok ? 'ok' : 'need'));
  }, [handle]);

  const exportBytes = useCallback(async (): Promise<ArrayBuffer> => {
    if (!exportApi.current) throw new Error(__('Görüntüleyici hazır değil'));
    const raw = await exportApi.current.saveAsCopy().toPromise();
    // Metin kutularındaki ı, ğ, ş, İ, Ğ, Ş harfleri başka programlarda da görünsün
    return fixTurkishFreeText(raw, new URL('vendor/fonts/', document.baseURI).href);
  }, []);

  /** Kaydet: tarayıcı kopyası + (izin varsa ve çakışma yoksa) asıl dosya */
  const persistNow = useCallback(
    async (opts: { force?: boolean } = {}) => {
      if (!canSave) return;
      window.clearTimeout(timer.current);
      const run = (async () => {
        setState('saving');
        try {
          const bytes = await exportBytes();
          let fileModified = known.current;
          if (handle && (linkRef.current === 'ok' || (opts.force && linkRef.current === 'conflict'))) {
            const current = await handleModified(handle);
            if (!opts.force && known.current !== undefined && current !== known.current) {
              // Dosya biz açtıktan sonra başka bir yerde (ör. başka cihazda) değişmiş
              setLink('conflict');
            } else {
              fileModified = await writeHandle(handle, bytes);
              known.current = fileModified;
              unsynced.current = false;
              if (linkRef.current !== 'ok') setLink('ok');
            }
          }
          if (storageOk) await onPersist({ ...doc, name }, bytes, fileModified);
          setState((s) => (s === 'saving' ? 'saved' : s));
        } catch (err) {
          console.error('[Tura Belge] kayıt hatası', err);
          const n = (err as Error)?.name;
          if (handle && (n === 'NotAllowedError' || n === 'SecurityError')) setLink('need');
          else if (handle && n === 'NoModificationAllowedError') setLink('readonly');
          setState('error');
        }
      })();
      savingRef.current = run;
      await run;
      savingRef.current = null;
    },
    [doc, name, exportBytes, onPersist, storageOk, canSave, handle],
  );

  const persistRef = useRef(persistNow);
  persistRef.current = persistNow;

  const markDirty = useCallback(() => {
    if (!canSave) return;
    unsynced.current = !!handle;
    setState('dirty');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void persistRef.current(), AUTOSAVE_MS);
  }, [canSave, handle]);

  const onReady = useCallback(
    (registry: PluginRegistry) => {
      exportApi.current = registry.getPlugin<ExportPlugin>('export')?.provides() ?? null;
      setRegistry(registry);
      if (import.meta.env.DEV) (window as unknown as { __tura: unknown }).__tura = registry;
      const annotations = registry.getPlugin<AnnotationPlugin>('annotation')?.provides();
      const history = registry.getPlugin<HistoryPlugin>('history')?.provides();
      annotations?.onAnnotationEvent((e: AnnotationEvent) => {
        if (e.type !== 'loaded' && e.committed) markDirty();
      });
      history?.onHistoryChange(() => markDirty());
      try {
        addSelectionActions(registry, () => selRef.current);
      } catch (err) {
        console.warn('[Tura Belge] seçim menüsü eklenemedi', err);
      }
      try {
        setupDocumentUi(registry, () => actionsRef.current);
        styleViewer(viewerRef.current);
        window.setTimeout(() => styleViewer(viewerRef.current), 300);
      } catch (err) {
        console.warn('[Tura Belge] belge araç çubukları kurulamadı', err);
      }
      // Sayfa ekleyip/silip ya da araçtan dönünce kalınan yere ve sekmeye dön
      if ((doc.startPage && doc.startPage > 1) || doc.startMode) {
        const scroll = registry.getPlugin<ScrollPlugin>('scroll')?.provides();
        const off = scroll?.onLayoutReady((e) => {
          if (e.documentId !== doc.id) return;
          off?.();
          if (doc.startPage && doc.startPage > 1)
            scroll!.forDocument(doc.id).scrollToPage({ pageNumber: Math.min(doc.startPage, e.totalPages), behavior: 'instant' });
          if (doc.startMode) {
            try {
              registry.getPlugin<CommandsPlugin>('commands')?.provides().execute(doc.startMode, doc.id);
            } catch {
              /* sekme yoksa görüntüleme kipinde kalır */
            }
          }
        });
      }

      // İmzalar yalnızca bu tarayıcıda saklanır; her belgede yeniden çizmek gerekmez.
      const signatures = registry.getPlugin<SignaturePlugin>('signature')?.provides();
      if (signatures) {
        try {
          const saved = localStorage.getItem(SIGNATURE_KEY);
          if (saved) signatures.loadEntries(deserializeEntries(JSON.parse(saved)));
        } catch {
          /* depolama kapalı olabilir */
        }
        signatures.onEntriesChange((entries) => {
          try {
            localStorage.setItem(SIGNATURE_KEY, JSON.stringify(serializeEntries(entries)));
          } catch {
            /* depolama kapalı olabilir */
          }
        });
      }
      setReady(true);
      // Sayfa düzenlemeden gelen değişiklik hemen kaydedilsin
      if (doc.dirty) markDirty();
    },
    [markDirty, doc.dirty, doc.startPage, doc.startMode, doc.id],
  );

  useEffect(() => () => window.clearTimeout(timer.current), []);

  // Sekmeye geri dönüldüğünde dosya başka bir yerde güncellenmiş mi?
  useEffect(() => {
    if (!handle) return;
    const check = async () => {
      if (document.visibilityState !== 'visible' || linkRef.current !== 'ok') return;
      try {
        const current = await handleModified(handle);
        if (known.current !== undefined && current !== known.current) {
          const busy = stateRef.current === 'dirty' || stateRef.current === 'saving';
          setLink(busy ? 'conflict' : 'external');
          if (busy) window.clearTimeout(timer.current);
        }
      } catch {
        /* dosya geçici olarak erişilemez olabilir */
      }
    };
    document.addEventListener('visibilitychange', check);
    window.addEventListener('focus', check);
    return () => {
      document.removeEventListener('visibilitychange', check);
      window.removeEventListener('focus', check);
    };
  }, [handle]);

  // Sekme kapanırken kaydedilmemiş değişiklik uyarısı
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => {
      if (stateRef.current === 'dirty' || stateRef.current === 'saving' || unsynced.current) e.preventDefault();
    };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, []);

  const grant = async () => {
    if (!handle) return;
    const ok = await ensurePermission(handle, 'readwrite', true);
    setLink(ok ? 'ok' : 'need');
    linkRef.current = ok ? 'ok' : 'need';
    if (ok) {
      flash(__('Değişiklikler artık asıl dosyaya kaydedilecek'));
      if (unsynced.current || stateRef.current === 'dirty') await persistRef.current();
    }
  };

  const handleDownload = async () => {
    try {
      const bytes = await exportBytes();
      const r = await downloadPdf(name, bytes);
      if (r === 'saved') flash(__('PDF indirildi'));
      else if (r === 'declined') flash(__('İndirme iptal edildi'));
      else flash(__('Bu görünümde indirme kullanılamıyor'));
    } catch (err) {
      console.error(err);
      flash(__('PDF hazırlanamadı'));
    }
  };

  const noText = () =>
    flash(__('Bu PDF’te seçilebilir yazı yok (taranmış olabilir). Önce “PDF araçları → Yazıyı tanı” ile yazıları tanıt.'));

  /** Farklı kaydet: PDF dışındaki biçimler yazıdan (başlık, paragraf, liste) yeniden kurulur */
  const handleSaveAs = async (fmt: ExportFormat) => {
    if (fmt === 'pdf') return handleDownload();
    setConvBusy(__('{0} hazırlanıyor…', [formatInfo(fmt).label]));
    try {
      const r = await exportPdfAs(await exportBytes(), name, fmt, (p, t) => setConvBusy(__('{0} hazırlanıyor… {1}/{2}', [formatInfo(fmt).label, p, t])));
      const res = await downloadFile(safeFileName(name, formatInfo(fmt).ext), r.blob);
      if (res === 'saved')
        flash(r.empty ? __('{0} olarak kaydedildi · {1} taranmış sayfanın yazısı yok', [formatInfo(fmt).label, r.empty]) : __('{0} olarak kaydedildi', [formatInfo(fmt).label]));
      else flash(res === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
    } catch (err) {
      if (err instanceof NoTextError) noText();
      else {
        console.error(err);
        flash(__('Dönüştürülemedi'));
      }
    } finally {
      setConvBusy(null);
    }
  };

  /** PDF'in yazısını düzenlenebilir Markdown notu olarak açar */
  const openAsMarkdown = async () => {
    setConvBusy(__('Markdown’a çevriliyor…'));
    try {
      const r = await pdfToMd(await exportBytes(), (p, t) => setConvBusy(__('Markdown’a çevriliyor… {0}/{1}', [p, t])));
      if (stateRef.current === 'dirty' || stateRef.current === 'saving') await (savingRef.current ?? persistRef.current());
      await onOpenMarkdown(name, r.md);
    } catch (err) {
      if (err instanceof NoTextError) noText();
      else {
        console.error(err);
        flash(__('Markdown’a çevrilemedi'));
      }
      setConvBusy(null);
    }
  };

  // Paylaş (Android, iPhone/iPad, Windows paylaşım penceresi)
  const canShare = useMemo(() => {
    if (isNative()) return true;
    try {
      const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
      return !isEmbedded() && !!nav.canShare?.({ files: [new File([new Uint8Array(1)], 'a.pdf', { type: 'application/pdf' })] });
    } catch {
      return false;
    }
  }, []);
  const handleShare = async () => {
    try {
      const bytes = await exportBytes();
      const file = new File([bytes], pdfFileName(name), { type: 'application/pdf' });
      if (isNative()) await nativeShare(file.name, file);
      else await navigator.share({ files: [file], title: name });
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') flash(__('Paylaşılamadı'));
    }
  };

  const handleOrganize = async (tool = 'sayfalar') => {
    try {
      window.clearTimeout(timer.current);
      if (savingRef.current) await savingRef.current;
      const bytes = await exportBytes();
      if (storageOk) await onPersist({ ...doc, name }, bytes, known.current);
      onOrganize({ ...doc, name, fileModified: known.current, startPage: currentPage().current, startMode: currentMode() }, bytes, tool);
    } catch (err) {
      console.error(err);
      flash(tool === 'sayfalar' ? __('Sayfa düzenleyici açılamadı') : __('Araç açılamadı'));
    }
  };

  /** Açık belge sekmesinin komutu (yeniden açınca aynı sekmeye dönmek için) */
  const currentMode = () => {
    const bar = registry?.getPlugin<UIPlugin>('ui')?.provides()?.forDocument(doc.id).getActiveToolbar('top', 'secondary');
    const modes: Record<string, string> = {
      'annotation-toolbar': 'mode:annotate',
      'tura-pages-toolbar': 'mode:shapes',
      'tura-tools-toolbar': 'mode:insert',
    };
    return bar ? modes[bar] : undefined;
  };

  const currentPage = () => {
    const scroll = registry?.getPlugin<ScrollPlugin>('scroll')?.provides()?.forDocument(doc.id);
    return { current: Math.max(1, scroll?.getCurrentPage() ?? 1), total: scroll?.getTotalPages() ?? 1 };
  };

  /** Sayfa ekle/sil: güncel belgeyi (notlarla) alır, değiştirir ve aynı belge olarak yeniden açar */
  const applyPages = async (op: (bytes: ArrayBuffer) => Promise<ArrayBuffer>, startPage: number) => {
    setPageBusy(true);
    try {
      window.clearTimeout(timer.current);
      if (savingRef.current) await savingRef.current;
      const bytes = await op(await exportBytes());
      setPageDlg(null);
      await onReplace({ ...doc, name, fileModified: known.current, startPage, startMode: currentMode() }, bytes);
    } catch (err) {
      console.error(err);
      flash(err instanceof ToolError ? err.message : __('Sayfalar değiştirilemedi'));
    } finally {
      setPageBusy(false);
    }
  };
  const addPages = (o: BlankPageOptions) => applyPages((b) => insertBlankPages(b, o, name), o.at + 1);
  const removePages = (pages: number[]) =>
    applyPages((b) => deletePages(b, pages, name), Math.min(...pages) + 1);

  actionsRef.current = {
    openTool: (id) => {
      if (id === 'donustur-word') void handleSaveAs('docx');
      else if (id === 'donustur-md') void openAsMarkdown();
      else void handleOrganize(id);
    },
    addPage: () => setPageDlg({ kind: 'add', ...currentPage() }),
    deletePage: () => setPageDlg({ kind: 'delete', ...currentPage() }),
  };

  // Seçim menüsü → asistan paneli
  const seq = useRef(0);
  selRef.current = {
    ask: (p) => {
      setAiOpen(true);
      setAiReq({ seq: ++seq.current, kind: 'ask', quote: { text: p.text, where: __('{0} · s. {1}', [name, p.page]), docId: doc.id, page: p.page } });
    },
    translate: (p) => {
      setAiOpen(true);
      setAiReq({ seq: ++seq.current, kind: 'translate', quote: { text: p.text, where: __('{0} · s. {1}', [name, p.page]), docId: doc.id, page: p.page } });
    },
  };

  /** Asistanın kaynağına git: aynı belgedeyse sayfaya kaydır, değilse kaydedip o belgeyi aç */
  const jumpTo = async (t: JumpTarget) => {
    if (t.docId === doc.id && t.kind === 'pdf') {
      registry?.getPlugin<ScrollPlugin>('scroll')?.provides()?.forDocument(doc.id).scrollToPage({ pageNumber: t.n, behavior: 'smooth' });
      if (window.matchMedia('(max-width: 760px)').matches) setAiOpen(false);
      return;
    }
    window.clearTimeout(timer.current);
    if (stateRef.current === 'dirty' || stateRef.current === 'saving') await (savingRef.current ?? persistRef.current());
    onOpenDocAt(t);
  };

  const getCurrent = useCallback(
    async (): Promise<CurrentDoc | null> =>
      // Kitaplıkta saklanamıyorsa (ör. gizli sekme) açık belgenin kendisi okunur
      storageOk ? null : { meta: { id: doc.id, name, kind: 'pdf', updatedAt: 0 }, bytes: doc.bytes },
    [storageOk, doc.id, doc.bytes, name],
  );

  const handleBack = async () => {
    const pending = stateRef.current === 'dirty' || stateRef.current === 'saving';
    if (pending && canSave) await (savingRef.current ?? persistRef.current());
    const fileBehind = !!handle && unsynced.current;
    if (fileBehind || (!canSave && ready)) {
      setConfirmLeave(true);
      return;
    }
    onClose();
  };

  const commitName = () => {
    const clean = name.trim() || __('Adsız belge');
    setName(clean);
    if (clean !== doc.name) {
      onRename(clean);
      if (storageOk) markDirty();
    }
  };

  const fileName = handle?.name ?? '';
  const statusText: Record<SaveState, string> = {
    clean: handle ? __('Bağlı dosya: {0}', [fileName]) : __('Değişiklik yok'),
    dirty: __('Kaydedilmemiş değişiklikler'),
    saving: __('Kaydediliyor…'),
    saved: handle && link === 'ok' ? __('Kaydedildi: {0}', [fileName]) : __('Bu cihaza kaydedildi'),
    error: 'Kaydedilemedi',
    off: __('Otomatik kayıt kapalı — İndir ile kaydet'),
  };

  return (
    <div className="editor">
      <header className="editbar">
        <button className="btn btn--ghost editbar__back" onClick={handleBack} aria-label={__('Belgelerime dön')}>
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span className="hide-sm">{__('Belgelerim')}</span>
        </button>
        <span className="hide-xs" style={{ display: 'contents' }}>
          <BrandMark size={22} />
        </span>
        <label className="editbar__name">
          <span className="sr-only">{__('Belge adı')}</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={commitName}
            onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
            spellCheck={false}
          />
        </label>
        {ready && <DocTabs tabs={MODES} active={mode} onPick={pickMode} label={__('Belge sekmeleri')} />}
        <span className={`status status--${state}${handle && link === 'ok' ? ' status--linked' : ''}`} aria-live="polite" title={statusText[state]}>
          <i aria-hidden="true" />
          <span className="hide-sm">{statusText[state]}</span>
        </span>
        <button
          className={aiOpen ? 'btn btn--ghost editbar__ai editbar__ai--on' : 'btn btn--ghost editbar__ai'}
          onClick={() => {
            setAiReq(null);
            setAiOpen((v) => !v);
          }}
          aria-pressed={aiOpen}
          title={__('Asistan: notlarına dayanarak sorularını yanıtlar')}
        >
          <SparkIcon />
          <span className="hide-sm">{__('Asistan')}</span>
        </button>
        {canShare && (
          <button className="btn btn--ghost" onClick={handleShare} disabled={!ready} title={__('Paylaş')}>
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M12 15V4m0 0L8 8m4-4l4 4M6 12v6a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="hide-sm">{__('Paylaş')}</span>
          </button>
        )}
        <SaveMenu
          main="pdf"
          disabled={!ready}
          busy={!!convBusy}
          onSave={(f) => void handleSaveAs(f)}
          extras={[{ id: 'md-ac', label: 'Markdown notu olarak aç', hint: 'Yazıyı düzenlemek için (notlar ve çizimler aktarılmaz)' }]}
          onExtra={() => void openAsMarkdown()}
        />
      </header>

      {handle && link === 'need' && (
        <div className="linkbar" role="status">
          <span>
            <b>{fileName}</b> {__('dosyasındaki değişikliklerin aynı dosyaya (ör. OneDrive klasörüne) kaydedilmesi için izin ver.')}
          </span>
          <button className="btn btn--primary btn--sm" onClick={grant}>
            {__('Asıl dosyaya kaydetmeye izin ver')}
          </button>
        </div>
      )}
      {handle && link === 'readonly' && (
        <div className="linkbar linkbar--warn" role="alert">
          <span>
            <b>{fileName}</b> {__('bu konumda değiştirilemiyor (salt okunur). Değişiklikler yalnızca bu tarayıcıya kaydediliyor; “İndir” ile yeni bir kopya kaydedebilirsin.')}
          </span>
        </div>
      )}
      {handle && link === 'external' && (
        <div className="linkbar" role="alert">
          <span>
            <b>{fileName}</b> {__('başka bir yerde (ör. diğer cihazında) güncellenmiş.')}
          </span>
          <button className="btn btn--primary btn--sm" onClick={() => onReloadFromFile({ ...doc, name })}>
            {__('Yeni sürümü aç')}
          </button>
          <button className="btn btn--ghost btn--sm" onClick={() => setLink('ok')}>
            {__('Şimdilik kapat')}
          </button>
        </div>
      )}
      {handle && link === 'conflict' && (
        <div className="linkbar linkbar--warn" role="alert">
          <span>
            <b>{fileName}</b> {__('sen düzenlerken başka bir yerde de değiştirilmiş. Hangisi kalsın?')}
          </span>
          <button className="btn btn--danger btn--sm" onClick={() => void persistRef.current({ force: true })}>
            {__('Benim sürümüm (üzerine yaz)')}
          </button>
          <button className="btn btn--ghost btn--sm" onClick={() => onReloadFromFile({ ...doc, name })}>
            {__('Diğer sürümü aç')}
          </button>
        </div>
      )}

      <div className="editor__main">
        <div className="viewer" ref={viewerRef}>
          <PDFViewer config={config} onReady={onReady} style={{ width: '100%', height: '100%' }} />
          <PenLayer registry={registry} host={viewerRef.current} author={author} onToast={flash} />
        </div>
        {aiOpen && (
          <Suspense fallback={<aside className="aipanel aipanel--side aipanel--loading" aria-busy="true" />}>
            <AssistantPanel
              layout="side"
              storeKey={`doc:${doc.id}`}
              doc={{ id: doc.id, name, kind: 'pdf' }}
              folder={folder}
              getCurrent={getCurrent}
              request={aiReq}
              onClose={() => {
                setAiOpen(false);
                setAiReq(null);
              }}
              onJump={(t) => void jumpTo(t)}
              onSaveNote={onSaveNote}
            />
          </Suspense>
        )}
      </div>

      {pageDlg?.kind === 'add' && (
        <AddPageDialog current={pageDlg.current} total={pageDlg.total} onCancel={() => setPageDlg(null)} onSubmit={addPages} />
      )}
      {pageDlg?.kind === 'delete' && (
        <DeletePageDialog current={pageDlg.current} total={pageDlg.total} onCancel={() => setPageDlg(null)} onSubmit={removePages} />
      )}
      {(pageBusy || convBusy) && (
        <div className="toast" role="status">
          {pageBusy ? __('Sayfalar güncelleniyor…') : convBusy}
        </div>
      )}

      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}

      {confirmLeave && (
        <div className="dialog-veil" role="presentation" onClick={() => setConfirmLeave(false)}>
          <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="leave-title" onClick={(e) => e.stopPropagation()}>
            <h2 id="leave-title">{__('Belgeden çıkılsın mı?')}</h2>
            {handle ? (
              <p>
                {__('Son değişiklikler')} <b>{fileName}</b> {__('dosyasına henüz yazılmadı')}
                {storageOk ? __('; bu tarayıcıdaki kopyada duruyor.') : '.'} {__('Asıl dosyaya kaydetmek için izin verebilirsin.')}
              </p>
            ) : (
              <p>{__('Bu görünümde otomatik kayıt kapalı. Çıkmadan önce belgeyi indirmezsen notların ve imzaların kaybolur.')}</p>
            )}
            <div className="dialog__actions">
              <button className="btn btn--ghost" onClick={() => setConfirmLeave(false)}>
                {__('Vazgeç')}
              </button>
              <button className="btn btn--danger" onClick={onClose}>
                {handle ? __('Kaydetmeden çık') : __('İndirmeden çık')}
              </button>
              <button
                className="btn btn--primary"
                onClick={async () => {
                  if (handle) {
                    await grant();
                    if (!unsynced.current) onClose();
                  } else {
                    await handleDownload();
                    setConfirmLeave(false);
                  }
                }}
              >
                {handle ? __('İzin ver ve kaydet') : __('Önce indir')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
