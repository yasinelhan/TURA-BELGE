// SPDX-License-Identifier: AGPL-3.0-or-later
import { getLang } from '../i18n';
const base = import.meta.env.BASE_URL;

export function BrandMark({ size = 40 }: { size?: number }) {
  return (
    <img
      className="brand-mark"
      src={`${base}brand/mark.png`}
      width={Math.round(size * 1.87)}
      height={size}
      alt=""
      aria-hidden="true"
    />
  );
}

export function BrandLockup({ compact = false }: { compact?: boolean }) {
  return (
    <span className={compact ? 'lockup lockup--compact' : 'lockup'}>
      <BrandMark size={compact ? 24 : 34} />
      <span className="lockup__name">
        Tura <b>Belge</b>
      </span>
    </span>
  );
}

export function NahleCredit() {
  const logo = <img src={`${base}brand/nahle.png`} alt="NAHLE" height={14} width={71} />;
  // Türkçede "NAHLE tarafından geliştirildi", İngilizcede "Developed by NAHLE"
  return getLang() === 'en' ? (
    <span className="nahle-credit">
      <span>Developed by</span>
      {logo}
    </span>
  ) : (
    <span className="nahle-credit">
      {logo}
      <span>tarafından geliştirildi</span>
    </span>
  );
}
