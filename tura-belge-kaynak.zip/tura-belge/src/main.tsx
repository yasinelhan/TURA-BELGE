// Tura Belge — giriş noktası
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createRoot } from 'react-dom/client';
import './styles.css';
import App from './App.tsx';

createRoot(document.getElementById('root')!).render(<App />);
