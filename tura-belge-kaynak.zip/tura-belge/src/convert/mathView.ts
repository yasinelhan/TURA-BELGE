// Tura Belge — formüllü Markdown görünümü: $…$, $$…$$, \(…\) ve \[…\] KaTeX ile çizilir.
// (Notların önizlemesi ve asistan cevapları için; dışa aktarımlarda formül LaTeX yazısı olarak kalır.)
// SPDX-License-Identifier: AGPL-3.0-or-later
import katex from 'katex';
import { Marked, type TokenizerAndRendererExtension } from 'marked';
import { escHtml, safeRenderer } from './markdown';

const tex = (src: string, display: boolean) => {
  try {
    return katex.renderToString(src, { displayMode: display, throwOnError: false, strict: 'ignore', trust: false, output: 'htmlAndMathml' });
  } catch {
    return `<code>${escHtml(src)}</code>`;
  }
};

const mathBlock: TokenizerAndRendererExtension = {
  name: 'mathBlock',
  level: 'block',
  start: (src) => {
    const m = src.match(/^ {0,3}(\$\$|\\\[)/m);
    return m?.index;
  },
  tokenizer(src) {
    const m = /^ {0,3}(?:\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\])[ \t]*(?:\n+|$)/.exec(src);
    if (m) return { type: 'mathBlock', raw: m[0], text: (m[1] ?? m[2]).trim() };
    return undefined;
  },
  renderer: (t) => `<div class="math-block">${tex(t.text as string, true)}</div>\n`,
};

const mathInline: TokenizerAndRendererExtension = {
  name: 'mathInline',
  level: 'inline',
  start: (src) => {
    const i = src.search(/\$|\\\(/);
    return i < 0 ? undefined : i;
  },
  tokenizer(src) {
    let m = /^\$\$((?:\\.|[^$\\])+?)\$\$/.exec(src);
    if (m) return { type: 'mathInline', raw: m[0], text: m[1].trim(), display: true };
    // $x$: açılışta ve kapanışta boşluk yok, kapanıştan sonra rakam yok (ör. "5$ ve 10$" para birimi sayılır)
    m = /^\$(?![\s$])((?:\\.|[^\\$\n])+?)(?<![\s\\])\$(?!\d)/.exec(src);
    if (m) return { type: 'mathInline', raw: m[0], text: m[1], display: false };
    m = /^\\\(([\s\S]+?)\\\)/.exec(src);
    if (m) return { type: 'mathInline', raw: m[0], text: m[1].trim(), display: false };
    return undefined;
  },
  renderer: (t) => tex(t.text as string, !!t.display),
};

const md = new Marked({ gfm: true, breaks: false, renderer: safeRenderer as never }, { extensions: [mathBlock, mathInline] });

/** Formüllü güvenli HTML */
export function mdViewHtml(text: string): string {
  ensureKatexCss();
  return md.parse(text, { async: false }) as string;
}

/** KaTeX yazı tipleri ve biçimleri (yalnızca ilk formülde yüklenir) */
export function ensureKatexCss() {
  if (typeof document === 'undefined' || document.querySelector('link[data-katex]')) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = new URL('vendor/katex/katex.min.css', document.baseURI).href;
  link.dataset.katex = '';
  document.head.appendChild(link);
}
