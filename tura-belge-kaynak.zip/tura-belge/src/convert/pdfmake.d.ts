// pdfmake tarayıcı paketi için tür bildirimi (paket kendi türlerini getirmiyor)
declare module 'pdfmake/build/pdfmake.js' {
  const pdfMake: unknown;
  export default pdfMake;
}
