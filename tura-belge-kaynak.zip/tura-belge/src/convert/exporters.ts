// Tura Belge — "Farklı kaydet" biçimleri: PDF, Word, Markdown, web sayfası, düz metin
// SPDX-License-Identifier: AGPL-3.0-or-later
import { mdToHtmlPage, mdToText } from './markdown';
import { __, N_ } from '../i18n';

export type ExportFormat = 'pdf' | 'docx' | 'md' | 'html' | 'txt';

export const FORMATS: { id: ExportFormat; label: string; ext: string; mime: string }[] = [
  { id: 'pdf', label: 'PDF', ext: 'pdf', mime: 'application/pdf' },
  { id: 'docx', label: 'Word', ext: 'docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
  { id: 'md', label: 'Markdown', ext: 'md', mime: 'text/markdown' },
  { id: 'html', label: N_('Web sayfası'), ext: 'html', mime: 'text/html' },
  { id: 'txt', label: N_('Düz metin'), ext: 'txt', mime: 'text/plain' },
];
/** Biçim bilgisi (adı o anki dilde) */
export const formatInfo = (f: ExportFormat) => {
  const x = FORMATS.find((y) => y.id === f)!;
  return { ...x, label: __(x.label) };
};

const textBlob = (s: string, mime: string) => new Blob([s], { type: `${mime};charset=utf-8` });

/** Markdown metnini istenen biçime çevirir */
export async function exportMarkdown(text: string, title: string, fmt: ExportFormat): Promise<Blob> {
  switch (fmt) {
    case 'md':
      return textBlob(text, 'text/markdown');
    case 'txt':
      return textBlob(mdToText(text), 'text/plain');
    case 'html':
      return textBlob(mdToHtmlPage(text, title), 'text/html');
    case 'pdf': {
      const { mdToPdf } = await import('./mdToPdf');
      return new Blob([await mdToPdf(text, title)], { type: 'application/pdf' });
    }
    case 'docx': {
      const { mdToDocx } = await import('./mdToDocx');
      return mdToDocx(text, title);
    }
  }
}

export class NoTextError extends Error {}

/** PDF'i Markdown'a çevirir; metni yoksa (taranmış) NoTextError */
export async function pdfToMd(bytes: ArrayBuffer, onProgress?: (page: number, total: number) => void) {
  const { pdfToMarkdown } = await import('./pdfToMd');
  const r = await pdfToMarkdown(bytes, onProgress);
  if (!r.md.trim()) throw new NoTextError('no-text');
  return r;
}

/** PDF'i (PDF dışındaki) bir biçime çevirir: önce yapısıyla Markdown'a, oradan hedefe */
export async function exportPdfAs(bytes: ArrayBuffer, title: string, fmt: Exclude<ExportFormat, 'pdf'>, onProgress?: (page: number, total: number) => void) {
  const r = await pdfToMd(bytes, onProgress);
  return { blob: await exportMarkdown(r.md, title, fmt), empty: r.empty, pages: r.pages, md: r.md };
}
