// Tura Belge — Markdown: güvenli HTML'e çevirme, düz metin, dosya adları
// SPDX-License-Identifier: AGPL-3.0-or-later
import { locale, getLang } from '../i18n';
import { Marked, type Token, type Tokens } from 'marked';

const escHtml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Yalnızca güvenli bağlantılar (http, https, mailto, sayfa içi) */
export const safeHref = (href: string) => (/^(https?:|mailto:|#)/i.test(href.trim()) ? href.trim() : '');
const safeSrc = (src: string) => (/^(https?:|data:image\/(png|jpe?g|gif|webp);)/i.test(src.trim()) ? src.trim() : '');

/** Markdown'daki ham HTML çalıştırılmaz, yazı olarak gösterilir; bağlantılar süzülür */
export const safeRenderer = {
  html({ text }: { text: string }) {
    return escHtml(text);
  },
  link(this: { parser: { parseInline: (t: Token[]) => string } }, { href, title, tokens }: Tokens.Link) {
    const h = safeHref(href);
    const inner = this.parser.parseInline(tokens);
    if (!h) return inner;
    const ext = /^https?:/i.test(h);
    return `<a href="${escHtml(h)}"${title ? ` title="${escHtml(title)}"` : ''}${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}>${inner}</a>`;
  },
  image({ href, title, text }: Tokens.Image) {
    const s = safeSrc(href);
    if (!s) return escHtml(text);
    return `<img src="${escHtml(s)}" alt="${escHtml(text)}"${title ? ` title="${escHtml(title)}"` : ''} loading="lazy">`;
  },
};

const md = new Marked({ gfm: true, breaks: false, renderer: safeRenderer as never });

export { escHtml };

export function mdToHtml(text: string): string {
  return md.parse(text, { async: false }) as string;
}

export function mdTokens(text: string): Token[] {
  return md.lexer(text);
}

/** Satır içi parçalardan düz metin */
export function inlineText(tokens: Token[] | undefined): string {
  if (!tokens) return '';
  return tokens
    .map((t) => {
      if ('tokens' in t && t.tokens && t.type !== 'codespan') return inlineText(t.tokens);
      if (t.type === 'br') return '\n';
      if (t.type === 'image') return (t as Tokens.Image).text;
      return 'text' in t ? (t as { text: string }).text : t.raw;
    })
    .join('');
}

/** Markdown → düz metin (.txt) */
export function mdToText(text: string): string {
  const out: string[] = [];
  const walk = (tokens: Token[], indent = '') => {
    for (const t of tokens) {
      switch (t.type) {
        case 'heading':
          out.push(indent + inlineText(t.tokens).toLocaleUpperCase(locale()), '');
          break;
        case 'paragraph':
          out.push(indent + inlineText(t.tokens), '');
          break;
        case 'list': {
          const l = t as Tokens.List;
          l.items.forEach((it, i) => {
            const mark = it.task ? (it.checked ? '[x] ' : '[ ] ') : '';
            const bullet = l.ordered ? `${Number(l.start || 1) + i}. ` : '• ';
            const first = it.tokens.find((x) => x.type === 'text' || x.type === 'paragraph') as Tokens.Text | undefined;
            out.push(indent + bullet + mark + inlineText(first?.tokens ?? [first as Token].filter(Boolean)));
            const rest = it.tokens.filter((x) => x !== first);
            if (rest.length) walk(rest, indent + '   ');
          });
          out.push('');
          break;
        }
        case 'code':
          out.push(...(t as Tokens.Code).text.split('\n').map((x) => indent + '    ' + x), '');
          break;
        case 'blockquote':
          walk((t as Tokens.Blockquote).tokens, indent + '> ');
          break;
        case 'table': {
          const tb = t as Tokens.Table;
          out.push(indent + tb.header.map((c) => inlineText(c.tokens)).join(' | '));
          for (const r of tb.rows) out.push(indent + r.map((c) => inlineText(c.tokens)).join(' | '));
          out.push('');
          break;
        }
        case 'hr':
          out.push(indent + '—'.repeat(20), '');
          break;
        case 'space':
          break;
        default:
          if ('text' in t) out.push(indent + (t as { text: string }).text, '');
      }
    }
  };
  walk(mdTokens(text));
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}

/** İlk başlık ya da ilk satır: belgenin adı için */
export function mdTitle(text: string): string {
  const h = text.match(/^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/m);
  const first = h?.[1] ?? text.split('\n').find((l) => l.trim()) ?? '';
  return first.replace(/[*_`#>[\]]/g, '').trim().slice(0, 80);
}

export const MD_CSS = `
.md-view { font: 16px/1.65 'Noto Sans', 'Open Sans', system-ui, sans-serif; color: #1d2340; overflow-wrap: anywhere; }
.md-view > :first-child { margin-top: 0; }
.md-view h1, .md-view h2, .md-view h3, .md-view h4, .md-view h5, .md-view h6 { font-family: Montserrat, 'Noto Sans', sans-serif; line-height: 1.25; margin: 1.4em 0 0.5em; color: #14205a; }
.md-view h1 { font-size: 1.9em; padding-bottom: 0.25em; border-bottom: 2px solid #0b7a8f; }
.md-view h2 { font-size: 1.45em; padding-bottom: 0.2em; border-bottom: 1px solid #e2d3b8; }
.md-view h3 { font-size: 1.2em; } .md-view h4 { font-size: 1.05em; } .md-view h5, .md-view h6 { font-size: 1em; color: #4a5378; }
.md-view p, .md-view ul, .md-view ol, .md-view blockquote, .md-view pre, .md-view table { margin: 0 0 1em; }
.md-view ul, .md-view ol { padding-left: 1.6em; }
.md-view li + li { margin-top: 0.2em; }
.md-view li > input[type=checkbox] { margin: 0 0.45em 0 -1.3em; vertical-align: -0.1em; accent-color: #0b7a8f; }
.md-view li:has(> input[type=checkbox]) { list-style: none; }
.md-view a { color: #0b7a8f; }
.md-view code { font: 0.9em/1.4 'Noto Sans Mono', ui-monospace, Consolas, monospace; background: #f3ece0; padding: 0.1em 0.35em; border-radius: 4px; }
.md-view pre { background: #f6f1e8; border: 1px solid #e8dcc7; border-radius: 10px; padding: 12px 14px; overflow: auto; }
.md-view pre code { background: none; padding: 0; font-size: 0.88em; }
.md-view blockquote { margin-left: 0; padding: 0.2em 1em; border-left: 4px solid #0b7a8f; color: #4a5378; background: #f7f2e9; border-radius: 0 8px 8px 0; }
.md-view hr { border: 0; border-top: 1px solid #e2d3b8; margin: 1.6em 0; }
.md-view table { border-collapse: collapse; display: block; overflow-x: auto; max-width: 100%; }
.md-view th, .md-view td { border: 1px solid #e2d3b8; padding: 6px 10px; text-align: left; vertical-align: top; }
.md-view th { background: #f6f1e8; font-weight: 600; }
.md-view img { max-width: 100%; height: auto; border-radius: 6px; }
`;

/** Tek başına açılabilen HTML sayfası (.html olarak kaydetmek için) */
export function mdToHtmlPage(text: string, title: string): string {
  return `<!DOCTYPE html>
<html lang="${getLang()}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(title)}</title>
<style>
body { margin: 0; background: #faf6ee; }
main { max-width: 820px; margin: 0 auto; padding: 40px 24px 64px; }
${MD_CSS}
</style>
</head>
<body>
<main class="md-view">
${mdToHtml(text)}
</main>
</body>
</html>
`;
}
