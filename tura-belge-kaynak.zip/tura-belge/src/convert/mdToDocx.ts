// Tura Belge — Markdown'dan Word (.docx): başlıklar, kalın/eğik, bağlantılar, listeler, tablolar, kod, alıntı
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { Token, Tokens } from 'marked';
import { mdTokens, safeHref } from './markdown';
import { __ } from '../i18n';

type Docx = typeof import('docx');
/* eslint-disable @typescript-eslint/no-explicit-any */

interface Run {
  bold?: boolean;
  italics?: boolean;
  strike?: boolean;
  code?: boolean;
  link?: string;
}

const decode = (s: string) =>
  s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");

export async function mdToDocx(text: string, title: string): Promise<Blob> {
  const d: Docx = await import('docx');
  const { Document, Packer, Paragraph, TextRun, ExternalHyperlink, HeadingLevel, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, AlignmentType, LevelFormat } = d;
  const TEAL = '0B7A8F';
  const LINE = 'E2D3B8';
  let listInstance = 0;

  const runs = (tokens: Token[] | undefined, st: Run = {}): any[] => {
    if (!tokens) return [];
    const out: any[] = [];
    const push = (t: string) => {
      if (!t) return;
      const r = new TextRun({
        text: t,
        bold: st.bold,
        italics: st.italics,
        strike: st.strike,
        ...(st.code ? { font: 'Consolas', shading: { type: ShadingType.CLEAR, fill: 'F0E9DC', color: 'auto' } } : {}),
        ...(st.link ? { style: 'Hyperlink', color: TEAL, underline: {} } : {}),
      });
      out.push(st.link ? new ExternalHyperlink({ link: st.link, children: [r] }) : r);
    };
    for (const t of tokens) {
      switch (t.type) {
        case 'strong':
          out.push(...runs((t as Tokens.Strong).tokens, { ...st, bold: true }));
          break;
        case 'em':
          out.push(...runs((t as Tokens.Em).tokens, { ...st, italics: true }));
          break;
        case 'del':
          out.push(...runs((t as Tokens.Del).tokens, { ...st, strike: true }));
          break;
        case 'codespan':
          out.push(...runs([{ type: 'text', raw: '', text: (t as Tokens.Codespan).text } as Token], { ...st, code: true }));
          break;
        case 'link': {
          const l = t as Tokens.Link;
          const h = safeHref(l.href);
          out.push(...runs(l.tokens, h ? { ...st, link: h } : st));
          break;
        }
        case 'image':
          out.push(...runs([{ type: 'text', raw: '', text: `[${(t as Tokens.Image).text || __('görsel')}]` } as Token], { ...st, italics: true }));
          break;
        case 'br':
          out.push(new TextRun({ break: 1 }));
          break;
        case 'text':
        case 'escape': {
          const x = t as Tokens.Text;
          if (x.tokens?.length) out.push(...runs(x.tokens, st));
          else push(decode(x.text));
          break;
        }
        default:
          push(decode('text' in t ? String((t as { text: string }).text) : t.raw));
      }
    }
    return out;
  };

  const HEADINGS = [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3, HeadingLevel.HEADING_4, HeadingLevel.HEADING_5, HeadingLevel.HEADING_6];

  const blocks = (tokens: Token[], level = 0, quote = false): any[] => {
    const out: any[] = [];
    const para = (children: any[], extra: Record<string, unknown> = {}) =>
      new Paragraph({
        children,
        spacing: { after: 140, line: 300 },
        ...(quote ? { indent: { left: 360 }, border: { left: { style: BorderStyle.SINGLE, size: 18, color: TEAL, space: 10 } } } : {}),
        ...extra,
      });
    for (const t of tokens) {
      switch (t.type) {
        case 'heading': {
          const h = t as Tokens.Heading;
          out.push(new Paragraph({ heading: HEADINGS[Math.min(h.depth, 6) - 1], children: runs(h.tokens) }));
          break;
        }
        case 'paragraph':
          out.push(para(runs((t as Tokens.Paragraph).tokens, quote ? { italics: true } : {})));
          break;
        case 'text': {
          const x = t as Tokens.Text;
          out.push(para(x.tokens ? runs(x.tokens) : [new TextRun(decode(x.text))]));
          break;
        }
        case 'list': {
          const l = t as Tokens.List;
          const instance = ++listInstance;
          for (const it of l.items) {
            const inner = it.tokens.filter((x) => x.type !== 'checkbox');
            const first = inner[0];
            const rest = inner.slice(1);
            const box = it.task ? [new TextRun({ text: it.checked ? '☒ ' : '☐ ', font: 'Segoe UI Symbol' })] : [];
            const firstRuns = first && (first.type === 'text' || first.type === 'paragraph') ? runs((first as Tokens.Text).tokens ?? [first]) : [];
            out.push(
              new Paragraph({
                children: [...box, ...firstRuns],
                numbering: it.task ? undefined : { reference: l.ordered ? 'tura-sayi' : 'tura-madde', level: Math.min(level, 5), instance },
                indent: it.task ? { left: 360 * (level + 1) } : undefined,
                spacing: { after: 60, line: 290 },
              }),
            );
            const nested = firstRuns.length ? rest : inner;
            if (nested.length) out.push(...blocks(nested, level + 1, quote));
          }
          if (level === 0) out.push(new Paragraph({ children: [], spacing: { after: 60 } }));
          break;
        }
        case 'code':
          for (const line of (t as Tokens.Code).text.split('\n'))
            out.push(
              new Paragraph({
                children: [new TextRun({ text: line || ' ', font: 'Consolas', size: 19 })],
                shading: { type: ShadingType.CLEAR, fill: 'F6F1E8', color: 'auto' },
                spacing: { after: 0, line: 260 },
                indent: { left: 200, right: 200 },
              }),
            );
          out.push(new Paragraph({ children: [], spacing: { after: 120 } }));
          break;
        case 'blockquote':
          out.push(...blocks((t as Tokens.Blockquote).tokens, level, true));
          break;
        case 'table': {
          const tb = t as Tokens.Table;
          const align = (a: string | null) => (a === 'center' ? AlignmentType.CENTER : a === 'right' ? AlignmentType.RIGHT : AlignmentType.LEFT);
          const border = { style: BorderStyle.SINGLE, size: 4, color: LINE };
          const cell = (c: Tokens.TableCell, i: number, head: boolean) =>
            new TableCell({
              children: [new Paragraph({ alignment: align(tb.align[i]), children: runs(c.tokens, head ? { bold: true } : {}) })],
              shading: head ? { type: ShadingType.CLEAR, fill: 'F6F1E8', color: 'auto' } : undefined,
              margins: { top: 60, bottom: 60, left: 100, right: 100 },
              borders: { top: border, bottom: border, left: border, right: border },
            });
          out.push(
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                new TableRow({ tableHeader: true, children: tb.header.map((c, i) => cell(c, i, true)) }),
                ...tb.rows.map((r) => new TableRow({ children: r.map((c, i) => cell(c, i, false)) })),
              ],
            }),
            new Paragraph({ children: [], spacing: { after: 120 } }),
          );
          break;
        }
        case 'hr':
          out.push(new Paragraph({ children: [], border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: LINE, space: 4 } }, spacing: { after: 200 } }));
          break;
        case 'space':
          break;
        default:
          if ('text' in t) out.push(para([new TextRun(decode(String((t as { text: string }).text)))]));
      }
    }
    return out;
  };

  const levels = (ordered: boolean) =>
    Array.from({ length: 6 }, (_, i) => ({
      level: i,
      format: ordered ? [LevelFormat.DECIMAL, LevelFormat.LOWER_LETTER, LevelFormat.LOWER_ROMAN][i % 3] : LevelFormat.BULLET,
      text: ordered ? `%${i + 1}.` : ['•', '◦', '▪'][i % 3],
      alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 360 * (i + 1), hanging: 260 } } },
    }));

  const doc = new Document({
    creator: 'Tura Belge',
    title,
    styles: {
      default: { document: { run: { font: 'Calibri', size: 22, color: '1D2340' } } },
      paragraphStyles: [
        { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 40, bold: true, color: '14205A' }, paragraph: { spacing: { before: 240, after: 120 }, border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: TEAL, space: 4 } } } },
        { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 30, bold: true, color: '14205A' }, paragraph: { spacing: { before: 240, after: 100 } } },
        { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 26, bold: true, color: '14205A' }, paragraph: { spacing: { before: 200, after: 80 } } },
        { id: 'Heading4', name: 'Heading 4', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 23, bold: true, color: '14205A' }, paragraph: { spacing: { before: 160, after: 60 } } },
        { id: 'Heading5', name: 'Heading 5', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 22, bold: true, color: '14205A' } },
        { id: 'Heading6', name: 'Heading 6', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { size: 22, bold: true, color: '4A5378' } },
      ],
    },
    numbering: {
      config: [
        { reference: 'tura-madde', levels: levels(false) },
        { reference: 'tura-sayi', levels: levels(true) },
      ],
    },
    sections: [{ properties: { page: { margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 } } }, children: blocks(mdTokens(text)) }],
  });
  return Packer.toBlob(doc);
}
