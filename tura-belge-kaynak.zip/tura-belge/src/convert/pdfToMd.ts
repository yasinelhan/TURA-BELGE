// Tura Belge — PDF'ten Markdown: yazı parçalarının boyutu, kalınlığı ve konumundan
// başlıkları, paragrafları, listeleri ve kod bloklarını çıkarır.
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { PdfTextRun } from '@embedpdf/models';
import { openRenderDoc } from '../tools/lib/render';

interface Span {
  text: string;
  bold: boolean;
  italic: boolean;
  mono: boolean;
  x0: number;
  x1: number;
  size: number;
}
interface Line {
  spans: Span[];
  top: number;
  bottom: number;
  x0: number;
  size: number;
  page: number;
}

export interface PdfToMdResult {
  md: string;
  pages: number;
  /** Metni olmayan (taranmış) sayfa sayısı */
  empty: number;
}

const clean = (s: string) => s.replace(/\r\n?|\n/g, ' ').replace(/[\u0000-\u001f­]/g, '');
/** Markdown'da özel anlamı olan işaretler kaçırılır */
const esc = (s: string) => s.replace(/([\\`*_[\]<>])/g, '\\$1');

function toLines(runs: PdfTextRun[], page: number): Line[] {
  const items = runs
    .map((r) => ({
      text: clean(r.text),
      bold: (r.font?.weight ?? 400) >= 600 || /bold|black|heavy|semibold/i.test(r.font?.name ?? ''),
      italic: !!r.font?.italic || /italic|oblique/i.test(r.font?.name ?? ''),
      mono: !!r.font?.monospaced || /mono|courier|consol|code/i.test(r.font?.name ?? ''),
      x0: r.rect.origin.x,
      x1: r.rect.origin.x + r.rect.size.width,
      top: r.rect.origin.y,
      bottom: r.rect.origin.y + r.rect.size.height,
      size: r.fontSize || r.rect.size.height * 0.7,
    }))
    .filter((r) => r.text.trim());
  items.sort((a, b) => a.top - b.top || a.x0 - b.x0);
  const lines: Line[] = [];
  for (const it of items) {
    // Aynı satır: dikeyde yeterince örtüşüyor
    const line = lines.find((l) => {
      const ov = Math.min(l.bottom, it.bottom) - Math.max(l.top, it.top);
      return ov > 0.5 * Math.min(l.bottom - l.top, it.bottom - it.top);
    });
    const span: Span = { text: it.text, bold: it.bold, italic: it.italic, mono: it.mono, x0: it.x0, x1: it.x1, size: it.size };
    if (line) {
      line.spans.push(span);
      line.top = Math.min(line.top, it.top);
      line.bottom = Math.max(line.bottom, it.bottom);
      line.x0 = Math.min(line.x0, it.x0);
      line.size = Math.max(line.size, it.size);
    } else lines.push({ spans: [span], top: it.top, bottom: it.bottom, x0: it.x0, size: it.size, page });
  }
  for (const l of lines) l.spans.sort((a, b) => a.x0 - b.x0);
  return lines.sort((a, b) => a.top - b.top);
}

const plain = (l: Line) => l.spans.map((s) => s.text).join(' ').replace(/\s+/g, ' ').trim();

/** Satırı biçimli Markdown'a çevirir (kalın, eğik, kod) */
function inline(l: Line, wholeStyle: { bold: boolean; italic: boolean }): string {
  let out = '';
  let prev: Span | null = null;
  for (const s of l.spans) {
    let t = s.text;
    if (prev) {
      const gap = s.x0 - prev.x1;
      if (gap > s.size * 0.18 && !/\s$/.test(out) && !/^\s/.test(t)) out += ' ';
    }
    const lead = t.match(/^\s*/)![0];
    const trail = t.match(/\s*$/)![0];
    t = t.trim();
    if (t) {
      let m = s.mono ? '`' + t.replace(/`/g, "'") + '`' : esc(t);
      if (!s.mono) {
        if (s.bold && !wholeStyle.bold) m = `**${m}**`;
        if (s.italic && !wholeStyle.italic) m = `*${m}*`;
      }
      out += lead + m + trail;
    } else out += lead + trail;
    prev = s;
  }
  return out.replace(/\s+/g, ' ').replace(/\*\*\s*\*\*/g, ' ').trim();
}

/** Birçok sayfada aynı yerde tekrar eden satırlar (üst/alt bilgi, sayfa numarası) */
function repeated(lines: Line[], pages: number, heights: number[]): Set<Line> {
  const drop = new Set<Line>();
  if (pages < 2) {
    // Tek sayfada yalnızca "1 / 1" gibi sayfa numaraları
    for (const l of lines) if (/^\s*(sayfa\s*)?\d+\s*(\/|of|\s)\s*\d+\s*$/i.test(plain(l))) drop.add(l);
    return drop;
  }
  const key = (l: Line) => plain(l).replace(/\d+/g, '#').toLocaleLowerCase('tr');
  const count = new Map<string, Set<number>>();
  for (const l of lines) {
    const h = heights[l.page] || 842;
    if (l.top > h * 0.1 && l.bottom < h * 0.9) continue;
    const k = key(l);
    if (!count.has(k)) count.set(k, new Set());
    count.get(k)!.add(l.page);
  }
  for (const l of lines) {
    const h = heights[l.page] || 842;
    if (l.top > h * 0.1 && l.bottom < h * 0.9) continue;
    const n = count.get(key(l))?.size ?? 0;
    if (n >= Math.max(2, Math.ceil(pages * 0.5)) || /^\s*#\s*(\/\s*#)?\s*$/.test(key(l))) drop.add(l);
  }
  return drop;
}

const BULLET = /^[•·▪●◦○■□‣⁃–—*-]\s+/;
const STRONG_BULLET = /^[•▪●◦○■□‣⁃]\s+/;
const NUMBERED = /^(\d{1,3}|[a-zçğıöşü])[.)]\s+/i;

export async function pdfToMarkdown(bytes: ArrayBuffer, onProgress?: (page: number, total: number) => void): Promise<PdfToMdResult> {
  const doc = await openRenderDoc(bytes);
  try {
    const all: Line[] = [];
    const heights: number[] = [];
    let empty = 0;
    for (let i = 0; i < doc.pageCount; i++) {
      onProgress?.(i + 1, doc.pageCount);
      heights[i] = doc.sizePt(i).h;
      const lines = toLines(await doc.textRuns(i), i);
      if (!lines.length) empty++;
      all.push(...lines);
    }
    const drop = repeated(all, doc.pageCount, heights);
    const lines = all.filter((l) => !drop.has(l) && plain(l));
    if (!lines.length) return { md: '', pages: doc.pageCount, empty };

    // Gövde yazı boyutu: en çok karakterin yazıldığı boyut
    const bySize = new Map<number, number>();
    for (const l of lines) for (const s of l.spans) bySize.set(Math.round(s.size * 2) / 2, (bySize.get(Math.round(s.size * 2) / 2) ?? 0) + s.text.length);
    const body = [...bySize.entries()].sort((a, b) => b[1] - a[1])[0][0];
    const leftEdge = Math.min(...lines.map((l) => l.x0));

    const out: string[] = [];
    // Paragraf satırları; tamamı kalın/eğik satırlar birleştirilip bir kez işaretlenir
    let para: { t: string; w: '' | '**' | '*' }[] = [];
    let code: string[] = [];
    const flushPara = () => {
      if (para.length) {
        const parts: string[] = [];
        for (let i = 0; i < para.length; ) {
          let j = i;
          while (j + 1 < para.length && para[j + 1].w === para[i].w) j++;
          const joined = para.slice(i, j + 1).map((p) => p.t).join(' ');
          parts.push(para[i].w ? para[i].w + joined + para[i].w : joined);
          i = j + 1;
        }
        out.push(parts.join(' ').replace(/(\p{L})- (\p{Ll})/gu, '$1$2'));
      }
      para = [];
    };
    const flushCode = () => {
      if (code.length) out.push('```\n' + code.join('\n') + '\n```');
      code = [];
    };

    let prev: Line | null = null;
    for (const l of lines) {
      const text = plain(l);
      const gap = prev && prev.page === l.page ? l.top - prev.bottom : Infinity;
      const lh = (l.bottom - l.top) || body * 1.3;
      const allBold = l.spans.every((s) => s.bold || !s.text.trim());
      const allItalic = l.spans.every((s) => s.italic || !s.text.trim());
      const allMono = l.spans.every((s) => s.mono || !s.text.trim());

      if (allMono) {
        flushPara();
        code.push(l.spans.map((s) => s.text).join(' ').replace(/\s+$/, ''));
        prev = l;
        continue;
      }
      flushCode();

      const ratio = l.size / body;
      let heading = 0;
      if (ratio >= 1.6) heading = 1;
      else if (ratio >= 1.3) heading = 2;
      else if (ratio >= 1.12) heading = 3;
      else if (allBold && text.length < 80 && !/[.,;:]$/.test(text) && gap > lh * 0.35) heading = 4;
      if (heading) {
        flushPara();
        // Ardışık iki satırlık başlık birleştirilir
        const last = out[out.length - 1];
        const hashes = '#'.repeat(heading) + ' ';
        if (last?.startsWith(hashes) && prev && gap < lh * 0.6) out[out.length - 1] = last + ' ' + esc(text);
        else out.push(hashes + esc(text));
        prev = l;
        continue;
      }

      const line = inline(l, { bold: allBold, italic: allItalic });
      const wrap: '' | '**' | '*' = allBold ? '**' : allItalic ? '*' : '';
      const raw = text;
      // Paragrafın ortasında satır başına düşen "·" ya da "-" madde işareti sayılmaz
      const lastPara = para[para.length - 1]?.t ?? '';
      const continues = para.length > 0 && gap < lh * 0.6 && !/[.:;!?)]\**$/.test(lastPara);
      const isBullet = STRONG_BULLET.test(raw) || (BULLET.test(raw) && !continues);
      const isNum = NUMBERED.test(raw) && !/^\d{1,3}[.)]\s+\d/.test(raw) && !continues;
      if (isBullet || isNum) {
        flushPara();
        const indent = l.x0 - leftEdge > body * 1.5 ? '  ' : '';
        const content = inline(l, { bold: allBold, italic: allItalic }).replace(isBullet ? /^\\?[•·▪●◦○■□‣⁃–—*-]\s*/ : /^(\d{1,3}|[a-zçğıöşü])\\?[.)]\s*/i, '');
        out.push(indent + (isBullet ? '- ' : `${raw.match(NUMBERED)![1]}. `) + content);
        prev = l;
        continue;
      }
      // Liste maddesinin devam satırı
      const last = out[out.length - 1];
      if (!para.length && last && /^\s*(- |\d+\. )/.test(last) && gap < lh * 0.5 && l.x0 > leftEdge + body * 0.8) {
        out[out.length - 1] = last + ' ' + (wrap ? wrap + line + wrap : line);
        prev = l;
        continue;
      }
      if (para.length && (gap > lh * 0.6 || (l.page !== prev?.page && /[.!?:]\**$/.test(lastPara)))) flushPara();
      // Alt bilgideki sayfa numarası ("1 / 2") atılır
      const h = heights[l.page] || 842;
      const t = l.top > h * 0.9 ? line.replace(/\s+\d+\s*\/\s*\d+$/, '') : line;
      if (t) para.push({ t, w: wrap });
      prev = l;
    }
    flushPara();
    flushCode();
    return { md: out.join('\n\n').replace(/\n{3,}/g, '\n\n').trim() + '\n', pages: doc.pageCount, empty };
  } finally {
    doc.close();
  }
}
