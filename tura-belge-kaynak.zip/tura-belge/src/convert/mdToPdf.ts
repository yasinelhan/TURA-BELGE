// Tura Belge — Markdown'dan vektör PDF (pdfmake, gömülü Noto yazı tipleri; Türkçe karakterler tam)
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { Token, Tokens } from 'marked';
import { mdTokens, safeHref } from './markdown';
import { __ } from '../i18n';

/* eslint-disable @typescript-eslint/no-explicit-any */
type Node = any;

const abs = (p: string) => new URL(p, document.baseURI).href;
const INK = '#1d2340';
const HEAD = '#14205a';
const TEAL = '#0b7a8f';
const LINE = '#e2d3b8';
const SOFT = '#f6f1e8';

interface Style {
  bold?: boolean;
  italics?: boolean;
  decoration?: string;
  font?: string;
  color?: string;
  link?: string;
  background?: string;
}

function inlines(tokens: Token[] | undefined, st: Style = {}): Node[] {
  if (!tokens) return [];
  const out: Node[] = [];
  for (const t of tokens) {
    switch (t.type) {
      case 'strong':
        out.push(...inlines((t as Tokens.Strong).tokens, { ...st, bold: true }));
        break;
      case 'em':
        out.push(...inlines((t as Tokens.Em).tokens, { ...st, italics: true }));
        break;
      case 'del':
        out.push(...inlines((t as Tokens.Del).tokens, { ...st, decoration: 'lineThrough' }));
        break;
      case 'codespan':
        out.push({ text: (t as Tokens.Codespan).text, ...st, font: 'Mono', background: '#f0e9dc', fontSize: 9.5 });
        break;
      case 'link': {
        const l = t as Tokens.Link;
        const href = safeHref(l.href);
        out.push(...inlines(l.tokens, href ? { ...st, link: href, color: TEAL, decoration: 'underline' } : st));
        break;
      }
      case 'image':
        out.push({ text: `[${(t as Tokens.Image).text || __('görsel')}]`, ...st, italics: true, color: '#6b7190' });
        break;
      case 'br':
        out.push({ text: '\n', ...st });
        break;
      case 'escape':
      case 'text': {
        const x = t as Tokens.Text;
        if (x.tokens?.length) out.push(...inlines(x.tokens, st));
        else out.push({ text: decode(x.text), ...st });
        break;
      }
      case 'html':
        out.push({ text: (t as Tokens.HTML).text, ...st });
        break;
      default:
        out.push({ text: decode(t.raw), ...st });
    }
  }
  return out;
}

const decode = (s: string) =>
  s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");

const isImg = (tokens: Token[] | undefined) =>
  tokens?.length === 1 && tokens[0].type === 'image' && /^data:image\/(png|jpe?g);/i.test((tokens[0] as Tokens.Image).href);

function blocks(tokens: Token[]): Node[] {
  const out: Node[] = [];
  for (const t of tokens) {
    switch (t.type) {
      case 'heading': {
        const h = t as Tokens.Heading;
        const node: Node = { text: inlines(h.tokens), style: `h${Math.min(h.depth, 6)}` };
        out.push(node);
        if (h.depth <= 2)
          out.push({
            canvas: [{ type: 'line', x1: 0, y1: 0, x2: 483, y2: 0, lineWidth: h.depth === 1 ? 1.6 : 0.8, lineColor: h.depth === 1 ? TEAL : LINE }],
            margin: [0, 0, 0, 8],
          });
        break;
      }
      case 'paragraph': {
        const p = t as Tokens.Paragraph;
        if (isImg(p.tokens)) out.push({ image: (p.tokens[0] as Tokens.Image).href, fit: [483, 520], margin: [0, 2, 0, 10] });
        else out.push({ text: inlines(p.tokens), style: 'p' });
        break;
      }
      case 'list': {
        const l = t as Tokens.List;
        const items = l.items.map((it) => {
          const body = blocks(it.tokens.filter((x) => x.type !== 'checkbox'));
          if (it.task) {
            // Noto Sans Mono'da □ ve ■ var: boş ve işaretli kutu
            const box = it.checked ? '■ ' : '□ ';
            if (body[0]?.text !== undefined) body[0] = { ...body[0], text: [{ text: box, font: 'Mono', color: TEAL }, ...[].concat(body[0].text)] };
          }
          return body.length === 1 ? { ...body[0], margin: [0, 0, 0, 3] } : { stack: body, margin: [0, 0, 0, 3] };
        });
        const any = l.items.some((i) => i.task);
        out.push(
          l.ordered
            ? { ol: items, start: Number(l.start) || 1, margin: [4, 0, 0, 10] }
            : { ul: items, margin: [4, 0, 0, 10], ...(any ? { type: 'none' } : {}) },
        );
        break;
      }
      case 'text': {
        // Liste maddesinin içindeki düz metin
        const x = t as Tokens.Text;
        out.push({ text: x.tokens ? inlines(x.tokens) : decode(x.text), style: 'p', margin: [0, 0, 0, 2] });
        break;
      }
      case 'code':
        out.push({
          table: { widths: ['*'], body: [[{ text: (t as Tokens.Code).text, font: 'Mono', fontSize: 9, preserveLeadingSpaces: true, color: '#26304f' }]] },
          layout: { fillColor: SOFT, hLineColor: '#e8dcc7', vLineColor: '#e8dcc7', paddingLeft: () => 10, paddingRight: () => 10, paddingTop: () => 8, paddingBottom: () => 8 },
          margin: [0, 2, 0, 12],
        });
        break;
      case 'blockquote':
        out.push({
          table: { widths: ['*'], body: [[{ stack: blocks((t as Tokens.Blockquote).tokens), color: '#4a5378', italics: true }]] },
          layout: {
            fillColor: '#f7f2e9',
            hLineWidth: () => 0,
            vLineWidth: (i: number) => (i === 0 ? 3 : 0),
            vLineColor: () => TEAL,
            paddingLeft: () => 12,
            paddingTop: () => 6,
            paddingBottom: () => 0,
          },
          margin: [0, 2, 0, 12],
        });
        break;
      case 'table': {
        const tb = t as Tokens.Table;
        const align = (a: string | null) => (a === 'center' ? 'center' : a === 'right' ? 'right' : 'left');
        out.push({
          table: {
            headerRows: 1,
            widths: tb.header.map(() => '*'),
            body: [
              tb.header.map((c, i) => ({ text: inlines(c.tokens), bold: true, fillColor: SOFT, alignment: align(tb.align[i]) })),
              ...tb.rows.map((r) => r.map((c, i) => ({ text: inlines(c.tokens), alignment: align(tb.align[i]) }))),
            ],
          },
          layout: { hLineColor: () => LINE, vLineColor: () => LINE, paddingLeft: () => 6, paddingRight: () => 6, paddingTop: () => 4, paddingBottom: () => 4 },
          fontSize: 10,
          margin: [0, 2, 0, 12],
        });
        break;
      }
      case 'hr':
        out.push({ canvas: [{ type: 'line', x1: 0, y1: 0, x2: 483, y2: 0, lineWidth: 0.8, lineColor: LINE }], margin: [0, 8, 0, 14] });
        break;
      case 'html':
        out.push({ text: (t as Tokens.HTML).text, style: 'p', font: 'Mono', fontSize: 9 });
        break;
      case 'space':
        break;
      default:
        if ('text' in t) out.push({ text: decode((t as { text: string }).text), style: 'p' });
    }
  }
  return out;
}

let pdfMakePromise: Promise<any> | null = null;
async function getPdfMake() {
  if (!pdfMakePromise) {
    pdfMakePromise = import('pdfmake/build/pdfmake.js').then((m: any) => {
      const pm = m.default ?? m;
      const f = (n: string) => abs(`vendor/fonts/${n}`);
      pm.addFonts({
        Noto: { normal: f('NotoSans-Regular.ttf'), bold: f('NotoSans-Bold.ttf'), italics: f('NotoSans-Italic.ttf'), bolditalics: f('NotoSans-BoldItalic.ttf') },
        Mono: { normal: f('NotoSansMono-Regular.ttf'), bold: f('NotoSansMono-Regular.ttf'), italics: f('NotoSansMono-Regular.ttf'), bolditalics: f('NotoSansMono-Regular.ttf') },
      });
      // Yalnızca uygulamanın kendi dosyaları (yazı tipleri) indirilebilir; dışarıya istek gitmez
      pm.setUrlAccessPolicy?.((url: string) => url.startsWith(location.origin) || url.startsWith(new URL(document.baseURI).origin));
      return pm;
    });
    pdfMakePromise.catch(() => (pdfMakePromise = null));
  }
  return pdfMakePromise;
}

/** Markdown → PDF (A4) */
export async function mdToPdf(text: string, title: string): Promise<ArrayBuffer> {
  const pm = await getPdfMake();
  const doc = {
    pageSize: 'A4',
    pageMargins: [56, 56, 56, 60],
    info: { title, creator: 'Tura Belge', producer: 'Tura Belge' },
    defaultStyle: { font: 'Noto', fontSize: 10.5, lineHeight: 1.3, color: INK },
    styles: {
      h1: { fontSize: 22, bold: true, color: HEAD, margin: [0, 6, 0, 4] },
      h2: { fontSize: 16, bold: true, color: HEAD, margin: [0, 12, 0, 4] },
      h3: { fontSize: 13, bold: true, color: HEAD, margin: [0, 10, 0, 4] },
      h4: { fontSize: 11.5, bold: true, color: HEAD, margin: [0, 8, 0, 3] },
      h5: { fontSize: 10.5, bold: true, color: HEAD, margin: [0, 6, 0, 2] },
      h6: { fontSize: 10.5, bold: true, color: '#4a5378', margin: [0, 6, 0, 2] },
      p: { margin: [0, 0, 0, 8] },
    },
    content: blocks(mdTokens(text)),
    footer: (page: number, pages: number) =>
      pages > 1 ? { text: `${page} / ${pages}`, alignment: 'center', fontSize: 8.5, color: '#9aa0b4', margin: [0, 20, 0, 0] } : null,
  };
  const buf: Uint8Array = await pm.createPdf(doc).getBuffer();
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
}
