// Tura TeX — projeler ve kullanıcı şablonları (yalnızca bu tarayıcıda, IndexedDB)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createStore, del, get, keys, set } from 'idb-keyval';
import type { TexEngine } from './engine';

export type TexFiles = Record<string, string | Uint8Array>;

export interface TexProject {
  id: string;
  name: string;
  engine: TexEngine;
  main: string;
  files: TexFiles;
  createdAt: number;
  updatedAt: number;
}

export interface UserTemplate {
  id: string;
  name: string;
  desc: string;
  engine: TexEngine;
  files: TexFiles;
  createdAt: number;
}

let projects: ReturnType<typeof createStore> | null = null;
let templates: ReturnType<typeof createStore> | null = null;
const st = () => {
  projects ??= createStore('tura-tex-projects', 'projects');
  templates ??= createStore('tura-tex-templates', 'templates');
  return { projects, templates };
};

export const newId = (p: string) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

async function all<T>(store: ReturnType<typeof createStore>): Promise<T[]> {
  const ids = (await keys(store)) as string[];
  return (await Promise.all(ids.map((id) => get<T>(id, store)))).filter((x): x is Awaited<T> => !!x) as T[];
}

export const listProjects = async () =>
  (await all<TexProject>(st().projects)).sort((a, b) => b.updatedAt - a.updatedAt);
export const getProject = (id: string) => get<TexProject>(id, st().projects);
export const saveProject = (p: TexProject) => set(p.id, p, st().projects);
export const deleteProject = (id: string) => del(id, st().projects);

export const listUserTemplates = async () =>
  (await all<UserTemplate>(st().templates)).sort((a, b) => b.createdAt - a.createdAt);
export const saveUserTemplate = (t: UserTemplate) => set(t.id, t, st().templates);
export const deleteUserTemplate = (id: string) => del(id, st().templates);
