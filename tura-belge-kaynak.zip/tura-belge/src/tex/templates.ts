// Tura TeX — hazır Türkçe şablonlar
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Şablonlar "temel" LaTeX paketiyle derlenecek şekilde yazıldı (pdfLaTeX; xcolor,
// enumitem, tikz gibi paketler kullanılmaz). Türkçe için babel'in içe aktarma yöntemi kullanılır.

export interface TexTemplate {
  id: string;
  name: string;
  desc: string;
  /** Bu şablon için gereken en küçük motor paketi */
  needs: 'temel' | 'genis';
  engine: 'pdflatex' | 'xelatex' | 'lualatex';
  files: Record<string, string>;
}

const TR = String.raw`\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{babel}
\babelprovide[import,main]{turkish}`;

const odev = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=2.5cm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{color}
\definecolor{tura}{RGB}{11,122,143}
\usepackage[hidelinks]{hyperref}

\begin{document}

% ---------------- Kapak ----------------
\begin{titlepage}
  \centering
  {\large ÖRNEK ÜNİVERSİTESİ\par}
  {\normalsize Mühendislik Fakültesi -- Bilgisayar Mühendisliği Bölümü\par}
  \vspace{3cm}
  {\color{tura}\rule{\linewidth}{1.2pt}\par}
  \vspace{0.6cm}
  {\Large\bfseries BLM1011 -- Algoritmalar ve Programlama\par}
  \vspace{0.4cm}
  {\huge\bfseries Ödev 1: Sıralama Algoritmalarının Karşılaştırılması\par}
  \vspace{0.6cm}
  {\color{tura}\rule{\linewidth}{1.2pt}\par}
  \vfill
  \begin{tabular}{rl}
    \textbf{Hazırlayan:} & Ayşe Yılmaz \\
    \textbf{Öğrenci No:} & 24011057 \\
    \textbf{Ders Sorumlusu:} & Dr. Öğr. Üyesi Mehmet Kaya \\
    \textbf{Teslim Tarihi:} & \today \\
  \end{tabular}
\end{titlepage}

\section{Soru 1}
Kabarcık sıralamasının (bubble sort) en kötü durumdaki karmaşıklığını gösteriniz.

\paragraph{Çözüm.} $n$ elemanlı bir dizide dış döngü $n-1$ kez, iç döngü ise en fazla $n-i$ kez çalışır:
\begin{equation}
  T(n) = \sum_{i=1}^{n-1} (n-i) = \frac{n(n-1)}{2} \in O(n^2).
\end{equation}

\section{Soru 2}
Aşağıdaki tablo, farklı boyutlardaki diziler için ölçülen çalışma sürelerini göstermektedir.

\begin{center}
\begin{tabular}{|l|r|r|r|}
  \hline
  \textbf{Algoritma} & \textbf{$n=10^3$} & \textbf{$n=10^4$} & \textbf{$n=10^5$} \\ \hline
  Kabarcık & 4 ms & 410 ms & 41 s \\
  Birleştirme & 0,3 ms & 4 ms & 52 ms \\
  Hızlı sıralama & 0,2 ms & 3 ms & 38 ms \\ \hline
\end{tabular}
\end{center}

\section{Sonuç}
Ölçümler, $O(n \log n)$ karmaşıklığa sahip algoritmaların büyük dizilerde belirgin biçimde daha hızlı olduğunu göstermektedir.

\end{document}
`;

const lab = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=2.2cm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{array}
\usepackage{color}
\definecolor{tura}{RGB}{11,122,143}
\usepackage{fancyhdr}
\setlength{\headheight}{14pt}
\pagestyle{fancy}
\fancyhf{}
\lhead{FİZ 101L -- Deney Raporu}
\rhead{Deney 3}
\cfoot{\thepage}

\begin{document}

\begin{center}
  {\LARGE\bfseries\color{tura} Basit Sarkaç ile Yerçekimi İvmesinin Ölçülmesi\par}
  \vspace{0.3cm}
  \begin{tabular}{|>{\bfseries}l|l|>{\bfseries}l|l|}
    \hline
    Ad Soyad & Ayşe Yılmaz & Numara & 24011057 \\ \hline
    Grup & B2 & Tarih & \today \\ \hline
  \end{tabular}
\end{center}

\section{Amaç}
Basit sarkacın periyodunu farklı ip uzunluklarında ölçerek yerçekimi ivmesini ($g$) belirlemek.

\section{Kuramsal Bilgi}
Küçük açılı salınımlar için basit sarkacın periyodu
\begin{equation}
  T = 2\pi\sqrt{\frac{L}{g}}
  \qquad\Longrightarrow\qquad
  g = \frac{4\pi^2 L}{T^2}
\end{equation}
bağıntısıyla verilir.

\section{Deney Düzeneği ve Yöntem}
Sarkaç $5^\circ$'den küçük bir açıyla serbest bırakılmış, 10 tam salınımın süresi kronometreyle ölçülmüştür.

\section{Ölçümler}
\begin{center}
\begin{tabular}{|c|c|c|c|}
  \hline
  $L$ (m) & $10T$ (s) & $T$ (s) & $g$ (m/s$^2$) \\ \hline
  0,40 & 12,70 & 1,270 & 9,79 \\
  0,60 & 15,55 & 1,555 & 9,80 \\
  0,80 & 17,96 & 1,796 & 9,79 \\ \hline
\end{tabular}
\end{center}

\section{Sonuç ve Yorum}
Ortalama değer $\bar g = 9{,}79$ m/s$^2$ bulunmuştur; kabul edilen değerle ($9{,}81$ m/s$^2$) arasındaki bağıl hata yaklaşık \%0,2'dir.

\begin{thebibliography}{9}
  \bibitem{serway} R. A. Serway, J. W. Jewett, \emph{Fen ve Mühendislik için Fizik}, Palme Yayıncılık.
\end{thebibliography}

\end{document}
`;

const staj = String.raw`\documentclass[12pt,a4paper]{article}
${TR}
\usepackage[margin=2.5cm]{geometry}
\usepackage{graphicx}
\usepackage{array}
\usepackage{longtable}
\usepackage[hidelinks]{hyperref}
\linespread{1.3}

\begin{document}

\begin{titlepage}
  \centering
  {\Large ÖRNEK ÜNİVERSİTESİ\par}
  {\large Bilgisayar Mühendisliği Bölümü\par}
  \vspace{4cm}
  {\Huge\bfseries STAJ RAPORU\par}
  \vspace{1cm}
  {\Large Örnek Teknoloji A.Ş.\par}
  {\large 7 Temmuz -- 15 Ağustos 2027\par}
  \vfill
  {\large Ayşe Yılmaz \quad 24011057\par}
\end{titlepage}

\tableofcontents
\newpage

\section{Kurum Hakkında}
Örnek Teknoloji A.Ş., 2010 yılında kurulmuş, kurumsal yazılım geliştiren bir şirkettir.

\section{Yapılan Çalışmalar}
\subsection{Haftalık Özet}
\begin{longtable}{|p{2.2cm}|p{11cm}|}
  \hline
  \textbf{Hafta} & \textbf{Yapılan iş} \\ \hline \endhead
  1. hafta & Şirket tanıtımı, geliştirme ortamının kurulması. \\ \hline
  2. hafta & Mevcut projenin kod yapısının incelenmesi. \\ \hline
  3. hafta & Kullanıcı arayüzünde yeni bir form bileşeni geliştirilmesi. \\ \hline
  4. hafta & Birim testlerinin yazılması ve kod incelemesi. \\ \hline
\end{longtable}

\subsection{Kullanılan Teknolojiler}
\begin{itemize}
  \item TypeScript ve React
  \item PostgreSQL veritabanı
  \item Git ile sürüm kontrolü
\end{itemize}

\section{Sonuç}
Staj süresince yazılım geliştirme süreçlerini yerinde gözlemleme ve gerçek bir projeye katkı verme fırsatı buldum.

\end{document}
`;

const cv = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=1.8cm]{geometry}
\usepackage{tabularx}
\usepackage{color}
\definecolor{tura}{RGB}{11,122,143}
\definecolor{koyu}{RGB}{20,32,90}
\usepackage[hidelinks]{hyperref}
\pagestyle{empty}
\setlength{\parindent}{0pt}

\newcommand{\bolum}[1]{\vspace{10pt}{\large\bfseries\color{tura}#1}\par\vspace{-4pt}{\color{tura}\rule{\linewidth}{0.6pt}}\par\vspace{4pt}}
\newcommand{\satir}[3]{\textbf{#1} \hfill {\small #2}\par {\small #3}\par\vspace{6pt}}

\begin{document}

{\Huge\bfseries\color{koyu} Ayşe Yılmaz}\par
\vspace{4pt}
{\large Bilgisayar Mühendisliği Öğrencisi}\par
\vspace{6pt}
{\small İstanbul \quad·\quad ayse@ornek.com \quad·\quad +90 555 000 00 00 \quad·\quad github.com/ayse}\par

\bolum{Eğitim}
\satir{Örnek Üniversitesi -- Bilgisayar Mühendisliği (Lisans)}{2024 -- 2028}{Not ortalaması: 3,45 / 4,00}

\bolum{Deneyim}
\satir{Örnek Teknoloji A.Ş. -- Yazılım Stajyeri}{Temmuz -- Ağustos 2027}{React ile kullanıcı arayüzü bileşenleri geliştirdim; birim testleriyle kod kapsamını \%60'tan \%80'e çıkardım.}
\satir{Üniversite Robotik Kulübü -- Yazılım Ekibi}{2025 -- günümüz}{Otonom araç yarışması için görüntü işleme modülü yazdım.}

\bolum{Beceriler}
\begin{tabularx}{\linewidth}{@{}lX@{}}
  \textbf{Programlama} & Python, TypeScript, C, SQL \\
  \textbf{Araçlar} & Git, Docker, Linux, \LaTeX \\
  \textbf{Diller} & Türkçe (ana dil), İngilizce (B2), Almanca (A2) \\
\end{tabularx}

\bolum{Projeler}
\satir{Tura Belge}{2026}{Tarayıcıda çalışan açık kaynak PDF düzenleyici; not alma, imza ve PDF araçları.}

\end{document}
`;

const sinav = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=2cm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{multicol}
\usepackage{array}
\pagestyle{empty}
\setlength{\parindent}{0pt}

\newcounter{soru}
\newcommand{\soru}[1]{\stepcounter{soru}\par\vspace{10pt}\textbf{Soru \thesoru.} {\small(#1 puan)}\quad}

\begin{document}

\begin{center}
  {\large\bfseries ÖRNEK ÜNİVERSİTESİ -- MAT 101 MATEMATİK I}\par
  {\large\bfseries ARA SINAV}\par
\end{center}
\vspace{4pt}
\begin{tabular}{|p{8.6cm}|p{3.4cm}|p{3.4cm}|}
  \hline
  Ad Soyad: & No: & Puan: \\[14pt] \hline
\end{tabular}
\par\vspace{4pt}
{\small Süre 70 dakikadır. Hesap makinesi kullanılamaz. Çözümlerinizi ayrıntılı yazınız.}

\soru{20} $\displaystyle \lim_{x\to 0} \frac{\sin 3x}{x}$ limitini hesaplayınız.
\vspace{3cm}

\soru{25} $f(x) = x^3 - 3x^2 + 2$ fonksiyonunun yerel ekstremum noktalarını bulunuz.
\vspace{3.5cm}

\soru{15} Aşağıdakilerden hangisi $\int 2x\,dx$ ifadesine eşittir?
\begin{multicols}{4}
  a) $x^2 + C$ \par
  b) $2x^2 + C$ \par
  c) $x + C$ \par
  d) $\frac{x^2}{2} + C$
\end{multicols}

\soru{40} $\displaystyle \int_0^1 x e^{x}\,dx$ integralini kısmi integrasyon yöntemiyle hesaplayınız.
\vspace{4cm}

\begin{center}\small Başarılar dileriz.\end{center}
\end{document}
`;

const dersNotu = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=2.4cm]{geometry}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{color}
\definecolor{tura}{RGB}{11,122,143}
\definecolor{kum}{RGB}{251,235,210}
\usepackage[hidelinks]{hyperref}

\theoremstyle{definition}
\newtheorem{tanim}{Tanım}[section]
\newtheorem{ornek}{Örnek}[section]
\theoremstyle{plain}
\newtheorem{teorem}{Teorem}[section]

\newcommand{\onemli}[1]{\par\vspace{6pt}\noindent\fcolorbox{tura}{kum}{\parbox{\dimexpr\linewidth-2\fboxsep-2\fboxrule}{#1}}\par\vspace{6pt}}

\title{\color{tura}MAT 101 -- Ders Notları\\\large 4. Hafta: Türev}
\author{Ayşe Yılmaz}
\date{\today}

\begin{document}
\maketitle

\section{Türevin Tanımı}
\begin{tanim}
$f$ fonksiyonunun $a$ noktasındaki türevi, limit varsa
\[ f'(a) = \lim_{h\to 0}\frac{f(a+h)-f(a)}{h} \]
olarak tanımlanır.
\end{tanim}

\onemli{\textbf{Unutma:} Türevli her fonksiyon süreklidir; ancak her sürekli fonksiyon türevli değildir (ör. $|x|$, $x=0$'da).}

\section{Türev Kuralları}
\begin{teorem}[Çarpım kuralı]
$(fg)' = f'g + fg'$.
\end{teorem}

\begin{ornek}
$h(x) = x^2 \sin x$ ise $h'(x) = 2x\sin x + x^2\cos x$ olur.
\end{ornek}

\end{document}
`;

const dilekce = String.raw`\documentclass[12pt,a4paper]{article}
${TR}
\usepackage[margin=2.5cm]{geometry}
\pagestyle{empty}
\setlength{\parindent}{1.25cm}
\linespread{1.4}

\begin{document}

\begin{flushright}
\today
\end{flushright}

\vspace{1cm}
\begin{center}
\textbf{ÖRNEK ÜNİVERSİTESİ\\
MÜHENDİSLİK FAKÜLTESİ DEKANLIĞINA}
\end{center}

\vspace{0.8cm}
Fakülteniz Bilgisayar Mühendisliği Bölümü 2. sınıf öğrencisiyim. 2026--2027 Güz yarıyılında almakta olduğum
BLM2011 Veri Yapıları dersinin ara sınavına, ekte sunduğum sağlık raporu nedeniyle katılamadım.

Söz konusu ders için mazeret sınavı hakkı tanınması hususunda gereğinin yapılmasını arz ederim.

\vspace{1.5cm}
\begin{flushright}
\begin{tabular}{c}
Ayşe Yılmaz \\[1.2cm]
(İmza)
\end{tabular}
\end{flushright}

\vspace{1cm}
\noindent
\begin{tabular}{@{}ll}
\textbf{Öğrenci No:} & 24011057 \\
\textbf{Telefon:} & +90 555 000 00 00 \\
\textbf{Adres:} & Örnek Mah. Deneme Sok. No: 1, İstanbul \\
\end{tabular}

\vspace{0.8cm}
\noindent\textbf{Ek:} Sağlık raporu (1 sayfa)

\end{document}
`;

const bos = String.raw`\documentclass[11pt,a4paper]{article}
${TR}
\usepackage[margin=2.5cm]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}

\title{Başlık}
\author{Adınız Soyadınız}
\date{\today}

\begin{document}
\maketitle

\section{Giriş}
Yazmaya buradan başlayın.

\end{document}
`;

const sunum = String.raw`\documentclass{beamer}
${TR}
\usetheme{Madrid}
\usecolortheme{seahorse}
\title{Proje Sunumu}
\subtitle{Tura Belge: Açık Kaynak PDF Düzenleyici}
\author{Ayşe Yılmaz}
\date{\today}

\begin{document}
\frame{\titlepage}

\begin{frame}{Amaç}
  \begin{itemize}
    \item Öğrenciler için ücretsiz bir PDF düzenleyici
    \item Not alma, imza, tarama
    \item Tamamen tarayıcıda çalışma
  \end{itemize}
\end{frame}

\begin{frame}{Sonuç}
  Teşekkürler! Sorularınız?
\end{frame}
\end{document}
`;

export const TEMPLATES: TexTemplate[] = [
  { id: 'odev', name: 'Ödev', desc: 'Kapak sayfası, sorular, denklemler ve tablo.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': odev } },
  { id: 'lab', name: 'Laboratuvar raporu', desc: 'Amaç, kuram, ölçüm tablosu, sonuç ve kaynakça.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': lab } },
  { id: 'staj', name: 'Staj raporu', desc: 'Kapak, içindekiler, haftalık çalışma tablosu.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': staj } },
  { id: 'cv', name: 'Özgeçmiş (CV)', desc: 'Tek sayfalık, sade ve renkli başlıklı özgeçmiş.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': cv } },
  { id: 'sinav', name: 'Sınav kâğıdı', desc: 'Öğrenci bilgi tablosu, puanlı sorular, çoktan seçmeli.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': sinav } },
  { id: 'ders-notu', name: 'Ders notu', desc: 'Tanım, teorem, örnek kutuları ve vurgu kutusu.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': dersNotu } },
  { id: 'dilekce', name: 'Dilekçe', desc: 'Dekanlığa/bölüme resmi dilekçe biçimi.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': dilekce } },
  { id: 'sunum', name: 'Sunum (Beamer)', desc: 'Slayt sunumu; geniş LaTeX paketi gerekir.', needs: 'genis', engine: 'pdflatex', files: { 'main.tex': sunum } },
  { id: 'bos', name: 'Boş belge', desc: 'Türkçe ayarları hazır, boş bir makale.', needs: 'temel', engine: 'pdflatex', files: { 'main.tex': bos } },
];
