// Tura TeX — düzenleyici: kod, canlı PDF önizleme, hata listesi
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { zipSync, strToU8 } from 'fflate';
import { BrandMark } from '../components/Brand';
import { downloadFile, downloadPdf } from '../lib/download';
import { useToolHost } from '../tools/host';
import { Thumb, useRenderDoc } from '../tools/ui';
import { CodeEditor, type CodeEditorHandle } from './CodeEditor';
import { compileTex, installedPackages, texManifest, type TexEngine, type TexError, type TexManifest } from './engine';
import { getProject, newId, saveProject, saveUserTemplate, type TexProject } from './store';
import { __, N_, fmtNum } from '../i18n';

type Status = { kind: 'idle' | 'loading' | 'compiling' | 'ok' | 'error'; text: string };

const SNIPPETS: { label: string; title: string; text: string }[] = [
  { label: N_('Başlık'), title: N_('Bölüm başlığı'), text: '\\section{Başlık}\n' },
  { label: N_('Alt başlık'), title: N_('Alt bölüm başlığı'), text: '\\subsection{Alt başlık}\n' },
  { label: 'K', title: N_('Kalın yazı'), text: '\\textbf{kalın}' },
  { label: 'İ', title: N_('İtalik yazı'), text: '\\emph{italik}' },
  { label: N_('Liste'), title: N_('Madde işaretli liste'), text: '\\begin{itemize}\n  \\item Birinci madde\n  \\item İkinci madde\n\\end{itemize}\n' },
  { label: N_('Numaralı'), title: N_('Numaralı liste'), text: '\\begin{enumerate}\n  \\item Birinci\n  \\item İkinci\n\\end{enumerate}\n' },
  { label: N_('Denklem'), title: N_('Numaralı denklem'), text: '\\begin{equation}\n  E = mc^2\n\\end{equation}\n' },
  { label: N_('Kesir'), title: N_('Kesir'), text: '$\\frac{a}{b}$' },
  { label: N_('Tablo'), title: N_('3 sütunlu tablo'), text: '\\begin{center}\n\\begin{tabular}{|l|c|r|}\n  \\hline\n  A & B & C \\\\ \\hline\n  1 & 2 & 3 \\\\ \\hline\n\\end{tabular}\n\\end{center}\n' },
  { label: N_('Görsel'), title: N_('Eklenen görseli yerleştir'), text: '\\begin{center}\n  \\includegraphics[width=0.6\\linewidth]{gorsel.png}\n\\end{center}\n' },
];

const TEXT_EXT = /\.(tex|bib|sty|cls|txt|bst)$/i;
const isText = (path: string) => TEXT_EXT.test(path);

export function TexEditor({ projectId, onNavigate }: { projectId: string; onNavigate: (hash: string) => void }) {
  const host = useToolHost();
  const [project, setProject] = useState<TexProject | null>(null);
  const [missing, setMissing] = useState(false);
  const [file, setFile] = useState('main.tex');
  const [manifest, setManifest] = useState<TexManifest | null | undefined>(undefined);
  const [status, setStatus] = useState<Status>({ kind: 'idle', text: __('Derlemek için “Derle”ye bas') });
  const [pdf, setPdf] = useState<ArrayBuffer | null>(null);
  const [errors, setErrors] = useState<TexError[]>([]);
  const [log, setLog] = useState('');
  const [showLog, setShowLog] = useState(false);
  const [auto, setAuto] = useState(true);
  const [engineReady, setEngineReady] = useState(false);
  const [pane, setPane] = useState<'code' | 'preview'>('code');
  const [menu, setMenu] = useState(false);
  const [tplForm, setTplForm] = useState<{ name: string; desc: string } | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const editor = useRef<CodeEditorHandle>(null);
  const saveTimer = useRef<number | undefined>(undefined);
  const compileTimer = useRef<number | undefined>(undefined);
  const projectRef = useRef<TexProject | null>(null);
  projectRef.current = project;
  const compiling = useRef(false);
  const again = useRef(false);
  const addRef = useRef<HTMLInputElement>(null);
  const { doc } = useRenderDoc(pdf);

  const flash = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 3000);
  };

  useEffect(() => {
    getProject(projectId).then((p) => (p ? setProject(p) : setMissing(true)));
    void texManifest().then(setManifest);
  }, [projectId]);

  const persist = useCallback((p: TexProject) => {
    window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => void saveProject(p), 600);
  }, []);
  useEffect(() => () => {
    window.clearTimeout(saveTimer.current);
    window.clearTimeout(compileTimer.current);
    if (projectRef.current) void saveProject(projectRef.current);
  }, []);

  const compile = useCallback(async () => {
    const p = projectRef.current;
    if (!p || !manifest) return;
    if (compiling.current) {
      again.current = true;
      return;
    }
    compiling.current = true;
    setStatus({ kind: engineReady ? 'compiling' : 'loading', text: engineReady ? __('Derleniyor…') : __('LaTeX motoru hazırlanıyor…') });
    try {
      const files = Object.entries(p.files).map(([path, content]) => ({ path, content }));
      const res = await compileTex(files, p.main, p.engine, (pr) => {
        if (pr.phase === 'download') setStatus({ kind: 'loading', text: __('LaTeX motoru indiriliyor… %{0}', [Math.round(pr.percent ?? 0)]) });
        else if (pr.phase === 'init') setStatus({ kind: 'loading', text: __('LaTeX motoru başlatılıyor…') });
        else setStatus({ kind: 'compiling', text: __('Derleniyor…') });
      });
      setEngineReady(true);
      setLog(res.log);
      if (res.ok && res.pdf) {
        setPdf(res.pdf.buffer.slice(res.pdf.byteOffset, res.pdf.byteOffset + res.pdf.byteLength) as ArrayBuffer);
        setErrors([]);
        setStatus({ kind: 'ok', text: __('Derlendi · {0} sn', [fmtNum(res.ms / 1000)]) });
      } else {
        // Eksik paket varsa kurulu listeye göre açıkla
        const pkgs = await installedPackages();
        const errs = res.errors.length ? res.errors : [{ message: __('Derleme başarısız; ayrıntılar günlükte.') }];
        setErrors(
          errs.map((e) =>
            e.missingPackage && !pkgs.has(e.missingPackage)
              ? { ...e, message: __('{0} Daha geniş bir LaTeX paketi (genis/tam) kurulmalı ya da bu paket kaldırılmalı.', [e.message]) }
              : e,
          ),
        );
        setStatus({ kind: 'error', text: __('{0} hata', [errs.filter((e) => !/Fatal error/.test(e.message)).length || 1]) });
      }
    } catch (err) {
      console.error(err);
      setStatus({ kind: 'error', text: __('LaTeX motoru yüklenemedi') });
      setErrors([{ message: __('LaTeX motoru yüklenemedi. İnternet bağlantını kontrol edip tekrar dene.') }]);
    } finally {
      compiling.current = false;
      if (again.current) {
        again.current = false;
        void compile();
      }
    }
  }, [manifest, engineReady]);

  const update = (patch: Partial<TexProject>) => {
    setProject((p) => {
      if (!p) return p;
      const next = { ...p, ...patch, updatedAt: Date.now() };
      persist(next);
      return next;
    });
  };

  const onCode = (text: string) => {
    const p = projectRef.current;
    if (!p) return;
    update({ files: { ...p.files, [file]: text } });
    if (auto && engineReady) {
      window.clearTimeout(compileTimer.current);
      compileTimer.current = window.setTimeout(() => void compile(), 1400);
    }
  };

  const addFiles = async (list: FileList | File[]) => {
    const p = projectRef.current;
    if (!p) return;
    const files = { ...p.files };
    let last = '';
    for (const f of Array.from(list)) {
      const name = f.name.replace(/[^\p{L}\p{N}._-]+/gu, '-');
      files[name] = isText(name) ? await f.text() : new Uint8Array(await f.arrayBuffer());
      last = name;
    }
    update({ files });
    if (last && isText(last)) setFile(last);
    flash(__('{0} dosya eklendi', [Array.from(list).length]));
  };

  const removeFile = (path: string) => {
    const p = projectRef.current;
    if (!p || path === p.main) return;
    const files = { ...p.files };
    delete files[path];
    update({ files });
    if (file === path) setFile(p.main);
  };

  const exportZip = async () => {
    const p = projectRef.current;
    if (!p) return;
    const entries: Record<string, Uint8Array> = {};
    for (const [k, v] of Object.entries(p.files)) entries[k] = typeof v === 'string' ? strToU8(v) : v;
    if (Object.keys(entries).length === 1) {
      await downloadFile(`${p.name}.tex`, new Blob([p.files[p.main] as string], { type: 'text/plain' }));
    } else {
      const zip = zipSync(entries);
      await downloadFile(`${p.name}.zip`, new Blob([zip as BlobPart], { type: 'application/zip' }));
    }
    setMenu(false);
  };

  const saveTemplate = async () => {
    const p = projectRef.current;
    if (!p || !tplForm?.name.trim()) return;
    await saveUserTemplate({ id: newId('tpl'), name: tplForm.name.trim(), desc: tplForm.desc.trim(), engine: p.engine, files: p.files, createdAt: Date.now() });
    setTplForm(null);
    flash(__('Şablon kaydedildi; “LaTeX ile oluştur” sayfasında “Şablonlarım”da'))
  };

  const current = project?.files[file];
  const textFiles = useMemo(() => (project ? Object.keys(project.files) : []), [project]);

  if (missing)
    return (
      <div className="loading">
        <p>{__('Proje bulunamadı.')}</p>
        <button className="btn btn--primary" onClick={() => onNavigate('tex')}>
          {__('LaTeX projelerine dön')}
        </button>
      </div>
    );
  if (!project) return <div className="loading">{__('Açılıyor…')}</div>;

  return (
    <div className={`tex tex--${pane}`}>
      <header className="editbar">
        <button className="btn btn--ghost editbar__back" onClick={() => onNavigate('tex')} aria-label={__('LaTeX projelerine dön')}>
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span className="hide-sm">{__('LaTeX projeleri')}</span>
        </button>
        <BrandMark size={22} />
        <label className="editbar__name">
          <span className="sr-only">{__('Proje adı')}</span>
          <input value={project.name} onChange={(e) => update({ name: e.target.value })} spellCheck={false} />
        </label>
        <select
          className="input tex__engine"
          aria-label={__('LaTeX motoru')}
          value={project.engine}
          onChange={(e) => update({ engine: e.target.value as TexEngine })}
          title={__('pdfLaTeX önerilir; XeLaTeX/LuaLaTeX fontspec ile özel yazı tipleri için')}
        >
          <option value="pdflatex">{__('pdfLaTeX')}</option>
          <option value="xelatex">{__('XeLaTeX')}</option>
          <option value="lualatex">{__('LuaLaTeX')}</option>
        </select>
        <span className={`status status--tex-${status.kind}`} aria-live="polite">
          <i aria-hidden="true" />
          <span className="hide-sm">{status.text}</span>
        </span>
        <button className="btn btn--primary" onClick={() => void compile()} disabled={!manifest || status.kind === 'loading'} title={__('Derle (Ctrl+S)')}>
          {__('Derle')}
        </button>
        <div className="menuwrap">
          <button className="btn btn--ghost" aria-haspopup="menu" aria-expanded={menu} onClick={() => setMenu((v) => !v)}>
            {__('Dışa aktar')}
          </button>
          {menu && (
            <div className="popmenu" role="menu">
              <button role="menuitem" disabled={!pdf} onClick={async () => (pdf && (await host.openInEditor(project.name, pdf.slice(0))), setMenu(false))}>
                <span className="popmenu__dot" aria-hidden="true" />
                {__('Tura Belge’de aç (not al, imzala)')}
              </button>
              <button role="menuitem" disabled={!pdf} onClick={async () => (pdf && (await downloadPdf(project.name, pdf.slice(0))), setMenu(false))}>
                <span className="popmenu__dot" aria-hidden="true" />
                {__('PDF olarak indir')}
              </button>
              <button role="menuitem" onClick={exportZip}>
                <span className="popmenu__dot" aria-hidden="true" />
                {Object.keys(project.files).length > 1 ? __('Kaynak dosyaları indir (ZIP)') : __('.tex dosyasını indir')}
              </button>
              <hr />
              <button role="menuitem" onClick={() => (setTplForm({ name: project.name, desc: '' }), setMenu(false))}>
                <span className="popmenu__dot" aria-hidden="true">+</span>
                {__('Şablon olarak kaydet')}
              </button>
            </div>
          )}
        </div>
      </header>

      {manifest === null && (
        <div className="linkbar linkbar--warn">
          <span>{__('Bu kurulumda LaTeX motoru yok; yazabilir ve .tex indirebilirsin ama derleme yapılamaz.')}</span>
        </div>
      )}
      {tplForm && (
        <form
          className="linkbar"
          onSubmit={(e) => {
            e.preventDefault();
            void saveTemplate();
          }}
        >
          <input className="input" aria-label={__('Şablon adı')} placeholder={__('Şablon adı')} value={tplForm.name} onChange={(e) => setTplForm({ ...tplForm, name: e.target.value })} />
          <input className="input" aria-label={__('Kısa açıklama')} placeholder={__('Kısa açıklama (isteğe bağlı)')} value={tplForm.desc} onChange={(e) => setTplForm({ ...tplForm, desc: e.target.value })} />
          <button className="btn btn--primary btn--sm" type="submit" disabled={!tplForm.name.trim()}>
            {__('Kaydet')}
          </button>
          <button className="btn btn--ghost btn--sm" type="button" onClick={() => setTplForm(null)}>
            {__('Vazgeç')}
          </button>
        </form>
      )}

      <div className="tex__switch" role="tablist" aria-label={__('Görünüm')}>
        <button role="tab" aria-selected={pane === 'code'} onClick={() => setPane('code')}>
          {__('Kod')}
        </button>
        <button role="tab" aria-selected={pane === 'preview'} onClick={() => setPane('preview')}>
          {__('Önizleme')} {errors.length > 0 && <span className="chip chip--err">{errors.length}</span>}
        </button>
      </div>

      <div className="tex__body">
        <section className="tex__code" aria-label={__('Kaynak')}>
          <div className="tex__files" role="tablist" aria-label={__('Dosyalar')}>
            {textFiles.map((f) => (
              <span key={f} className={f === file ? 'texfile texfile--on' : 'texfile'}>
                <button role="tab" aria-selected={f === file} onClick={() => setFile(f)}>
                  {f}
                </button>
                {f !== project.main && (
                  <button className="texfile__x" aria-label={__('{0} dosyasını kaldır', [f])} onClick={() => removeFile(f)}>
                    ×
                  </button>
                )}
              </span>
            ))}
            <button className="texfile texfile--add" onClick={() => addRef.current?.click()} title={__('Görsel (.png, .jpg, .pdf), .bib ya da .tex ekle')}>
              {__('+ Dosya')}
            </button>
            <input ref={addRef} type="file" multiple hidden accept=".png,.jpg,.jpeg,.pdf,.bib,.tex,.sty,.cls" onChange={(e) => e.target.files && void addFiles(e.target.files)} />
          </div>
          {typeof current === 'string' ? (
            <>
              <div className="snippets" role="toolbar" aria-label={__('Hızlı ekle')}>
                {SNIPPETS.map((s) => (
                  <button key={s.label} title={__(s.title)} onClick={() => editor.current?.insert(s.text)}>
                    {s.label === 'K' ? <b>{__('K')}</b> : s.label === 'İ' ? <i>{__('İ')}</i> : __(s.label)}
                  </button>
                ))}
              </div>
              <div
                className="tex__editor"
                onDragOver={(e) => e.dataTransfer.types.includes('Files') && e.preventDefault()}
                onDrop={(e) => {
                  if (!e.dataTransfer.files.length) return;
                  e.preventDefault();
                  void addFiles(e.dataTransfer.files);
                }}
              >
                <CodeEditor ref={editor} docKey={`${project.id}:${file}`} value={current} onChange={onCode} onCompile={() => void compile()} />
              </div>
            </>
          ) : (
            <div className="tex__binary">
              <p>
                <b>{file}</b> {__('ikili bir dosya (')}{current ? Math.round((current as Uint8Array).byteLength / 1024) : 0} {__('KB). Belgede')}{' '}
                <code>{__('\\includegraphics')}{'{'}
                {file}
                {'}'}</code>{' '}
                {__('ile kullanabilirsin.')}
              </p>
            </div>
          )}
        </section>

        <section className="tex__preview" aria-label={__('PDF önizleme')}>
          <div className="tex__previewbar">
            <label className="check check--sm">
              <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
              <span>{__('Yazarken otomatik derle')}</span>
            </label>
            {doc && <span className="muted">{doc.pageCount} {__('sayfa')}</span>}
            <button className="link-btn" onClick={() => setShowLog((v) => !v)}>
              {showLog ? __('Günlüğü gizle') : __('Günlüğü göster')}
            </button>
          </div>
          {errors.length > 0 && (
            <ul className="texerrors" role="alert">
              {errors
                .filter((e) => !/Fatal error occurred/.test(e.message) || errors.length === 1)
                .map((e, i) => (
                  <li key={i}>
                    {e.line ? (
                      <button className="link-btn" onClick={() => (setFile(project.main), setPane('code'), window.setTimeout(() => editor.current?.gotoLine(e.line!), 50))}>
                        {__('Satır')} {e.line}
                      </button>
                    ) : null}
                    <span>{e.message}</span>
                  </li>
                ))}
            </ul>
          )}
          {showLog && <pre className="texlog">{log || __('Henüz derleme yapılmadı.')}</pre>}
          <div className="tex__pages">
            {doc ? (
              Array.from({ length: doc.pageCount }, (_, i) => (
                <div key={`${i}-${pdf?.byteLength}`} className="tex__page">
                  <Thumb doc={doc} index={i} width={880} />
                </div>
              ))
            ) : (
              <div className="tex__empty">
                <p>{manifest ? __('PDF önizlemesi burada görünecek.') : __('Önizleme için LaTeX motoru gerekli.')}</p>
                {manifest && !engineReady && (
                  <button className="btn btn--primary" onClick={() => void compile()} disabled={status.kind === 'loading'}>
                    {status.kind === 'loading' ? status.text : __('İlk derlemeyi başlat')}
                  </button>
                )}
              </div>
            )}
          </div>
        </section>
      </div>
      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
    </div>
  );
}
