// Tura TeX — LaTeX kod düzenleyici (CodeMirror 6)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { EditorView, basicSetup } from 'codemirror';
import { EditorState } from '@codemirror/state';
import { keymap } from '@codemirror/view';
import { indentWithTab } from '@codemirror/commands';
import { StreamLanguage, HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { stex } from '@codemirror/legacy-modes/mode/stex';
import { tags } from '@lezer/highlight';
import { __ } from '../i18n';

export interface CodeEditorHandle {
  gotoLine: (line: number) => void;
  focus: () => void;
  insert: (text: string) => void;
}

const turaHighlight = HighlightStyle.define([
  { tag: tags.keyword, color: 'var(--cm-kw)' },
  { tag: [tags.tagName, tags.typeName], color: 'var(--cm-tag)', fontWeight: '600' },
  { tag: tags.comment, color: 'var(--cm-comment)', fontStyle: 'italic' },
  { tag: [tags.bracket, tags.brace], color: 'var(--cm-bracket)' },
  { tag: [tags.string, tags.special(tags.string)], color: 'var(--cm-str)' },
  { tag: [tags.number, tags.atom], color: 'var(--cm-num)' },
  { tag: tags.variableName, color: 'var(--cm-var)' },
]);

const theme = EditorView.theme({
  '&': { height: '100%', fontSize: '15px', backgroundColor: 'var(--cm-bg)', color: 'var(--ink)' },
  '.cm-scroller': { fontFamily: "'JetBrains Mono', 'Cascadia Code', Consolas, 'Courier New', monospace", lineHeight: '1.6' },
  '.cm-gutters': { backgroundColor: 'var(--cm-gutter)', color: 'var(--muted)', border: 'none' },
  '.cm-activeLine': { backgroundColor: 'var(--cm-active)' },
  '.cm-activeLineGutter': { backgroundColor: 'var(--cm-active)' },
  '&.cm-focused .cm-cursor': { borderLeftColor: 'var(--teal)' },
  '&.cm-focused .cm-selectionBackground, .cm-selectionBackground': { backgroundColor: 'var(--cm-sel) !important' },
  '.cm-errorLine': { backgroundColor: 'var(--cm-err)' },
});

interface Props {
  value: string;
  onChange: (v: string) => void;
  onCompile?: () => void;
  docKey: string;
}

export const CodeEditor = forwardRef<CodeEditorHandle, Props>(function CodeEditor({ value, onChange, onCompile, docKey }, ref) {
  const host = useRef<HTMLDivElement>(null);
  const view = useRef<EditorView | null>(null);
  const changeRef = useRef(onChange);
  changeRef.current = onChange;
  const compileRef = useRef(onCompile);
  compileRef.current = onCompile;

  useEffect(() => {
    if (!host.current) return;
    const v = new EditorView({
      parent: host.current,
      state: EditorState.create({
        doc: value,
        extensions: [
          basicSetup,
          StreamLanguage.define(stex),
          syntaxHighlighting(turaHighlight),
          theme,
          EditorView.lineWrapping,
          keymap.of([
            indentWithTab,
            { key: 'Mod-s', preventDefault: true, run: () => (compileRef.current?.(), true) },
            { key: 'Mod-Enter', preventDefault: true, run: () => (compileRef.current?.(), true) },
          ]),
          EditorView.updateListener.of((u) => u.docChanged && changeRef.current(u.state.doc.toString())),
          EditorView.contentAttributes.of({ 'aria-label': __('LaTeX kaynak kodu'), spellcheck: 'false', autocapitalize: 'off' }),
        ],
      }),
    });
    view.current = v;
    return () => v.destroy();
    // Dosya değişince düzenleyici baştan kurulur
  }, [docKey]); // eslint-disable-line react-hooks/exhaustive-deps

  useImperativeHandle(ref, () => ({
    gotoLine: (line) => {
      const v = view.current;
      if (!v) return;
      const l = v.state.doc.line(Math.max(1, Math.min(line, v.state.doc.lines)));
      v.dispatch({ selection: { anchor: l.from, head: l.to }, effects: EditorView.scrollIntoView(l.from, { y: 'center' }) });
      v.focus();
    },
    focus: () => view.current?.focus(),
    insert: (text) => {
      const v = view.current;
      if (!v) return;
      const { from, to } = v.state.selection.main;
      v.dispatch({ changes: { from, to, insert: text }, selection: { anchor: from + text.length } });
      v.focus();
    },
  }));

  return <div className="code" ref={host} />;
});
