// Tura TeX — giriş: şablonlar, şablonlarım, projelerim
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState } from 'react';
import { TopNav } from '../components/TopNav';
import { texManifest, type TexManifest } from './engine';
import { TEMPLATES, type TexTemplate } from './templates';
import {
  deleteProject,
  deleteUserTemplate,
  listProjects,
  listUserTemplates,
  newId,
  saveProject,
  type TexFiles,
  type TexProject,
  type UserTemplate,
} from './store';
import { __, locale } from '../i18n';

const fmt = (t: number) => new Intl.DateTimeFormat(locale(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(t);
const RANK = { temel: 0, genis: 1, tam: 2 } as const;

export function TexHome({ onNavigate }: { onNavigate: (hash: string) => void }) {
  const [manifest, setManifest] = useState<TexManifest | null | undefined>(undefined);
  const [projects, setProjects] = useState<TexProject[]>([]);
  const [mine, setMine] = useState<UserTemplate[]>([]);
  const [confirm, setConfirm] = useState<string | null>(null);
  const importRef = useRef<HTMLInputElement>(null);

  const refresh = async () => {
    try {
      setProjects(await listProjects());
      setMine(await listUserTemplates());
    } catch {
      /* depolama kapalı */
    }
  };
  useEffect(() => {
    void texManifest().then(setManifest);
    void refresh();
  }, []);

  const create = async (name: string, engine: TexProject['engine'], files: TexFiles) => {
    const now = Date.now();
    const p: TexProject = { id: newId('tex'), name, engine, main: 'main.tex', files: { ...files }, createdAt: now, updatedAt: now };
    await saveProject(p);
    onNavigate(`tex-${p.id}`);
  };
  const fromTemplate = (t: TexTemplate) => create(t.name, t.engine, t.files);

  const importTex = async (file: File) => {
    const text = await file.text();
    await create(file.name.replace(/\.tex$/i, ''), /\\usepackage(\[[^\]]*\])?\{fontspec\}/.test(text) ? 'xelatex' : 'pdflatex', { 'main.tex': text });
  };

  const available = (t: TexTemplate) => !manifest || RANK[manifest.bundleKey] >= RANK[t.needs];

  return (
    <div className="home">
      <TopNav active="araclar" onNavigate={onNavigate} />
      <main className="tools-main">
        <button className="btn btn--ghost btn--sm tex-back" onClick={() => onNavigate('araclar')}>
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          {__('Tüm araçlar')}
        </button>
        <div className="tex-hero">
          <div>
            <h1 className="tools-title">{__('LaTeX ile oluştur')}</h1>
            <p className="open__lead">
              {__('LaTeX ile ödev, rapor, özgeçmiş ve dilekçe hazırla. Derleme tarayıcında yapılır; çıkan PDF’i Tura Belge’de açıp not alabilir, imzalayabilirsin.')}
            </p>
          </div>
          <div className="tex-hero__actions">
            <button className="btn btn--ghost" onClick={() => importRef.current?.click()}>
              {__('.tex dosyası aç')}
            </button>
            <input ref={importRef} type="file" accept=".tex,text/x-tex,text/plain" hidden onChange={(e) => e.target.files?.[0] && void importTex(e.target.files[0])} />
          </div>
        </div>

        {manifest === null && (
          <p className="info">
            {__('Bu kurulumda LaTeX motoru yok; belgeleri yazabilir ve .tex olarak indirebilirsin ama PDF’e derlenemez. Uygulamayı yayınlayan kişi motoru')} <code>{__('npm run tex:indir')}</code> {__('komutuyla ekleyebilir.')}
          </p>
        )}
        {manifest && (
          <p className="tex-note">
            {__('İlk derlemede LaTeX motoru bir kez indirilir (yaklaşık')} {Math.round(manifest.size / 1048576)} {__('MB), sonra bu cihazda saklanır. Kurulu paket:')} <b>{manifest.bundleKey === 'temel' ? __('Temel') : manifest.bundleKey === 'genis' ? __('Geniş') : __('Tam')}</b> {__('(TeX Live 2026).')}
          </p>
        )}

        {projects.length > 0 && (
          <section className="toolgroup" aria-labelledby="tex-projects">
            <h2 id="tex-projects">{__('Projelerim')}</h2>
            <ul className="texprojects">
              {projects.map((p) => (
                <li key={p.id}>
                  <button className="texproject" onClick={() => onNavigate(`tex-${p.id}`)}>
                    <span className="texproject__icon" aria-hidden="true">
                      {__('TeX')}
                    </span>
                    <span className="texproject__text">
                      <b>{p.name}</b>
                      <span>
                        {fmt(p.updatedAt)} · {Object.keys(p.files).length} {__('dosya')}
                      </span>
                    </span>
                  </button>
                  {confirm === p.id ? (
                    <span className="doc__confirm">
                      <button className="btn btn--danger btn--sm" onClick={async () => (await deleteProject(p.id), setConfirm(null), refresh())}>
                        {__('Sil')}
                      </button>
                      <button className="btn btn--ghost btn--sm" onClick={() => setConfirm(null)}>
                        {__('Vazgeç')}
                      </button>
                    </span>
                  ) : (
                    <button className="icon-btn" aria-label={__('{0} projesini sil', [p.name])} onClick={() => setConfirm(p.id)}>
                      <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                        <path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </section>
        )}

        {mine.length > 0 && (
          <section className="toolgroup" aria-labelledby="tex-mine">
            <h2 id="tex-mine">{__('Şablonlarım')}</h2>
            <ul className="tplgrid">
              {mine.map((t) => (
                <li key={t.id} className="tpl">
                  <button className="tpl__open" onClick={() => create(t.name, t.engine, t.files)}>
                    <span className="tpl__thumb tpl__thumb--mine" aria-hidden="true">
                      <span>{__(t.name).slice(0, 2).toLocaleUpperCase(locale())}</span>
                    </span>
                    <b>{__(t.name)}</b>
                    <span>{t.desc ? __(t.desc) : __('Kendi şablonun')}</span>
                  </button>
                  <button className="link-btn tpl__del" onClick={async () => (await deleteUserTemplate(t.id), refresh())}>
                    {__('Şablonu sil')}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="toolgroup" aria-labelledby="tex-templates">
          <h2 id="tex-templates">{__('Şablondan başla')}</h2>
          <ul className="tplgrid">
            {TEMPLATES.map((t) => (
              <li key={t.id} className={available(t) ? 'tpl' : 'tpl tpl--locked'}>
                <button className="tpl__open" onClick={() => fromTemplate(t)}>
                  <span className="tpl__thumb">
                    {t.id === 'sunum' ? (
                      <span className="tpl__slide" aria-hidden="true">
                        <i />
                        <span>{__('Proje Sunumu')}</span>
                      </span>
                    ) : (
                      <img src={`${import.meta.env.BASE_URL}tex/sablonlar/${t.id}.webp`} alt="" loading="lazy" />
                    )}
                  </span>
                  <b>
                    {t.name}
                    {!available(t) && <span className="chip">{__('geniş paket')}</span>}
                  </b>
                  <span>{__(t.desc)}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
