// Tura TeX — tarayıcıda LaTeX derleme (BusyTeX, TeX Live 2026, WebAssembly)
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { BusyTexRunner, CompileResult } from 'texlyre-busytex';
import { __ } from '../i18n';

export type TexEngine = 'pdflatex' | 'xelatex' | 'lualatex';

export interface TexManifest {
  version: string;
  bundle: 'basic' | 'recommended' | 'extra';
  bundleKey: 'temel' | 'genis' | 'tam';
  size: number;
}

const base = () => new URL('tex/busytex', document.baseURI).href;

let manifestP: Promise<TexManifest | null> | null = null;
/** LaTeX motoru bu kurulumda var mı? (dosyalar `npm run tex:indir` ile eklenir) */
export function texManifest(): Promise<TexManifest | null> {
  manifestP ??= fetch(`${base()}/manifest.json`, { cache: 'no-cache' })
    .then((r) => (r.ok ? (r.json() as Promise<TexManifest>) : null))
    .catch(() => null);
  return manifestP;
}

let packagesP: Promise<Set<string>> | null = null;
/** Kurulu paket adları (\ProvidesPackage listesi) */
export function installedPackages(): Promise<Set<string>> {
  packagesP ??= fetch(`${base()}/packages.txt`)
    .then((r) => (r.ok ? r.text() : ''))
    .then((t) => new Set([...t.matchAll(/ProvidesPackage\{([^}]+)\}/g)].map((m) => m[1])))
    .catch(() => new Set<string>());
  return packagesP;
}

export interface Progress {
  phase: 'download' | 'init' | 'compile';
  percent?: number;
}

let runnerP: Promise<BusyTexRunner> | null = null;

export function getRunner(onProgress?: (p: Progress) => void): Promise<BusyTexRunner> {
  if (!runnerP) {
    runnerP = (async () => {
      const manifest = await texManifest();
      if (!manifest) throw new Error(__('LaTeX motoru bu kurulumda yok.'));
      const { BusyTexRunner } = await import('texlyre-busytex');
      const runner = new BusyTexRunner({
        busytexBasePath: base(),
        engineMode: 'combined',
        preloadDataPackages: [`${base()}/texlive-${manifest.bundle}.js`],
        onDownloadProgress: (p) => onProgressRef?.({ phase: 'download', percent: p.percent }),
      });
      onProgressRef?.({ phase: 'init' });
      await runner.initialize(true);
      return runner;
    })();
    runnerP.catch(() => (runnerP = null));
  }
  onProgressRef = onProgress ?? onProgressRef;
  return runnerP;
}
let onProgressRef: ((p: Progress) => void) | undefined;

export interface TexFile {
  path: string;
  content: string | Uint8Array;
}

export interface TexResult {
  ok: boolean;
  pdf?: Uint8Array;
  log: string;
  errors: TexError[];
  ms: number;
}

export interface TexError {
  message: string;
  line?: number;
  file?: string;
  missingPackage?: string;
}

// Sık görülen LaTeX hatalarının Türkçe açıklaması
const EXPLAIN: [RegExp, (m: RegExpExecArray) => string][] = [
  [/^Undefined control sequence/, () => __('Tanımsız komut: yazım hatası olabilir ya da gereken paket eklenmemiş.')],
  [/^Missing \$ inserted/, () => __('Matematik ifadesi $ … $ arasında yazılmalı.')],
  [/^(Extra \}, or forgotten \$|Missing \} inserted|Extra \})/, () => __('Süslü parantezler { } eşleşmiyor.')],
  [/^File ended while scanning use of/, () => __('Bir süslü parantez kapatılmamış.')],
  [/^Paragraph ended before (.+) was complete/, (m) => __('{0} komutunun parantezi kapanmamış.', [m[1]])],
  [/^LaTeX Error: Environment (\S+) undefined/, (m) => __('“{0}” ortamı tanımlı değil (paket eksik ya da yazım hatası).', [m[1]])],
  [/^LaTeX Error: \\begin\{([^}]+)\} on input line (\d+) ended by \\end\{([^}]+)\}/, (m) => __('\\begin{{0}} (satır {1}) ile \\end{{2}} eşleşmiyor.', [m[1], m[2], m[3]])],
  [/^LaTeX Error: Missing \\begin\{document\}/, () => __('\\begin{document} eksik ya da öncesinde metin var.')],
  [/^Misplaced alignment tab character &/, () => __('& işareti yalnızca tablo içinde kullanılabilir; metinde \\& yazın.')],
  [/^Double superscript|^Double subscript/, () => __('Üst/alt simge iki kez yazılmış; süslü parantezle gruplayın: x^{ab}.')],
  [/^LaTeX Error: Unknown graphics extension|^LaTeX Error: File `([^']+)' not found/, (m) => (m[1] ? __('“{0}” dosyası projede yok; “+ Dosya” ile ekleyin.', [m[1]]) : __('Görsel dosyası okunamadı.'))],
];
function explain(raw: string): string {
  for (const [re, fn] of EXPLAIN) {
    const m = re.exec(raw);
    if (m) return `${fn(m)} (${raw})`;
  }
  return raw;
}

/** LaTeX günlüğünden anlaşılır hata listesi çıkarır */
export function parseLog(log: string): TexError[] {
  const lines = log.split(/\r?\n/);
  const errors: TexError[] = [];
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const missing = /! LaTeX Error: File `([^']+)\.(sty|cls)' not found/.exec(l);
    if (missing) {
      errors.push({ message: __('“{0}” paketi bu kurulumda yok.', [missing[1]]), missingPackage: missing[1] });
      continue;
    }
    if (l.startsWith('! ')) {
      let line: number | undefined;
      for (let k = i + 1; k < Math.min(lines.length, i + 12); k++) {
        const m = /^l\.(\d+)/.exec(lines[k]);
        if (m) {
          line = Number(m[1]);
          break;
        }
      }
      errors.push({ message: explain(l.slice(2).trim()), line });
    }
  }
  // Aynı hatayı tekrar etme; asıl hata varsa "Emergency stop"/"Fatal error" satırlarını gösterme
  const seen = new Set<string>();
  const real = errors.filter((e) => !/^(Emergency stop|==> Fatal error)/.test(e.message));
  return (real.length ? real : errors).filter((e) => {
    const k = `${e.message}|${e.line}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

export async function compileTex(
  files: TexFile[],
  main: string,
  engine: TexEngine,
  onProgress?: (p: Progress) => void,
): Promise<TexResult> {
  const t0 = performance.now();
  const runner = await getRunner(onProgress);
  onProgress?.({ phase: 'compile' });
  const mod = await import('texlyre-busytex');
  const Tool = engine === 'xelatex' ? mod.XeLatex : engine === 'lualatex' ? mod.LuaLatex : mod.PdfLatex;
  const mainFile = files.find((f) => f.path === main);
  if (!mainFile || typeof mainFile.content !== 'string') throw new Error(__('Ana .tex dosyası bulunamadı.'));
  const usesRefs = /\\(tableofcontents|ref|pageref|cite|label)\b/.test(files.map((f) => (typeof f.content === 'string' ? f.content : '')).join('\n'));
  const res: CompileResult = await new Tool(runner).compile({
    input: mainFile.content,
    mainTexPath: main,
    additionalFiles: files.filter((f) => f.path !== main),
    rerun: usesRefs,
    bibtex: files.some((f) => f.path.endsWith('.bib')),
  });
  const log = res.log || res.logs?.map((l) => l.log || l.stdout).join('\n') || '';
  const ok = !!res.success && !!res.pdf && res.pdf.byteLength > 0;
  return { ok, pdf: res.pdf, log, errors: ok ? [] : parseLog(log), ms: Math.round(performance.now() - t0) };
}
