// Tura Belge — dil desteği (Türkçe / English). Metinler kaynakta Türkçe yazılır;
// İngilizce karşılıkları en.ts sözlüğünden gelir (bulunamazsa Türkçe gösterilir).
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useSyncExternalStore } from 'react';
import { EN } from './en';

export type Lang = 'tr' | 'en';
const KEY = 'tura-belge:dil';

function detect(): Lang {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved === 'tr' || saved === 'en') return saved;
  } catch {
    /* depolama kapalı olabilir */
  }
  const langs = navigator.languages?.length ? navigator.languages : [navigator.language];
  // Türkçe tarayıcıda Türkçe; diğer dillerde İngilizce
  return langs.some((l) => /^tr\b/i.test(l ?? '')) ? 'tr' : 'en';
}

let lang: Lang = typeof navigator !== 'undefined' ? detect() : 'tr';
const listeners = new Set<() => void>();
if (typeof document !== 'undefined') document.documentElement.lang = lang;

export const getLang = () => lang;
/** Tarih ve sayı biçimleri için yerel ayar */
export const locale = () => (lang === 'tr' ? 'tr-TR' : 'en-GB');

export function setLang(l: Lang) {
  if (l === lang) return;
  lang = l;
  try {
    localStorage.setItem(KEY, l);
  } catch {
    /* depolama kapalı olabilir */
  }
  document.documentElement.lang = l;
  listeners.forEach((f) => f());
}

export function useLang(): Lang {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    getLang,
  );
}

type Vars = (string | number)[] | Record<string, string | number>;

/** Çeviri: Türkçe kaynak metni o anki dile çevirir; {0}, {1}… yer tutucularını doldurur */
export function __(src: string, vars?: Vars): string {
  let s = lang === 'en' ? (EN[src] ?? src) : src;
  if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String((vars as Record<string, string | number>)[k]) : m));
  return s;
}

/** Yalnızca işaretler: modül düzeyindeki metinler kullanıldıkları yerde __() ile çevrilir */
export const N_ = (src: string) => src;

/** Ondalık sayı (Türkçede virgül) */
export const fmtNum = (n: number, digits = 1) => n.toLocaleString(locale(), { maximumFractionDigits: digits, minimumFractionDigits: digits });
