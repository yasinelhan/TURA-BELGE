// Tura Belge — Markdown görüntüleyici ve düzenleyici: canlı önizleme, biçim çubuğu,
// otomatik kayıt, asıl dosyaya yazma; PDF, Word, web sayfası ve düz metin olarak kaydetme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ViewerDoc } from '../lib/viewerConfig';
import { ensurePermission, handleModified, writeHandle } from '../lib/fileLink';
import { downloadFile, safeFileName } from '../lib/download';
import { MD_CSS, mdTitle } from '../convert/markdown';
import { mdViewHtml } from '../convert/mathView';
import { exportMarkdown, formatInfo, type ExportFormat } from '../convert/exporters';
import { DocTabs } from '../components/DocTabs';
import { SaveMenu } from '../components/SaveMenu';
import { BrandMark } from '../components/Brand';
import { __, getLang } from '../i18n';
import { getMeta, listFolders } from '../lib/storage';
import { SparkIcon } from '../ai/SparkIcon';
import { findMdSection, mdSectionTitle } from '../ai/sources';
import type { AskRequest, CurrentDoc, JumpTarget } from '../ai/AssistantPanel';

const AssistantPanel = lazy(() => import('../ai/AssistantPanel').then((m) => ({ default: m.AssistantPanel })));

type SaveState = 'clean' | 'dirty' | 'saving' | 'saved' | 'error' | 'off';
type Tab = 'gor' | 'duz';

interface Props {
  doc: ViewerDoc;
  storageOk: boolean;
  onPersist: (doc: ViewerDoc, bytes: ArrayBuffer, fileModified?: number) => Promise<void>;
  onRename: (name: string) => void;
  onClose: () => void;
  /** Markdown'dan üretilen PDF'i PDF düzenleyicide yeni belge olarak açar */
  onOpenPdf: (name: string, bytes: ArrayBuffer) => Promise<void>;
  onReloadFromFile: (doc: ViewerDoc) => void;
  onOpenDocAt: (t: JumpTarget) => void;
  onSaveNote: (name: string, text: string, folderId?: string) => Promise<void>;
}

const AUTOSAVE_MS = 1200;
const enc = new TextEncoder();
const dec = new TextDecoder();
/** Görev kutuları: "- [ ] iş" */
const TASK_RE = /^(\s*(?:[-*+]|\d+[.)])\s+)\[( |x|X)\]/gm;

export function MdEditor({ doc, storageOk, onPersist, onRename, onClose, onOpenPdf, onReloadFromFile, onOpenDocAt, onSaveNote }: Props) {
  const handle = doc.handle;
  const canSave = storageOk || !!handle;
  const [text, setText] = useState(() => dec.decode(doc.bytes));
  const [tab, setTab] = useState<Tab>(() => (dec.decode(doc.bytes).trim() ? 'gor' : 'duz'));
  const [name, setName] = useState(doc.name);
  const [state, setState] = useState<SaveState>(canSave ? 'clean' : 'off');
  const [linkOk, setLinkOk] = useState(false);
  const [conflict, setConflict] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const known = useRef<number | undefined>(doc.fileModified);
  const timer = useRef<number | undefined>(undefined);
  const area = useRef<HTMLTextAreaElement>(null);
  /** Yeni notun adı ilk başlıktan kendiliğinden alınır (kullanıcı adı değiştirene kadar) */
  const autoName = useRef(doc.name === __('Yeni not'));
  const textRef = useRef(text);
  textRef.current = text;
  const stateRef = useRef(state);
  stateRef.current = state;

  const flash = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 3200);
  };

  // ---------------------------------------------------------------- asistan
  const [aiOpen, setAiOpen] = useState(false);
  const [aiReq, setAiReq] = useState<AskRequest | null>(null);
  const [folder, setFolder] = useState<{ id: string; name: string } | undefined>(undefined);
  const [selPop, setSelPop] = useState<{ x: number; y: number; below: boolean; text: string } | null>(null);
  const paperRef = useRef<HTMLElement>(null);
  const seq = useRef(0);
  useEffect(() => {
    if (!storageOk) return;
    let live = true;
    void (async () => {
      const meta = await getMeta(doc.id).catch(() => undefined);
      if (!meta?.folderId) return;
      const f = (await listFolders().catch(() => [])).find((x) => x.id === meta.folderId);
      if (live && f) setFolder({ id: f.id, name: f.name });
    })();
    return () => {
      live = false;
    };
  }, [doc.id, storageOk]);

  const quoteOf = (sel: string) => {
    const sec = findMdSection(textRef.current, sel);
    return { text: sel, where: sec?.title ? `${name} · ${sec.title}` : name, docId: doc.id, page: sec?.n };
  };
  const askAbout = (kind: 'ask' | 'translate', sel: string) => {
    setSelPop(null);
    setAiOpen(true);
    setAiReq({ seq: ++seq.current, kind, quote: quoteOf(sel.slice(0, 4000)) });
  };
  /** Düzenleme alanında seçili metin (yoksa boş) */
  const areaSelection = () => {
    const ta = area.current;
    return ta ? ta.value.slice(ta.selectionStart, ta.selectionEnd).trim() : '';
  };

  // Önizlemede metin seçilince küçük "Asistana sor · Çevir" çubuğu
  useEffect(() => {
    let t = 0;
    const read = () => {
      const sel = document.getSelection();
      const paper = paperRef.current;
      if (!sel || sel.isCollapsed || !sel.rangeCount || !paper || !paper.contains(sel.getRangeAt(0).commonAncestorContainer)) {
        setSelPop(null);
        return;
      }
      const text = sel.toString().replace(/\s+/g, ' ').trim();
      if (!text) return setSelPop(null);
      const r = sel.getRangeAt(0).getBoundingClientRect();
      const below = r.top < 120;
      setSelPop({ x: Math.min(Math.max(r.left + r.width / 2, 130), window.innerWidth - 130), y: below ? r.bottom + 8 : r.top - 8, below, text });
    };
    const later = () => {
      window.clearTimeout(t);
      t = window.setTimeout(read, 180);
    };
    document.addEventListener('selectionchange', later);
    window.addEventListener('scroll', later, true);
    return () => {
      window.clearTimeout(t);
      document.removeEventListener('selectionchange', later);
      window.removeEventListener('scroll', later, true);
    };
  }, []);

  /** Notta bir bölüme git (önizlemede başlığa kaydır) */
  const scrollToSection = (title?: string) => {
    if (!title) return;
    if (tab === 'duz' && !window.matchMedia('(min-width: 900px)').matches) setTab('gor');
    window.setTimeout(() => {
      const hs = paperRef.current?.querySelectorAll('h1, h2, h3, h4, h5, h6') ?? [];
      const h = Array.from(hs).find((x) => x.textContent?.trim() === title.trim());
      h?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };
  // Asistanın kaynağından açıldıysa o bölüme kaydır
  useEffect(() => {
    if (doc.startPage && doc.startPage > 1) scrollToSection(mdSectionTitle(textRef.current, doc.startPage));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const jumpTo = async (t: JumpTarget) => {
    if (t.docId === doc.id) {
      scrollToSection(t.title ?? mdSectionTitle(textRef.current, t.n));
      if (window.matchMedia('(max-width: 760px)').matches) setAiOpen(false);
      return;
    }
    if (stateRef.current === 'dirty') await persistRef.current();
    onOpenDocAt(t);
  };
  const getCurrent = useCallback(
    async (): Promise<CurrentDoc | null> => (storageOk ? null : { meta: { id: doc.id, name, kind: 'md', updatedAt: 0 }, bytes: enc.encode(textRef.current).buffer as ArrayBuffer }),
    [storageOk, doc.id, name],
  );

  useEffect(() => {
    if (handle) void ensurePermission(handle, 'readwrite', false).then(setLinkOk);
  }, [handle]);

  const persist = useCallback(
    async (force = false) => {
      if (!canSave) return;
      window.clearTimeout(timer.current);
      setState('saving');
      try {
        const bytes = enc.encode(textRef.current).buffer as ArrayBuffer;
        let fileModified = known.current;
        if (handle && linkOk) {
          const now = await handleModified(handle);
          if (!force && known.current !== undefined && now !== known.current) {
            setConflict(true);
          } else {
            fileModified = await writeHandle(handle, bytes);
            known.current = fileModified;
            setConflict(false);
          }
        }
        if (storageOk) await onPersist({ ...doc, name, kind: 'md' }, bytes, fileModified);
        setState('saved');
      } catch (err) {
        console.error('[Tura Belge] Markdown kaydedilemedi', err);
        setState('error');
      }
    },
    [canSave, handle, linkOk, storageOk, onPersist, doc, name],
  );
  const persistRef = useRef(persist);
  persistRef.current = persist;

  const change = (v: string) => {
    setText(v);
    if (autoName.current) {
      const t = mdTitle(v);
      if (t && t !== name) {
        setName(t);
        onRename(t);
      }
    }
    if (!canSave) return;
    setState('dirty');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void persistRef.current(), AUTOSAVE_MS);
  };
  useEffect(() => () => window.clearTimeout(timer.current), []);
  useEffect(() => {
    if (doc.dirty) void persistRef.current();
  }, [doc.dirty]);
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => {
      if (stateRef.current === 'dirty' || stateRef.current === 'saving') e.preventDefault();
    };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, []);

  const back = async () => {
    if (stateRef.current === 'dirty') await persistRef.current();
    onClose();
  };
  const grant = async () => {
    if (!handle) return;
    const ok = await ensurePermission(handle, 'readwrite', true);
    setLinkOk(ok);
    if (ok) flash(__('Değişiklikler artık asıl dosyaya kaydedilecek'));
  };
  const commitName = () => {
    autoName.current = false;
    const clean = name.trim() || __('Adsız not');
    setName(clean);
    if (clean !== doc.name) {
      onRename(clean);
      if (canSave) change(textRef.current);
    }
  };

  // ---------------------------------------------------------------- kaydetme biçimleri
  const save = async (fmt: ExportFormat) => {
    setBusy(true);
    try {
      const blob = await exportMarkdown(textRef.current, name, fmt);
      const r = await downloadFile(safeFileName(name, formatInfo(fmt).ext), blob);
      flash(r === 'saved' ? __('{0} olarak kaydedildi', [formatInfo(fmt).label]) : r === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
    } catch (err) {
      console.error(err);
      flash(__('Dönüştürülemedi'));
    } finally {
      setBusy(false);
    }
  };
  const extra = async (id: string) => {
    if (id !== 'pdf-ac') return;
    setBusy(true);
    try {
      if (stateRef.current === 'dirty') await persistRef.current();
      const { mdToPdf } = await import('../convert/mdToPdf');
      await onOpenPdf(name, await mdToPdf(textRef.current, name));
    } catch (err) {
      console.error(err);
      flash(__('PDF oluşturulamadı'));
      setBusy(false);
    }
  };

  // ---------------------------------------------------------------- önizleme
  const html = useMemo(() => {
    // Görev kutuları tıklanabilsin (sırasıyla numaralanır)
    let n = 0;
    return mdViewHtml(text).replace(/<input (checked="" )?disabled="" type="checkbox">/g, (_m, c) => `<input type="checkbox" data-task="${n++}"${c ? ' checked' : ''}>`);
  }, [text]);
  const toggleTask = (e: React.MouseEvent) => {
    const el = e.target as HTMLElement;
    const ix = el.getAttribute?.('data-task');
    if (ix === null || ix === undefined) return;
    e.preventDefault();
    let n = 0;
    const next = textRef.current.replace(TASK_RE, (m, pre, mark) => (n++ === Number(ix) ? `${pre}[${mark === ' ' ? 'x' : ' '}]` : m));
    change(next);
  };

  // ---------------------------------------------------------------- biçim çubuğu
  const edit = (fn: (sel: string, before: string, after: string) => { insert: string; select?: [number, number] }, lineMode = false) => {
    const ta = area.current;
    if (!ta) return;
    ta.focus();
    let a = ta.selectionStart;
    let b = ta.selectionEnd;
    const v = ta.value;
    if (lineMode) {
      a = v.lastIndexOf('\n', a - 1) + 1;
      const e = v.indexOf('\n', b === a ? b : b - 1);
      b = e < 0 ? v.length : e;
    }
    const r = fn(v.slice(a, b), v.slice(0, a), v.slice(b));
    ta.setSelectionRange(a, b);
    // execCommand geri al (Ctrl+Z) geçmişini korur; olmazsa doğrudan yazılır
    if (!document.execCommand?.('insertText', false, r.insert)) ta.setRangeText(r.insert, a, b, 'end');
    if (r.select) ta.setSelectionRange(a + r.select[0], a + r.select[1]);
    change(ta.value);
  };
  const wrap = (m: string, ph: string) =>
    edit((sel) => {
      const s = sel || ph;
      return { insert: m + s + m, select: [m.length, m.length + s.length] };
    });
  const prefix = (p: string | ((i: number) => string), strip: RegExp) =>
    edit((sel) => {
      const lines = sel.split('\n');
      const all = lines.every((l) => strip.test(l) || !l.trim());
      const out = lines.map((l, i) => (all ? l.replace(strip, '') : l.trim() ? (typeof p === 'function' ? p(i) : p) + l.replace(strip, '') : l)).join('\n');
      return { insert: out, select: [0, out.length] };
    }, true);
  const heading = () =>
    edit((sel) => {
      const m = sel.match(/^(#{1,6})\s/);
      const depth = m ? m[1].length : 0;
      const body = sel.replace(/^#{1,6}\s+/, '');
      const out = depth >= 3 ? body : '#'.repeat(depth + 1) + ' ' + body;
      return { insert: out, select: [out.length, out.length] };
    }, true);
  const ACTIONS: { id: string; t: string; d: string; run: () => void; key?: string }[] = [
    { id: 'h', t: __('Başlık (tekrar bas: daha küçük)'), d: 'M5 5v14M13 5v14M5 12h8M17 9l2-1v11', run: heading },
    { id: 'b', t: __('Kalın (Ctrl+B)'), d: 'M7 5h6a3.5 3.5 0 0 1 0 7H7zM7 12h7a3.5 3.5 0 0 1 0 7H7z', run: () => wrap('**', __('kalın yazı')), key: 'b' },
    { id: 'i', t: __('Eğik (Ctrl+I)'), d: 'M11 5h6M7 19h6M14 5l-4 14', run: () => wrap('*', __('eğik yazı')), key: 'i' },
    { id: 's', t: __('Üstü çizili'), d: 'M5 12h14M16 7a4 3 0 0 0-4-2c-2.5 0-4 1.2-4 3M8 17a4 3 0 0 0 4 2c2.5 0 4-1.2 4-3', run: () => wrap('~~', __('çizili')) },
    { id: 'ul', t: __('Madde listesi'), d: 'M10 6h10M10 12h10M10 18h10M5 6h.01M5 12h.01M5 18h.01', run: () => prefix('- ', /^\s*[-*+]\s(?!\[)/) },
    { id: 'ol', t: __('Numaralı liste'), d: 'M10 6h10M10 12h10M10 18h10M4 5l1.5-1v5M4 14h3l-3 4h3', run: () => prefix((i) => `${i + 1}. `, /^\s*\d+[.)]\s/) },
    { id: 'task', t: __('Yapılacaklar (görev kutusu)'), d: 'M4 5h5v5H4zM4 14h5v5H4zM5 16.5l1.2 1.2 2-2.4M12 7.5h8M12 16.5h8', run: () => prefix('- [ ] ', /^\s*[-*+]\s\[[ xX]\]\s/) },
    { id: 'q', t: __('Alıntı'), d: 'M6 7h4v4H7l-1 4M14 7h4v4h-3l-1 4', run: () => prefix('> ', /^>\s?/) },
    {
      id: 'code',
      t: 'Kod',
      d: 'M9 7l-5 5 5 5M15 7l5 5-5 5',
      run: () =>
        edit((sel) =>
          sel.includes('\n') || !sel
            ? { insert: '```\n' + (sel || 'kod') + '\n```', select: [4, 4 + (sel || 'kod').length] }
            : { insert: '`' + sel + '`', select: [1, 1 + sel.length] },
        ),
    },
    {
      id: 'link',
      t: __('Bağlantı'),
      d: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
      run: () => edit((sel) => ({ insert: `[${sel || __('bağlantı')}](https://)`, select: [(sel || __('bağlantı')).length + 3, (sel || __('bağlantı')).length + 11] })),
    },
    {
      id: 'table',
      t: 'Tablo',
      d: 'M4 5h16v14H4zM4 10h16M4 15h16M10 5v14',
      run: () =>
        edit((_s, before) => {
          const lead = before && !before.endsWith('\n\n') ? (before.endsWith('\n') ? '\n' : '\n\n') : '';
          const t = __('{0}| Başlık | Başlık |\n| --- | --- |\n| Hücre | Hücre |\n', [lead]);
          return { insert: t, select: [lead.length + 2, lead.length + 8] };
        }),
    },
    { id: 'hr', t: __('Ayırıcı çizgi'), d: 'M4 12h16', run: () => edit(() => ({ insert: '\n\n---\n\n' })) },
  ];
  const onKey = (e: React.KeyboardEvent) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    const a = ACTIONS.find((x) => x.key === e.key.toLowerCase());
    if (a) {
      e.preventDefault();
      a.run();
    } else if (e.key.toLowerCase() === 's') {
      e.preventDefault();
      void persistRef.current();
    }
  };

  const statusText: Record<SaveState, string> = {
    clean: handle ? __('Bağlı dosya: {0}', [handle.name]) : __('Değişiklik yok'),
    dirty: __('Kaydedilmemiş değişiklikler'),
    saving: __('Kaydediliyor…'),
    saved: handle && linkOk ? __('Kaydedildi: {0}', [handle.name]) : __('Bu cihaza kaydedildi'),
    error: 'Kaydedilemedi',
    off: __('Otomatik kayıt kapalı — İndir ile kaydet'),
  };
  const words = useMemo(() => (text.match(/[\p{L}\p{N}]+/gu) ?? []).length, [text]);

  return (
    <div className="editor mdedit">
      <style>{MD_CSS}</style>
      <header className="editbar">
        <button className="btn btn--ghost editbar__back" onClick={back} aria-label={__('Belgelerime dön')}>
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span className="hide-sm">{__('Belgelerim')}</span>
        </button>
        <span className="hide-xs" style={{ display: 'contents' }}>
          <BrandMark size={22} />
        </span>
        <label className="editbar__name">
          <span className="sr-only">{__('Not adı')}</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={commitName}
            onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
            spellCheck={false}
          />
        </label>
        <DocTabs
          tabs={[
            { id: 'gor', label: 'Görüntüle' },
            { id: 'duz', label: 'Düzenle' },
          ]}
          active={tab}
          onPick={(id) => setTab(id as Tab)}
          label={__('Not sekmeleri')}
        />
        <span className={`status status--${state}${handle && linkOk ? ' status--linked' : ''}`} aria-live="polite" title={statusText[state]}>
          <i aria-hidden="true" />
          <span className="hide-sm">{statusText[state]}</span>
        </span>
        <button
          className={aiOpen ? 'btn btn--ghost editbar__ai editbar__ai--on' : 'btn btn--ghost editbar__ai'}
          onClick={() => {
            const sel = tab === 'duz' ? areaSelection() : '';
            if (sel) askAbout('ask', sel);
            else {
              setAiReq(null);
              setAiOpen((v) => !v);
            }
          }}
          aria-pressed={aiOpen}
          title={__('Asistan: notlarına dayanarak sorularını yanıtlar')}
        >
          <SparkIcon />
          <span className="hide-sm">{__('Asistan')}</span>
        </button>
        <SaveMenu
          main="md"
          busy={busy}
          onSave={(f) => void save(f)}
          extras={[{ id: 'pdf-ac', label: 'PDF olarak aç', hint: 'Not almak, kalemle yazmak, imzalamak için' }]}
          onExtra={(id) => void extra(id)}
        />
      </header>

      {handle && !linkOk && (
        <div className="linkbar" role="status">
          <span>
            <b>{handle.name}</b> {__('dosyasındaki değişikliklerin aynı dosyaya kaydedilmesi için izin ver.')}
          </span>
          <button className="btn btn--primary btn--sm" onClick={grant}>
            {__('Asıl dosyaya kaydetmeye izin ver')}
          </button>
        </div>
      )}
      {handle && conflict && (
        <div className="linkbar linkbar--warn" role="alert">
          <span>
            <b>{handle.name}</b> {__('sen düzenlerken başka bir yerde de değiştirilmiş. Hangisi kalsın?')}
          </span>
          <button className="btn btn--danger btn--sm" onClick={() => void persist(true)}>
            {__('Benim sürümüm (üzerine yaz)')}
          </button>
          <button className="btn btn--ghost btn--sm" onClick={() => onReloadFromFile({ ...doc, name, kind: 'md' })}>
            {__('Diğer sürümü aç')}
          </button>
        </div>
      )}

      <div className="editor__main">
      <div className={`mdedit__body mdedit__body--${tab}`}>
        {tab === 'duz' && (
          <section className="mdedit__src" aria-label={__('Markdown kaynağı')}>
            <div className="mdedit__tools" role="toolbar" aria-label={__('Biçim')}>
              {ACTIONS.map((a) => (
                <button key={a.id} className="mdedit__tool" title={a.t} aria-label={a.t} onMouseDown={(e) => e.preventDefault()} onClick={a.run}>
                  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                    <path d={a.d} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              ))}
              <button
                className="mdedit__tool mdedit__tool--ai"
                title={__('Seçili metni asistana sor')}
                aria-label={__('Seçili metni asistana sor')}
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  const sel = areaSelection();
                  if (sel) askAbout('ask', sel);
                  else {
                    setAiReq(null);
                    setAiOpen(true);
                  }
                }}
              >
                <SparkIcon />
              </button>
              <span className="mdedit__count">{words} {__('kelime')}</span>
            </div>
            <textarea
              ref={area}
              className="mdedit__area"
              value={text}
              onChange={(e) => change(e.target.value)}
              onKeyDown={onKey}
              spellCheck
              lang={getLang()}
              autoFocus={!text.trim()}
              placeholder={__('# Başlık\n\nNotunu buraya yaz. **Kalın**, *eğik*, - madde, - [ ] yapılacak…')}
              aria-label={__('Markdown metni')}
            />
          </section>
        )}
        <section className="mdedit__preview" aria-label={__('Önizleme')}>
          <article ref={paperRef} className="md-view mdedit__paper" onClick={toggleTask} dangerouslySetInnerHTML={{ __html: html || `<p class="mdedit__empty">${__('Henüz bir şey yazılmadı.')}</p>` }} />
        </section>
      </div>
        {aiOpen && (
          <Suspense fallback={<aside className="aipanel aipanel--side aipanel--loading" aria-busy="true" />}>
            <AssistantPanel
              layout="side"
              storeKey={`doc:${doc.id}`}
              doc={{ id: doc.id, name, kind: 'md' }}
              folder={folder}
              getCurrent={getCurrent}
              request={aiReq}
              onClose={() => {
                setAiOpen(false);
                setAiReq(null);
              }}
              onJump={(t) => void jumpTo(t)}
              onSaveNote={onSaveNote}
            />
          </Suspense>
        )}
      </div>

      {selPop && (
        <div
          className={selPop.below ? 'selpop selpop--below' : 'selpop'}
          style={{ left: selPop.x, top: selPop.y }}
          role="toolbar"
          aria-label={__('Seçim')}
          onMouseDown={(e) => e.preventDefault()}
        >
          <button type="button" onClick={() => askAbout('ask', selPop.text)}>
            <SparkIcon size={16} /> {__('Asistana sor')}
          </button>
          <button type="button" onClick={() => askAbout('translate', selPop.text)}>
            {__('Çevir')}
          </button>
        </div>
      )}

      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
    </div>
  );
}
