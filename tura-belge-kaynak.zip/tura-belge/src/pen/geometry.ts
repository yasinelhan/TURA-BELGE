// Tura Kalem — kalem izinin geometrisi: basınca göre değişen kalınlık, sadeleştirme,
// şekil tanıma (düz çizgi, elips, dikdörtgen) ve el yazısı güzelleştirme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { getStroke } from 'perfect-freehand';

/** x, y (sayfa noktası, pt) ve basınç (0–1) */
export type P3 = [number, number, number];
export type P2 = [number, number];

export type PenKind = 'kalem' | 'fosforlu';
/** Kalem türleri: tükenmez, dolma (mürekkepli), kurşun, keçeli, fosforlu */
export type PenType = 'tukenmez' | 'dolma' | 'kursun' | 'kececi' | 'fosforlu';
export type Nib = 'yuvarlak' | 'keski';

export interface PenStyle {
  kind: PenKind;
  type?: PenType;
  /** Uç kalınlığı (pt) */
  size: number;
  /** Gerçek basınç verisi var mı (kalem); yoksa hıza göre benzetilir */
  pressure: boolean;
  /** Basınç hassasiyeti 0–0,95: bastırdıkça ne kadar kalınlaşsın */
  thinning?: number;
  /** Titreme düzeltme 0–1 */
  smoothing?: number;
  /** Uç biçimi: yuvarlak ya da keski (hat kalemi / fosforlu keski uç) */
  nib?: Nib;
  /** Keski ucun açısı (derece) */
  angle?: number;
  opacity?: number;
}

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Kalem izinin dış çevresi (dolu çokgen) */
export function outline(points: P3[], style: PenStyle, last = true, extraSmooth = false): P2[] {
  if (!points.length) return [];
  const hl = style.kind === 'fosforlu';
  const thinning = clamp(style.thinning ?? (hl ? 0 : style.pressure ? 0.6 : 0.45), 0, 0.95);
  const sm = clamp(extraSmooth ? Math.max(0.85, style.smoothing ?? 0.5) : (style.smoothing ?? 0.5), 0, 1);
  if (style.nib === 'keski') return ribbon(points, style, thinning, sm);
  // Basınç verisi yoksa hıza göre benzetilir; hassasiyet sıfırsa kalınlık sabit kalır
  const simulate = !style.pressure && thinning > 0.05;
  const taper = !style.pressure && thinning > 0.25 ? style.size * 2 * thinning : 0;
  return getStroke(points, {
    size: style.size,
    thinning,
    smoothing: 0.35 + 0.55 * sm,
    streamline: 0.2 + 0.65 * sm,
    simulatePressure: simulate,
    easing: (t) => Math.sin((t * Math.PI) / 2),
    start: { cap: true, taper },
    end: { cap: true, taper },
    last,
  }) as P2[];
}

/**
 * Keski uç: sabit açılı bir ucun bıraktığı şerit. Uca dik hareketlerde kalın, uç yönünde ince çizer
 * (hat yazısı ve gerçek fosforlu kalem görünümü).
 */
function ribbon(points: P3[], style: PenStyle, thinning: number, sm: number): P2[] {
  const stream = 0.15 + 0.6 * sm;
  const pts: P3[] = [];
  let prev = points[0];
  for (const p of points) {
    prev = [prev[0] + (p[0] - prev[0]) * (1 - stream), prev[1] + (p[1] - prev[1]) * (1 - stream), p[2]];
    pts.push(prev);
  }
  if (pts.length === 1) pts.push([pts[0][0] + 0.3, pts[0][1] + 0.3, pts[0][2]]);
  const a = ((style.angle ?? 45) * Math.PI) / 180;
  const nx = Math.cos(a);
  const ny = -Math.sin(a);
  const half = style.size / 2;
  const min = Math.max(0.12, style.size * 0.09);
  const left: P2[] = [];
  const right: P2[] = [];
  for (let i = 0; i < pts.length; i++) {
    const [x, y, p] = pts[i];
    const f = style.pressure ? clamp(1 - thinning + thinning * 2 * p, 0.15, 1 + thinning) : 1;
    const w = half * f;
    // Uç yönünde ilerlerken de çizgi kaybolmasın: harekete dik küçük bir kalınlık
    const q = pts[Math.min(pts.length - 1, i + 1)];
    const o = pts[Math.max(0, i - 1)];
    let dx = q[0] - o[0];
    let dy = q[1] - o[1];
    const L = Math.hypot(dx, dy) || 1;
    dx /= L;
    dy /= L;
    const px = -dy * min;
    const py = dx * min;
    left.push([x + nx * w + px, y + ny * w + py]);
    right.push([x - nx * w - px, y - ny * w - py]);
  }
  return [...left, ...right.reverse()];
}

/** Ramer–Douglas–Peucker: kapalı çokgeni sadeleştirir (dosya küçük kalsın) */
export function simplify(pts: P2[], eps: number): P2[] {
  if (pts.length < 8) return pts;
  const keep = new Uint8Array(pts.length);
  keep[0] = keep[pts.length - 1] = 1;
  const stack: [number, number][] = [[0, pts.length - 1]];
  while (stack.length) {
    const [a, b] = stack.pop()!;
    const [ax, ay] = pts[a];
    const [bx, by] = pts[b];
    const dx = bx - ax;
    const dy = by - ay;
    const L = Math.hypot(dx, dy) || 1;
    let best = -1;
    let bi = -1;
    for (let i = a + 1; i < b; i++) {
      const d = Math.abs((pts[i][0] - ax) * dy - (pts[i][1] - ay) * dx) / L;
      if (d > best) {
        best = d;
        bi = i;
      }
    }
    if (best > eps && bi > 0) {
      keep[bi] = 1;
      stack.push([a, bi], [bi, b]);
    }
  }
  return pts.filter((_, i) => keep[i]);
}

export function bounds(pts: P2[] | P3[]): { x: number; y: number; w: number; h: number } {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const p of pts) {
    if (p[0] < x0) x0 = p[0];
    if (p[1] < y0) y0 = p[1];
    if (p[0] > x1) x1 = p[0];
    if (p[1] > y1) y1 = p[1];
  }
  return { x: x0, y: y0, w: Math.max(0.01, x1 - x0), h: Math.max(0.01, y1 - y0) };
}

/** Nokta çokgenin içinde mi (çift-tek kuralı) */
export function inside(x: number, y: number, poly: P2[]): boolean {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi || 1e-9) + xi) c = !c;
  }
  return c;
}

/** Noktanın doğru parçasına uzaklığı */
export function segDist(px: number, py: number, a: P2 | P3, b: P2 | P3): number {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const L2 = dx * dx + dy * dy;
  let t = L2 ? ((px - a[0]) * dx + (py - a[1]) * dy) / L2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (a[0] + t * dx), py - (a[1] + t * dy));
}

const pathLen = (p: P3[]) => {
  let s = 0;
  for (let i = 1; i < p.length; i++) s += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]);
  return s;
};

/** Eşit aralıklı yeniden örnekleme */
function resample(p: P3[], n: number): P3[] {
  if (p.length < 2) return p;
  const L = pathLen(p);
  const step = L / (n - 1);
  const out: P3[] = [p[0]];
  let acc = 0;
  for (let i = 1; i < p.length && out.length < n; i++) {
    let a = p[i - 1];
    const b = p[i];
    let d = Math.hypot(b[0] - a[0], b[1] - a[1]);
    while (acc + d >= step && out.length < n) {
      const t = (step - acc) / d;
      const q: P3 = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
      out.push(q);
      a = q;
      d = Math.hypot(b[0] - a[0], b[1] - a[1]);
      acc = 0;
    }
    acc += d;
  }
  while (out.length < n) out.push(p[p.length - 1]);
  return out;
}

export type Shape = 'cizgi' | 'elips' | 'dikdortgen' | null;

/** Kabaca çizilmiş düz çizgi, daire/elips ya da dikdörtgeni tanır */
export function recognize(p: P3[]): { shape: Shape; pts: P3[] } {
  if (p.length < 4) return { shape: null, pts: p };
  const L = pathLen(p);
  const a = p[0];
  const z = p[p.length - 1];
  const chord = Math.hypot(z[0] - a[0], z[1] - a[1]);
  const mean = p.reduce((s, q) => s + q[2], 0) / p.length;
  // Düz çizgi: yol uzunluğu kirişe çok yakın ve sapma küçük
  let dev = 0;
  for (const q of p) dev = Math.max(dev, segDist(q[0], q[1], a, z));
  if (chord > 8 && dev / chord < 0.06 && L / chord < 1.08) {
    let [x0, y0, x1, y1] = [a[0], a[1], z[0], z[1]];
    // Yataya/dikeye 8°'den yakınsa tam hizala
    const ang = Math.abs((Math.atan2(y1 - y0, x1 - x0) * 180) / Math.PI);
    if (ang < 8 || ang > 172) y1 = y0 = (y0 + y1) / 2;
    else if (Math.abs(ang - 90) < 8) x1 = x0 = (x0 + x1) / 2;
    const pts: P3[] = Array.from({ length: 12 }, (_, i) => [x0 + ((x1 - x0) * i) / 11, y0 + ((y1 - y0) * i) / 11, mean]);
    return { shape: 'cizgi', pts };
  }
  // Kapalı şekil: başı sonuna yakın
  if (chord > L * 0.18 || L < 30) return { shape: null, pts: p };
  const b = bounds(p);
  const cx = b.x + b.w / 2;
  const cy = b.y + b.h / 2;
  const rx = b.w / 2;
  const ry = b.h / 2;
  // Elips uyumu: her nokta için normalleştirilmiş yarıçap ~1
  let eErr = 0;
  for (const q of p) eErr += Math.abs(Math.hypot((q[0] - cx) / rx, (q[1] - cy) / ry) - 1);
  eErr /= p.length;
  // Dikdörtgen uyumu: her nokta en yakın kenara yakın
  let rErr = 0;
  for (const q of p) rErr += Math.min(Math.abs(q[0] - b.x), Math.abs(q[0] - b.x - b.w), Math.abs(q[1] - b.y), Math.abs(q[1] - b.y - b.h)) / Math.min(b.w, b.h);
  rErr /= p.length;
  if (rErr < 0.06 && rErr < eErr * 0.8) {
    const c: P2[] = [
      [b.x, b.y],
      [b.x + b.w, b.y],
      [b.x + b.w, b.y + b.h],
      [b.x, b.y + b.h],
      [b.x, b.y],
    ];
    const pts: P3[] = [];
    for (let i = 0; i < 4; i++) for (let k = 0; k < 6; k++) pts.push([c[i][0] + ((c[i + 1][0] - c[i][0]) * k) / 6, c[i][1] + ((c[i + 1][1] - c[i][1]) * k) / 6, mean]);
    pts.push([b.x, b.y, mean]);
    return { shape: 'dikdortgen', pts };
  }
  if (eErr < 0.12) {
    // Daireye çok yakınsa tam daire
    const r = Math.abs(rx - ry) / Math.max(rx, ry) < 0.12 ? (rx + ry) / 2 : 0;
    const start = Math.atan2(a[1] - cy, a[0] - cx);
    const pts: P3[] = Array.from({ length: 49 }, (_, i) => {
      const t = start + (i / 48) * Math.PI * 2;
      return [cx + (r || rx) * Math.cos(t), cy + (r || ry) * Math.sin(t), mean];
    });
    return { shape: 'elips', pts };
  }
  return { shape: null, pts: p };
}

/**
 * El yazısını güzelleştirir: titremeyi alır, basıncı yumuşatır, köşeleri korur.
 * Şekle benziyorsa (çizgi, daire, dikdörtgen) düzgün şekle çevirir.
 */
export function beautify(p: P3[]): { pts: P3[]; shape: Shape } {
  const r = recognize(p);
  if (r.shape) return { pts: r.pts, shape: r.shape };
  if (p.length < 4) return { pts: p, shape: null };
  const n = Math.max(8, Math.min(400, Math.round(pathLen(p) / 0.8)));
  let q = resample(p, n);
  // İki tur hafif ortalama (Gauss benzeri); uçlar sabit
  for (let pass = 0; pass < 2; pass++) {
    q = q.map((pt, i) => {
      if (i === 0 || i === q.length - 1) return pt;
      const a = q[i - 1];
      const c = q[i + 1];
      return [(a[0] + 2 * pt[0] + c[0]) / 4, (a[1] + 2 * pt[1] + c[1]) / 4, (a[2] + 2 * pt[2] + c[2]) / 4] as P3;
    });
  }
  return { pts: q, shape: null };
}

/** Saklanacak orta çizgi: 2 ondalık, basınç 2 ondalık */
export const packPts = (p: P3[]) => p.map((q) => [Math.round(q[0] * 100) / 100, Math.round(q[1] * 100) / 100, Math.round(q[2] * 100) / 100]);

/**
 * Silgi: orta çizgiden silginin (a→b doğrusu boyunca r yarıçaplı) geçtiği yerleri çıkarır.
 * Dokunmadıysa null; dokunduysa kalan parçaları (boş dizi: tamamı silindi) döndürür.
 */
export function eraseFrom(center: P3[], a: P2, b: P2, r: number, half: number): P3[][] | null {
  const reach = r + half;
  const step = Math.max(0.25, r / 4);
  const pts: P3[] = [];
  for (let i = 0; i < center.length; i++) {
    const p = center[i];
    if (i > 0) {
      // Silgiye yakın aralıklar sıklaştırılır; böylece kesik uçlar silginin kenarına oturur
      const q = center[i - 1];
      const d = Math.hypot(p[0] - q[0], p[1] - q[1]);
      const near = Math.min(segDist(p[0], p[1], a, b), segDist(q[0], q[1], a, b)) < reach + d;
      const n = near ? Math.floor(d / step) : 0;
      for (let k = 1; k < n; k++) {
        const t = k / n;
        pts.push([q[0] + (p[0] - q[0]) * t, q[1] + (p[1] - q[1]) * t, q[2] + (p[2] - q[2]) * t]);
      }
    }
    pts.push(p);
  }
  let hit = false;
  const keep = pts.map((p) => {
    const h = segDist(p[0], p[1], a, b) < reach;
    if (h) hit = true;
    return !h;
  });
  if (!hit) return null;
  const parts: P3[][] = [];
  let cur: P3[] = [];
  pts.forEach((p, i) => {
    if (keep[i]) cur.push(p);
    else {
      if (cur.length) parts.push(cur);
      cur = [];
    }
  });
  if (cur.length) parts.push(cur);
  // Çok kısa kırıntılar bırakılmaz
  const len = (s: P3[]) => s.reduce((acc, p, i) => (i ? acc + Math.hypot(p[0] - s[i - 1][0], p[1] - s[i - 1][1]) : 0), 0);
  return parts.filter((s) => s.length >= 2 && len(s) > Math.max(0.4, half * 0.6));
}
