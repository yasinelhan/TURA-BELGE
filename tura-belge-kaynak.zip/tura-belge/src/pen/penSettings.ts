// Tura Kalem — kalem türleri, renk skalası ve kullanıcının ayarları (bu cihazda saklanır)
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { Nib, PenKind, PenStyle, PenType } from './geometry';
import { N_ } from '../i18n';

export interface PenTypeInfo {
  id: PenType;
  t: string;
  kind: PenKind;
  icon: string;
  /** Kalınlık aralığı ve varsayılanı (pt) */
  min: number;
  max: number;
  size: number;
  /** Varsayılan basınç hassasiyeti, titreme düzeltme, saydamlık */
  sens: number;
  smooth: number;
  opacity: number;
  nib: Nib;
  /** Keski ucun açısı (derece) */
  angle: number;
  color: string;
}

export const PEN_TYPES: PenTypeInfo[] = [
  {
    id: 'tukenmez',
    t: N_('Tükenmez kalem'),
    kind: 'kalem',
    icon: 'M4 20l3.6-.9L19.2 7.5a2 2 0 0 0-2.7-2.7L4.9 16.4zM14.8 6.5l2.7 2.7M4 20l1.3-1.3',
    min: 0.4,
    max: 4,
    size: 1.3,
    sens: 0.3,
    smooth: 0.5,
    opacity: 1,
    nib: 'yuvarlak',
    angle: 45,
    color: '#1d3fbf',
  },
  {
    id: 'dolma',
    t: N_('Dolma (mürekkepli) kalem'),
    kind: 'kalem',
    icon: 'M20 4l-1.6 4.8L9.6 17.6 6.4 14.4 15.2 5.6zM6.4 14.4L3.5 20.5l6.1-2.9M12 12l-4.4 4.4M15.2 5.6l3.2 3.2',
    min: 0.6,
    max: 7,
    size: 2.2,
    sens: 0.7,
    smooth: 0.6,
    opacity: 1,
    nib: 'yuvarlak',
    angle: 40,
    color: '#14205a',
  },
  {
    id: 'kursun',
    t: N_('Kurşun kalem'),
    kind: 'kalem',
    icon: 'M4.5 19.5l1-4.2L16.3 4.5l3.2 3.2L8.7 18.5zM13.9 6.9l3.2 3.2M5.5 15.3l3.2 3.2M4.5 19.5l1.6-.4',
    min: 0.4,
    max: 3.5,
    size: 1.1,
    sens: 0.5,
    smooth: 0.45,
    opacity: 0.82,
    nib: 'yuvarlak',
    angle: 45,
    color: '#4a4a50',
  },
  {
    id: 'kececi',
    t: N_('Keçeli kalem'),
    kind: 'kalem',
    icon: 'M9 3h6v9.5l-1.2 3h-3.6L9 12.5zM10.4 15.5l.6 5h2l.6-5M9 8h6',
    min: 1.5,
    max: 12,
    size: 3.6,
    sens: 0.08,
    smooth: 0.55,
    opacity: 1,
    nib: 'yuvarlak',
    angle: 45,
    color: '#c62828',
  },
  {
    id: 'fosforlu',
    t: N_('Fosforlu kalem'),
    kind: 'fosforlu',
    icon: 'M9 15l-4 5h6l2-2M9 15l6-11 5 3-6 11zM9 15l5 3',
    min: 5,
    max: 30,
    size: 12,
    sens: 0,
    smooth: 0.7,
    opacity: 0.38,
    nib: 'yuvarlak',
    angle: 80,
    color: '#ffe14d',
  },
];
export const TYPE = Object.fromEntries(PEN_TYPES.map((p) => [p.id, p])) as Record<PenType, PenTypeInfo>;
export const isPenType = (t: string | null): t is PenType => !!t && t in TYPE;

/** Geniş renk skalası: 10 gri + 10 renk tonunun 4 koyuluğu */
export const INK_PALETTE = [
  ['#000000', '#1b1b1f', '#333338', '#4a4a50', '#66676e', '#85868d', '#a5a6ad', '#c6c7cc', '#e4e5e8', '#ffffff'],
  ['#8e1b1b', '#9a3f00', '#8a6a00', '#0f5c2e', '#075a69', '#0d2a8a', '#3b1f87', '#6d1a6e', '#8a1846', '#4e2e1a'],
  ['#c62828', '#d9600b', '#c99700', '#16803c', '#0b7a8f', '#1d3fbf', '#5b37c8', '#9c27b0', '#c2185b', '#7a4a2a'],
  ['#e5484d', '#f5891f', '#f2c200', '#2fa65a', '#19a3b6', '#3b6ef0', '#7f5ff0', '#c25cd4', '#e64d8a', '#a87148'],
  ['#f28b8f', '#f9b56d', '#f7dc6f', '#7cd39a', '#7fd1dc', '#8fb0fb', '#b8a5fa', '#e3a5ec', '#f5a3c4', '#d1a77f'],
];
export const HL_PALETTE = [
  ['#ffe14d', '#fff176', '#ffd54f', '#ffb74d', '#ff8a65'],
  ['#ff9ec8', '#f48fb1', '#ce93d8', '#b39ddb', '#90caf9'],
  ['#7cc8ff', '#80deea', '#7ee8a1', '#c5e1a5', '#e6ee9c'],
];

export interface PenSetting {
  color: string;
  size: number;
  sens: number;
  smooth: number;
  opacity: number;
  nib: Nib;
}

export type EraserMode = 'kismi' | 'tam';
export interface EraserSetting {
  /** Ekrandaki çapı (piksel) */
  size: number;
  mode: EraserMode;
}
export const ERASER_MIN = 6;
export const ERASER_MAX = 96;

export interface PenPrefs {
  type: PenType;
  eraser: EraserSetting;
  per: Record<PenType, PenSetting>;
  /** Son kullanılan renkler (yazı kalemleri ve fosforlu ayrı) */
  recent: string[];
  recentHl: string[];
  penOnly: boolean;
}

const KEY = 'tura-kalem:ayarlar';

export const defaultSetting = (t: PenType): PenSetting => {
  const i = TYPE[t];
  return { color: i.color, size: i.size, sens: i.sens, smooth: i.smooth, opacity: i.opacity, nib: i.nib };
};

export function loadPrefs(): PenPrefs {
  const base: PenPrefs = {
    type: 'tukenmez',
    eraser: { size: 24, mode: 'kismi' },
    per: Object.fromEntries(PEN_TYPES.map((p) => [p.id, defaultSetting(p.id)])) as Record<PenType, PenSetting>,
    recent: ['#1d3fbf', '#1b1b1f', '#c62828', '#16803c'],
    recentHl: ['#ffe14d', '#7ee8a1', '#7cc8ff', '#ff9ec8'],
    penOnly: false,
  };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? 'null') as Partial<PenPrefs> | null;
    if (!raw) return base;
    for (const p of PEN_TYPES) {
      const s = raw.per?.[p.id];
      if (s) base.per[p.id] = { ...base.per[p.id], ...s, size: Math.min(p.max, Math.max(p.min, Number(s.size) || p.size)) };
    }
    if (raw.type && raw.type in TYPE) base.type = raw.type;
    if (raw.eraser) {
      base.eraser = {
        size: Math.min(ERASER_MAX, Math.max(ERASER_MIN, Number(raw.eraser.size) || 24)),
        mode: raw.eraser.mode === 'tam' ? 'tam' : 'kismi',
      };
    }
    if (Array.isArray(raw.recent)) base.recent = raw.recent.slice(0, 8);
    if (Array.isArray(raw.recentHl)) base.recentHl = raw.recentHl.slice(0, 8);
    base.penOnly = !!raw.penOnly;
  } catch {
    /* depolama kapalı olabilir */
  }
  return base;
}

export function savePrefs(p: PenPrefs) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* depolama kapalı olabilir */
  }
}

/** Ayarlardan çizim stili */
export function styleFrom(t: PenType, s: PenSetting, pressure: boolean): PenStyle {
  const i = TYPE[t];
  return {
    kind: i.kind,
    type: t,
    size: s.size,
    pressure,
    thinning: Math.round(s.sens * 0.95 * 100) / 100,
    smoothing: s.smooth,
    nib: s.nib,
    angle: i.angle,
    opacity: s.opacity,
  };
}

export const pushRecent = (list: string[], c: string) => [c, ...list.filter((x) => x.toLowerCase() !== c.toLowerCase())].slice(0, 8);
