// Tura Kalem — basınca duyarlı kalem, avuç içi engelleme, kement ile seçme, güzelleştirme, el yazısı tanıma
// SPDX-License-Identifier: AGPL-3.0-or-later
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { PluginRegistry } from '@embedpdf/react-pdf-viewer';
import { PdfAnnotationSubtype, type PdfAnnotationObject } from '@embedpdf/models';
import { beautify, eraseFrom, inside, outline, segDist, simplify, type P2, type P3, type PenStyle, type PenType } from './geometry';
import { ViewerBridge, isPen, styleOf, type PageHit, type PenCustom } from './viewerBridge';
import {
  ERASER_MAX,
  ERASER_MIN,
  HL_PALETTE,
  INK_PALETTE,
  PEN_TYPES,
  TYPE,
  defaultSetting,
  isPenType,
  loadPrefs,
  pushRecent,
  savePrefs,
  styleFrom,
  type EraserSetting,
  type PenPrefs,
  type PenSetting,
} from './penSettings';
import { recognizeStrokes, type HandwritingResult } from './handwriting';
import { closeOcr } from '../tools/lib/ocr';
import { __, fmtNum, getLang } from '../i18n';

type Tool = PenType | 'silgi' | 'kement';
type Pop = 'renk' | 'ayar' | 'silgi' | null;

const I = {
  kalem: 'M4 20l4-1L19 8l-3-3L5 16zM14 7l3 3',
  ayar: 'M4 7h9M17 7h3M4 17h3M11 17h9M15 5v4M9 15v4',
  renk: 'M12 3a9 9 0 1 0 0 18c1.2 0 1.6-.8 1.3-1.7-.4-1.1.3-2.3 1.6-2.3H17a4 4 0 0 0 4-4c0-5.5-4-10-9-10zM7.5 11.5h.01M10 7.5h.01M14.5 7.5h.01M17 11h.01',
  silgi: 'M7 20h12M5 15l8-8 6 6-5 5H9z',
  kement: 'M12 4c5 0 8 2 8 5s-3 5-8 5-8-2-8-5 3-5 8-5zM7 13c-1 3 0 6 3 7',
  tani: 'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M8 8h8M12 8v8',
  guzel: 'M5 19l9-9M14 6l1-3 1 3 3 1-3 1-1 3-1-3-3-1zM18 13l.6-1.6L20 11l-1.4-.4L18 9l-.6 1.6L16 11l1.4.4z',
  sil: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13',
  kapat: 'M6 6l12 12M18 6L6 18',
};

function Icon({ d, size = 20 }: { d: string; size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
      <path d={d} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

interface Live {
  id: number;
  tool: Tool;
  hit: PageHit;
  pts: P3[];
  pen: boolean;
  erased: Set<string>;
}

export function PenLayer({
  registry,
  host,
  author,
  onToast,
}: {
  registry: PluginRegistry | null;
  host: HTMLElement | null;
  author: string;
  onToast: (m: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [prefs, setPrefs] = useState<PenPrefs>(loadPrefs);
  const [tool, setTool] = useState<Tool | null>(prefs.type);
  const [pop, setPop] = useState<Pop>(null);
  const penOnly = prefs.penOnly;
  const setPenOnly = (v: boolean) => setPrefs((p) => ({ ...p, penOnly: v }));
  const [selCount, setSelCount] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [result, setResult] = useState<{ r: HandwritingResult; ids: string[]; page: number } | null>(null);
  const [livePath, setLivePath] = useState<string>('');
  /** Silginin ekrandaki yeri ve yarıçapı (imleç halkası) */
  const [eraserAt, setEraserAt] = useState<{ x: number; y: number; r: number } | null>(null);
  const [liveFill, setLiveFill] = useState<{ color: string; opacity: number; lasso: boolean; blend: boolean }>({
    color: '#000',
    opacity: 1,
    lasso: false,
    blend: false,
  });

  const bridge = useRef<ViewerBridge | null>(null);
  const live = useRef<Live | null>(null);
  const palette = useRef<HTMLDivElement>(null);
  const lastPen = useRef(0);
  const raf = useRef(0);
  /** Bu oturumda kalemle yazılan sayfalar: kalem kapatılınca el yazısı tanınır */
  const written = useRef(new Set<number>());
  const st = useRef({ tool, prefs, penOnly, open });
  st.current = { tool, prefs, penOnly, open };

  useEffect(() => savePrefs(prefs), [prefs]);

  useEffect(() => {
    bridge.current = registry && host ? new ViewerBridge(registry, host) : null;
    if (import.meta.env.DEV) (window as any).__turaPen = bridge.current;
    const ann = bridge.current?.ann;
    if (!ann) return;
    const off = ann.onStateChange?.(() => setSelCount(ann.getSelectedAnnotations?.().length ?? 0));
    return () => {
      if (typeof off === 'function') off();
    };
  }, [registry, host]);

  // ---------------------------------------------------------------- canlı çizim
  const draw = useCallback(() => {
    raf.current = 0;
    const l = live.current;
    if (!l) {
      setLivePath('');
      return;
    }
    const { rect, w, h } = l.hit;
    const toScreen = (x: number, y: number) => `${(rect.left + (x / w) * rect.width).toFixed(1)},${(rect.top + (y / h) * rect.height).toFixed(1)}`;
    if (l.tool === 'silgi') {
      setLivePath('');
      return;
    }
    if (l.tool === 'kement') {
      setLivePath(l.pts.length ? 'M' + l.pts.map((p) => toScreen(p[0], p[1])).join('L') : '');
      return;
    }
    const o = outline(l.pts, styleFor(l), false);
    setLivePath(o.length ? 'M' + o.map((p) => toScreen(p[0], p[1])).join('L') + 'Z' : '');
  }, []);
  const schedule = () => {
    if (!raf.current) raf.current = requestAnimationFrame(draw);
  };

  const styleFor = (l: { tool: Tool; pen: boolean }): PenStyle => {
    const t = isPenType(l.tool) ? l.tool : 'tukenmez';
    return styleFrom(t, st.current.prefs.per[t], l.pen);
  };

  // ---------------------------------------------------------------- silgi
  /** Silgi yarıçapı sayfa biriminde (pt): ekrandaki boyut yakınlaştırmaya göre çevrilir */
  const eraserRadius = (hit: PageHit) => (st.current.prefs.eraser.size / 2) * (hit.w / hit.rect.width);

  /** Silgi (ax,ay)→(x,y) boyunca geçer: Tura Kalem izleri kalem gibi kısmen, diğer çizimler bütün olarak silinir */
  const eraseAt = (l: Live, ax: number, ay: number, x: number, y: number) => {
    const b = bridge.current;
    if (!b) return;
    const r = eraserRadius(l.hit);
    const whole = st.current.prefs.eraser.mode === 'tam';
    const x0 = Math.min(ax, x) - r;
    const x1 = Math.max(ax, x) + r;
    const y0 = Math.min(ay, y) - r;
    const y1 = Math.max(ay, y) + r;
    for (const o of b.annotations(l.hit.index)) {
      if (l.erased.has(o.id)) continue;
      const pad = ((o as any).custom?.s ?? 2) + 2;
      const rc = o.rect;
      if (rc.origin.x - pad > x1 || rc.origin.x + rc.size.width + pad < x0 || rc.origin.y - pad > y1 || rc.origin.y + rc.size.height + pad < y0) continue;
      if (isPen(o)) {
        const c = (o as any).custom as PenCustom;
        const center = b.centerOf(o);
        if (!center) continue;
        const parts = eraseFrom(center, [ax, ay], [x, y], r, c.s / 2);
        if (!parts) continue;
        if (whole || !parts.length) {
          l.erased.add(o.id);
          b.ann?.deleteAnnotation(o.pageIndex, o.id);
          continue;
        }
        const style: PenStyle = { ...styleOf(c), opacity: (o as any).opacity ?? 1 };
        const shape = (pts: P3[]) => simplify(outline(pts, style, true), 0.06);
        b.updateStroke(o, shape(parts[0]), parts[0]);
        for (const seg of parts.slice(1)) b.addStroke(o.pageIndex, shape(seg), seg, style, (o as any).color ?? '#000', author);
      } else if (o.type === PdfAnnotationSubtype.INK) {
        const w = ((o as any).strokeWidth ?? 1) / 2 + r;
        const hit = ((o as any).inkList as { points: { x: number; y: number }[] }[]).some((s) =>
          s.points.some((q) => segDist(q.x, q.y, [ax, ay], [x, y]) < w),
        );
        if (hit) {
          l.erased.add(o.id);
          b.ann?.deleteAnnotation(o.pageIndex, o.id);
        }
      }
    }
  };

  // ---------------------------------------------------------------- kement
  const lassoSelect = (l: Live) => {
    const b = bridge.current;
    if (!b || l.pts.length < 3) return;
    const poly = l.pts.map((p) => [p[0], p[1]] as P2);
    const ids: string[] = [];
    for (const o of b.annotations(l.hit.index)) {
      let pts: P2[];
      if ((o as any).vertices) pts = (o as any).vertices.map((q: any) => [q.x, q.y]);
      else if ((o as any).inkList) pts = (o as any).inkList.flatMap((s: any) => s.points.map((q: any) => [q.x, q.y]));
      else pts = [[o.rect.origin.x + o.rect.size.width / 2, o.rect.origin.y + o.rect.size.height / 2]];
      if (!pts.length) continue;
      const step = Math.max(1, Math.floor(pts.length / 40));
      let inn = 0;
      let all = 0;
      for (let i = 0; i < pts.length; i += step, all++) if (inside(pts[i][0], pts[i][1], poly)) inn++;
      if (inn / all >= 0.6) ids.push(o.id);
    }
    if (!ids.length) {
      onToast(__('Kement içinde not yok'));
      return;
    }
    b.ann?.setSelection(ids);
    // Seçim tutamaçlarıyla taşınıp boyutlandırılabilsin diye kalem geçici olarak bırakılır
    setTool(null);
    onToast(__('{0} öge seçildi: sürükle, köşelerden büyüt; renk ve diğer işlemler aşağıda', [ids.length]));
  };

  // ---------------------------------------------------------------- bitir
  const finish = (l: Live) => {
    const b = bridge.current;
    if (!b) return;
    if (l.tool === 'kement') return lassoSelect(l);
    if (l.tool === 'silgi') return;
    let pts = l.pts;
    if (pts.length === 1) pts = [pts[0], [pts[0][0] + 0.2, pts[0][1] + 0.2, pts[0][2]]];
    if (!isPenType(l.tool)) return;
    const style = styleFor(l);
    const o = simplify(outline(pts, style, true), 0.06);
    const id = b.addStroke(l.hit.index, o, pts, style, st.current.prefs.per[l.tool].color, author);
    if (id && style.kind === 'kalem') written.current.add(l.hit.index);
  };

  // ---------------------------------------------------------------- giriş olayları
  useEffect(() => {
    if (!open || !tool) return;
    const own = (e: Event) => !!palette.current && e.composedPath().includes(palette.current);

    const down = (e: PointerEvent) => {
      const s = st.current;
      if (!s.tool || own(e)) return;
      const isPenInput = e.pointerType === 'pen';
      if (isPenInput) {
        lastPen.current = Date.now();
        // Kalem kullanılıyorsa parmak artık çizmez: avuç içi ve parmak sayfayı kaydırır
        if (!s.penOnly) setPrefs((p) => ({ ...p, penOnly: true }));
      }
      if (e.pointerType === 'touch' && (s.penOnly || live.current)) {
        // Yazarken değen avuç içi hiçbir şey yapmasın (sayfa da kaymasın)
        if (live.current || Date.now() - lastPen.current < 500) {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
        return;
      }
      if (live.current) return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const b = bridge.current;
      const hit = b?.pageAt(e.clientX, e.clientY);
      if (!b || !hit) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      // Kalemin arka ucu ya da silgi düğmesi: silgi
      const tl: Tool = isPenInput && (e.buttons & 32) ? 'silgi' : s.tool;
      const [x, y] = b.toPage(hit, e.clientX, e.clientY);
      const p = isPenInput && e.pressure > 0 ? e.pressure : 0.5;
      live.current = { id: e.pointerId, tool: tl, hit, pts: [[x, y, p]], pen: isPenInput, erased: new Set() };
      setPop(null);
      setLiveFill(
        isPenType(tl)
          ? { color: s.prefs.per[tl].color, opacity: s.prefs.per[tl].opacity, lasso: false, blend: tl === 'fosforlu' || tl === 'kursun' }
          : { color: '#0b7a8f', opacity: 1, lasso: true, blend: false },
      );
      if (tl === 'silgi') {
        eraseAt(live.current, x, y, x, y);
        setEraserAt({ x: e.clientX, y: e.clientY, r: s.prefs.eraser.size / 2 });
      }
      schedule();
    };
    const move = (e: PointerEvent) => {
      const l = live.current;
      if (!l) {
        // Silgi seçiliyken fare ya da kalem gezdirildiğinde silgi halkası görünür
        if (st.current.tool === 'silgi' && e.pointerType !== 'touch' && bridge.current?.pageAt(e.clientX, e.clientY))
          setEraserAt({ x: e.clientX, y: e.clientY, r: st.current.prefs.eraser.size / 2 });
        else setEraserAt(null);
        return;
      }
      if (e.pointerId !== l.id) {
        if (e.pointerType === 'touch') {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      if (l.pen) lastPen.current = Date.now();
      if (l.tool === 'silgi') setEraserAt({ x: e.clientX, y: e.clientY, r: st.current.prefs.eraser.size / 2 });
      const evs = (e as any).getCoalescedEvents?.() as PointerEvent[] | undefined;
      for (const ev of evs?.length ? evs : [e]) {
        const [x, y] = bridge.current!.toPage(l.hit, ev.clientX, ev.clientY);
        const last = l.pts[l.pts.length - 1];
        if (Math.hypot(x - last[0], y - last[1]) < 0.15) continue;
        const p = l.pen && ev.pressure > 0 ? ev.pressure : 0.5;
        if (l.tool === 'silgi') eraseAt(l, last[0], last[1], x, y);
        l.pts.push([x, y, p]);
      }
      schedule();
    };
    const up = (e: PointerEvent) => {
      const l = live.current;
      if (!l || e.pointerId !== l.id) {
        if (live.current && e.pointerType === 'touch') e.stopImmediatePropagation();
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      live.current = null;
      if (l.pen) lastPen.current = Date.now();
      if (l.tool === 'silgi' && e.pointerType === 'touch') setEraserAt(null);
      if (e.type === 'pointerup') finish(l);
      schedule();
    };
    // Kalem değerken ve hemen ardından sayfa kaymasın (dokunmatik kaydırmayı durdur)
    const touch = (e: TouchEvent) => {
      if (own(e)) return;
      const stylus = Array.from(e.touches).some((t) => (t as any).touchType === 'stylus');
      const writing = !!live.current || Date.now() - lastPen.current < 500;
      if (stylus || writing) {
        if (e.cancelable) e.preventDefault();
        return;
      }
      // Parmakla yazma açıkken: tek parmak sayfada yazar (kaydırmaz), iki parmak kaydırır/yakınlaştırır
      const t = e.touches[0];
      if (!st.current.penOnly && e.touches.length === 1 && t && bridge.current?.pageAt(t.clientX, t.clientY)) {
        if (e.cancelable) e.preventDefault();
      }
    };
    const opts = { capture: true, passive: false } as AddEventListenerOptions;
    window.addEventListener('pointerdown', down, opts);
    window.addEventListener('pointermove', move, opts);
    window.addEventListener('pointerup', up, opts);
    window.addEventListener('pointercancel', up, opts);
    window.addEventListener('touchstart', touch, opts);
    window.addEventListener('touchmove', touch, opts);
    return () => {
      window.removeEventListener('pointerdown', down, opts);
      window.removeEventListener('pointermove', move, opts);
      window.removeEventListener('pointerup', up, opts);
      window.removeEventListener('pointercancel', up, opts);
      window.removeEventListener('touchstart', touch, opts);
      window.removeEventListener('touchmove', touch, opts);
      live.current = null;
      setLivePath('');
      setEraserAt(null);
    };
  }, [open, tool]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---------------------------------------------------------------- seçim işlemleri
  const selected = (): PdfAnnotationObject[] => (bridge.current?.ann?.getSelectedAnnotations() ?? []).map((t) => t.object);

  const recolor = (c: string) => {
    const b = bridge.current;
    if (!b) return;
    for (const o of selected()) b.setColor(o, c);
  };

  const enhance = () => {
    const b = bridge.current;
    if (!b) return;
    const pens = selected().filter(isPen);
    if (!pens.length) {
      onToast(__('Güzelleştirme Tura Kalem ile yazılanlarda çalışır'));
      return;
    }
    let shapes = 0;
    for (const o of pens) {
      const c = (o as any).custom as PenCustom;
      const center = b.centerOf(o);
      if (!center) continue;
      const r = beautify(center);
      if (r.shape) shapes++;
      const style: PenStyle = styleOf(c, !!c.pr && !r.shape);
      b.updateStroke(o, simplify(outline(r.pts, style, true, true), 0.06), r.pts);
    }
    onToast(shapes ? __('Güzelleştirildi · {0} şekil düzeltildi', [shapes]) : __('Güzelleştirildi'));
  };

  const removeSel = () => {
    const sel = selected();
    bridge.current?.ann?.deleteAnnotations(sel.map((o) => ({ pageIndex: o.pageIndex, id: o.id })) as any);
  };

  const recognize = async (useSelection: boolean) => {
    const b = bridge.current;
    if (!b) return;
    let strokes = useSelection ? selected().filter(isPen) : [];
    let page = strokes[0]?.pageIndex ?? -1;
    if (!strokes.length) {
      page = (registry?.getPlugin('scroll') as any)?.provides?.().getCurrentPage?.() - 1;
      if (!(page >= 0)) page = 0;
      strokes = b.annotations(page).filter(isPen);
    }
    if (!strokes.length) {
      onToast(__('Bu sayfada Tura Kalem ile yazılmış yazı yok'));
      return;
    }
    setBusy(__('El yazısı tanınıyor…'));
    try {
      const r = await recognizeStrokes(strokes, 'tur+eng', (p) => setBusy(p.phase === 'yukleniyor' ? __('Yazı tanıma hazırlanıyor…') : __('El yazısı tanınıyor…')));
      if (!r?.text) onToast(__('Yazı tanınamadı; daha belirgin yazmayı deneyin'));
      else setResult({ r, ids: strokes.map((s) => s.id), page });
    } catch (e) {
      onToast(__('Tanıma başarısız: ') + (e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  /** Kalem kapatılırken: bu oturumda yazılan sayfalardaki el yazısı tanınıp notlara eklenir (arama için) */
  const autoRecognize = async () => {
    const b = bridge.current;
    const pages = [...written.current];
    written.current.clear();
    if (!b || !pages.length) return;
    let n = 0;
    for (const page of pages) {
      const strokes = b.annotations(page).filter((o) => isPen(o) && (o as any).custom?.k === 'kalem');
      const fresh = strokes.filter((o) => !(o as any).custom?.ocr);
      if (!fresh.length) continue;
      try {
        const r = await recognizeStrokes(strokes, 'tur+eng');
        if (!r?.text) continue;
        // Metin, sayfadaki ilk izin notuna yazılır; diğerleri "tanındı" olarak işaretlenir
        strokes.forEach((o, i) =>
          b.ann?.updateAnnotation(o.pageIndex, o.id, {
            ...(i === 0 ? { contents: __('El yazısı: {0}', [r.text]) } : {}),
            custom: { ...(o as any).custom, ocr: 1 },
          } as any),
        );
        n++;
      } catch {
        /* tanıma isteğe bağlı */
      }
    }
    if (n) onToast(__('El yazısı tanındı ve notlara eklendi ({0} sayfa)', [n]));
  };

  const toText = () => {
    const b = bridge.current;
    if (!b || !result) return;
    const { r, ids, page } = result;
    const fontSize = Math.max(8, Math.min(28, (r.box.h / r.lines) * 0.62));
    b.ann?.createAnnotation(page, {
      type: PdfAnnotationSubtype.FREETEXT,
      id: crypto.randomUUID(),
      pageIndex: page,
      rect: { origin: { x: r.box.x, y: r.box.y }, size: { width: Math.max(r.box.w, 60), height: Math.max(r.box.h, fontSize * 1.6) } },
      contents: r.text,
      fontFamily: 4,
      fontSize,
      fontColor: st.current.prefs.per[isPenType(st.current.tool) && st.current.tool !== 'fosforlu' ? st.current.tool : 'tukenmez'].color,
      textAlign: 0,
      verticalAlign: 0,
      opacity: 1,
      flags: ['print'],
      author,
      created: new Date(),
    } as any);
    b.ann?.deleteAnnotations(ids.map((id) => ({ pageIndex: page, id })) as any);
    setResult(null);
    onToast(__('El yazısı metne çevrildi'));
  };

  // ---------------------------------------------------------------- ayarlar
  const penTool: PenType | null = isPenType(tool) ? tool : null;
  const setting = (t: PenType) => prefs.per[t];
  const patch = (t: PenType, p: Partial<PenSetting>) => setPrefs((x) => ({ ...x, per: { ...x.per, [t]: { ...x.per[t], ...p } } }));

  const pickTool = (t: Tool) => {
    bridge.current?.ann?.deselectAnnotation();
    if (t === tool && (isPenType(t) || t === 'silgi')) {
      // Aynı kaleme ya da silgiye yeniden dokunmak ayarlarını açar
      const want: Pop = t === 'silgi' ? 'silgi' : 'ayar';
      setPop((p) => (p === want ? null : want));
      return;
    }
    setTool(t);
    setPop(null);
    if (isPenType(t)) setPrefs((p) => ({ ...p, type: t }));
  };

  const pickColor = (c: string) => {
    if (showSel) {
      recolor(c);
      return;
    }
    const t = penTool ?? 'tukenmez';
    const hl = TYPE[t].kind === 'fosforlu';
    setPrefs((x) => ({
      ...x,
      per: { ...x.per, [t]: { ...x.per[t], color: c } },
      ...(hl ? { recentHl: pushRecent(x.recentHl, c) } : { recent: pushRecent(x.recent, c) }),
    }));
  };

  const close = () => {
    setOpen(false);
    setPop(null);
    void autoRecognize().finally(() => void closeOcr());
  };

  // ---------------------------------------------------------------- arayüz
  const showSel = open && !tool && selCount > 0;
  const colorTool: PenType = penTool ?? 'tukenmez';
  const isHl = TYPE[colorTool].kind === 'fosforlu';
  const current = setting(colorTool).color;
  const quick = useMemo(() => {
    const list = isHl ? prefs.recentHl : prefs.recent;
    return [current, ...list.filter((c) => c.toLowerCase() !== current.toLowerCase())].slice(0, 4);
  }, [isHl, prefs.recent, prefs.recentHl, current]);
  if (!registry) return null;

  return (
    <>
      {open && tool === 'silgi' && eraserAt && (
        <svg className="pen-live" aria-hidden="true">
          <circle cx={eraserAt.x} cy={eraserAt.y} r={eraserAt.r} fill="rgb(255 255 255 / 0.35)" stroke="#0b7a8f" strokeWidth="1.5" />
          <circle cx={eraserAt.x} cy={eraserAt.y} r={Math.max(0, eraserAt.r - 1.5)} fill="none" stroke="rgb(0 0 0 / 0.25)" strokeWidth="1" />
        </svg>
      )}
      {livePath && (
        <svg className="pen-live" aria-hidden="true">
          {liveFill.lasso ? (
            <path d={livePath} fill="rgb(11 122 143 / 0.08)" stroke="#0b7a8f" strokeWidth="1.5" strokeDasharray="5 4" />
          ) : (
            <path d={livePath} fill={liveFill.color} opacity={liveFill.opacity} style={{ mixBlendMode: liveFill.blend ? 'multiply' : undefined }} />
          )}
        </svg>
      )}

      {!open ? (
        <button
          className="pen-fab"
          aria-label={__('Tura Kalem')}
          onClick={() => (setOpen(true), setTool((t) => t ?? prefs.type))}
          title={__('Tura Kalem: tükenmez, dolma, kurşun, keçeli ve fosforlu kalem; kement, güzelleştirme, el yazısı tanıma')}
        >
          <Icon d={I.kalem} size={22} />
          <span>{__('Kalem')}</span>
        </button>
      ) : (
        <div className="pen-bar" ref={palette} role="toolbar" aria-label={__('Tura Kalem')}>
          {pop === 'renk' && (
            <ColorPop
              palette={isHl && !showSel ? HL_PALETTE : INK_PALETTE}
              current={showSel ? '' : current}
              title={showSel ? __('Seçilenlerin rengi') : __('{0} rengi', [__(TYPE[colorTool].t)])}
              onPick={(c) => {
                pickColor(c);
                if (showSel) setPop(null);
              }}
              onClose={() => setPop(null)}
            />
          )}
          {pop === 'ayar' && penTool && (
            <SettingsPop
              type={penTool}
              value={setting(penTool)}
              penOnly={penOnly}
              onPenOnly={setPenOnly}
              onChange={(p) => patch(penTool, p)}
              onReset={() => patch(penTool, defaultSetting(penTool))}
              onClose={() => setPop(null)}
            />
          )}

          {pop === 'silgi' && (
            <EraserPop
              value={prefs.eraser}
              onChange={(p) => setPrefs((x) => ({ ...x, eraser: { ...x.eraser, ...p } }))}
              onClose={() => setPop(null)}
            />
          )}

          <div className="pen-bar__group pen-bar__tools" role="group" aria-label={__('Kalemler')}>
            {PEN_TYPES.map((p) => (
              <button
                key={p.id}
                className={tool === p.id ? 'pen-btn pen-tool pen-btn--on' : 'pen-btn pen-tool'}
                aria-pressed={tool === p.id}
                aria-label={__(p.t)}
                title={tool === p.id ? __('{0} — ayarlar için yeniden dokun', [__(p.t)]) : __(p.t)}
                onClick={() => pickTool(p.id)}
              >
                <Icon d={p.icon} />
                <i className="pen-tool__ink" style={{ background: setting(p.id).color, opacity: Math.max(0.5, setting(p.id).opacity) }} aria-hidden="true" />
              </button>
            ))}
            <button
              className={tool === 'silgi' ? 'pen-btn pen-btn--on' : 'pen-btn'}
              aria-pressed={tool === 'silgi'}
              aria-label={__('Silgi')}
              title={tool === 'silgi' ? __('Silgi — ayarlar için yeniden dokun') : __('Silgi (kalemin arka ucu da siler)')}
              onClick={() => pickTool('silgi')}
            >
              <Icon d={I.silgi} />
            </button>
            <button
              className={tool === 'kement' ? 'pen-btn pen-btn--on' : 'pen-btn'}
              aria-pressed={tool === 'kement'}
              aria-label={__('Kement')}
              title={__('Kement: çevresini çizerek seç; taşı, büyüt, rengini değiştir')}
              onClick={() => pickTool('kement')}
            >
              <Icon d={I.kement} />
            </button>
          </div>

          {tool === 'silgi' && (
            <div className="pen-bar__group" role="group" aria-label={__('Silgi boyutu')}>
              {[12, 24, 48].map((d) => (
                <button
                  key={d}
                  className={prefs.eraser.size === d ? 'pen-btn pen-btn--on' : 'pen-btn'}
                  aria-label={__('Silgi boyutu {0}', [d])}
                  title={d === 12 ? __('Küçük silgi') : d === 24 ? __('Orta silgi') : __('Büyük silgi')}
                  onClick={() => setPrefs((x) => ({ ...x, eraser: { ...x.eraser, size: d } }))}
                >
                  <span className="pen-eraser-dot" style={{ width: 6 + d / 3, height: 6 + d / 3 }} />
                </button>
              ))}
              <button
                className={pop === 'silgi' ? 'pen-btn pen-btn--on' : 'pen-btn'}
                aria-label={__('Silgi ayarları')}
                aria-expanded={pop === 'silgi'}
                title={__('Silgi boyutu ve silme biçimi')}
                onClick={() => setPop((p) => (p === 'silgi' ? null : 'silgi'))}
              >
                <Icon d={I.ayar} />
              </button>
            </div>
          )}
          {(penTool || showSel) && (
            <div className="pen-bar__group" role="group" aria-label={__('Renk')}>
              {(showSel ? INK_PALETTE[2].slice(0, 4) : quick).map((c) => (
                <button
                  key={c}
                  className={!showSel && current.toLowerCase() === c.toLowerCase() ? 'pen-dot pen-dot--on' : 'pen-dot'}
                  style={{ background: c }}
                  aria-label={__('Renk {0}', [c])}
                  onClick={() => pickColor(c)}
                />
              ))}
              <button
                className={pop === 'renk' ? 'pen-btn pen-btn--on' : 'pen-btn'}
                aria-label={__('Tüm renkler')}
                aria-expanded={pop === 'renk'}
                title={__('Tüm renkler ve özel renk')}
                onClick={() => setPop((p) => (p === 'renk' ? null : 'renk'))}
              >
                <Icon d={I.renk} />
              </button>
            </div>
          )}
          {penTool && (
            <div className="pen-bar__group">
              <button
                className={pop === 'ayar' ? 'pen-btn pen-btn--on' : 'pen-btn'}
                aria-label={__('Kalem ayarları')}
                aria-expanded={pop === 'ayar'}
                title={__('Kalınlık, basınç hassasiyeti, uç ve titreme düzeltme')}
                onClick={() => setPop((p) => (p === 'ayar' ? null : 'ayar'))}
              >
                <span
                  className="pen-size"
                  style={{
                    width: Math.max(4, Math.min(20, 3 + setting(penTool).size * 2)),
                    height: Math.max(4, Math.min(20, 3 + setting(penTool).size * 2)),
                    background: setting(penTool).color,
                  }}
                />
                <Icon d={I.ayar} />
              </button>
            </div>
          )}

          {showSel ? (
            <div className="pen-bar__group">
              <button className="pen-btn" onClick={enhance} title={__('Titremeyi al, çizgi/daire/dikdörtgeni düzelt')}>
                <Icon d={I.guzel} />
                <span className="pen-btn__t">{__('Güzelleştir')}</span>
              </button>
              <button className="pen-btn" onClick={() => void recognize(true)} title={__('Seçili el yazısını metne çevir')}>
                <Icon d={I.tani} />
                <span className="pen-btn__t">{__('El yazısını tanı')}</span>
              </button>
              <button className="pen-btn pen-btn--danger" onClick={removeSel} title={__('Seçileni sil')} aria-label={__('Seçileni sil')}>
                <Icon d={I.sil} />
              </button>
            </div>
          ) : (
            <div className="pen-bar__group">
              <button className="pen-btn" onClick={() => void recognize(false)} title={__('Bu sayfadaki el yazısını tanı')}>
                <Icon d={I.tani} />
                <span className="pen-btn__t">{__('El yazısını tanı')}</span>
              </button>
            </div>
          )}
          <button className="pen-btn" onClick={close} title={__('Kalemi kapat')} aria-label={__('Kalemi kapat')}>
            <Icon d={I.kapat} />
          </button>
          {busy && (
            <p className="pen-busy" role="status">
              {busy}
            </p>
          )}
        </div>
      )}

      {result && (
        <div className="dialog-veil" role="presentation" onClick={() => setResult(null)}>
          <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="hw-title" onClick={(e) => e.stopPropagation()}>
            <h2 id="hw-title">{__('Tanınan yazı')}</h2>
            <textarea
              className="ocr-text__area"
              rows={6}
              value={result.r.text}
              onChange={(e) => setResult({ ...result, r: { ...result.r, text: e.target.value } })}
              aria-label={__('Tanınan yazı (düzeltebilirsin)')}
            />
            <p className="pen-note">
              {__('Güven: %')}{Math.round(result.r.confidence)}{__('. El yazısında tanıma hata yapabilir; metni burada düzeltebilirsin.')}
            </p>
            <div className="dialog__actions">
              <button className="btn btn--ghost" onClick={() => setResult(null)}>
                {__('Kapat')}
              </button>
              <button
                className="btn btn--ghost"
                onClick={() => {
                  void navigator.clipboard?.writeText(result.r.text).then(
                    () => onToast(__('Metin panoya kopyalandı')),
                    () => onToast(__('Kopyalanamadı')),
                  );
                }}
              >
                {__('Kopyala')}
              </button>
              <button className="btn btn--primary" onClick={toText}>
                {__('Metne çevir')}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}


// ---------------------------------------------------------------- açılır paneller
function ColorPop({
  palette,
  current,
  title,
  onPick,
  onClose,
}: {
  palette: string[][];
  current: string;
  title: string;
  onPick: (c: string) => void;
  onClose: () => void;
}) {
  const [hex, setHex] = useState(current);
  useEffect(() => setHex(current), [current]);
  const valid = /^#[0-9a-f]{6}$/i.test(hex);
  return (
    <div className="pen-pop" role="dialog" aria-label={title}>
      <div className="pen-pop__head">
        <b>{title}</b>
        <button className="pen-btn pen-btn--sm" onClick={onClose} aria-label={__('Kapat')}>
          <Icon d={I.kapat} size={16} />
        </button>
      </div>
      <div className="pen-palette" role="radiogroup" aria-label={__('Renk skalası')} style={{ gridTemplateColumns: `repeat(${palette[0].length}, 1fr)` }}>
        {palette.flat().map((c) => (
          <button
            key={c}
            role="radio"
            aria-checked={current.toLowerCase() === c.toLowerCase()}
            aria-label={__('Renk {0}', [c])}
            className="pen-sw"
            style={{ background: c }}
            onClick={() => onPick(c)}
          />
        ))}
      </div>
      <div className="pen-pop__row">
        <label className="pen-custom" title={__('Herhangi bir renk seç')}>
          <span className="pen-custom__sw" style={{ background: valid ? hex : current || '#000' }} />
          {__('Özel renk')}
          <input type="color" value={valid ? hex : '#000000'} onChange={(e) => (setHex(e.target.value), onPick(e.target.value))} />
        </label>
        <input
          className="pen-hex"
          value={hex}
          maxLength={7}
          spellCheck={false}
          aria-label={__('Renk kodu')}
          onChange={(e) => setHex(e.target.value.startsWith('#') ? e.target.value : `#${e.target.value}`)}
          onKeyDown={(e) => e.key === 'Enter' && valid && onPick(hex.toLowerCase())}
          onBlur={() => valid && hex.toLowerCase() !== current.toLowerCase() && onPick(hex.toLowerCase())}
        />
      </div>
    </div>
  );
}

/** Örnek bir çizgiyle kalemin o anki görünümü (basınç yavaşça artıp azalır) */
function PenPreview({ type, value }: { type: PenType; value: PenSetting }) {
  const d = useMemo(() => {
    const pts: P3[] = [];
    for (let i = 0; i <= 60; i++) {
      const t = i / 60;
      pts.push([12 + t * 156, 26 + Math.sin(t * Math.PI * 2.2) * 11, 0.15 + 0.8 * Math.sin(Math.PI * t)]);
    }
    const o = outline(pts, styleFrom(type, value, true), true);
    return o.length ? 'M' + o.map((p) => `${p[0].toFixed(2)},${p[1].toFixed(2)}`).join('L') + 'Z' : '';
  }, [type, value]);
  const hl = TYPE[type].kind === 'fosforlu';
  return (
    <svg className="pen-preview" viewBox="0 0 180 52" aria-hidden="true">
      {hl && (
        <g fill="#9aa0b4">
          <rect x="14" y="16" width="150" height="3" rx="1.5" />
          <rect x="14" y="25" width="120" height="3" rx="1.5" />
          <rect x="14" y="34" width="140" height="3" rx="1.5" />
        </g>
      )}
      <path d={d} fill={value.color} opacity={value.opacity} style={{ mixBlendMode: hl || type === 'kursun' ? 'multiply' : undefined }} />
    </svg>
  );
}

function Range({
  label,
  value,
  min,
  max,
  step,
  show,
  hint,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  show: string;
  hint?: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="pen-range">
      <span className="pen-range__top">
        {label}
        <output>{show}</output>
      </span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
      {hint && <small>{hint}</small>}
    </label>
  );
}

function SettingsPop({
  type,
  value,
  penOnly,
  onPenOnly,
  onChange,
  onReset,
  onClose,
}: {
  type: PenType;
  value: PenSetting;
  penOnly: boolean;
  onPenOnly: (v: boolean) => void;
  onChange: (p: Partial<PenSetting>) => void;
  onReset: () => void;
  onClose: () => void;
}) {
  const info = TYPE[type];
  const pct = (v: number) => (getLang() === 'tr' ? `%${Math.round(v * 100)}` : `${Math.round(v * 100)}%`);
  return (
    <div className="pen-pop pen-pop--ayar" role="dialog" aria-label={__('{0} ayarları', [info.t])}>
      <div className="pen-pop__head">
        <b>{__(info.t)}</b>
        <button className="pen-link" onClick={onReset}>
          {__('Varsayılan')}
        </button>
        <button className="pen-btn pen-btn--sm" onClick={onClose} aria-label={__('Kapat')}>
          <Icon d={I.kapat} size={16} />
        </button>
      </div>
      <PenPreview type={type} value={value} />
      <Range
        label={__('Uç kalınlığı')}
        value={value.size}
        min={info.min}
        max={info.max}
        step={0.1}
        show={`${fmtNum(value.size)} pt`}
        onChange={(size) => onChange({ size })}
      />
      {info.kind === 'kalem' && (
        <Range
          label={__('Basınç hassasiyeti')}
          value={value.sens}
          min={0}
          max={1}
          step={0.05}
          show={pct(value.sens)}
          hint={value.sens < 0.1 ? __('Kalınlık sabit kalır') : __('Bastırdıkça kalınlaşır; kalem yoksa yazma hızına göre')}
          onChange={(sens) => onChange({ sens })}
        />
      )}
      <Range
        label={__('Titreme düzeltme')}
        value={value.smooth}
        min={0}
        max={1}
        step={0.05}
        show={pct(value.smooth)}
        onChange={(smooth) => onChange({ smooth })}
      />
      <Range
        label={__('Mürekkep yoğunluğu')}
        value={value.opacity}
        min={info.kind === 'fosforlu' ? 0.15 : 0.3}
        max={info.kind === 'fosforlu' ? 0.7 : 1}
        step={0.01}
        show={pct(value.opacity)}
        onChange={(opacity) => onChange({ opacity })}
      />
      <div className="pen-range">
        <span className="pen-range__top">{__('Uç biçimi')}</span>
        <div className="pen-seg" role="radiogroup" aria-label={__('Uç biçimi')}>
          {(
            [
              ['yuvarlak', __('Yuvarlak')],
              ['keski', type === 'fosforlu' ? __('Keski (düz uç)') : __('Keski (hat yazısı)')],
            ] as const
          ).map(([v, t]) => (
            <button key={v} role="radio" aria-checked={value.nib === v} className={value.nib === v ? 'pen-seg__on' : ''} onClick={() => onChange({ nib: v })}>
              {t}
            </button>
          ))}
        </div>
      </div>
      <label className="pen-check" title={__('Kalem kullanırken parmak ve avuç içi yazmaz, yalnızca sayfayı kaydırır')}>
        <input type="checkbox" checked={penOnly} onChange={(e) => onPenOnly(e.target.checked)} />
        {__('Yalnızca kalem yazsın (parmak sayfayı kaydırır)')}
      </label>
    </div>
  );
}

function EraserPop({ value, onChange, onClose }: { value: EraserSetting; onChange: (p: Partial<EraserSetting>) => void; onClose: () => void }) {
  return (
    <div className="pen-pop" role="dialog" aria-label={__('Silgi ayarları')}>
      <div className="pen-pop__head">
        <b>{__('Silgi')}</b>
        <button className="pen-btn pen-btn--sm" onClick={onClose} aria-label={__('Kapat')}>
          <Icon d={I.kapat} size={16} />
        </button>
      </div>
      <div className="pen-eraser-preview" aria-hidden="true">
        <span style={{ width: value.size, height: value.size }} />
      </div>
      <Range
        label={__('Silgi boyutu')}
        value={value.size}
        min={ERASER_MIN}
        max={ERASER_MAX}
        step={1}
        show={`${value.size} px`}
        hint={__('Ekranda görünen büyüklük; yakınlaştırınca daha ince yerleri silebilirsin')}
        onChange={(size) => onChange({ size })}
      />
      <div className="pen-range">
        <span className="pen-range__top">{__('Silme biçimi')}</span>
        <div className="pen-seg" role="radiogroup" aria-label={__('Silme biçimi')}>
          {(
            [
              ['kismi', __('Dokunduğu yeri sil')],
              ['tam', __('Bütün çizgiyi sil')],
            ] as const
          ).map(([v, t]) => (
            <button key={v} role="radio" aria-checked={value.mode === v} className={value.mode === v ? 'pen-seg__on' : ''} onClick={() => onChange({ mode: v })}>
              {t}
            </button>
          ))}
        </div>
        <small>{__('Kalem gibi kısmen silme Tura Kalem yazılarında çalışır; başka uygulamalardan gelen çizimler bütün olarak silinir.')}</small>
      </div>
    </div>
  );
}
