// Tura Kalem — el yazısını tanıma: kalem izleri temiz siyah-beyaz görüntüye çizilir, Tesseract okur
// SPDX-License-Identifier: AGPL-3.0-or-later
/* eslint-disable @typescript-eslint/no-explicit-any */
import type { PdfAnnotationObject } from '@embedpdf/models';
import { ocrImage, type OcrLang, type OcrProgress } from '../tools/lib/ocr';
import { bounds, type P2 } from './geometry';
import { __ } from '../i18n';

export interface HandwritingResult {
  text: string;
  confidence: number;
  /** Yazının sayfadaki kutusu (pt) */
  box: { x: number; y: number; w: number; h: number };
  /** Satır sayısı (metne çevirirken yazı boyutu için) */
  lines: number;
}

/** Fosforlu kalem dışındaki kalem izlerini okur */
export async function recognizeStrokes(strokes: PdfAnnotationObject[], lang: OcrLang, onProgress?: OcrProgress): Promise<HandwritingResult | null> {
  const polys = strokes
    .filter((o) => (o as any).custom?.k !== 'fosforlu')
    .map((o) => ((o as any).vertices as { x: number; y: number }[]).map((v) => [v.x, v.y] as P2))
    .filter((p) => p.length > 2);
  if (!polys.length) return null;
  const box = bounds(polys.flat());
  // Yazı yüksekliği ~30 piksel olacak şekilde büyüt (Tesseract'ın sevdiği boyut)
  const k = Math.min(8, Math.max(2, 2600 / Math.max(box.w, box.h)));
  const pad = 24;
  const W = Math.round(box.w * k) + pad * 2;
  const H = Math.round(box.h * k) + pad * 2;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const g = c.getContext('2d')!;
  g.fillStyle = '#fff';
  g.fillRect(0, 0, W, H);
  g.fillStyle = '#000';
  for (const p of polys) {
    g.beginPath();
    p.forEach(([x, y], i) => {
      const X = (x - box.x) * k + pad;
      const Y = (y - box.y) * k + pad;
      if (i) g.lineTo(X, Y);
      else g.moveTo(X, Y);
    });
    g.closePath();
    g.fill();
  }
  const blob = await new Promise<Blob>((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error(__('görüntü')))), 'image/png'));
  c.width = c.height = 0;
  const r = await ocrImage(blob, lang, onProgress, { block: true });
  const text = r.text
    .replace(/[|]/g, 'l')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return { text, confidence: r.confidence, box, lines: Math.max(1, text.split('\n').filter(Boolean).length) };
}
