// Tura Kalem — görüntüleyiciyle köprü: ekrandaki nokta hangi sayfanın neresi, not ekleme/silme
// SPDX-License-Identifier: AGPL-3.0-or-later
/* eslint-disable @typescript-eslint/no-explicit-any */
import type { AnnotationPlugin, PluginRegistry } from '@embedpdf/react-pdf-viewer';
import { PdfAnnotationBorderStyle, PdfAnnotationSubtype, PdfBlendMode, type PdfAnnotationObject } from '@embedpdf/models';
import { bounds, packPts, type Nib, type P2, type P3, type PenStyle, type PenType } from './geometry';

export interface PageHit {
  index: number;
  rect: DOMRect;
  /** Sayfanın görünen boyutu (pt) */
  w: number;
  h: number;
}

/** Tura Kalem izinin saklanan bilgisi (PDF'te ek veri olarak kalır) */
export interface PenCustom {
  tura: 'kalem';
  k: PenStyle['kind'];
  s: number;
  pr: 0 | 1;
  /** Orta çizgi: [x, y, basınç] */
  p: number[][];
  /** Oluşturulduğu andaki çevre kutusu: [x, y, w, h] — taşınıp boyutlandırılınca dönüşüm buradan bulunur */
  b: [number, number, number, number];
  /** Tanınan yazı yapıldı mı */
  ocr?: 1;
  /** 0.6+: kalem türü, basınç hassasiyeti, titreme düzeltme, uç biçimi ve açısı */
  t?: PenType;
  th?: number;
  sm?: number;
  n?: Nib;
  a?: number;
}

/** Saklanan bilgiden kalem stilini geri kurar (eski izler de çalışır) */
export function styleOf(c: PenCustom, pressure = !!c.pr): PenStyle {
  return { kind: c.k, type: c.t, size: c.s, pressure, thinning: c.th, smoothing: c.sm, nib: c.n, angle: c.a };
}

/** Kurşun kalem ve fosforlu kâğıda karışır (çarpma karışımı) */
const blends = (style: PenStyle) => style.kind === 'fosforlu' || style.type === 'kursun';

export const isPen = (o: PdfAnnotationObject | undefined): boolean =>
  !!o && o.type === PdfAnnotationSubtype.POLYGON && (o as any).custom?.tura === 'kalem';

export class ViewerBridge {
  private registry: PluginRegistry;
  private host: HTMLElement;
  constructor(registry: PluginRegistry, host: HTMLElement) {
    this.registry = registry;
    this.host = host;
  }

  get ann() {
    return this.registry.getPlugin<AnnotationPlugin>("annotation")?.provides?.();
  }
  private get scroll(): any {
    return (this.registry.getPlugin('scroll') as any)?.provides?.();
  }
  private root(): ShadowRoot | null {
    return (this.host.querySelector('embedpdf-container') as HTMLElement | null)?.shadowRoot ?? null;
  }

  /** Sayfaların kaydırıldığı alan (araç çubukları dışında) */
  scroller(): HTMLElement | null {
    const r = this.root();
    if (!r) return null;
    return ([...r.querySelectorAll('div')] as HTMLDivElement[]).find((d) => d.style.overflow === 'auto') ?? null;
  }

  /** Ekranda çizilmiş sayfalar ve sırası */
  pages(): { index: number; el: HTMLElement }[] {
    const r = this.root();
    if (!r) return [];
    const slots = ([...r.querySelectorAll('div')] as HTMLDivElement[])
      .filter((d) => d.style.transformOrigin === '0px 0px' && d.parentElement?.style.position === 'relative')
      .map((d) => d.parentElement as HTMLElement);
    const rendered: number[] = [...(this.scroll?.getMetrics?.().renderedPageIndexes ?? [])].sort((a: number, b: number) => a - b);
    const n = Math.min(slots.length, rendered.length);
    return Array.from({ length: n }, (_, i) => ({ index: rendered[i], el: slots[i] }));
  }

  /** Sayfaların görünen boyutları (pt), sayfa düzeninden */
  private sizes(): { w: number; h: number }[] {
    const items: any[] = this.scroll?.getLayout?.()?.virtualItems ?? [];
    const out: { w: number; h: number }[] = [];
    for (const it of items) for (const p of it.pageLayouts ?? []) out[p.pageIndex] = { w: p.rotatedWidth ?? p.width, h: p.rotatedHeight ?? p.height };
    return out;
  }

  /** Ekran noktasının altındaki sayfa */
  pageAt(x: number, y: number): PageHit | null {
    const sc = this.scroller()?.getBoundingClientRect();
    if (!sc || x < sc.left || x > sc.right || y < sc.top || y > sc.bottom) return null;
    const sizes = this.sizes();
    for (const p of this.pages()) {
      const rect = p.el.getBoundingClientRect();
      if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
        const s = sizes[p.index];
        if (!s) return null;
        return { index: p.index, rect, w: s.w, h: s.h };
      }
    }
    return null;
  }

  /** Aynı sayfanın güncel ekran konumu (kaydırma/yakınlaştırmadan sonra) */
  pageRect(index: number): DOMRect | null {
    return this.pages().find((p) => p.index === index)?.el.getBoundingClientRect() ?? null;
  }

  toPage(hit: PageHit, x: number, y: number): P2 {
    return [((x - hit.rect.left) / hit.rect.width) * hit.w, ((y - hit.rect.top) / hit.rect.height) * hit.h];
  }

  annotations(pageIndex: number): PdfAnnotationObject[] {
    return (this.ann?.getAnnotations({ pageIndex }) ?? []).map((t) => t.object);
  }

  /** Kalem izini sayfaya dolu çokgen not olarak ekler (vektör, basınca göre değişen kalınlık) */
  addStroke(pageIndex: number, outlinePts: P2[], center: P3[], style: PenStyle, color: string, author: string): string | null {
    const ann = this.ann;
    if (!ann || outlinePts.length < 3) return null;
    const b = bounds(outlinePts);
    const id = crypto.randomUUID();
    const hl = style.kind === 'fosforlu';
    const custom: PenCustom = {
      tura: 'kalem',
      k: style.kind,
      s: style.size,
      pr: style.pressure ? 1 : 0,
      p: packPts(center),
      b: [b.x, b.y, b.w, b.h],
      ...(style.type ? { t: style.type } : {}),
      ...(style.thinning !== undefined ? { th: Math.round(style.thinning * 100) / 100 } : {}),
      ...(style.smoothing !== undefined ? { sm: Math.round(style.smoothing * 100) / 100 } : {}),
      ...(style.nib === 'keski' ? { n: 'keski' as Nib, a: style.angle ?? 45 } : {}),
    };
    const opacity = style.opacity ?? (hl ? 0.35 : 1);
    ann.createAnnotation(pageIndex, {
      type: PdfAnnotationSubtype.POLYGON,
      id,
      pageIndex,
      rect: { origin: { x: b.x, y: b.y }, size: { width: b.w, height: b.h } },
      vertices: outlinePts.map(([x, y]) => ({ x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100 })),
      color,
      strokeColor: color,
      strokeWidth: 0,
      strokeStyle: PdfAnnotationBorderStyle.SOLID,
      opacity: Math.round(opacity * 100) / 100,
      ...(blends(style) ? { blendMode: PdfBlendMode.Multiply } : {}),
      flags: ['print'],
      author,
      created: new Date(),
      custom,
    } as any);
    return id;
  }

  /** Kalem izinin güncel orta çizgisi (taşınmış/boyutlandırılmış olabilir) */
  centerOf(o: PdfAnnotationObject): P3[] | null {
    const c = (o as any).custom as PenCustom | undefined;
    const v = (o as any).vertices as { x: number; y: number }[] | undefined;
    if (!c?.p?.length || !v?.length) return null;
    const now = bounds(v.map((q) => [q.x, q.y] as P2));
    const [bx, by, bw, bh] = c.b;
    const sx = now.w / bw;
    const sy = now.h / bh;
    return c.p.map(([x, y, p]) => [now.x + (x - bx) * sx, now.y + (y - by) * sy, p] as P3);
  }

  /** Kalem izini yeni çevre ve orta çizgiyle günceller */
  updateStroke(o: PdfAnnotationObject, outlinePts: P2[], center: P3[], patch: Partial<PenCustom> = {}) {
    const b = bounds(outlinePts);
    const c = (o as any).custom as PenCustom;
    this.ann?.updateAnnotation(o.pageIndex, o.id, {
      rect: { origin: { x: b.x, y: b.y }, size: { width: b.w, height: b.h } },
      vertices: outlinePts.map(([x, y]) => ({ x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100 })),
      custom: { ...c, ...patch, p: packPts(center), b: [b.x, b.y, b.w, b.h] },
    } as any);
  }

  setColor(o: PdfAnnotationObject, color: string) {
    const t = o.type;
    if (t === PdfAnnotationSubtype.POLYGON || t === PdfAnnotationSubtype.SQUARE || t === PdfAnnotationSubtype.CIRCLE) {
      this.ann?.updateAnnotation(o.pageIndex, o.id, isPen(o) ? ({ color, strokeColor: color } as any) : ({ strokeColor: color } as any));
    } else if (t === PdfAnnotationSubtype.INK || t === PdfAnnotationSubtype.LINE || t === PdfAnnotationSubtype.POLYLINE) {
      this.ann?.updateAnnotation(o.pageIndex, o.id, { strokeColor: color, color } as any);
    } else if (t === PdfAnnotationSubtype.FREETEXT) {
      this.ann?.updateAnnotation(o.pageIndex, o.id, { fontColor: color } as any);
    }
  }
}
