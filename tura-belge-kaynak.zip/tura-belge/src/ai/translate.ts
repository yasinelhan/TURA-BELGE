// Tura Asistan — çeviri. Önce tarayıcının cihaz içi çevirmeni denenir (Chrome/Edge masaüstü,
// ücretsiz ve internetsiz); yoksa bağlı model çevirir.
// SPDX-License-Identifier: AGPL-3.0-or-later

const TURKISH = /[çğıöşüÇĞİÖŞÜ]/;

/** Tarayıcının yapay zeka API'leri bazen hiç yanıt vermez (ör. model indirilemiyorsa): süre sınırı */
const within = <T,>(p: Promise<T>, ms: number): Promise<T | null> =>
  Promise.race([p.catch(() => null), new Promise<null>((r) => window.setTimeout(() => r(null), ms))]);
const TR_WORDS = /\b(ve|bir|bu|ile|için|olarak|olan|değil|gibi|daha|çok|ise|da|de)\b/i;

interface TranslatorLike {
  translate: (t: string) => Promise<string>;
  destroy?: () => void;
}
interface TranslatorStatic {
  availability: (o: { sourceLanguage: string; targetLanguage: string }) => Promise<string>;
  create: (o: { sourceLanguage: string; targetLanguage: string; monitor?: (m: EventTarget) => void }) => Promise<TranslatorLike>;
}
interface DetectorStatic {
  availability: (o?: object) => Promise<string>;
  create: () => Promise<{ detect: (t: string) => Promise<{ detectedLanguage: string; confidence: number }[]> }>;
}

/** Kaynak dil (tahmini): tr, en ya da tarayıcının bulduğu başka bir dil */
export async function detectLang(text: string): Promise<string> {
  const D = (self as unknown as { LanguageDetector?: DetectorStatic }).LanguageDetector;
  if (D) {
    try {
      if ((await within(D.availability(), 1500)) === 'available') {
        const det = await within(D.create(), 3000);
        const [best] = (det && (await within(det.detect(text), 3000))) || [];
        if (best && best.confidence > 0.5 && best.detectedLanguage !== 'und') return best.detectedLanguage.split('-')[0];
      }
    } catch {
      /* tahmin yöntemine geçilir */
    }
  }
  return TURKISH.test(text) || TR_WORDS.test(text) ? 'tr' : 'en';
}

/** Türkçe metin İngilizceye, diğer diller Türkçeye çevrilir */
export const targetFor = (source: string): 'tr' | 'en' => (source === 'tr' ? 'en' : 'tr');

export const hasDeviceTranslator = () => typeof self !== 'undefined' && 'Translator' in self;

/**
 * Tarayıcının cihaz içi çevirmeni; yoksa, bu dil çifti desteklenmiyorsa ya da zamanında yanıt vermezse null.
 * Dil paketi henüz indirilmemişse ve bir model bağlıysa uzun beklenmez, modele geçilir.
 */
export async function deviceTranslate(text: string, source: string, target: string, opts: { onProgress?: (p: number) => void; hasModel?: boolean } = {}): Promise<string | null> {
  const T = (self as unknown as { Translator?: TranslatorStatic }).Translator;
  if (!T || source === target) return null;
  try {
    const pair = { sourceLanguage: source, targetLanguage: target };
    const a = await within(T.availability(pair), 2500);
    if (!a || a === 'unavailable' || a === 'no') return null;
    const tr = await within(
      T.create({
        ...pair,
        monitor: (m) => m.addEventListener('downloadprogress', (e) => opts.onProgress?.((e as unknown as { loaded: number }).loaded)),
      }),
      a === 'available' ? 8000 : opts.hasModel ? 12000 : 60000,
    );
    if (!tr) return null;
    try {
      return await within(tr.translate(text), 20000);
    } finally {
      tr.destroy?.();
    }
  } catch (err) {
    console.warn('[Tura Asistan] cihaz içi çeviri kullanılamadı', err);
    return null;
  }
}

export const googleTranslateUrl = (text: string, target: string) =>
  `https://translate.google.com/?sl=auto&tl=${target}&text=${encodeURIComponent(text.slice(0, 4000))}&op=translate`;
