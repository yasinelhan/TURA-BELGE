// Tura Asistan — klasör sayfası: klasördeki (ya da tüm) notlara dayanarak soru sorma
// SPDX-License-Identifier: AGPL-3.0-or-later
import { BrandMark } from '../components/Brand';
import { Notebook } from '../components/Notebook';
import type { DocMeta, Folder } from '../lib/storage';
import { __ } from '../i18n';
import { AssistantPanel, type JumpTarget } from './AssistantPanel';
import { SparkIcon } from './SparkIcon';

interface Props {
  folderId: string | null;
  folders: Folder[];
  docs: DocMeta[];
  storageOk: boolean;
  onNavigate: (hash: string) => void;
  onJump: (t: JumpTarget) => void;
  onSaveNote: (name: string, text: string, folderId?: string) => Promise<void>;
}

export function AssistantPage({ folderId, folders, docs, storageOk, onNavigate, onJump, onSaveNote }: Props) {
  const folder = folderId ? (folders.find((f) => f.id === folderId) ?? null) : null;
  const inScope = folder ? docs.filter((d) => d.folderId === folder.id) : docs;
  return (
    <div className="editor aipage">
      <header className="editbar">
        <button className="btn btn--ghost editbar__back" onClick={() => onNavigate('')} aria-label={__('Belgelerime dön')}>
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span className="hide-sm">{__('Belgelerim')}</span>
        </button>
        <span className="hide-xs" style={{ display: 'contents' }}>
          <BrandMark size={22} />
        </span>
        <h1 className="aipage__title">
          <SparkIcon size={20} />
          <span>{folder ? __('Asistan · {0}', [folder.name]) : __('Asistan · Tüm kitaplık')}</span>
        </h1>
      </header>
      <div className="aipage__body">
        <aside className="aipage__docs" aria-label={__('Kaynaklar')}>
          <h2>{__('Asistanın okuduğu belgeler')}</h2>
          {inScope.length ? (
            <ul>
              {inScope.map((d) => (
                <li key={d.id}>
                  <button type="button" onClick={() => onJump({ docId: d.id, kind: d.kind === 'md' ? 'md' : 'pdf', n: 1 })} title={__('{0} belgesini aç', [d.name])}>
                    <span className="aipage__nb">
                      <Notebook id={d.id} cover={d.cover} mini label={d.kind === 'md' ? __('NOT') : undefined} />
                    </span>
                    <span className="aipage__name">{d.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">{storageOk ? __('Bu klasörde henüz belge yok.') : __('Bu görünümde kitaplık kullanılamıyor.')}</p>
          )}
          <p className="aipage__hint">{__('Klasöre belge ya da not ekledikçe asistan onları da okur. Taranmış PDF’lerin önce “Yazıyı tanı” ile tanıtılması gerekir.')}</p>
        </aside>
        <AssistantPanel
          layout="page"
          storeKey={folder ? `folder:${folder.id}` : 'all'}
          folder={folder ? { id: folder.id, name: folder.name } : undefined}
          onJump={onJump}
          onSaveNote={storageOk ? onSaveNote : undefined}
        />
      </div>
    </div>
  );
}
