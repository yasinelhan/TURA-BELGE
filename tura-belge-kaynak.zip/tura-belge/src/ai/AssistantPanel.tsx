// Tura Asistan — sohbet paneli: belgenin yanında (seçili metin için) ya da klasör sayfasında.
// Cevaplar öğrencinin notlarına dayanır, kaynak numaraları sayfaya götürür; notlarda olmayan kısım ayrıca işaretlenir.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { __, N_, getLang, locale } from '../i18n';
import { MD_CSS } from '../convert/markdown';
import { mdViewHtml } from '../convert/mathView';
import { AiError, chatStream, modelCaps, visibleAnswer, type ModelCaps } from './client';
import { aiReady, getAi, modelName, useAi, type AiSettings } from './settings';
import { retrieve, sourceLabel, type Scope, type Source } from './sources';
import { GEN_MARK, QUICK, budgets, buildMessages, translatePrompt, type QuickId, type Turn } from './prompt';
import { detectLang, deviceTranslate, googleTranslateUrl, targetFor } from './translate';
import { loadChat, saveChat, type ChatItem } from './chats';
import { AiSettingsDialog } from './AiSettingsDialog';
import { SparkIcon } from './SparkIcon';

export interface Quote {
  text: string;
  where: string;
  docId?: string;
  page?: number;
}

/** Belgeden gelen istek: seçili metin için "Sor" ya da "Çevir" */
export interface AskRequest {
  seq: number;
  kind: 'ask' | 'translate';
  quote: Quote;
  quick?: QuickId;
}

export interface JumpTarget {
  docId: string;
  kind: 'pdf' | 'md';
  n: number;
  title?: string;
}

export interface CurrentDoc {
  meta: { id: string; name: string; kind: 'pdf' | 'md'; updatedAt: number };
  bytes: ArrayBuffer;
}

interface Props {
  layout: 'side' | 'page';
  /** Sohbetin saklandığı anahtar (belge ya da klasör başına) */
  storeKey: string;
  doc?: { id: string; name: string; kind: 'pdf' | 'md' };
  folder?: { id: string; name: string };
  /** Kitaplıkta kayıtlı olmayan açık belgenin yazısı için */
  getCurrent?: () => Promise<CurrentDoc | null>;
  request?: AskRequest | null;
  onClose?: () => void;
  /** Kaynağa git: belgeyi o sayfada (notta o bölümde) açar */
  onJump: (s: JumpTarget) => void;
  onSaveNote?: (name: string, text: string, folderId?: string) => Promise<void>;
}

const capsCache = new Map<string, ModelCaps>();
async function capsFor(s: AiSettings): Promise<ModelCaps> {
  const k = `${s.provider}|${s.url}|${s.model}`;
  const c = capsCache.get(k);
  if (c) return c;
  const got = await modelCaps(s);
  capsCache.set(k, got);
  return got;
}

const uid = () => Math.random().toString(36).slice(2, 10);
const tq = (id: QuickId) => QUICK[id][getLang()];
const QUICK_LABELS: [QuickId | 'translate', string][] = [
  ['explain', N_('Açıkla')],
  ['origin', N_('Nereden geliyor?')],
  ['example', N_('Örnek ver')],
  ['summary', N_('Özetle')],
  ['translate', N_('Çevir')],
];

/** Cevabın HTML'i: [n] kaynak düğmesi olur, "Notlarında yok:" paragrafları ayrı renkte */
function decorate(html: string, sources: Source[]): string {
  const tpl = document.createElement('template');
  tpl.innerHTML = html;
  const walker = document.createTreeWalker(tpl.content, NodeFilter.SHOW_TEXT);
  const nodes: Text[] = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n as Text);
  const re = /\[(\d{1,2}(?:\s*[,;–-]\s*\d{1,2})*)\]/g;
  for (const node of nodes) {
    const parent = node.parentElement;
    if (!parent || parent.closest('code, pre, .katex, a') || !re.test(node.data)) continue;
    re.lastIndex = 0;
    const frag = document.createDocumentFragment();
    let last = 0;
    for (const m of node.data.matchAll(re)) {
      const nums = m[1].split(/\s*[,;–-]\s*/).map(Number);
      if (!nums.every((x) => x >= 1 && x <= sources.length)) continue;
      frag.append(node.data.slice(last, m.index));
      const span = document.createElement('span');
      span.className = 'cites';
      for (const x of nums) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'cite';
        b.dataset.cite = String(x);
        b.textContent = String(x);
        b.title = sourceLabel(sources[x - 1]);
        span.append(b);
      }
      frag.append(span);
      last = m.index! + m[0].length;
    }
    if (!last) continue;
    frag.append(node.data.slice(last));
    node.replaceWith(frag);
  }
  const marks = [GEN_MARK.tr, GEN_MARK.en];
  tpl.content.querySelectorAll('p, li, blockquote').forEach((el) => {
    const t = el.textContent?.trimStart() ?? '';
    const mark = marks.find((m) => t.startsWith(m));
    if (!mark || el.parentElement?.closest('.ai-gen')) return;
    el.classList.add('ai-gen');
    // İşaret kalın yazılmadıysa kalın yap
    const first = document.createTreeWalker(el, NodeFilter.SHOW_TEXT).nextNode() as Text | null;
    if (first && first.parentElement === el && first.data.trimStart().startsWith(mark)) {
      const i = first.data.indexOf(mark);
      const b = document.createElement('strong');
      b.className = 'ai-gen__mark';
      b.textContent = mark;
      first.replaceWith(first.data.slice(0, i), b, first.data.slice(i + mark.length));
    }
  });
  return tpl.innerHTML;
}

function AnswerBody({ text, sources, onCite }: { text: string; sources: Source[]; onCite: (s: Source) => void }) {
  const html = useMemo(() => decorate(mdViewHtml(text), sources), [text, sources]);
  return (
    <div
      className="md-view aimsg__body"
      onClick={(e) => {
        const b = (e.target as HTMLElement).closest<HTMLElement>('[data-cite]');
        if (b) onCite(sources[Number(b.dataset.cite) - 1]);
      }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export function AssistantPanel(props: Props) {
  const { layout, storeKey, doc, folder } = props;
  const ai = useAi();
  const [items, setItems] = useState<ChatItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [input, setInput] = useState('');
  const [quote, setQuote] = useState<Quote | null>(null);
  const [scopeKind, setScopeKind] = useState<Scope['kind']>(folder ? 'folder' : doc ? 'doc' : 'all');
  const [busy, setBusy] = useState<string | null>(null); // çalışan cevabın kimliği
  const [phase, setPhase] = useState('');
  const [settings, setSettings] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const stick = useRef(true);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  const flash = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 2600);
  };

  useEffect(() => {
    let live = true;
    setLoaded(false);
    void loadChat(storeKey).then((c) => {
      if (!live) return;
      setItems(c);
      setLoaded(true);
    });
    return () => {
      live = false;
      abortRef.current?.abort();
    };
  }, [storeKey]);

  // Bittiğinde sohbet saklanır
  useEffect(() => {
    if (loaded && !busy) void saveChat(storeKey, items);
  }, [items, busy, loaded, storeKey]);

  // En alta kaydır (kullanıcı yukarı kaydırmadıysa)
  useEffect(() => {
    const el = listRef.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [items, phase]);

  const update = useCallback((id: string, patch: Partial<ChatItem>) => {
    setItems((prev) => prev.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  }, []);

  const scope: Scope = useMemo(() => {
    if (scopeKind === 'doc' && doc) return { kind: 'doc', docId: doc.id };
    if (scopeKind === 'folder' && folder) return { kind: 'folder', folderId: folder.id };
    return { kind: 'all' };
  }, [scopeKind, doc, folder]);

  /** Akışı ekrana az sıklıkla yansıt */
  const streamTo = (id: string) => {
    let raw = '';
    let frame = 0;
    const flush = () => {
      frame = 0;
      const v = visibleAnswer(raw);
      update(id, { text: v.text });
      setPhase(v.thinking && !v.text ? __('Düşünüyor…') : '');
    };
    return {
      add(t: string) {
        raw += t;
        if (!frame) frame = requestAnimationFrame(flush);
      },
      done() {
        if (frame) cancelAnimationFrame(frame);
        flush();
        return visibleAnswer(raw).text;
      },
    };
  };

  const fail = (id: string, err: unknown, partial?: string) => {
    if ((err as Error)?.name === 'AbortError') {
      update(id, { stopped: true, text: partial ?? '' });
      return;
    }
    console.warn('[Tura Asistan]', err);
    update(id, { error: err instanceof AiError ? err.message : __('Cevap alınamadı: {0}', [String((err as Error)?.message ?? err)]) });
  };

  /** Notlara dayalı soru */
  const ask = async (question: string, q: Quote | null, shown?: string) => {
    if (busy || !question.trim()) return;
    const cfg = getAi();
    if (!aiReady(cfg)) {
      setSettings(true);
      return;
    }
    const history: Turn[] = [];
    const list = itemsRef.current;
    for (let i = 1; i < list.length; i++) {
      const u = list[i - 1];
      const a = list[i];
      if (u.role === 'user' && a.role === 'assistant' && a.kind !== 'translate' && a.text && !a.error)
        history.push({ q: u.quote ? `${u.text}\n"""${u.quote.text}"""` : u.text, a: a.text });
    }
    const aid = uid();
    setItems((prev) => [
      ...prev,
      { id: uid(), role: 'user', text: shown ?? question, quote: q ?? undefined, kind: 'answer', at: Date.now() },
      { id: aid, role: 'assistant', text: '', kind: 'answer', model: modelName(cfg), at: Date.now() },
    ]);
    stick.current = true;
    setBusy(aid);
    const ac = new AbortController();
    abortRef.current = ac;
    const out = streamTo(aid);
    try {
      setPhase(__('Notlar okunuyor…'));
      const b = budgets(cfg.ctx);
      const lastQ = history.length && question.length < 60 ? ` ${history[history.length - 1].q}` : '';
      const current = (await props.getCurrent?.()) ?? undefined;
      const r = await retrieve({
        scope,
        query: `${question} ${q?.text ?? ''}${lastQ}`,
        budget: b.sources,
        pin: q?.docId && q.page ? { docId: q.docId, page: q.page, selection: q.text } : undefined,
        current,
        signal: ac.signal,
        onProgress: (d, t) => t > 1 && setPhase(__('Notlar okunuyor… {0}/{1}', [Math.min(d + 1, t), t])),
      });
      update(aid, { sources: r.sources });
      setPhase(__('Model yanıtlıyor…'));
      const caps = await capsFor(cfg);
      const msgs = buildMessages({ question, selection: q ? { text: q.text, where: q.where } : undefined, sources: r.sources, history, historyBudget: b.history });
      for await (const part of chatStream(cfg, msgs, { signal: ac.signal, caps })) {
        if (part.type === 'think') setPhase(__('Düşünüyor…'));
        else out.add(part.text);
      }
      const final = out.done();
      if (!final.trim()) update(aid, { error: __('Model boş bir cevap döndürdü.') });
      if (r.noText.length) update(aid, { note: __('Yazısı olmayan (taranmış) belge okunamadı: {0}. “PDF araçları → Yazıyı tanı” ile tanıtabilirsin.', [r.noText.join(', ')]) });
    } catch (err) {
      fail(aid, err, out.done());
    } finally {
      setBusy(null);
      setPhase('');
      abortRef.current = null;
    }
  };

  /** Çeviri: önce cihaz içi çevirmen, yoksa model */
  const translate = async (q: Quote) => {
    if (busy) return;
    const aid = uid();
    setItems((prev) => [
      ...prev,
      { id: uid(), role: 'user', text: __('Çevir'), quote: q, kind: 'translate', at: Date.now() },
      { id: aid, role: 'assistant', text: '', kind: 'translate', at: Date.now() },
    ]);
    stick.current = true;
    setBusy(aid);
    const ac = new AbortController();
    abortRef.current = ac;
    const out = streamTo(aid);
    try {
      setPhase(__('Çevriliyor…'));
      const source = await detectLang(q.text);
      const target = targetFor(source);
      const link = googleTranslateUrl(q.text, target);
      const dev = await deviceTranslate(q.text, source, target, {
        hasModel: aiReady(getAi()),
        onProgress: (p) => setPhase(__('Çeviri dil paketi indiriliyor… %{0}', [Math.round(p * 100)])),
      });
      if (dev) {
        update(aid, { text: dev, note: __('Tarayıcının cihaz içi çevirmeniyle'), link });
        return;
      }
      const cfg = getAi();
      if (!aiReady(cfg)) {
        update(aid, { error: __('Bu tarayıcıda cihaz içi çevirmen yok. Çeviri için asistanı bir modele bağla ya da Google Çeviri’de aç.'), link });
        return;
      }
      update(aid, { model: modelName(cfg), link });
      const caps = await capsFor(cfg);
      for await (const part of chatStream({ ...cfg, think: false }, translatePrompt(q.text, target), { signal: ac.signal, caps, temperature: 0.2 })) {
        if (part.type === 'text') out.add(part.text);
      }
      out.done();
    } catch (err) {
      fail(aid, err, out.done());
    } finally {
      setBusy(null);
      setPhase('');
      abortRef.current = null;
    }
  };

  // Belgeden gelen istekler (seçim menüsü)
  const lastSeq = useRef(0);
  useEffect(() => {
    const r = props.request;
    if (!r || r.seq === lastSeq.current || !loaded) return;
    lastSeq.current = r.seq;
    setQuote(r.quote);
    if (r.kind === 'translate') void translate(r.quote);
    else if (r.quick) void ask(tq(r.quick), r.quote, __(QUICK_LABELS.find((x) => x[0] === r.quick)![1]));
    else window.setTimeout(() => inputRef.current?.focus(), 50);
  }, [props.request, loaded]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = () => {
    const t = input.trim();
    if (!t) return;
    setInput('');
    void ask(t, quote);
  };

  const quick = (id: QuickId | 'translate') => {
    if (!quote) return;
    if (id === 'translate') void translate(quote);
    else void ask(tq(id), quote, __(QUICK_LABELS.find((x) => x[0] === id)![1]));
  };

  const jump = (s: Source | undefined) => s && props.onJump({ docId: s.docId, kind: s.kind, n: s.n, title: s.title });

  const asNote = async () => {
    if (!props.onSaveNote || !items.length) return;
    const first = items.find((x) => x.role === 'user')?.text ?? __('Sohbet');
    const date = new Intl.DateTimeFormat(locale(), { dateStyle: 'long', timeStyle: 'short' }).format(Date.now());
    const lines = [`# ${__('Asistan')}: ${first.slice(0, 70)}`, '', `_${date}_`, ''];
    for (const x of items) {
      if (x.role === 'user') {
        lines.push(`## ${x.text}`, '');
        if (x.quote) lines.push(...x.quote.text.split('\n').map((l) => `> ${l}`), `> — ${x.quote.where}`, '');
      } else if (x.text) {
        lines.push(x.text.trim(), '');
        if (x.sources?.length) lines.push(`**${__('Kaynaklar')}:** ${x.sources.map((s) => `[${s.ref}] ${sourceLabel(s)}`).join(' · ')}`, '');
        if (x.model) lines.push(`_${__('Model')}: ${x.model}_`, '');
      }
    }
    try {
      await props.onSaveNote(`${__('Asistan')} – ${first.slice(0, 40)}`, lines.join('\n'), folder?.id);
      flash(folder ? __('Not olarak “{0}” klasörüne kaydedildi', [folder.name]) : __('Not olarak kitaplığa kaydedildi'));
    } catch {
      flash(__('Not kaydedilemedi'));
    }
  };

  const ready = aiReady(ai);
  const scopes: [Scope['kind'], string][] = [];
  if (doc) scopes.push(['doc', __('Bu belge')]);
  if (folder) scopes.push(['folder', __('Klasör: {0}', [folder.name])]);
  scopes.push(['all', __('Tüm kitaplık')]);

  return (
    <aside className={`aipanel aipanel--${layout}`} aria-label={__('Tura Asistan')}>
      <style>{MD_CSS}</style>
      <header className="aipanel__head">
        <span className="aipanel__title" title={__('Tura Asistan')}>
          <SparkIcon />
          <span className="sr-only">{__('Tura Asistan')}</span>
        </span>
        <select className="aipanel__scope" value={scopeKind} onChange={(e) => setScopeKind(e.target.value as Scope['kind'])} aria-label={__('Hangi notlara dayansın')}>
          {scopes.map(([k, l]) => (
            <option key={k} value={k}>
              {l}
            </option>
          ))}
        </select>
        <button type="button" className={ready ? 'aipanel__model' : 'aipanel__model aipanel__model--off'} onClick={() => setSettings(true)} title={__('Asistan bağlantısı')}>
          <i aria-hidden="true" />
          <span>{ready ? modelName(ai) : __('Bağla')}</span>
        </button>
        <span className="aipanel__spacer" />
        {props.onSaveNote && items.length > 0 && (
          <button type="button" className="icon-btn icon-btn--mini" onClick={() => void asNote()} disabled={!!busy} title={__('Sohbeti not olarak kaydet')} aria-label={__('Sohbeti not olarak kaydet')}>
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M6 3h9l3 3v15H6zM9 3v5h6V3M9 14h6M9 17h4" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" strokeLinecap="round" />
            </svg>
          </button>
        )}
        {items.length > 0 && (
          <button
            type="button"
            className="icon-btn icon-btn--mini"
            onClick={() => {
              abortRef.current?.abort();
              setItems([]);
            }}
            title={__('Yeni sohbet')}
            aria-label={__('Yeni sohbet')}
          >
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M4 20l1.2-3.6A8 8 0 1 1 8 19zM12 8v6M9 11h6" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" strokeLinecap="round" />
            </svg>
          </button>
        )}
        {props.onClose && (
          <button type="button" className="icon-btn icon-btn--mini" onClick={props.onClose} aria-label={__('Paneli kapat')} title={__('Paneli kapat')}>
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        )}
      </header>

      <div
        className="aipanel__list"
        ref={listRef}
        onScroll={(e) => {
          const el = e.currentTarget;
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
        }}
        aria-live="polite"
      >
        {!items.length && (
          <div className="aipanel__empty">
            {!ready ? (
              <>
                <h3>{__('Asistanı bağla')}</h3>
                <p>
                  {__('Tura Asistan bir yapay zeka servisine bağlanır. En kolayı: Google Gemini’den 1 dakikada ücretsiz anahtar al ve yapıştır. ChatGPT, Claude, Groq, OpenRouter ya da bilgisayarında çalışan Ollama da olur.')}
                </p>
                <button type="button" className="btn btn--primary btn--sm" onClick={() => setSettings(true)}>
                  {__('Bağlantıyı ayarla')}
                </button>
              </>
            ) : (
              <>
                <h3>{layout === 'page' ? __('Notlarına sor') : __('Belgeye sor')}</h3>
                <p>
                  {doc
                    ? __('Belgede bir kelime ya da cümle seç, açılan menüden ✨ Asistana sor’a dokun. Ya da aşağıya sorunu yaz.')
                    : __('Bu klasördeki notlarına dayanarak sorularını yanıtlar; notlarında eksik kalan yeri kendi bilgisiyle açıklar ve bunu ayrıca belirtir.')}
                </p>
                <div className="aipanel__ideas">
                  {[__('Bu notlardaki ana konuları özetle'), __('En önemli formülleri ve nereden geldiklerini açıkla'), __('Bu konudan sınavda çıkabilecek 3 soru yaz')].map((t) => (
                    <button key={t} type="button" className="aipanel__idea" onClick={() => void ask(t, null)}>
                      {t}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
        {items.map((x) =>
          x.role === 'user' ? (
            <div key={x.id} className="aimsg aimsg--user">
              {x.quote && (
                <blockquote className="aimsg__quote" title={x.quote.where}>
                  {x.quote.text}
                </blockquote>
              )}
              <p>{x.text}</p>
            </div>
          ) : (
            <div key={x.id} className="aimsg aimsg--bot">
              {x.text ? (
                <AnswerBody text={x.text} sources={x.sources ?? []} onCite={jump} />
              ) : busy === x.id ? (
                <p className="aimsg__phase">
                  <span className="aimsg__dots" aria-hidden="true" />
                  {phase || __('Hazırlanıyor…')}
                </p>
              ) : null}
              {busy === x.id && x.text && phase && <p className="aimsg__phase">{phase}</p>}
              {x.error && (
                <p className="aimsg__err" role="alert">
                  {x.error}{' '}
                  {x.kind !== 'translate' && (
                    <button type="button" className="aimsg__link" onClick={() => setSettings(true)}>
                      {__('Bağlantı ayarları')}
                    </button>
                  )}
                </p>
              )}
              {x.stopped && <p className="aimsg__meta">{__('Durduruldu')}</p>}
              {x.note && <p className="aimsg__meta">{x.note}</p>}
              {!!x.sources?.length && busy !== x.id && (
                <details className="aimsg__sources">
                  <summary>{__('Kaynaklar ({0})', [x.sources.length])}</summary>
                  <ul>
                    {x.sources.map((s) => (
                      <li key={s.ref}>
                        <button type="button" onClick={() => jump(s)} title={s.text.slice(0, 300)}>
                          <b>{s.ref}</b> {sourceLabel(s)}
                          {s.pinned && <em> · {__('seçimin olduğu yer')}</em>}
                        </button>
                      </li>
                    ))}
                  </ul>
                </details>
              )}
              {busy !== x.id && (x.text || x.link) && (
                <div className="aimsg__actions">
                  {x.text && (
                    <button type="button" onClick={() => void navigator.clipboard?.writeText(x.text).then(() => flash(__('Kopyalandı')))}>
                      {__('Kopyala')}
                    </button>
                  )}
                  {x.kind === 'translate' && ready && x.text && (
                    <button
                      type="button"
                      onClick={() => {
                        const u = items[items.indexOf(x) - 1];
                        if (u?.quote) void ask(__('“{0}” bu notlarda ne anlama geliyor? Bağlamıyla açıkla.', [u.quote.text.slice(0, 200)]), u.quote, __('Bağlamıyla açıkla'));
                      }}
                    >
                      {__('Bağlamıyla açıkla')}
                    </button>
                  )}
                  {x.link && (
                    <a href={x.link} target="_blank" rel="noopener noreferrer">
                      {__('Google Çeviri’de aç')}
                    </a>
                  )}
                  {x.model && <span className="aimsg__model">{x.model}</span>}
                </div>
              )}
            </div>
          ),
        )}
      </div>

      <div className="aipanel__compose">
        {quote && (
          <div className="aiquote">
            <div className="aiquote__head">
              <span>{quote.where}</span>
              <button type="button" onClick={() => setQuote(null)} aria-label={__('Seçimi kaldır')} title={__('Seçimi kaldır')}>
                ×
              </button>
            </div>
            <p className="aiquote__text">{quote.text}</p>
            <div className="aiquote__quick">
              {QUICK_LABELS.map(([id, label]) => (
                <button key={id} type="button" disabled={!!busy} onClick={() => quick(id)}>
                  {__(label)}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="aipanel__inputrow">
          <textarea
            ref={inputRef}
            className="aipanel__input"
            rows={2}
            value={input}
            placeholder={quote ? __('Seçili metinle ilgili sor…') : __('Notlarına sor… (ör. Bu yöntem nasıl çalışıyor?)')}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                e.preventDefault();
                submit();
              } else if (e.key === 'Escape' && props.onClose) props.onClose();
            }}
            aria-label={__('Soru')}
          />
          {busy ? (
            <button type="button" className="btn btn--ghost btn--sm aipanel__send" onClick={() => abortRef.current?.abort()}>
              {__('Durdur')}
            </button>
          ) : (
            <button type="button" className="btn btn--primary btn--sm aipanel__send" onClick={submit} disabled={!input.trim()}>
              {__('Sor')}
            </button>
          )}
        </div>
        <p className="aipanel__fine">{__('Cevaplar yapay zekadan gelir ve yanlış olabilir; kaynaklarına bakarak kontrol et.')}</p>
      </div>

      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
      {settings && <AiSettingsDialog onClose={() => setSettings(false)} />}
    </aside>
  );
}
