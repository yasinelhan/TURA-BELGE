// Tura Asistan — kaynaklar: belgelerin yazısını sayfa sayfa çıkarır (bu cihazda, önbellekli),
// soruyla en ilgili parçaları bulur ve modele kaynak numaralarıyla verir.
// Arama sözcük temellidir (BM25); Türkçe ekler için kelime kökünün başı da eşleştirilir.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createStore, del, get, set } from 'idb-keyval';
import { listDocs, loadDocBytes, type DocMeta } from '../lib/storage';
import { openRenderDoc } from '../tools/lib/render';
import { mdTokens, inlineText } from '../convert/markdown';
import { __ } from '../i18n';

const VERSION = 2;

export interface SourcePage {
  /** PDF'te sayfa numarası, notta bölüm sırası (1'den başlar) */
  n: number;
  /** Notlarda bölüm başlığı */
  title?: string;
  text: string;
}

export interface DocText {
  v: number;
  id: string;
  name: string;
  kind: 'pdf' | 'md';
  at: number;
  pages: SourcePage[];
  /** Yazısı olmayan (taranmış) sayfa sayısı */
  empty: number;
}

/** Modele verilen bir kaynak parçası */
export interface Source {
  /** Cevaptaki [numara] */
  ref: number;
  docId: string;
  docName: string;
  kind: 'pdf' | 'md';
  n: number;
  title?: string;
  text: string;
  /** Seçili metnin geçtiği yer mi */
  pinned?: boolean;
}

export type Scope = { kind: 'doc'; docId: string } | { kind: 'folder'; folderId: string } | { kind: 'all' };

let store: ReturnType<typeof createStore> | null = null;
const idb = () => (store ??= createStore('tura-belge-yz-metin', 'metin'));
const memo = new Map<string, DocText>();

// ------------------------------------------------------------------ Belge yazısı

function mdSections(text: string): SourcePage[] {
  const out: SourcePage[] = [];
  let cur: { title?: string; lines: string[] } = { lines: [] };
  const flush = () => {
    const t = cur.lines.join('\n').trim();
    if (t) out.push({ n: out.length + 1, title: cur.title, text: t });
  };
  for (const tok of mdTokens(text)) {
    if (tok.type === 'heading') {
      flush();
      const title = inlineText((tok as { tokens?: never[] }).tokens).trim();
      cur = { title, lines: [title] };
    } else cur.lines.push(tok.raw.trim());
  }
  flush();
  return out;
}

/** Nottaki n. bölümün başlığı (kaynağa gitmek için) */
export function mdSectionTitle(text: string, n: number): string | undefined {
  return mdSections(text).find((s) => s.n === n)?.title;
}

/** Seçili metnin nottaki bölümü (kaynak numarasıyla aynı sıralama) */
export function findMdSection(text: string, selection: string): { n: number; title?: string } | null {
  const needle = fold(selection).replace(/\s+/g, ' ').trim().slice(0, 50);
  if (!needle) return null;
  for (const s of mdSections(text)) if (fold(s.text).replace(/[*_`#>]/g, '').replace(/\s+/g, ' ').includes(needle)) return { n: s.n, title: s.title };
  return null;
}

const cleanPdfText = (t: string) =>
  t
    .replace(/(\p{L})-\n(\p{Ll})/gu, '$1$2') // satır sonunda bölünmüş kelimeler
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

/**
 * Belgenin yazısı (önbellekten ya da yeniden çıkarılarak).
 * bytes verilirse (açık belge) o hâli kullanılır.
 */
export async function docText(meta: Pick<DocMeta, 'id' | 'name' | 'kind' | 'updatedAt'>, bytes?: ArrayBuffer): Promise<DocText> {
  const kind = meta.kind === 'md' ? 'md' : 'pdf';
  const key = meta.id;
  const fresh = (d: DocText | undefined) => !!d && d.v === VERSION && d.at === meta.updatedAt && meta.updatedAt > 0;
  const m = memo.get(key);
  if (fresh(m)) return { ...m!, name: meta.name };
  if (!bytes) {
    try {
      const c = await get<DocText>(key, idb());
      if (fresh(c)) {
        memo.set(key, c!);
        return { ...c!, name: meta.name };
      }
    } catch {
      /* depolama kapalı olabilir */
    }
    bytes = await loadDocBytes(meta.id);
    if (!bytes) throw new Error('missing');
  }
  let pages: SourcePage[] = [];
  let empty = 0;
  if (kind === 'md') {
    pages = mdSections(new TextDecoder().decode(bytes));
  } else {
    const doc = await openRenderDoc(bytes);
    try {
      for (let i = 0; i < doc.pageCount; i++) {
        const t = cleanPdfText(await doc.text(i));
        if (t.replace(/\s/g, '').length < 15) empty++;
        else pages.push({ n: i + 1, text: t });
      }
    } finally {
      doc.close();
    }
  }
  const out: DocText = { v: VERSION, id: meta.id, name: meta.name, kind, at: meta.updatedAt, pages, empty };
  memo.set(key, out);
  if (meta.updatedAt > 0) await set(key, out, idb()).catch(() => undefined);
  return out;
}

export async function forgetDocText(id: string) {
  memo.delete(id);
  await del(id, idb()).catch(() => undefined);
}

/** Kapsamdaki belgeler */
export async function scopeDocs(scope: Scope): Promise<DocMeta[]> {
  const docs = await listDocs().catch(() => [] as DocMeta[]);
  if (scope.kind === 'doc') return docs.filter((d) => d.id === scope.docId);
  if (scope.kind === 'folder') return docs.filter((d) => d.folderId === scope.folderId);
  return docs;
}

// ------------------------------------------------------------------ Arama

const FOLD: Record<string, string> = { ç: 'c', ğ: 'g', ı: 'i', ö: 'o', ş: 's', ü: 'u', â: 'a', î: 'i', û: 'u' };
export const fold = (s: string) =>
  s
    .toLocaleLowerCase('tr')
    .replace(/[çğıöşüâîû]/g, (c) => FOLD[c])
    .normalize('NFD')
    .replace(/\p{M}/gu, '');

const STOP = new Set(
  (
    've ile bir bu su o da de ki mi mu ne neden nedir nasil nicin icin gibi daha en cok ise ya veya ama fakat olan olarak ' +
    'her hangi kadar sonra once diye bana beni sen ben biz siz onlar bunu sunu bunun neye nereden nerede gelir geliyor ' +
    'acikla anlat soyle yani ayni boyle oyle var yok mi midir dir dur tir tur the a an of to in is are and or for what how ' +
    'why this that with on be it as by from at was were which where does do can'
  ).split(' '),
);

/** Kelimeler → arama özellikleri: kökün ilk 4 ve ilk 6 harfi (Türkçe ekleri tolere etmek için) */
function features(text: string): Map<string, number> {
  const f = new Map<string, number>();
  const add = (k: string, w: number) => f.set(k, (f.get(k) ?? 0) + w);
  for (const tok of fold(text).match(/[\p{L}\p{N}]+/gu) ?? []) {
    if (STOP.has(tok)) continue;
    if (/^\p{N}+$/u.test(tok)) {
      add(`#${tok}`, 1);
      continue;
    }
    if (tok.length < 3) continue;
    if (tok.length <= 4) add(`4:${tok}`, 1);
    else add(`4:${tok.slice(0, 4)}`, 1);
    if (tok.length >= 6) add(`6:${tok.slice(0, 6)}`, 1);
    else add(`6:${tok}`, 1);
  }
  return f;
}

interface Chunk {
  doc: DocText;
  page: SourcePage;
  text: string;
  f: Map<string, number>;
  len: number;
}

/** Sayfayı ~900 karakterlik parçalara böler (paragraf ve cümle sınırlarından) */
function splitText(text: string, max = 900): string[] {
  const paras = text.split(/\n\s*\n/).flatMap((p) => (p.length > max ? p.split(/(?<=[.!?:;])\s+|\n/) : [p]));
  const out: string[] = [];
  let cur = '';
  for (const raw of paras) {
    const p = raw.trim();
    if (!p) continue;
    if (cur && cur.length + p.length + 1 > max) {
      out.push(cur);
      cur = '';
    }
    if (p.length > max) {
      for (let i = 0; i < p.length; i += max) out.push(p.slice(i, i + max));
      continue;
    }
    cur = cur ? `${cur}\n${p}` : p;
  }
  if (cur) out.push(cur);
  return out;
}

function chunksOf(docs: DocText[]): Chunk[] {
  const out: Chunk[] = [];
  for (const doc of docs)
    for (const page of doc.pages)
      for (const text of splitText(page.text)) {
        const f = features(text);
        let len = 0;
        f.forEach((v) => (len += v));
        out.push({ doc, page, text, f, len });
      }
  return out;
}

function rank(chunks: Chunk[], query: string): { c: Chunk; score: number }[] {
  const q = features(query);
  if (!q.size || !chunks.length) return [];
  const N = chunks.length;
  const avg = chunks.reduce((s, c) => s + c.len, 0) / N || 1;
  const df = new Map<string, number>();
  for (const key of q.keys()) df.set(key, chunks.reduce((s, c) => s + (c.f.has(key) ? 1 : 0), 0));
  const k1 = 1.2;
  const b = 0.75;
  return chunks
    .map((c) => {
      let score = 0;
      for (const [key, qw] of q) {
        const tf = c.f.get(key);
        if (!tf) continue;
        const n = df.get(key) ?? 0;
        const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
        const w = key.startsWith('6:') ? 1 : key.startsWith('#') ? 0.8 : 0.45;
        score += w * Math.min(qw, 3) * idf * ((tf * (k1 + 1)) / (tf + k1 * (1 - b + (b * c.len) / avg)));
      }
      return { c, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);
}

/** Seçili metnin geçtiği yerin çevresi (bulunamazsa sayfanın başı) */
function around(page: SourcePage, selection: string, width = 1600): string {
  const t = page.text;
  if (t.length <= width) return t;
  const needle = fold(selection).replace(/\s+/g, ' ').trim().slice(0, 60);
  const hay = fold(t).replace(/\s/g, ' ');
  const i = needle ? hay.indexOf(needle) : -1;
  if (i < 0) return t.slice(0, width);
  const start = Math.max(0, i - Math.floor((width - selection.length) / 2));
  return (start > 0 ? '…' : '') + t.slice(start, start + width) + (start + width < t.length ? '…' : '');
}

export interface Retrieval {
  sources: Source[];
  /** Kapsamdaki belge sayısı */
  docs: number;
  /** Yazısı olmayan (taranmış) belgeler */
  noText: string[];
}

export interface RetrieveOpts {
  scope: Scope;
  query: string;
  /** Kaç karakterlik kaynak gönderilebileceği */
  budget: number;
  /** Seçimin yapıldığı belge ve sayfa: o yer her zaman ilk kaynak olur */
  pin?: { docId: string; page: number; selection: string };
  /** Açık belgenin güncel hâli */
  current?: { meta: Pick<DocMeta, 'id' | 'name' | 'kind' | 'updatedAt'>; bytes: ArrayBuffer };
  onProgress?: (done: number, total: number, name: string) => void;
  signal?: AbortSignal;
}

export async function retrieve(o: RetrieveOpts): Promise<Retrieval> {
  let metas = await scopeDocs(o.scope);
  if (o.current && !metas.some((m) => m.id === o.current!.meta.id) && (o.scope.kind === 'doc' || !metas.length))
    metas = [o.current.meta as DocMeta, ...metas];
  const texts: DocText[] = [];
  for (let i = 0; i < metas.length; i++) {
    if (o.signal?.aborted) throw new DOMException('aborted', 'AbortError');
    const m = metas[i];
    o.onProgress?.(i, metas.length, m.name);
    try {
      const cur = o.current && o.current.meta.id === m.id ? o.current : null;
      texts.push(await docText(cur ? cur.meta : m, cur?.bytes));
    } catch (err) {
      console.warn('[Tura Asistan] belge okunamadı', m.name, err);
    }
  }
  o.onProgress?.(metas.length, metas.length, '');

  const sources: Source[] = [];
  let used = 0;
  const push = (s: Omit<Source, 'ref'>) => {
    sources.push({ ...s, ref: sources.length + 1 });
    used += s.text.length + 60;
  };
  const pinPage = o.pin ? texts.find((d) => d.id === o.pin!.docId)?.pages.find((p) => p.n === o.pin!.page) : undefined;
  if (o.pin && pinPage) {
    const doc = texts.find((d) => d.id === o.pin!.docId)!;
    push({ docId: doc.id, docName: doc.name, kind: doc.kind, n: pinPage.n, title: pinPage.title, text: around(pinPage, o.pin.selection), pinned: true });
  }
  const ranked = rank(chunksOf(texts), o.query);
  const top = ranked[0]?.score ?? 0;
  for (const { c, score } of ranked) {
    if (used >= o.budget || score < top * 0.18) break;
    if (c.text.length + used > o.budget * 1.1) continue;
    // Seçimin geçtiği sayfadan zaten alındıysa aynı parçayı tekrarlama
    if (pinPage && c.doc.id === o.pin!.docId && c.page.n === pinPage.n && sources[0]?.text.includes(c.text.slice(0, 80))) continue;
    push({ docId: c.doc.id, docName: c.doc.name, kind: c.doc.kind, n: c.page.n, title: c.page.title, text: c.text });
    if (sources.length >= 14) break;
  }
  // Hiçbir şey eşleşmediyse ve kapsam tek belgeyse: belgenin başından bağlam ver
  if (!sources.length && texts.length === 1 && texts[0].pages.length) {
    for (const p of texts[0].pages) {
      if (used >= o.budget * 0.6) break;
      push({ docId: texts[0].id, docName: texts[0].name, kind: texts[0].kind, n: p.n, title: p.title, text: p.text.slice(0, 1200) });
    }
  }
  return {
    sources,
    docs: metas.length,
    noText: texts.filter((t) => t.kind === 'pdf' && !t.pages.length).map((t) => t.name),
  };
}

/** Kaynağın kısa adı: "Fizik-2 · s. 12" ya da "Ders notu · Türev" */
export function sourceLabel(s: Pick<Source, 'docName' | 'kind' | 'n' | 'title'>): string {
  if (s.kind === 'md') return s.title ? `${s.docName} · ${s.title}` : s.docName;
  return __('{0} · s. {1}', [s.docName, s.n]);
}
