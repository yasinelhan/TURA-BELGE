// Tura Asistan — sohbetler bu cihazda saklanır (belge ya da klasör başına bir sohbet)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createStore, del, get, set } from 'idb-keyval';
import type { Source } from './sources';

export interface ChatItem {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  /** Soruyla birlikte gönderilen seçili metin */
  quote?: { text: string; where: string; docId?: string; page?: number };
  sources?: Source[];
  kind?: 'answer' | 'translate';
  /** Kısa açıklama (ör. "Tarayıcının çevirmeniyle") */
  note?: string;
  /** Çeviri için Google Çeviri bağlantısı */
  link?: string;
  model?: string;
  error?: string;
  stopped?: boolean;
  at: number;
}

let store: ReturnType<typeof createStore> | null = null;
const idb = () => (store ??= createStore('tura-belge-yz-sohbet', 'sohbet'));

export async function loadChat(key: string): Promise<ChatItem[]> {
  try {
    return (await get<ChatItem[]>(key, idb())) ?? [];
  } catch {
    return [];
  }
}

export async function saveChat(key: string, items: ChatItem[]): Promise<void> {
  try {
    if (items.length) await set(key, items.slice(-80), idb());
    else await del(key, idb());
  } catch {
    /* depolama kapalı olabilir */
  }
}
