// Tura Asistan — yapay zeka bağlantı ayarları.
// Üç yol: (1) bulut servisi + kullanıcının kendi API anahtarı (Gemini, ChatGPT, Claude, Groq, OpenRouter…),
// (2) bilgisayarda ücretsiz çalışan model (Ollama, LM Studio, Open WebUI, AnythingLLM, Jan),
// (3) hazır bağlantılar: claude.ai içinde kullanıcının Claude hesabı ya da ekibin kurduğu Tura sunucusu.
// Ayarlar ve anahtarlar yalnızca bu cihazda saklanır.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useSyncExternalStore } from 'react';
import { N_ } from '../i18n';

export type ProviderId =
  | 'claude-ai'
  | 'tura'
  | 'gemini'
  | 'openai'
  | 'anthropic'
  | 'groq'
  | 'openrouter'
  | 'deepseek'
  | 'ollama'
  | 'lmstudio'
  | 'openwebui'
  | 'anythingllm'
  | 'jan'
  | 'custom';

/** Bağlantı dili */
export type Dialect = 'ollama' | 'openai' | 'anthropic' | 'gemini' | 'claude-ai';
export type Group = 'ready' | 'cloud' | 'local';
/** Fiyat rozeti */
export type Price = 'free' | 'free-tier' | 'paid' | 'cheap';

export interface Provider {
  id: ProviderId;
  name: string;
  group: Group;
  dialect: Dialect;
  url: string;
  /** API anahtarı gerekiyor mu */
  key: 'none' | 'optional' | 'required';
  /** Anahtarın alındığı sayfa */
  keyUrl?: string;
  price: Price;
  /** Model listesinde ne yazdığı (AnythingLLM'de model = çalışma alanı) */
  modelLabel?: string;
  /** Model listesi alınamazsa önerilen model */
  model?: string;
  /** Varsayılan bağlam penceresi (token) */
  ctx: number;
  /** Sıcaklık (temperature) gönderilmez (bazı modeller kabul etmiyor) */
  noTemperature?: boolean;
  blurb: string;
  /** Kısa uyarı (ör. ücretsiz katmanda verilerin kullanımı) */
  note?: string;
}

// Ekibin kurduğu sunucu (derlemede VITE_TURA_AI_URL verilirse görünür; kullanıcıdan kurulum istemez)
const env = (import.meta as unknown as { env?: Record<string, string | undefined> }).env ?? {};
const TURA_URL = (env.VITE_TURA_AI_URL ?? '').trim().replace(/\/+$/, '');
// Sunucunun herkese açık, sınırlı anahtarı (varsa). Gizli bir anahtar buraya konmamalı: uygulamanın içinden okunabilir.
const TURA_KEY = (env.VITE_TURA_AI_KEY ?? '').trim();

export const PROVIDERS: Provider[] = [
  {
    id: 'claude-ai',
    name: N_('Claude (claude.ai hesabın)'),
    group: 'ready',
    dialect: 'claude-ai',
    url: 'claude.ai',
    key: 'none',
    price: 'free',
    modelLabel: N_('Hız'),
    model: 'default',
    ctx: 32768,
    blurb: N_('Tura Belge claude.ai içinde açıkken kurulum gerekmez; cevaplar senin Claude hesabının kullanımından düşer.'),
  },
  {
    id: 'tura',
    name: env.VITE_TURA_AI_NAME || N_('Tura sunucusu'),
    group: 'ready',
    dialect: 'openai',
    url: TURA_URL,
    key: 'optional',
    price: 'free',
    model: env.VITE_TURA_AI_MODEL || '',
    ctx: Number(env.VITE_TURA_AI_CTX) || 16384,
    blurb: N_('Ekibin hazırladığı sunucu; kurulum ve anahtar gerekmez.'),
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    group: 'cloud',
    dialect: 'gemini',
    url: 'https://generativelanguage.googleapis.com/v1beta',
    key: 'required',
    keyUrl: 'https://aistudio.google.com/apikey',
    price: 'free-tier',
    model: 'gemini-flash-latest',
    ctx: 32768,
    blurb: N_('Önerilen. Kartsız ücretsiz katman; Google hesabınla 1 dakikada anahtar alınır.'),
    note: N_('Ücretsiz katmanda Google gönderilen metinleri ürünlerini geliştirmek için kullanabilir; gizli bilgi gönderme.'),
  },
  {
    id: 'groq',
    name: 'Groq',
    group: 'cloud',
    dialect: 'openai',
    url: 'https://api.groq.com/openai/v1',
    key: 'required',
    keyUrl: 'https://console.groq.com/keys',
    price: 'free-tier',
    model: 'openai/gpt-oss-120b',
    ctx: 8192,
    blurb: N_('Kartsız ücretsiz katman, çok hızlı açık modeller (gpt-oss, Qwen…).'),
    note: N_('Ücretsiz katmanın dakikalık sınırı düşük: uzun sorularda biraz beklemek gerekebilir.'),
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    group: 'cloud',
    dialect: 'openai',
    url: 'https://openrouter.ai/api/v1',
    key: 'required',
    keyUrl: 'https://openrouter.ai/settings/keys',
    price: 'free-tier',
    ctx: 16384,
    blurb: N_('Tek anahtarla birçok model; adı “:free” ile biten modeller ücretsiz (günlük sınırlı).'),
  },
  {
    id: 'openai',
    name: N_('OpenAI (ChatGPT)'),
    group: 'cloud',
    dialect: 'openai',
    url: 'https://api.openai.com/v1',
    key: 'required',
    keyUrl: 'https://platform.openai.com/api-keys',
    price: 'paid',
    noTemperature: true,
    ctx: 16384,
    blurb: N_('ChatGPT’nin modelleri. Kullandıkça ödenir; ChatGPT Plus aboneliği API’yi kapsamaz.'),
  },
  {
    id: 'anthropic',
    name: N_('Anthropic (Claude API)'),
    group: 'cloud',
    dialect: 'anthropic',
    url: 'https://api.anthropic.com/v1',
    key: 'required',
    keyUrl: 'https://console.anthropic.com/settings/keys',
    price: 'paid',
    ctx: 16384,
    blurb: N_('Claude modelleri. Kullandıkça ödenir; Claude Pro aboneliği API’yi kapsamaz.'),
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    group: 'cloud',
    dialect: 'openai',
    url: 'https://api.deepseek.com',
    key: 'required',
    keyUrl: 'https://platform.deepseek.com/api_keys',
    price: 'cheap',
    model: 'deepseek-chat',
    ctx: 16384,
    blurb: N_('Çok ucuz, matematikte güçlü. Kullandıkça ödenir.'),
  },
  {
    id: 'ollama',
    name: 'Ollama',
    group: 'local',
    dialect: 'ollama',
    url: 'http://localhost:11434',
    key: 'none',
    price: 'free',
    ctx: 8192,
    blurb: N_('Ücretsiz; modeli kendi bilgisayarında çalıştırır, notlar bilgisayardan çıkmaz.'),
  },
  {
    id: 'lmstudio',
    name: 'LM Studio',
    group: 'local',
    dialect: 'openai',
    url: 'http://localhost:1234/v1',
    key: 'none',
    price: 'free',
    ctx: 8192,
    blurb: N_('Ücretsiz masaüstü uygulaması; model indirip yerel sunucu açar.'),
  },
  {
    id: 'openwebui',
    name: 'Open WebUI',
    group: 'local',
    dialect: 'openai',
    url: 'http://localhost:3000/api',
    key: 'required',
    price: 'free',
    ctx: 8192,
    blurb: N_('Kendi Open WebUI kurulumun (arkada genellikle Ollama).'),
  },
  {
    id: 'anythingllm',
    name: 'AnythingLLM',
    group: 'local',
    dialect: 'openai',
    url: 'http://localhost:3001/api/v1/openai',
    key: 'required',
    price: 'free',
    modelLabel: N_('Çalışma alanı'),
    ctx: 8192,
    blurb: N_('AnythingLLM masaüstü ya da Docker; modeli onun ayarlarından gelir.'),
  },
  {
    id: 'jan',
    name: 'Jan',
    group: 'local',
    dialect: 'openai',
    url: 'http://localhost:1337/v1',
    key: 'optional',
    price: 'free',
    ctx: 8192,
    blurb: N_('Ücretsiz, açık kaynak masaüstü uygulaması.'),
  },
  {
    id: 'custom',
    name: N_('Diğer (OpenAI uyumlu)'),
    group: 'local',
    dialect: 'openai',
    url: 'http://localhost:8080/v1',
    key: 'optional',
    price: 'free',
    ctx: 8192,
    blurb: N_('llama.cpp sunucusu, vLLM, okulunun sunucusu ya da başka bir OpenAI uyumlu adres.'),
  },
];

/** Tura Belge claude.ai içinde (Claude yapıtı ya da Claude masaüstü uygulaması) mı açık */
export const inClaudeViewer = () => typeof window !== 'undefined' && typeof (window as unknown as { claude?: { use?: unknown } }).claude?.use === 'function';

export const providerOf = (id: ProviderId) => PROVIDERS.find((p) => p.id === id) ?? PROVIDERS.find((p) => p.id === 'gemini')!;
/** Ekip sunucusu derlemede tanımlandı mı */
export const turaServer = () => !!TURA_URL;

export interface AiSettings {
  provider: ProviderId;
  url: string;
  key: string;
  model: string;
  /** Model "düşünerek" yanıt verebiliyorsa: daha yavaş ama daha dikkatli */
  think: boolean;
  /** Bağlam penceresi (token): notlardan ne kadarının modele gönderileceğini belirler */
  ctx: number;
  /** Sağlayıcı başına saklanan anahtarlar ve adresler (sağlayıcı değiştirince kaybolmasın) */
  keys?: Partial<Record<ProviderId, string>>;
  urls?: Partial<Record<ProviderId, string>>;
  models?: Partial<Record<ProviderId, string>>;
  /** OpenRouter: yalnızca ücretsiz modeller */
  freeOnly?: boolean;
}

export const CTX_OPTIONS = [4096, 8192, 16384, 32768, 65536];
const KEY = 'tura-belge:yz';

function defaults(): AiSettings {
  const p = inClaudeViewer() ? providerOf('claude-ai') : TURA_URL ? providerOf('tura') : providerOf('gemini');
  return { provider: p.id, url: p.url, key: p.id === 'tura' ? TURA_KEY : '', model: p.model ?? '', think: false, ctx: p.ctx, freeOnly: true };
}

let current: AiSettings = load();
const listeners = new Set<() => void>();

function load(): AiSettings {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = { ...defaults(), ...(JSON.parse(raw) as Partial<AiSettings>) };
      // Ekip sunucusu kaldırıldıysa ya da bilinmeyen bir sağlayıcı kaldıysa varsayılana dön
      if (
        !PROVIDERS.some((p) => p.id === s.provider) ||
        (s.provider === 'tura' && !TURA_URL) ||
        (s.provider === 'claude-ai' && !inClaudeViewer())
      )
        return defaults();
      if (s.provider === 'tura') {
        s.url = TURA_URL;
        s.key = TURA_KEY;
      }
      return s;
    }
  } catch {
    /* depolama kapalı olabilir */
  }
  return defaults();
}

export const getAi = () => current;

/** Asistan kullanılabilir mi (bağlantı ayarlanmış mı) */
export const aiReady = (s: AiSettings = current) => {
  const p = providerOf(s.provider);
  if (p.id === 'claude-ai') return inClaudeViewer();
  if (p.id === 'tura') return !!TURA_URL && !!(s.model || p.model);
  if (p.key === 'required' && !s.key.trim()) return false;
  return !!s.model && !!s.url;
};

/** Sağlayıcıya geçerken o sağlayıcı için daha önce girilen anahtar, adres ve model geri gelir */
export function switchProvider(s: AiSettings, id: ProviderId): AiSettings {
  const p = providerOf(id);
  const keys = { ...s.keys, [s.provider]: s.key };
  const urls = { ...s.urls, [s.provider]: s.url };
  const models = { ...s.models, [s.provider]: s.model };
  return {
    ...s,
    keys,
    urls,
    models,
    provider: id,
    key: id === 'tura' ? TURA_KEY : (keys[id] ?? ''),
    url: id === 'tura' ? TURA_URL : (urls[id] ?? p.url),
    model: models[id] ?? p.model ?? '',
    ctx: p.ctx,
  };
}

export function setAi(next: AiSettings) {
  const keys = { ...next.keys, [next.provider]: next.key };
  const urls = { ...next.urls, [next.provider]: next.url };
  const models = { ...next.models, [next.provider]: next.model };
  current = { ...next, url: next.url.trim().replace(/\/+$/, ''), key: next.key.trim(), keys, urls, models };
  try {
    localStorage.setItem(KEY, JSON.stringify(current));
  } catch {
    /* depolama kapalı olabilir */
  }
  listeners.forEach((f) => f());
}

export function useAi(): AiSettings {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    getAi,
  );
}

/** Ekranda gösterilen model adı */
export const modelName = (s: AiSettings = current) => (providerOf(s.provider).dialect === 'claude-ai' ? 'Claude' : s.model || providerOf(s.provider).model || '');
