// Tura Asistan — modele giden mesajlar. Asistan önce öğrencinin notlarına dayanır;
// notlar yetmezse (ör. yalnızca adı geçen bir yöntem) kendi bilgisiyle açıklar ve bunu ayrıca belirtir.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { getLang } from '../i18n';
import type { ChatMsg } from './client';
import { sourceLabel, type Source } from './sources';

/** Cevapta notlarda olmayan (genel bilgiyle eklenen) kısmın işareti */
export const GEN_MARK = { tr: 'Notlarında yok:', en: 'Not in your notes:' };

const SYSTEM = {
  tr: `Sen Tura Belge uygulamasındaki çalışma asistanısın ve bir öğrencinin kendi ders notlarını anlamasına yardım ediyorsun.
Her soruyla birlikte öğrencinin belgelerinden parçalar gelir; her parçanın başında [numara] ve kaynağı yazar.

Kurallar:
1. Önce bu parçalara dayan. Bir bilgiyi bir parçadan aldığında cümlenin sonuna köşeli parantezle numarasını yaz, ör. [2].
2. Notlar yetersizse — bir yöntemin yalnızca adı geçiyorsa, bir formül gerekçesiz verilmişse, bir adım atlanmışsa — kendi bilginle açıkla, türet ve gerekirse örnek ver. Bu kısmı ayrı bir paragraf yap ve paragrafı "${GEN_MARK.tr}" diye başlat. Bu kısma kaynak numarası koyma.
3. "Nereden geliyor?" sorusunda formülü adım adım türet; hangi tanımdan, yasadan ya da varsayımdan çıktığını söyle; notlarda geçtiği yeri numarasıyla göster.
4. Kaynak numarası uydurma. Parçalarda olmayan bir şeyi notlardan geliyormuş gibi gösterme. Emin olmadığın yerde bunu söyle.
5. Matematiği LaTeX ile yaz: satır içinde $...$, ayrı satırda $$...$$.
6. Kullanıcının yazdığı dilde, açık ve öğretici yaz. Gereksiz uzatma; başlık ve madde işaretlerini yalnızca gerçekten gerekiyorsa kullan.`,
  en: `You are the study assistant in the Tura Belge app, helping a student understand their own course notes.
Each question comes with excerpts from the student's documents; each excerpt starts with [number] and its source.

Rules:
1. Rely on these excerpts first. When you take something from an excerpt, put its number in square brackets at the end of the sentence, e.g. [2].
2. If the notes are not enough — a method is only named, a formula is given without justification, a step is skipped — explain it from your own knowledge, derive it and give an example if useful. Put that part in its own paragraph starting with "${GEN_MARK.en}". Do not put source numbers on it.
3. For "where does this come from?", derive the formula step by step, say which definition, law or assumption it follows from, and point to where it appears in the notes by number.
4. Never invent source numbers. Do not present anything that is not in the excerpts as coming from the notes. Say so when you are unsure.
5. Write mathematics in LaTeX: $...$ inline, $$...$$ on its own line.
6. Answer in the language the user writes in, clearly and didactically. Keep it focused; use headings and bullet points only when they really help.`,
};

export interface Turn {
  q: string;
  a: string;
}

export interface PromptInput {
  question: string;
  selection?: { text: string; where: string };
  sources: Source[];
  history: Turn[];
  /** Geçmiş için ayrılan en fazla karakter */
  historyBudget: number;
}

export function buildMessages(p: PromptInput): ChatMsg[] {
  const lang = getLang();
  const msgs: ChatMsg[] = [{ role: 'system', content: SYSTEM[lang] }];
  // Önceki konuşma: en yeni sorular önce sığdırılır
  const turns: Turn[] = [];
  let used = 0;
  for (let i = p.history.length - 1; i >= 0; i--) {
    const t = p.history[i];
    const size = t.q.length + t.a.length;
    if (used + size > p.historyBudget) break;
    used += size;
    turns.unshift(t);
  }
  for (const t of turns) msgs.push({ role: 'user', content: t.q }, { role: 'assistant', content: t.a });

  const L = lang === 'tr'
    ? { ex: 'Öğrencinin belgelerinden parçalar', none: '(Bu soruyla eşleşen bir not bulunamadı; kendi bilginle yanıtla ve bunu belirt.)', sel: 'Öğrencinin seçtiği metin', q: 'Soru' }
    : { ex: "Excerpts from the student's documents", none: '(No matching notes were found; answer from your own knowledge and say so.)', sel: 'Text selected by the student', q: 'Question' };
  const parts: string[] = [];
  parts.push(`${L.ex}:`);
  if (p.sources.length) for (const s of p.sources) parts.push(`[${s.ref}] ${sourceLabel(s)}\n${s.text.trim()}`);
  else parts.push(L.none);
  if (p.selection?.text) parts.push(`${L.sel} (${p.selection.where}):\n"""${p.selection.text.trim()}"""`);
  parts.push(`${L.q}: ${p.question.trim()}`);
  msgs.push({ role: 'user', content: parts.join('\n\n') });
  return msgs;
}

/** Bağlam penceresine göre kaynaklara ve geçmişe ayrılacak karakter (yaklaşık 2,6 karakter/token) */
export function budgets(ctx: number): { sources: number; history: number } {
  const total = (ctx - 1400) * 2.6 - 2400; // cevap ve yönerge payı düşülür
  return { sources: Math.max(2200, Math.round(total * 0.72)), history: Math.max(800, Math.round(total * 0.28)) };
}

/** Hızlı düğmeler: seçili metin için hazır sorular */
export const QUICK = {
  explain: { tr: 'Bunu açıkla: ne anlama geliyor ve neden önemli? Notlarda eksik kalan yeri kendi bilginle tamamla.', en: 'Explain this: what does it mean and why does it matter? Fill in whatever the notes leave out.' },
  origin: { tr: 'Bu nereden geliyor? Formülse adım adım türet; bir yöntemse nasıl çalıştığını ve hangi varsayımlara dayandığını anlat.', en: 'Where does this come from? If it is a formula, derive it step by step; if it is a method, explain how it works and which assumptions it rests on.' },
  example: { tr: 'Bunu basit, sayısal bir örnekle göster.', en: 'Show this with a simple worked numerical example.' },
  summary: { tr: 'Bunu birkaç cümleyle özetle.', en: 'Summarise this in a few sentences.' },
} as const;
export type QuickId = keyof typeof QUICK;

export function translatePrompt(text: string, target: 'tr' | 'en'): ChatMsg[] {
  const tl = target === 'tr' ? 'Türkçe' : 'English';
  const short = text.trim().split(/\s+/).length <= 3;
  const ask =
    getLang() === 'tr'
      ? short
        ? `Şu ifadeyi ${tl} diline çevir. Önce çeviriyi kalın yaz, sonra bir satırda anlamını (birden fazla anlamı varsa en olası olanları) açıkla ve kısa bir örnek cümle ver.\n\n"""${text}"""`
        : `Şu metni ${tl} diline çevir. Yalnızca çeviriyi yaz; formülleri ve özel adları koru.\n\n"""${text}"""`
      : short
        ? `Translate this expression into ${tl}. Give the translation in bold first, then explain its meaning in one line (the most likely senses if there are several) and give a short example sentence.\n\n"""${text}"""`
        : `Translate this text into ${tl}. Write only the translation; keep formulas and proper names.\n\n"""${text}"""`;
  return [{ role: 'user', content: ask }];
}
