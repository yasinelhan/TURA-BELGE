// Tura Asistan — "Asistan bağlantısı" penceresi: hazır bağlantılar (claude.ai, ekip sunucusu),
// internetten API anahtarıyla (Gemini, ChatGPT, Claude, Groq, OpenRouter, DeepSeek) ya da
// bilgisayarda çalışan model (Ollama, LM Studio, Open WebUI, AnythingLLM, Jan); kurulum adımları
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { __, N_, fmtNum } from '../i18n';
import { isNative } from '../lib/native';
import { AiError, claudeAvailable, listModels, mixedContentBlocked, modelCaps, type ModelCaps, type ModelInfo } from './client';
import {
  CTX_OPTIONS,
  PROVIDERS,
  getAi,
  inClaudeViewer,
  providerOf,
  setAi,
  switchProvider,
  turaServer,
  type AiSettings,
  type Group,
  type Price,
  type ProviderId,
} from './settings';

/** Ollama'nın kendiliğinden izin verdiği adresler (bunlar için OLLAMA_ORIGINS gerekmez) */
const OLLAMA_DEFAULT_ORIGIN = /^(https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?|app:\/\/|file:\/\/|tauri:\/\/)/i;

function Cmd({ children }: { children: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <span className="aiset__cmd">
      <code>{children}</code>
      <button
        type="button"
        className="aiset__copy"
        onClick={() => {
          void navigator.clipboard?.writeText(children).then(() => {
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1500);
          });
        }}
      >
        {copied ? __('Kopyalandı') : __('Kopyala')}
      </button>
    </span>
  );
}

function Help({ id }: { id: ProviderId }) {
  const origin = typeof location !== 'undefined' ? location.origin : '';
  const needOrigin = !OLLAMA_DEFAULT_ORIGIN.test(origin);
  const steps: Partial<Record<ProviderId, ReactNode>> = {
    ollama: (
      <ol>
        <li>
          {__('Ollama’yı indirip kur:')}{' '}
          <a href="https://ollama.com/download" target="_blank" rel="noreferrer">
            ollama.com/download
          </a>{' '}
          {__('(Windows, macOS, Linux; ücretsiz).')}
        </li>
        <li>
          {__('Bir model indir (terminalde):')}
          <Cmd>ollama pull gemma4:e4b</Cmd>
          <span className="aiset__note">
            {__('8 GB belleği olan bilgisayarlar için daha küçük modeller: gemma4:e2b ya da qwen3.5:4b. 16 GB ve üstü için: qwen3.5:9b ya da gemma4:12b.')}
          </span>
        </li>
        {needOrigin ? (
          <li>
            {__('Tura Belge’nin bu adresten bağlanabilmesi için Ollama’ya izin ver, sonra Ollama’yı kapatıp yeniden aç:')}
            <span className="aiset__os">Windows</span>
            <Cmd>{`setx OLLAMA_ORIGINS "${origin}"`}</Cmd>
            <span className="aiset__os">macOS</span>
            <Cmd>{`launchctl setenv OLLAMA_ORIGINS "${origin}"`}</Cmd>
            <span className="aiset__os">Linux</span>
            <span className="aiset__note">
              {__('“sudo systemctl edit ollama” ile açılan dosyaya [Service] altına şunu ekle, sonra “sudo systemctl restart ollama”:')}
            </span>
            <Cmd>{`Environment="OLLAMA_ORIGINS=${origin}"`}</Cmd>
          </li>
        ) : (
          <li>{__('Bu adresten bağlanmak için Ollama’da ek izin gerekmez.')}</li>
        )}
        <li>
          {__('Telefondan (Tura Belge mobil uygulaması) bilgisayardaki modeli kullanmak için: bilgisayarda OLLAMA_HOST değerini 0.0.0.0 yap, iki cihaz aynı Wi-Fi’de olsun ve adres olarak bilgisayarın yerel IP adresini yaz, ör. http://192.168.1.20:11434')}
          {!isNative() && ' ' + __('(Web sürümü güvenlik nedeniyle başka cihazdaki http adresine bağlanamaz.)')}
        </li>
      </ol>
    ),
    lmstudio: (
      <ol>
        <li>
          {__('LM Studio’yu kur:')}{' '}
          <a href="https://lmstudio.ai" target="_blank" rel="noreferrer">
            lmstudio.ai
          </a>{' '}
          {__('ve bir model indir (ör. Gemma 4 E4B ya da Qwen3.5 9B).')}
        </li>
        <li>{__('“Developer” bölümünde sunucuyu başlat (Start Server).')}</li>
        <li>{__('Sunucu ayarlarında “Enable CORS” seçeneğini aç; yoksa tarayıcı bağlanamaz.')}</li>
      </ol>
    ),
    openwebui: (
      <ol>
        <li>{__('Open WebUI’da Ayarlar → Hesap → API anahtarları bölümünden yeni bir anahtar oluştur (yönetici API anahtarlarını açmış olmalı) ve aşağıya yapıştır.')}</li>
        <li>{__('Adres: Open WebUI adresinin sonuna /api ekle (ör. http://localhost:3000/api).')}</li>
        <li>{__('Open WebUI varsayılan olarak her adresten gelen isteğe izin verir; CORS_ALLOW_ORIGIN değiştirildiyse bu adresi de ekle:')} <code>{origin}</code></li>
      </ol>
    ),
    anythingllm: (
      <ol>
        <li>{__('AnythingLLM’de Ayarlar → Araçlar → Geliştirici API bölümünden yeni bir API anahtarı oluştur ve aşağıya yapıştır.')}</li>
        <li>{__('Adres: http://localhost:3001/api/v1/openai (sunucun başka adresteyse onu yaz).')}</li>
        <li>{__('Model listesinde AnythingLLM çalışma alanların görünür; asistan seçtiğin çalışma alanının modelini kullanır.')}</li>
      </ol>
    ),
    jan: (
      <ol>
        <li>
          {__('Jan’ı kur:')}{' '}
          <a href="https://jan.ai" target="_blank" rel="noreferrer">
            jan.ai
          </a>{' '}
          {__('ve bir model indir.')}
        </li>
        <li>{__('Ayarlar → Local API Server bölümünden sunucuyu başlat; CORS açık olsun. API anahtarı belirlediysen aşağıya yaz.')}</li>
      </ol>
    ),
    custom: (
      <ol>
        <li>{__('OpenAI uyumlu bir sunucunun adresini yaz (genellikle sonu /v1 ile biter). Sunucu tarayıcıdan gelen isteklere (CORS) izin vermeli.')}</li>
      </ol>
    ),
  };
  if (!steps[id]) return null;
  return (
    <div className="aiset__help">
      {steps[id]}
      <p className="aiset__note">
        {__('Open Notebook ve SurfSense gibi araçlar da arkada Ollama gibi bir model kullanır; Tura Belge’yi aynı Ollama’ya bağlaman yeterli.')}{' '}
        {__('Tarayıcı “yerel ağdaki cihazlara erişim” izni sorarsa izin ver.')}
      </p>
    </div>
  );
}


const gb = (b?: number) => (b ? `${fmtNum(b / 1e9, 1)} GB` : '');

const PRICE: Record<Price, string> = {
  free: N_('Ücretsiz'),
  'free-tier': N_('Ücretsiz katman'),
  cheap: N_('Ucuz'),
  paid: N_('Ücretli'),
};
const GROUPS: [Group, string][] = [
  ['ready', N_('Hazır bağlantı')],
  ['cloud', N_('İnternetten (API anahtarı)')],
  ['local', N_('Bilgisayarımda')],
];

export function AiSettingsDialog({ onClose }: { onClose: () => void }) {
  const [s, setS] = useState<AiSettings>(getAi);
  const [models, setModels] = useState<ModelInfo[] | null>(null);
  const [caps, setCaps] = useState<ModelCaps | null>(null);
  const [status, setStatus] = useState<{ kind: 'idle' | 'busy' | 'ok' | 'err'; text?: string }>({ kind: 'idle' });
  /** claude.ai içindeki Claude bu görünümde var mı (null: bakılıyor) */
  const [claudeOk, setClaudeOk] = useState<boolean | null>(inClaudeViewer() ? null : false);
  const abort = useRef<AbortController | null>(null);
  const p = providerOf(s.provider);
  const [group, setGroup] = useState<Group>(p.group);

  useEffect(() => {
    if (!inClaudeViewer()) return;
    let live = true;
    void claudeAvailable().then((ok) => live && setClaudeOk(ok));
    return () => {
      live = false;
    };
  }, []);

  const visible = (id: ProviderId) => (id === 'claude-ai' ? claudeOk !== false : id === 'tura' ? turaServer() : true);
  const hasReady = visible('claude-ai') || visible('tura');
  const groups = GROUPS.filter(([g]) => g !== 'ready' || hasReady);

  const connect = async (cfg: AiSettings = s) => {
    abort.current?.abort();
    const ac = new AbortController();
    abort.current = ac;
    const prov = providerOf(cfg.provider);
    if (prov.key === 'required' && !cfg.key.trim()) {
      setStatus({ kind: 'err', text: __('Önce API anahtarını yapıştır.') });
      return;
    }
    setStatus({ kind: 'busy', text: __('Bağlanılıyor…') });
    try {
      const list = await listModels(cfg, ac.signal);
      if (ac.signal.aborted) return;
      setModels(list);
      if (!list.length) {
        setStatus({
          kind: prov.model ? 'ok' : 'err',
          text:
            prov.dialect === 'ollama'
              ? __('Bağlandı ama hiç model yok. Önce bir model indir (ör. ollama pull gemma4:e4b).')
              : __('Bağlandı ama model listesi boş. Modelin adını elle yazabilirsin.'),
        });
        if (prov.model && !cfg.model) setS((x) => ({ ...x, model: prov.model! }));
        return;
      }
      const keep = list.some((m) => m.id === cfg.model) ? cfg.model : list[0].id;
      setS((x) => ({ ...x, model: keep }));
      setStatus({ kind: 'ok', text: prov.dialect === 'claude-ai' ? __('Kullanıma hazır') : __('Bağlandı · {0} model', [list.length]) });
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') return;
      setModels(null);
      setStatus({ kind: 'err', text: err instanceof AiError ? err.message : String(err) });
    }
  };

  // Seçili modelin yetenekleri (düşünme, görsel)
  useEffect(() => {
    setCaps(null);
    if (!s.model || status.kind !== 'ok') return;
    const ac = new AbortController();
    void modelCaps(s, ac.signal).then((c) => !ac.signal.aborted && setCaps(c));
    return () => ac.abort();
  }, [s.model, s.url, s.provider, status.kind]); // eslint-disable-line react-hooks/exhaustive-deps

  // Kayıtlı bir bağlantı varsa açılışta modelleri getir
  useEffect(() => {
    const prov = providerOf(s.provider);
    if (prov.group === 'ready' || (s.url && (prov.key !== 'required' || s.key))) void connect();
    return () => abort.current?.abort();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = (id: ProviderId) => {
    const next = switchProvider(s, id);
    setS(next);
    setModels(null);
    setStatus({ kind: 'idle' });
    const prov = providerOf(id);
    // Anahtar gerektirmeyen hazır bağlantılar ve daha önce anahtarı girilmiş servisler hemen bağlanır
    if (prov.group === 'ready' || (prov.key === 'required' && next.key)) void connect(next);
  };

  const save = () => {
    setAi(s);
    onClose();
  };

  const mixed = mixedContentBlocked(s.url);
  const canSave = !!s.model.trim() && (p.key !== 'required' || !!s.key.trim()) && (p.group === 'ready' || !!s.url.trim());
  const shown = PROVIDERS.filter((x) => x.group === group && visible(x.id));

  return (
    <div className="dialog-veil" role="presentation" onClick={onClose}>
      <div className="dialog aiset" role="dialog" aria-modal="true" aria-labelledby="aiset-title" onClick={(e) => e.stopPropagation()}>
        <h2 id="aiset-title">{__('Asistan bağlantısı')}</h2>
        <p>{__('Asistanın cevaplarını yazacak yapay zekayı seç. Sorduğun soru ve notlarından ilgili parçalar yalnızca seçtiğin servise gönderilir; anahtarın yalnızca bu cihazda saklanır.')}</p>

        <div className="seg aiset__groups" role="tablist" aria-label={__('Bağlantı türü')}>
          {groups.map(([g, label]) => (
            <button key={g} type="button" role="tab" aria-selected={group === g} className={group === g ? 'seg__opt seg__opt--on' : 'seg__opt'} onClick={() => setGroup(g)}>
              {__(label)}
            </button>
          ))}
        </div>

        {inClaudeViewer() && group !== 'ready' && (
          <p className="aiset__warn" role="note">
            {__('Bu claude.ai sayfası dış adreslere bağlanamaz. Bu seçenekler Tura Belge’yi kendi adresinde (ör. GitHub Pages ya da bilgisayarında) ya da mobil uygulamada açınca çalışır.')}
          </p>
        )}

        <div className="aiset__providers" role="radiogroup" aria-label={__('Servis')}>
          {shown.map((x) => (
            <button
              key={x.id}
              type="button"
              role="radio"
              aria-checked={s.provider === x.id}
              className={s.provider === x.id ? 'aiset__prov aiset__prov--on' : 'aiset__prov'}
              onClick={() => pick(x.id)}
            >
              <span className="aiset__provhead">
                <b>{__(x.name)}</b>
                <i className={`aiset__price aiset__price--${x.price}`}>{__(PRICE[x.price])}</i>
              </span>
              <small>{__(x.blurb)}</small>
            </button>
          ))}
          {group === 'ready' && claudeOk === null && <p className="aiset__note">{__('claude.ai bağlantısı kontrol ediliyor…')}</p>}
        </div>

        {p.group === group && (
          <>
            {p.group === 'cloud' && (
              <ol className="aiset__keysteps">
                <li>
                  {__('Anahtar al:')}{' '}
                  <a href={p.keyUrl} target="_blank" rel="noreferrer">
                    {p.keyUrl?.replace(/^https:\/\//, '')} ↗
                  </a>{' '}
                  <span className="aiset__note">{__('(hesabınla giriş yap, “Create API key” / “Anahtar oluştur”)')}</span>
                </li>
                <li>
                  <label className="field">
                    <span className="field__label">{__('API anahtarını buraya yapıştır')}</span>
                    <input
                      className="input"
                      type="password"
                      autoComplete="off"
                      spellCheck={false}
                      value={s.key}
                      placeholder={__('Anahtar')}
                      onChange={(e) => setS({ ...s, key: e.target.value })}
                      onBlur={() => s.key.trim() && status.kind !== 'ok' && void connect()}
                      onPaste={(e) => {
                        const v = e.clipboardData.getData('text').trim();
                        if (v) window.setTimeout(() => void connect({ ...s, key: v }), 0);
                      }}
                    />
                  </label>
                </li>
              </ol>
            )}
            {p.note && <p className="aiset__note aiset__note--warn">{__(p.note)}</p>}
            {p.id === 'openrouter' && (
              <label className="check">
                <input
                  type="checkbox"
                  checked={s.freeOnly !== false}
                  onChange={(e) => {
                    const next = { ...s, freeOnly: e.target.checked };
                    setS(next);
                    if (status.kind === 'ok') void connect(next);
                  }}
                />
                <span>{__('Yalnızca ücretsiz modelleri göster')}</span>
              </label>
            )}

            {p.group === 'local' && (
              <details className="aiset__steps" open={!getAi().model || getAi().provider !== p.id}>
                <summary>{__('{0} nasıl kurulur?', [__(p.name)])}</summary>
                <Help id={s.provider} />
              </details>
            )}

            {p.group === 'local' && (
              <div className="aiset__grid">
                <label className="field">
                  <span className="field__label">{__('Adres')}</span>
                  <input className="input" value={s.url} spellCheck={false} inputMode="url" onChange={(e) => setS({ ...s, url: e.target.value })} />
                </label>
                {p.key !== 'none' && (
                  <label className="field">
                    <span className="field__label">
                      {__('API anahtarı')} {p.key === 'optional' && <small className="field__hint">{__('(isteğe bağlı)')}</small>}
                    </span>
                    <input className="input" type="password" autoComplete="off" value={s.key} onChange={(e) => setS({ ...s, key: e.target.value })} />
                  </label>
                )}
              </div>
            )}
            {mixed && (
              <p className="aiset__warn" role="alert">
                {__('Tarayıcı, güvenli (https) sayfadan başka bir cihazdaki http adresine bağlanmaya izin vermiyor. Bilgisayardaki modele telefondan bağlanmak için Tura Belge mobil uygulamasını kullan.')}
              </p>
            )}

            <div className="aiset__connect">
              <button type="button" className="btn btn--primary btn--sm" onClick={() => void connect()} disabled={status.kind === 'busy' || (p.group !== 'ready' && !s.url.trim())}>
                {status.kind === 'ok' ? __('Yenile') : __('Bağlan')}
              </button>
              {status.text && (
                <span className={`aiset__status aiset__status--${status.kind}`} role={status.kind === 'err' ? 'alert' : 'status'}>
                  {status.text}
                </span>
              )}
            </div>

            {(models || (s.model && status.kind !== 'err')) && (
              <div className="aiset__grid">
                <label className="field">
                  <span className="field__label">{p.modelLabel ? __(p.modelLabel) : __('Model')}</span>
                  {models && models.length ? (
                    <select className="input" value={s.model} onChange={(e) => setS({ ...s, model: e.target.value })}>
                      {models.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.label && m.label !== m.id ? (p.dialect === 'claude-ai' ? m.label : `${m.label} · ${m.id}`) : m.id}
                          {m.size ? ` · ${gb(m.size)}` : ''}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input className="input" value={s.model} spellCheck={false} placeholder={p.model || 'gemma4:e4b'} onChange={(e) => setS({ ...s, model: e.target.value })} />
                  )}
                  {caps && (caps.thinking || caps.vision) && (
                    <span className="field__hint">
                      {[caps.thinking && __('düşünerek yanıt verebilir'), caps.vision && __('görsel okuyabilir')].filter(Boolean).join(' · ')}
                    </span>
                  )}
                </label>
                <label className="field">
                  <span className="field__label">{__('Bağlam uzunluğu')}</span>
                  <select className="input" value={s.ctx} onChange={(e) => setS({ ...s, ctx: Number(e.target.value) })}>
                    {CTX_OPTIONS.map((c) => (
                      <option key={c} value={c}>
                        {c / 1024}K
                      </option>
                    ))}
                  </select>
                  <span className="field__hint">{__('Büyüdükçe notlardan daha çok parça okunur; ama yavaşlar, ücretli servislerde daha çok tutar.')}</span>
                </label>
              </div>
            )}
            {caps?.thinking && (
              <label className="check">
                <input type="checkbox" checked={s.think} onChange={(e) => setS({ ...s, think: e.target.checked })} />
                <span>{__('Düşünerek yanıtla (daha yavaş, türetmelerde daha dikkatli)')}</span>
              </label>
            )}
            {p.group === 'cloud' && (
              <details className="aiset__steps">
                <summary>{__('Gelişmiş: adres')}</summary>
                <label className="field">
                  <span className="field__label">{__('Adres')}</span>
                  <input className="input" value={s.url} spellCheck={false} inputMode="url" onChange={(e) => setS({ ...s, url: e.target.value })} />
                </label>
              </details>
            )}
          </>
        )}

        <div className="dialog__actions">
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            {__('Vazgeç')}
          </button>
          <button type="button" className="btn btn--primary" onClick={save} disabled={!canSave}>
            {__('Kaydet')}
          </button>
        </div>
      </div>
    </div>
  );
}
