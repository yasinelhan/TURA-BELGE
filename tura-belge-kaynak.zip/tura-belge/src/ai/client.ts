// Tura Asistan — modele bağlanma. Bağlantı dilleri: Ollama, OpenAI uyumlu sohbet (ChatGPT, Groq, OpenRouter,
// DeepSeek, LM Studio, Open WebUI, AnythingLLM, Jan…), Anthropic (Claude API), Google Gemini ve
// claude.ai içindeki Claude (yapıtın "sample" yeteneği). Cevaplar akış hâlinde gelir.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { isNative } from '../lib/native';
import { __, N_ } from '../i18n';
import { inClaudeViewer, providerOf, type AiSettings, type Provider } from './settings';

export interface ChatMsg {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ModelInfo {
  id: string;
  /** Listede gösterilen ad (yoksa id) */
  label?: string;
  /** Bayt cinsinden boyut (Ollama bildirir) */
  size?: number;
}

export interface ModelCaps {
  thinking: boolean;
  vision: boolean;
}

export type AiErrorKind = 'network' | 'mixed' | 'auth' | 'notfound' | 'limit' | 'server' | 'empty';

export class AiError extends Error {
  kind: AiErrorKind;
  constructor(kind: AiErrorKind, message: string) {
    super(message);
    this.kind = kind;
  }
}

const prov = (s: AiSettings) => providerOf(s.provider);
const base = (s: AiSettings) => s.url.trim().replace(/\/+$/, '');

function headers(s: AiSettings): Record<string, string> {
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  const key = s.key.trim();
  const d = prov(s).dialect;
  if (d === 'anthropic') {
    h['x-api-key'] = key;
    h['anthropic-version'] = '2023-06-01';
    // Anthropic, anahtarı kullanıcının kendisinin girdiği tarayıcı uygulamalarına bu başlıkla izin verir
    h['anthropic-dangerous-direct-browser-access'] = 'true';
  } else if (d !== 'gemini' && key) h.Authorization = `Bearer ${key}`;
  return h;
}

const LOCAL = /^(localhost|127\.0\.0\.1|\[::1\]|.*\.localhost)$/i;

/** https sayfasından http adresine (bu cihaz dışında) tarayıcı bağlanmaya izin vermez; mobil uygulamada izinli */
export function mixedContentBlocked(url: string): boolean {
  if (typeof location === 'undefined' || location.protocol !== 'https:' || isNative()) return false;
  try {
    const u = new URL(url);
    return u.protocol === 'http:' && !LOCAL.test(u.hostname);
  } catch {
    return false;
  }
}

function networkError(s: AiSettings): AiError {
  const p = prov(s);
  if (inClaudeViewer())
    return new AiError('network', __('Bu claude.ai sayfası dış adreslere bağlanamıyor. “Claude (claude.ai hesabın)” seçeneğini kullan ya da Tura Belge’yi kendi adresinde aç.'));
  if (p.group === 'cloud')
    return new AiError('network', __('{0} sunucusuna ulaşılamadı. İnternet bağlantını kontrol et; reklam engelleyici ya da okul/iş ağı bu adresi engelliyor olabilir.', [__(p.name)]));
  return new AiError('network', __('Bağlanılamadı. Program açık mı, adres doğru mu? Tarayıcıdan bağlanma izni verilmemiş de olabilir (ayrıntılar “Bağlantı” penceresinde).'));
}

async function call(s: AiSettings, path: string, init: RequestInit = {}): Promise<Response> {
  let url = base(s) + path;
  if (prov(s).dialect === 'gemini') url += (url.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(s.key.trim());
  if (mixedContentBlocked(url))
    throw new AiError('mixed', __('Tarayıcı, güvenli (https) sayfadan başka bir cihazdaki http adresine bağlanmaya izin vermiyor. Bilgisayardaki modele telefondan bağlanmak için Tura Belge mobil uygulamasını kullan.'));
  let res: Response;
  try {
    res = await fetch(url, { ...init, headers: { ...headers(s), ...(init.headers as Record<string, string> | undefined) } });
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') throw err;
    throw networkError(s);
  }
  if (res.ok) return res;
  let detail = '';
  try {
    const body = await res.text();
    const j = JSON.parse(body) as { error?: string | { message?: string }; message?: string; detail?: string };
    detail = (typeof j.error === 'string' ? j.error : j.error?.message) ?? j.message ?? j.detail ?? '';
  } catch {
    /* gövde JSON değil */
  }
  detail = String(detail).slice(0, 300);
  if (res.status === 401 || res.status === 403 || /api[ _-]?key (not valid|invalid)|invalid[ _-]api[ _-]key|unauthori/i.test(detail))
    throw new AiError('auth', __('Bağlantı reddedildi: API anahtarı eksik ya da yanlış.'));
  if (res.status === 402) throw new AiError('limit', __('Bu hesapta kredi kalmamış ya da ödeme gerekiyor.{0}', [detail ? ` (${detail})` : '']));
  if (res.status === 429)
    throw new AiError('limit', __('Kullanım sınırına ulaşıldı (ücretsiz katmanın dakikalık ya da günlük sınırı olabilir). Biraz bekleyip tekrar dene.'));
  if (res.status === 413) throw new AiError('limit', __('İstek bu model için fazla uzun. Bağlantı ayarlarından “Bağlam uzunluğu”nu küçült.'));
  if (res.status === 404)
    throw new AiError('notfound', detail ? __('Bulunamadı: {0}', [detail]) : __('Adres bulunamadı. Bağlantı adresini kontrol et.'));
  throw new AiError('server', __('Model hata verdi ({0}){1}', [res.status, detail ? `: ${detail}` : '']));
}

// ------------------------------------------------------------------ claude.ai içindeki Claude

interface SampleFn {
  (input: { role: 'user' | 'assistant'; content: string }[], opts: Record<string, unknown>): Promise<{ text: string; truncated: boolean }>;
}
let samplePromise: Promise<SampleFn | null> | null = null;
function getSample(): Promise<SampleFn | null> {
  if (!inClaudeViewer()) return Promise.resolve(null);
  samplePromise ??= (window as unknown as { claude: { use: (n: string) => Promise<SampleFn | null> } }).claude
    .use('sample')
    .catch(() => null);
  return samplePromise;
}
/** claude.ai içindeki Claude bu görünümde kullanılabilir mi (en fazla ~10 sn sürer) */
export const claudeAvailable = async () => !!(await getSample());

const SAMPLE_ERRORS: Record<string, string> = {
  not_granted: N_('Claude’u kullanmaya izin verilmedi. Sayfayı yenileyip izin penceresinde “İzin ver”i seçebilirsin.'),
  sampling_disabled: N_('Bu hesapta bu sayfadan Claude kullanılamıyor.'),
  rate_limited: N_('Claude kullanım sınırına ulaşıldı. Biraz sonra tekrar dene.'),
  session_expired: N_('claude.ai oturumu sona ermiş; yeniden giriş yap.'),
  prompt_too_large: N_('İstek çok uzun. Bağlantı ayarlarından “Bağlam uzunluğu”nu küçült.'),
  refused: N_('Claude bu isteği yanıtlamadı.'),
  empty_completion: N_('Claude boş bir cevap döndürdü.'),
};

async function* claudeStream(s: AiSettings, messages: ChatMsg[], signal?: AbortSignal): AsyncGenerator<StreamPart> {
  const sample = await getSample();
  if (!sample) throw new AiError('notfound', __('Claude bu görünümde kullanılamıyor (yalnızca claude.ai içinde açılan Tura Belge’de çalışır).'));
  // Yapıtın Claude'unda sistem rolü yok: yönerge baştaki kullanıcı mesajı olur
  const turns = messages.map((m) => ({ role: m.role === 'assistant' ? ('assistant' as const) : ('user' as const), content: m.content }));
  const queue: StreamPart[] = [];
  let wake: (() => void) | null = null;
  let done = false;
  let failure: unknown = null;
  const tier = ['quick', 'default', 'complex'].includes(s.model) ? s.model : 'default';
  sample(turns, {
    cache: false,
    modelTier: tier,
    signal,
    onText: ({ delta }: { delta: string }) => {
      queue.push({ type: 'text', text: delta });
      wake?.();
    },
  })
    .catch((e: { code?: string; message?: string }) => {
      if (e?.code === 'cancelled') failure = new DOMException('aborted', 'AbortError');
      else failure = new AiError(e?.code === 'rate_limited' ? 'limit' : 'server', e?.code && SAMPLE_ERRORS[e.code] ? __(SAMPLE_ERRORS[e.code]) : __('Claude cevap veremedi: {0}', [e?.message ?? e?.code ?? '?']));
    })
    .finally(() => {
      done = true;
      wake?.();
    });
  for (;;) {
    while (queue.length) yield queue.shift()!;
    if (done) break;
    await new Promise<void>((r) => (wake = r));
    wake = null;
  }
  while (queue.length) yield queue.shift()!;
  if (failure) throw failure;
}

// ------------------------------------------------------------------ Model listesi

/** Sürüm numarası (ör. "gemini-3.8-flash" → 3.8) */
const ver = (id: string) => Number(id.match(/(\d+(?:\.\d+)?)/)?.[1] ?? 0);

/** Sağlayıcıya göre gereksiz modelleri ayıklar, önerileni başa alır */
function rankModels(p: Provider, list: ModelInfo[], s: AiSettings): ModelInfo[] {
  let out = list;
  let score: (id: string) => number = () => 1;
  switch (p.id) {
    case 'openai':
      out = list.filter((m) => /^(gpt-|o\d|chatgpt-)/.test(m.id) && !/(audio|realtime|transcribe|tts|image|search|embed|moderation|instruct|codex|dall-e|whisper|computer|deep-research)/.test(m.id));
      score = (id) => (/mini/.test(id) && !/nano/.test(id) ? 0 : /nano/.test(id) ? 2 : 1);
      break;
    case 'anthropic':
      score = (id) => (/haiku/.test(id) ? 0 : /sonnet/.test(id) ? 1 : 2);
      break;
    case 'gemini':
      out = list.filter((m) => /^(gemini|gemma)/.test(m.id) && !/(image|tts|audio|live|embed|aqa|vision|robotics|computer|thinking-exp|native)/.test(m.id));
      score = (id) => (/^gemini-[\d.]+-flash$/.test(id) ? 0 : id === 'gemini-flash-latest' ? 1 : /flash-lite/.test(id) ? 3 : /flash/.test(id) ? 2 : /pro/.test(id) ? 4 : 5);
      break;
    case 'groq':
      out = list.filter((m) => !/(whisper|tts|guard|playai|orpheus|distil|compound)/i.test(m.id));
      score = (id) => (id === 'openai/gpt-oss-120b' ? 0 : /gpt-oss/.test(id) ? 1 : /qwen/.test(id) ? 2 : /llama/.test(id) ? 3 : 4);
      break;
    case 'openrouter':
      if (s.freeOnly !== false) out = list.filter((m) => m.id.endsWith(':free'));
      score = (id) => (/(deepseek|qwen|gemini|gpt-oss)/.test(id) ? 0 : /(llama|mistral|gemma)/.test(id) ? 1 : 2);
      break;
    case 'deepseek':
      score = (id) => (id === 'deepseek-chat' ? 0 : 1);
      break;
    default:
      return list;
  }
  return [...out].sort((a, b) => score(a.id) - score(b.id) || ver(b.id) - ver(a.id) || a.id.localeCompare(b.id));
}

/** Kullanılabilir modeller (AnythingLLM'de çalışma alanları, claude.ai'de hız seçenekleri) */
export async function listModels(s: AiSettings, signal?: AbortSignal): Promise<ModelInfo[]> {
  const p = prov(s);
  if (p.dialect === 'claude-ai') {
    if (!(await getSample())) throw new AiError('notfound', __('Claude bu görünümde kullanılamıyor (yalnızca claude.ai içinde açılan Tura Belge’de çalışır).'));
    return [
      { id: 'default', label: __('Dengeli (önerilen)') },
      { id: 'quick', label: __('Hızlı') },
      { id: 'complex', label: __('En güçlü (yavaş)') },
    ];
  }
  if (p.dialect === 'ollama') {
    const res = await call(s, '/api/tags', { signal });
    const j = (await res.json()) as { models?: { name: string; size?: number }[] };
    return (j.models ?? []).map((m) => ({ id: m.name, size: m.size })).sort((a, b) => a.id.localeCompare(b.id));
  }
  if (p.dialect === 'gemini') {
    const res = await call(s, '/models?pageSize=200', { signal });
    const j = (await res.json()) as { models?: { name: string; displayName?: string; supportedGenerationMethods?: string[] }[] };
    const list = (j.models ?? [])
      .filter((m) => (m.supportedGenerationMethods ?? ['generateContent']).includes('generateContent'))
      .map((m) => ({ id: m.name.replace(/^models\//, ''), label: m.displayName }));
    return rankModels(p, list, s);
  }
  const res = await call(s, '/models', { signal });
  const j = (await res.json()) as { data?: { id: string; display_name?: string }[] } | { id: string }[];
  const list = (Array.isArray(j) ? j : (j.data ?? []))
    .filter((m) => m && typeof m.id === 'string')
    .map((m) => ({ id: m.id, label: (m as { display_name?: string }).display_name }));
  return rankModels(p, list, s);
}

/** Modelin yetenekleri (yalnızca Ollama bildirir; diğerlerinde bilinmiyor sayılır) */
export async function modelCaps(s: AiSettings, signal?: AbortSignal): Promise<ModelCaps> {
  if (prov(s).dialect !== 'ollama' || !s.model) return { thinking: false, vision: false };
  try {
    const res = await call(s, '/api/show', { method: 'POST', body: JSON.stringify({ model: s.model }), signal });
    const j = (await res.json()) as { capabilities?: string[] };
    const c = j.capabilities ?? [];
    return { thinking: c.includes('thinking'), vision: c.includes('vision') };
  } catch {
    return { thinking: false, vision: false };
  }
}

export interface StreamPart {
  type: 'text' | 'think';
  text: string;
}

/** Satır satır okur (NDJSON ve SSE için) */
async function* lines(res: Response): AsyncGenerator<string> {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i: number;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (line) yield line;
    }
  }
  buf += dec.decode();
  if (buf.trim()) yield buf.trim();
}

/** SSE "data:" satırlarındaki JSON nesneleri */
async function* sseJson<T>(res: Response): AsyncGenerator<T> {
  for await (const line of lines(res)) {
    if (!line.startsWith('data:')) continue;
    const data = line.slice(5).trim();
    if (data === '[DONE]') return;
    try {
      yield JSON.parse(data) as T;
    } catch {
      /* yarım satır */
    }
  }
}

/** Sohbet: cevabı parça parça döndürür */
export async function* chatStream(
  s: AiSettings,
  messages: ChatMsg[],
  opts: { signal?: AbortSignal; caps?: ModelCaps; temperature?: number } = {},
): AsyncGenerator<StreamPart> {
  const p = prov(s);
  const temperature = opts.temperature ?? 0.3;
  const model = s.model || p.model || '';

  if (p.dialect === 'claude-ai') {
    yield* claudeStream(s, messages, opts.signal);
    return;
  }

  if (p.dialect === 'ollama') {
    const body: Record<string, unknown> = { model, messages, stream: true, keep_alive: '20m', options: { num_ctx: s.ctx, temperature } };
    // Düşünebilen modellerde açıkça söylenir (söylenmezse model kendi varsayılanını kullanır)
    if (opts.caps?.thinking) body.think = s.think;
    const res = await call(s, '/api/chat', { method: 'POST', body: JSON.stringify(body), signal: opts.signal });
    for await (const line of lines(res)) {
      let j: { message?: { content?: string; thinking?: string }; error?: string; done?: boolean };
      try {
        j = JSON.parse(line);
      } catch {
        continue;
      }
      if (j.error) throw new AiError('server', j.error);
      if (j.message?.thinking) yield { type: 'think', text: j.message.thinking };
      if (j.message?.content) yield { type: 'text', text: j.message.content };
      if (j.done) return;
    }
    return;
  }

  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const turns = messages.filter((m) => m.role !== 'system');

  if (p.dialect === 'anthropic') {
    const res = await call(s, '/messages', {
      method: 'POST',
      body: JSON.stringify({ model, max_tokens: 4096, system, messages: turns, stream: true, temperature }),
      signal: opts.signal,
    });
    for await (const j of sseJson<{ type?: string; delta?: { type?: string; text?: string; thinking?: string }; error?: { message?: string } }>(res)) {
      if (j.type === 'error') throw new AiError('server', j.error?.message ?? 'error');
      if (j.type === 'content_block_delta') {
        if (j.delta?.type === 'text_delta' && j.delta.text) yield { type: 'text', text: j.delta.text };
        else if (j.delta?.type === 'thinking_delta' && j.delta.thinking) yield { type: 'think', text: j.delta.thinking };
      }
      if (j.type === 'message_stop') return;
    }
    return;
  }

  if (p.dialect === 'gemini') {
    const body = {
      ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
      contents: turns.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
      generationConfig: { temperature },
    };
    const res = await call(s, `/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`, { method: 'POST', body: JSON.stringify(body), signal: opts.signal });
    for await (const j of sseJson<{
      candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] }; finishReason?: string }[];
      promptFeedback?: { blockReason?: string };
      error?: { message?: string };
    }>(res)) {
      if (j.error) throw new AiError('server', j.error.message ?? 'error');
      if (j.promptFeedback?.blockReason) throw new AiError('server', __('İstek model tarafından engellendi ({0}).', [j.promptFeedback.blockReason]));
      for (const part of j.candidates?.[0]?.content?.parts ?? []) if (part.text) yield { type: part.thought ? 'think' : 'text', text: part.text };
    }
    return;
  }

  // OpenAI uyumlu
  const send = (withTemp: boolean) =>
    call(s, '/chat/completions', {
      method: 'POST',
      body: JSON.stringify({ model, messages, stream: true, ...(withTemp ? { temperature } : {}) }),
      signal: opts.signal,
    });
  let res: Response;
  try {
    res = await send(!p.noTemperature);
  } catch (err) {
    // Bazı modeller sıcaklık ayarını kabul etmiyor: bir kez onsuz dene
    if (err instanceof AiError && err.kind === 'server' && /temperature/i.test(err.message) && !p.noTemperature) res = await send(false);
    else throw err;
  }
  // Akışı desteklemeyen sunucular tek seferde JSON döndürür
  if ((res.headers.get('content-type') ?? '').includes('application/json')) {
    const j = (await res.json()) as { choices?: { message?: { content?: string; reasoning_content?: string } }[] };
    const m = j.choices?.[0]?.message;
    if (m?.reasoning_content) yield { type: 'think', text: m.reasoning_content };
    if (m?.content) yield { type: 'text', text: m.content };
    return;
  }
  for await (const j of sseJson<{
    choices?: { delta?: { content?: string | null; reasoning_content?: string | null; reasoning?: string | null }; message?: { content?: string } }[];
    error?: string | { message?: string };
  }>(res)) {
    if (j.error) throw new AiError('server', typeof j.error === 'string' ? j.error : (j.error.message ?? 'error'));
    const d = j.choices?.[0]?.delta;
    const think = d?.reasoning_content ?? d?.reasoning;
    if (think) yield { type: 'think', text: think };
    const text = d?.content ?? j.choices?.[0]?.message?.content;
    if (text) yield { type: 'text', text };
  }
}

/** Bazı modeller düşüncelerini <think>…</think> içinde cevaba katar: görünen cevaptan ayıklanır */
export function visibleAnswer(raw: string): { text: string; thinking: boolean } {
  const open = raw.lastIndexOf('<think>');
  const close = raw.lastIndexOf('</think>');
  const thinking = open >= 0 && close < open;
  const text = raw
    .replace(/<think>[\s\S]*?<\/think>/g, '')
    .replace(/<think>[\s\S]*$/, '')
    .replace(/^\s+/, '');
  return { text, thinking };
}
