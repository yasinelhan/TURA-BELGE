// Tura Belge — genel ayarlar
// SPDX-License-Identifier: AGPL-3.0-or-later

/**
 * Kaynak kodun adresi (ör. https://github.com/ekip-adi/tura-belge).
 * AGPL-3.0 gereği, uygulamayı internette yayınlarken kullanıcılara kaynak koda
 * ulaşma yolu gösterilmelidir. Depo açılınca burayı doldurun; alt bilgide bağlantı çıkar.
 */
export const SOURCE_URL = '';

export const APP_VERSION = '0.8.1';
