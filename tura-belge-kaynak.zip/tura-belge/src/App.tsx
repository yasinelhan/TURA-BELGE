// Tura Belge — uygulama kabuğu
// SPDX-License-Identifier: AGPL-3.0-or-later
import { Fragment, lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { Home } from './components/Home';
import { BrandMark } from './components/Brand';
import {
  deleteDoc,
  deleteFolder,
  listFolders,
  moveDocToFolder,
  saveFolder,
  type Folder,
  findDocByHandle,
  getHandle,
  getMeta,
  listDocs,
  loadDocBytes,
  newDocId,
  saveDoc,
  saveHandle,
  storageAvailable,
  type DocMeta,
} from './lib/storage';
import { baseName, canLinkFiles, ensurePermission, isMarkdownName, onLaunchFiles, pickPdfHandle, PickCancelled, readHandle } from './lib/fileLink';
import type { DocKind } from './lib/storage';
import { nextCover } from './components/Notebook';
import type { ViewerDoc } from './lib/viewerConfig';
import { ToolHost, type PdfInput, type ToolHostApi } from './tools/host';
import { __, useLang } from './i18n';

// PDF motoru ve araçlar büyük olduğu için yalnızca gerektiğinde yüklenir.
const Editor = lazy(() => import('./components/Editor').then((m) => ({ default: m.Editor })));
const ToolsView = lazy(() => import('./tools/ToolsView').then((m) => ({ default: m.ToolsView })));
const TexHome = lazy(() => import('./tex/TexHome').then((m) => ({ default: m.TexHome })));
const TexEditor = lazy(() => import('./tex/TexEditor').then((m) => ({ default: m.TexEditor })));
const MdEditor = lazy(() => import('./md/MdEditor').then((m) => ({ default: m.MdEditor })));
const AssistantPage = lazy(() => import('./ai/AssistantPage').then((m) => ({ default: m.AssistantPage })));

const isPdfBytes = (bytes: ArrayBuffer) => new TextDecoder('latin1').decode(new Uint8Array(bytes.slice(0, 1024))).includes('%PDF');
/** Metin dosyası mı (Markdown): ilk bölümde boş bayt yok ve UTF-8 olarak okunabiliyor */
const isTextBytes = (bytes: ArrayBuffer) => {
  const head = new Uint8Array(bytes.slice(0, 4096));
  if (head.includes(0)) return false;
  try {
    new TextDecoder('utf-8', { fatal: true }).decode(head.slice(0, Math.max(0, head.length - 4)));
    return true;
  } catch {
    return false;
  }
};

type Route =
  | { view: 'home' }
  | { view: 'tools'; tool: string | null }
  | { view: 'tex'; project: string | null }
  | { view: 'ai'; folder: string | null };

// Yalnızca düz "#ad" biçimi kullanılır (Claude yapıt görünümüyle de uyumlu)
function parseHash(): Route {
  const h = decodeURIComponent(location.hash.replace(/^#/, ''));
  if (h === 'araclar') return { view: 'tools', tool: null };
  if (h.startsWith('arac-')) return { view: 'tools', tool: h.slice(5) };
  if (h === 'tex') return { view: 'tex', project: null };
  if (h.startsWith('tex-')) return { view: 'tex', project: h.slice(4) };
  if (h === 'asistan') return { view: 'ai', folder: null };
  if (h.startsWith('asistan-')) return { view: 'ai', folder: h.slice(8) };
  return { view: 'home' };
}

const AUTHOR = 'Ben';
const MAX_MB = 200;

function Loading({ text }: { text: string }) {
  return (
    <div className="loading">
      <BrandMark size={48} />
      <p>{text}</p>
    </div>
  );
}

export default function App() {
  const lang = useLang();
  const [docs, setDocs] = useState<DocMeta[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [storageOk, setStorageOk] = useState<boolean | null>(null);
  const [current, setCurrent] = useState<ViewerDoc | null>(null);
  const [route, setRoute] = useState<Route>(parseHash);
  const [preset, setPreset] = useState<PdfInput | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Belgeden bir araca geçildiyse "Belgeye dön" için belgenin o anki hâli
  const [returnDoc, setReturnDoc] = useState<{ doc: ViewerDoc; bytes: ArrayBuffer } | null>(null);

  const refresh = useCallback(async () => {
    try {
      const [d, f] = await Promise.all([listDocs(), listFolders()]);
      setDocs(d);
      setFolders(f);
    } catch {
      setDocs([]);
    }
  }, []);

  const onMove = async (docId: string, folderId: string | undefined) => {
    await moveDocToFolder(docId, folderId);
    void refresh();
  };
  const onCreateFolder = async (name: string) => {
    const folder: Folder = { id: `f-${Date.now().toString(36)}`, name, createdAt: Date.now() };
    await saveFolder(folder);
    await refresh();
    return folder;
  };
  const onRenameFolder = async (folder: Folder, name: string) => {
    await saveFolder({ ...folder, name });
    void refresh();
  };
  const onDeleteFolder = async (folder: Folder) => {
    await deleteFolder(folder.id);
    void refresh();
  };

  useEffect(() => {
    storageAvailable().then((ok) => {
      setStorageOk(ok);
      if (ok) void refresh();
    });
    const onHash = () => setRoute(parseHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, [refresh]);

  // Ana ekrana dönülünce "Belgeye dön" bağlantısı unutulur
  useEffect(() => {
    if (route.view === 'home') setReturnDoc(null);
  }, [route.view]);

  const navigate = useCallback((hash: string) => {
    if (hash) {
      if (location.hash !== `#${hash}`) location.hash = hash;
    } else if (location.hash) {
      history.pushState(null, '', location.pathname + location.search);
    }
    setRoute(parseHash());
    window.scrollTo(0, 0);
  }, []);

  interface OpenOpts {
    id?: string;
    persist?: boolean;
    handle?: FileSystemFileHandle;
    fileModified?: number;
    dirty?: boolean;
    startPage?: number;
    startMode?: string;
    /** Yeni belge kitaplıkta bu klasöre konur */
    folderId?: string;
    /** Belge türü; verilmezse içerikten anlaşılır */
    kind?: DocKind;
  }
  const openBytes = useCallback(
    async (name: string, bytes: ArrayBuffer, opts: OpenOpts = {}) => {
      const { id = newDocId(), persist = true, handle, fileModified, dirty, startPage, startMode, folderId } = opts;
      const kind: DocKind | null = isPdfBytes(bytes) ? 'pdf' : opts.kind === 'md' && isTextBytes(bytes) ? 'md' : null;
      if (!kind) {
        setError(__('Bu dosya PDF ya da Markdown gibi görünmüyor. Lütfen bir PDF (.pdf) ya da Markdown (.md) dosyası seçin.'));
        return;
      }
      setError(null);
      if (persist && storageOk) {
        const prev = await getMeta(id).catch(() => undefined);
        const now = Date.now();
        await saveDoc(
          {
            id,
            name,
            size: bytes.byteLength,
            createdAt: prev?.createdAt ?? now,
            updatedAt: now,
            linkedFile: handle?.name ?? prev?.linkedFile,
            fileModified: fileModified ?? prev?.fileModified,
            folderId: prev?.folderId ?? folderId,
            kind,
            cover: prev?.cover ?? nextCover(),
          },
          bytes.slice(0),
        );
        if (handle) await saveHandle(id, handle);
        void refresh();
      }
      setReturnDoc(null);
      setCurrent((c) => ({ id, name, bytes, handle, fileModified, dirty, startPage, startMode, kind, rev: (c?.id === id ? (c.rev ?? 0) : 0) + 1 }));
    },
    [storageOk, refresh],
  );

  /** Cihazdaki bir dosyayı (OneDrive klasörü vb.) bağlı olarak açar */
  const openHandle = useCallback(
    async (handle: FileSystemFileHandle, ask: boolean, folderId?: string) => {
      if (!(await ensurePermission(handle, 'read', ask))) {
        setError(__('“{0}” dosyasını okumak için izin verilmedi.', [handle.name]));
        return;
      }
      const file = await readHandle(handle);
      // Yazma iznini hemen iste (tıklamanın hemen ardındaysak tarayıcı sorar)
      if (ask) await ensurePermission(handle, 'readwrite', true);
      const existing = storageOk ? await findDocByHandle(handle) : null;
      await openBytes(baseName(file.name), file.bytes, {
        id: existing ?? newDocId(),
        handle,
        fileModified: file.modified,
        folderId,
        kind: isMarkdownName(handle.name) ? 'md' : 'pdf',
      });
    },
    [openBytes, storageOk],
  );

  const onPickFile = async (folderId?: string) => {
    setBusy(true);
    try {
      await openHandle(await pickPdfHandle(), true, folderId);
    } catch (err) {
      if (!(err instanceof PickCancelled)) {
        console.error(err);
        setError(__('Dosya açılamadı.'));
      }
    } finally {
      setBusy(false);
    }
  };

  const onDropHandle = async (handle: FileSystemFileHandle, folderId?: string) => {
    setBusy(true);
    try {
      await openHandle(handle, true, folderId);
    } catch (err) {
      console.error(err);
      setError(__('Dosya açılamadı.'));
    } finally {
      setBusy(false);
    }
  };

  // Kurulu uygulama "Birlikte aç → Tura Belge" ile açıldıysa
  useEffect(() => {
    if (storageOk === null) return;
    onLaunchFiles((h) => void openHandle(h, false));
  }, [storageOk, openHandle]);

  const onOpenFile = async (file: File, folderId?: string) => {
    if (file.size > MAX_MB * 1024 * 1024) {
      setError(__('Dosya çok büyük (en fazla {0} MB).', [MAX_MB]));
      return;
    }
    setBusy(true);
    try {
      await openBytes(baseName(file.name), await file.arrayBuffer(), { folderId, kind: isMarkdownName(file.name) ? 'md' : 'pdf' });
    } catch (err) {
      console.error(err);
      setError(__('Dosya okunamadı.'));
    } finally {
      setBusy(false);
    }
  };

  const onOpenStored = async (meta: DocMeta, startPage?: number) => {
    setBusy(true);
    try {
      const handle = await getHandle(meta.id);
      if (handle && (await ensurePermission(handle, 'read', true))) {
        try {
          // Asıl dosya esas alınır: başka cihazda değiştiyse güncel hâli açılır
          const file = await readHandle(handle);
          await ensurePermission(handle, 'readwrite', true);
          const changed = file.modified !== meta.fileModified;
          if (changed) {
            await openBytes(meta.name, file.bytes, { id: meta.id, handle, fileModified: file.modified, kind: meta.kind, startPage });
          } else {
            const bytes = (await loadDocBytes(meta.id)) ?? file.bytes;
            await openBytes(meta.name, bytes, { id: meta.id, handle, fileModified: file.modified, persist: false, kind: meta.kind, startPage });
          }
          return;
        } catch {
          setError(__('“{0}” asıl konumunda bulunamadı (taşınmış ya da silinmiş olabilir); bu tarayıcıdaki kopya açıldı.', [meta.linkedFile ?? meta.name]));
        }
      }
      const bytes = await loadDocBytes(meta.id);
      if (!bytes) throw new Error('missing');
      await openBytes(meta.name, bytes, { id: meta.id, persist: false, kind: meta.kind, startPage });
    } catch {
      setError(__('Belge bu tarayıcıda bulunamadı.'));
      void refresh();
    } finally {
      setBusy(false);
    }
  };

  /** Asistanın gösterdiği kaynağı açar (PDF'te o sayfada, notta o bölümde) */
  const openDocAt = async (t: { docId: string; n: number }) => {
    const meta = await getMeta(t.docId).catch(() => undefined);
    if (!meta) {
      setError(__('Belge bu tarayıcıda bulunamadı.'));
      return;
    }
    await onOpenStored(meta, t.n);
  };

  /** Asistan sohbetini Markdown notu olarak kitaplığa ekler (açmadan) */
  const saveNote = async (name: string, text: string, folderId?: string) => {
    if (!storageOk) throw new Error('storage');
    const bytes = new TextEncoder().encode(text).buffer as ArrayBuffer;
    const now = Date.now();
    await saveDoc({ id: newDocId(), name, size: bytes.byteLength, createdAt: now, updatedAt: now, folderId, kind: 'md', cover: nextCover() }, bytes);
    void refresh();
  };

  // Düzenleyicideki "Yeni sürümü aç": asıl dosyanın güncel hâlini yükler
  const onReloadFromFile = async (doc: ViewerDoc) => {
    if (!doc.handle) return;
    try {
      const file = await readHandle(doc.handle);
      await openBytes(doc.name, file.bytes, { id: doc.id, handle: doc.handle, fileModified: file.modified, kind: doc.kind });
    } catch {
      setError(__('Asıl dosya okunamadı.'));
    }
  };

  const onDelete = async (meta: DocMeta) => {
    await deleteDoc(meta.id);
    // Asistanın bu belge için tuttuğu yazı önbelleği ve sohbeti de silinir
    void import('./ai/sources').then((m) => m.forgetDocText(meta.id)).catch(() => undefined);
    void import('./ai/chats').then((m) => m.saveChat(`doc:${meta.id}`, [])).catch(() => undefined);
    void refresh();
  };

  const onPersist = useCallback(async (doc: ViewerDoc, bytes: ArrayBuffer, fileModified?: number) => {
    const prev = await getMeta(doc.id).catch(() => undefined);
    const now = Date.now();
    await saveDoc(
      {
        id: doc.id,
        name: doc.name,
        size: bytes.byteLength,
        createdAt: prev?.createdAt ?? now,
        updatedAt: now,
        linkedFile: doc.handle?.name ?? prev?.linkedFile,
        fileModified: fileModified ?? prev?.fileModified,
        folderId: prev?.folderId,
        kind: doc.kind ?? prev?.kind,
        cover: prev?.cover,
      },
      bytes,
    );
  }, []);

  const onRename = (name: string) => setCurrent((c) => (c ? { ...c, name } : c));

  // "Belgelerim" düğmesi her zaman ana ekrana döner
  const onClose = () => {
    setCurrent(null);
    navigate('');
    void refresh();
  };

  // Belgedeki "Sayfalar" ve "PDF araçları" sekmeleri: belgeyi ilgili araca taşır
  const onOrganize = (doc: ViewerDoc, bytes: ArrayBuffer, tool = 'sayfalar') => {
    setPreset({ name: doc.name, bytes, docId: storageOk ? doc.id : undefined });
    setCurrent(null);
    setReturnDoc({ doc: { ...doc, dirty: false }, bytes });
    navigate(`arac-${tool}`);
    void refresh();
  };

  // Sayfa ekle / sil: aynı belge yeni hâliyle yeniden açılır ve kaydedilir
  const onReplace = async (doc: ViewerDoc, bytes: ArrayBuffer) => {
    await openBytes(doc.name, bytes, {
      id: doc.id,
      handle: doc.handle,
      fileModified: doc.fileModified,
      dirty: true,
      startPage: doc.startPage,
      startMode: doc.startMode,
    });
  };

  /** Markdown metnini yeni not olarak kitaplığa ekleyip açar */
  const openMarkdown = useCallback(
    async (name: string, text: string, folderId?: string) => {
      await openBytes(name, new TextEncoder().encode(text).buffer as ArrayBuffer, { kind: 'md', folderId, dirty: false });
    },
    [openBytes],
  );
  const onNewNote = (folderId?: string) => void openMarkdown(__('Yeni not'), '', folderId);

  // Çok sayıda PDF bırakıldıysa hepsi kitaplığa eklenir (açılmaz)
  const onAddFiles = async (files: File[], folderId?: string) => {
    if (!storageOk) {
      if (files[0]) await onOpenFile(files[0], folderId);
      return;
    }
    setBusy(true);
    let added = 0;
    try {
      for (const f of files) {
        if (f.size > MAX_MB * 1024 * 1024) continue;
        const bytes = await f.arrayBuffer();
        const kind: DocKind | null = isPdfBytes(bytes) ? 'pdf' : isMarkdownName(f.name) && isTextBytes(bytes) ? 'md' : null;
        if (!kind) continue;
        const now = Date.now();
        await saveDoc({ id: newDocId(), name: baseName(f.name), size: bytes.byteLength, createdAt: now, updatedAt: now, folderId, kind, cover: nextCover() }, bytes);
        added++;
      }
      setError(added < files.length ? __('{0} dosya PDF ya da Markdown olmadığı ya da çok büyük olduğu için eklenmedi.', [files.length - added]) : null);
    } finally {
      setBusy(false);
      void refresh();
    }
  };

  const host = useMemo<ToolHostApi>(
    () => ({
      storageOk: !!storageOk,
      docs,
      loadStored: async (meta) => {
        const bytes = await loadDocBytes(meta.id);
        if (!bytes) throw new Error(__('Belge bulunamadı'));
        return { name: meta.name, bytes, docId: meta.id };
      },
      openInEditor: async (name, bytes, replaceId) => {
        const handle = replaceId ? await getHandle(replaceId) : undefined;
      const meta = replaceId ? await getMeta(replaceId) : undefined;
      await openBytes(name, bytes, { id: replaceId ?? newDocId(), handle, fileModified: meta?.fileModified, dirty: !!replaceId });
      },
      saveToDocs: async (name, bytes) => {
        const now = Date.now();
        await saveDoc({ id: newDocId(), name, size: bytes.byteLength, createdAt: now, updatedAt: now, cover: nextCover() }, bytes);
        void refresh();
      },
      goTool: (id) => navigate(id ? `arac-${id}` : 'araclar'),
      preset,
      clearPreset: () => setPreset(null),
      openMarkdown: (name, text) => openMarkdown(name, text),
      newNote: () => onNewNote(),
      backToDoc: returnDoc
        ? () => {
            const { doc, bytes } = returnDoc;
            void openBytes(doc.name, bytes, {
              id: doc.id,
              handle: doc.handle,
              fileModified: doc.fileModified,
              persist: false,
              startPage: doc.startPage,
              startMode: doc.startMode,
            });
          }
        : undefined,
    }),
    [storageOk, docs, openBytes, refresh, navigate, preset, returnDoc, openMarkdown], // eslint-disable-line react-hooks/exhaustive-deps
  );

  let body;
  if (current?.kind === 'md') {
    body = (
      <Suspense fallback={<Loading text={__('Not açılıyor…')} />}>
        <MdEditor
          key={`${current.id}:${current.rev ?? 0}`}
          doc={current}
          storageOk={!!storageOk}
          onPersist={onPersist}
          onRename={onRename}
          onClose={onClose}
          onOpenPdf={async (name, bytes) => {
            await openBytes(name, bytes, { kind: 'pdf' });
          }}
          onReloadFromFile={onReloadFromFile}
          onOpenDocAt={(t) => void openDocAt(t)}
          onSaveNote={saveNote}
        />
      </Suspense>
    );
  } else if (current) {
    body = (
      <Suspense fallback={<Loading text={__('Düzenleyici hazırlanıyor…')} />}>
        <Editor
          key={`${current.id}:${current.rev ?? 0}`}
          doc={current}
          storageOk={!!storageOk}
          author={AUTHOR}
          onPersist={onPersist}
          onRename={onRename}
          onClose={onClose}
          onOrganize={onOrganize}
          onReplace={onReplace}
          onOpenMarkdown={(name, text) => openMarkdown(name, text)}
          onReloadFromFile={onReloadFromFile}
          onOpenDocAt={(t) => void openDocAt(t)}
          onSaveNote={saveNote}
        />
      </Suspense>
    );
  } else if (route.view === 'tools') {
    body = (
      <Suspense fallback={<Loading text={__('Araçlar hazırlanıyor…')} />}>
        <ToolsView toolId={route.tool} onNavigate={navigate} />
      </Suspense>
    );
  } else if (route.view === 'ai') {
    body = (
      <Suspense fallback={<Loading text={__('Asistan hazırlanıyor…')} />}>
        <AssistantPage
          key={route.folder ?? 'all'}
          folderId={route.folder}
          folders={folders}
          docs={docs}
          storageOk={!!storageOk}
          onNavigate={navigate}
          onJump={(t) => void openDocAt(t)}
          onSaveNote={saveNote}
        />
      </Suspense>
    );
  } else if (route.view === 'tex') {
    body = (
      <Suspense fallback={<Loading text={__('LaTeX düzenleyici hazırlanıyor…')} />}>
        {route.project ? <TexEditor key={route.project} projectId={route.project} onNavigate={navigate} /> : <TexHome onNavigate={navigate} />}
      </Suspense>
    );
  } else {
    body = (
      <Home
        docs={docs}
        storageOk={storageOk}
        busy={busy}
        error={error}
        onOpenFile={onOpenFile}
        onAddFiles={onAddFiles}
        onNewNote={onNewNote}
        onPickFile={canLinkFiles() ? onPickFile : undefined}
        onDropHandle={canLinkFiles() ? onDropHandle : undefined}
        onOpenStored={onOpenStored}
        onDelete={onDelete}
        onNavigate={navigate}
        folders={folders}
        onMove={onMove}
        onCreateFolder={onCreateFolder}
        onRenameFolder={onRenameFolder}
        onDeleteFolder={onDeleteFolder}
        onAssistant={(folderId) => navigate(folderId ? `asistan-${folderId}` : 'asistan')}
      />
    );
  }

  // Dil değişince arayüz baştan çizilir (açık belge yokken; dil seçimi üst çubukta)
  return (
    <ToolHost.Provider value={host}>
      <Fragment key={lang}>{body}</Fragment>
    </ToolHost.Provider>
  );
}
