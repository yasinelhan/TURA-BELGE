// Tura Belge — Böl ve ayıkla
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useMemo, useState } from 'react';
import { useEditorPreset, type PdfInput } from './host';
import { extractGroups } from './lib/pdfOps';
import { formatRanges, parseRanges } from './lib/pageRanges';
import { ErrorNote, Field, FileChip, FilePicker, ResultPanel, Seg, Thumb, ToolIcon, ToolShell, errText, useRenderDoc, type Output } from './ui';
import { __ } from '../i18n';

type Mode = 'extract' | 'ranges' | 'every' | 'each';

export function SplitTool() {
  const [input, setInput] = useState<PdfInput | null>(null);
  const { doc, error: openError } = useRenderDoc(input?.bytes);
  const total = doc?.pageCount ?? 0;
  const [mode, setMode] = useState<Mode>('extract');
  const [rangeText, setRangeText] = useState('');
  const [every, setEvery] = useState(2);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Output[] | null>(null);
  useEditorPreset(setInput);

  useEffect(() => {
    setRangeText('');
    setResult(null);
  }, [doc]);

  const plan = useMemo((): { groups: number[][]; error?: string } => {
    if (!total) return { groups: [] };
    if (mode === 'each') return { groups: Array.from({ length: total }, (_, i) => [i]) };
    if (mode === 'every') {
      const n = Math.max(1, Math.floor(every) || 1);
      const groups: number[][] = [];
      for (let i = 0; i < total; i += n) groups.push(Array.from({ length: Math.min(n, total - i) }, (_, k) => i + k));
      return { groups };
    }
    if (!rangeText.trim()) return { groups: [] };
    const r = parseRanges(rangeText, total);
    if (r.error) return r;
    return mode === 'extract' ? { groups: [r.groups.flat()] } : r;
  }, [mode, rangeText, every, total]);

  const selected = useMemo(() => new Set(mode === 'extract' || mode === 'ranges' ? plan.groups.flat() : []), [plan, mode]);
  const togglePage = (i: number) => {
    const set = new Set(selected);
    if (set.has(i)) set.delete(i);
    else set.add(i);
    setRangeText(formatRanges([...set]));
    setResult(null);
  };

  const label = (g: number[]) => (g.length === 1 ? `s. ${g[0] + 1}` : `s. ${g[0] + 1}-${g[g.length - 1] + 1}`);
  const run = async () => {
    if (!input || !plan.groups.length) return;
    setBusy(true);
    setError(null);
    try {
      const outs = await extractGroups(input.bytes, plan.groups, input.name);
      setResult(
        outs.map((bytes, i) => ({
          name:
            mode === 'extract'
              ? __('{0} (seçilen sayfalar)', [input.name])
              : `${input.name} (${plan.groups[i].length > 1 && mode === 'ranges' && !isContiguous(plan.groups[i]) ? __('parça {0}', [i + 1]) : label(plan.groups[i])})`,
          ext: 'pdf' as const,
          blob: new Blob([bytes], { type: 'application/pdf' }),
          pages: plan.groups[i].length,
        })),
      );
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };

  if (!input) {
    return (
      <ToolShell id="bol">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
      </ToolShell>
    );
  }

  const files = plan.groups.length;
  return (
    <ToolShell id="bol">
      <FileChip name={input.name} detail={total ? __('{0} sayfa', [total]) : __('açılıyor…')} onClear={() => (setInput(null), setResult(null))} />
      <ErrorNote error={openError} />
      <div className="tool__options">
        <Seg<Mode>
          label={__('Bölme şekli')}
          value={mode}
          onChange={(m) => (setMode(m), setResult(null))}
          options={[
            { v: 'extract', t: 'Sayfa ayıkla' },
            { v: 'ranges', t: 'Aralıklara böl' },
            { v: 'every', t: 'Her N sayfada' },
            { v: 'each', t: 'Her sayfa ayrı' },
          ]}
        />
        {(mode === 'extract' || mode === 'ranges') && (
          <Field
            label={mode === 'extract' ? __('Çıkarılacak sayfalar') : __('Aralıklar (her biri ayrı dosya)')}
            hint={__('Örnek: 1-3, 5, 8-son · Aşağıdaki sayfalara tıklayarak da seçebilirsin.')}
          >
            <input
              className="input"
              value={rangeText}
              placeholder={mode === 'extract' ? '1-3, 5' : __('1-3, 4-6, 7-son')}
              onChange={(e) => (setRangeText(e.target.value), setResult(null))}
            />
          </Field>
        )}
        {mode === 'every' && (
          <Field label={__('Kaç sayfada bir bölünsün?')}>
            <input
              className="input input--num"
              type="number"
              min={1}
              max={Math.max(1, total)}
              value={every}
              onChange={(e) => (setEvery(Number(e.target.value)), setResult(null))}
            />
          </Field>
        )}
        <p className="plan">
          {plan.error ? (
            <span className="plan__err">{plan.error}</span>
          ) : files ? (
            mode === 'extract' ? (
              __('{0} sayfa tek bir PDF olarak çıkarılacak.', [plan.groups[0].length])
            ) : (
              __('{0} dosya oluşacak: {1}{2}', [files, plan.groups.slice(0, 6).map(label).join(', '), files > 6 ? '…' : ''])
            )
          ) : (
            __('Sayfa seçin.')
          )}
        </p>
      </div>

      {(mode === 'extract' || mode === 'ranges') && (
        <ol className="pagegrid pagegrid--pick">
          {Array.from({ length: total }, (_, i) => (
            <li key={i} className={selected.has(i) ? 'pagecard pagecard--sel' : 'pagecard'}>
              <button className="pagecard__sel" aria-pressed={selected.has(i)} aria-label={__('Sayfa {0}', [i + 1])} onClick={() => togglePage(i)}>
                <Thumb doc={doc} index={i} width={130} />
                <span className="pagecard__check" aria-hidden="true">
                  <ToolIcon path="M5 12.5l4.5 4.5L19 7.5" size={14} />
                </span>
              </button>
              <div className="pagecard__foot">
                <span className="pagecard__num">{i + 1}</span>
              </div>
            </li>
          ))}
        </ol>
      )}

      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy || !files || !!plan.error} onClick={run}>
          {busy ? __('Hazırlanıyor…') : mode === 'extract' ? __('Sayfaları çıkar') : __('{0} dosyaya böl', [files || ''])}
        </button>
      </div>
      {result && <ResultPanel outputs={result} zipName={__('{0} (bölünmüş)', [input.name])} />}
      <ErrorNote error={error} />
    </ToolShell>
  );
}

function isContiguous(g: number[]) {
  return g.every((v, i) => i === 0 || v === g[i - 1] + 1 || v === g[i - 1] - 1);
}
