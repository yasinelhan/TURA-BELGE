// Tura Belge — Sayfaları düzenle: sırala, döndür, sil, çoğalt, boş sayfa ekle
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useCallback, useEffect, useState } from 'react';
import { useToolHost, type PdfInput } from './host';
import { organizePages, type PageItem } from './lib/pdfOps';
import { ErrorNote, FileChip, FilePicker, ResultPanel, Thumb, ToolIcon, ToolShell, errText, useRenderDoc, type Output } from './ui';
import { __ } from '../i18n';

type Card = PageItem & { key: string };
let keySeq = 0;
const nk = () => `k${++keySeq}`;

const ICONS = {
  left: 'M3 4v6h6M3.5 10A9 9 0 1 1 5 17',
  right: 'M21 4v6h-6M20.5 10A9 9 0 1 0 19 17',
  del: 'M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3',
  dup: 'M8 8h11v11H8zM5 16V5h11',
  moveL: 'M14 6l-6 6 6 6',
  moveR: 'M10 6l6 6-6 6',
  blank: 'M6 3h9l4 4v14H6zM12 11v6M9 14h6',
  undo: 'M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3',
};

export function OrganizeTool() {
  const host = useToolHost();
  const [input, setInput] = useState<PdfInput | null>(null);
  const [fromEditor, setFromEditor] = useState<string | undefined>();
  const { doc, error: openError } = useRenderDoc(input?.bytes);
  const [cards, setCards] = useState<Card[]>([]);
  const [history, setHistory] = useState<Card[][]>([]);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [anchor, setAnchor] = useState<string | null>(null);
  const [drag, setDrag] = useState<string | null>(null);
  const [over, setOver] = useState<{ key: string; after: boolean } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Output[] | null>(null);

  // Düzenleyiciden "Sayfalar" ile gelindiyse belge hazır gelir
  useEffect(() => {
    if (host.preset) {
      setInput(host.preset);
      setFromEditor(host.preset.docId);
      host.clearPreset();
    }
  }, [host]);

  useEffect(() => {
    if (!doc) return;
    setCards(Array.from({ length: doc.pageCount }, (_, i) => ({ kind: 'page', src: i, rotate: 0, key: nk() })));
    setHistory([]);
    setSel(new Set());
    setResult(null);
  }, [doc]);

  const commit = useCallback((next: Card[]) => {
    setCards((prev) => {
      setHistory((h) => [...h.slice(-49), prev]);
      return next;
    });
    setResult(null);
  }, []);

  const rotate = (keys: Set<string>, delta: number) =>
    commit(cards.map((c) => (keys.has(c.key) ? { ...c, rotate: (c.rotate + delta + 360) % 360 } : c)));
  const remove = (keys: Set<string>) => {
    if (keys.size >= cards.length) return setError(__('Belgede en az bir sayfa kalmalı.'));
    setError(null);
    commit(cards.filter((c) => !keys.has(c.key)));
    setSel(new Set());
  };
  const duplicate = (keys: Set<string>) => {
    const next: Card[] = [];
    for (const c of cards) {
      next.push(c);
      if (keys.has(c.key)) next.push({ ...c, key: nk() });
    }
    commit(next);
  };
  const addBlank = () => {
    const lastSel = [...cards].reverse().find((c) => sel.has(c.key));
    const at = lastSel ? cards.indexOf(lastSel) + 1 : cards.length;
    const like = cards[Math.max(0, at - 1)];
    const blank: Card = { kind: 'blank', rotate: 0, like: like?.kind === 'page' ? like.src : 0, key: nk() };
    commit([...cards.slice(0, at), blank, ...cards.slice(at)]);
  };
  const shift = (dir: -1 | 1) => {
    if (!sel.size) return;
    const next = [...cards];
    const order = dir < 0 ? next.map((_, i) => i) : next.map((_, i) => next.length - 1 - i);
    for (const i of order) {
      const j = i + dir;
      if (sel.has(next[i].key) && j >= 0 && j < next.length && !sel.has(next[j].key))
        [next[i], next[j]] = [next[j], next[i]];
    }
    commit(next);
  };
  const moveTo = (dragKey: string, targetKey: string, after: boolean) => {
    const moving = sel.has(dragKey) ? cards.filter((c) => sel.has(c.key)) : cards.filter((c) => c.key === dragKey);
    const ids = new Set(moving.map((c) => c.key));
    if (ids.has(targetKey)) return;
    const rest = cards.filter((c) => !ids.has(c.key));
    let at = rest.findIndex((c) => c.key === targetKey);
    if (after) at++;
    commit([...rest.slice(0, at), ...moving, ...rest.slice(at)]);
  };
  const undo = () => {
    const prev = history[history.length - 1];
    if (!prev) return;
    setHistory((h) => h.slice(0, -1));
    setCards(prev);
    setResult(null);
  };
  const toggle = (key: string, e: { shiftKey: boolean; metaKey: boolean; ctrlKey: boolean }) => {
    setSel((prev) => {
      const next = new Set(prev);
      if (e.shiftKey && anchor) {
        const a = cards.findIndex((c) => c.key === anchor);
        const b = cards.findIndex((c) => c.key === key);
        const [lo, hi] = a < b ? [a, b] : [b, a];
        for (let i = lo; i <= hi; i++) next.add(cards[i].key);
      } else if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
    setAnchor(key);
  };

  const save = async () => {
    if (!input) return;
    setBusy(true);
    setError(null);
    try {
      const bytes = await organizePages(
        input.bytes,
        cards.map(({ key: _k, ...rest }) => rest as PageItem),
        input.name,
      );
      setResult([{ name: input.name, ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages: cards.length }]);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setInput(null);
    setCards([]);
    setResult(null);
    setFromEditor(undefined);
  };

  if (!input) {
    return (
      <ToolShell id="sayfalar">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
      </ToolShell>
    );
  }

  const changed = history.length > 0;
  const selKeys = sel.size ? sel : new Set(cards.map((c) => c.key));
  return (
    <ToolShell id="sayfalar">
      <FileChip name={input.name} detail={__('{0} sayfa', [cards.length])} onClear={reset} />
      <ErrorNote error={openError ?? error} />

      <div className="pagebar" role="toolbar" aria-label={__('Sayfa işlemleri')}>
        <button className="btn btn--ghost btn--sm" onClick={() => setSel(sel.size === cards.length ? new Set() : new Set(cards.map((c) => c.key)))}>
          {sel.size === cards.length ? __('Seçimi kaldır') : __('Tümünü seç')}
        </button>
        <span className="pagebar__info">{sel.size ? __('{0} sayfa seçili', [sel.size]) : __('Seçim yok: işlemler tüm sayfalara uygulanır')}</span>
        <span className="pagebar__group">
          <button className="icon-btn icon-btn--tool" title={__('Sola döndür')} aria-label={__('Sola döndür')} onClick={() => rotate(selKeys, -90)}>
            <ToolIcon path={ICONS.left} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Sağa döndür')} aria-label={__('Sağa döndür')} onClick={() => rotate(selKeys, 90)}>
            <ToolIcon path={ICONS.right} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Seçileni öne taşı')} aria-label={__('Seçileni öne taşı')} disabled={!sel.size} onClick={() => shift(-1)}>
            <ToolIcon path={ICONS.moveL} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Seçileni geriye taşı')} aria-label={__('Seçileni geriye taşı')} disabled={!sel.size} onClick={() => shift(1)}>
            <ToolIcon path={ICONS.moveR} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Çoğalt')} aria-label={__('Seçili sayfaları çoğalt')} disabled={!sel.size} onClick={() => duplicate(sel)}>
            <ToolIcon path={ICONS.dup} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Boş sayfa ekle')} aria-label={__('Boş sayfa ekle')} onClick={addBlank}>
            <ToolIcon path={ICONS.blank} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool icon-btn--danger" title={__('Sil')} aria-label={__('Seçili sayfaları sil')} disabled={!sel.size} onClick={() => remove(sel)}>
            <ToolIcon path={ICONS.del} size={20} />
          </button>
          <button className="icon-btn icon-btn--tool" title={__('Geri al')} aria-label={__('Geri al')} disabled={!history.length} onClick={undo}>
            <ToolIcon path={ICONS.undo} size={20} />
          </button>
        </span>
      </div>

      <p className="tool__hint">{__('Sürükleyerek ya da seçip ‹ › oklarıyla sırala. Birden çok sayfa seçmek için tıkla; Shift ile aralık seç.')}</p>

      <ol className="pagegrid">
        {cards.map((c, i) => {
          const isSel = sel.has(c.key);
          const cls = [
            'pagecard',
            isSel && 'pagecard--sel',
            drag === c.key && 'pagecard--drag',
            over?.key === c.key && (over.after ? 'pagecard--over-after' : 'pagecard--over-before'),
          ]
            .filter(Boolean)
            .join(' ');
          return (
            <li
              key={c.key}
              className={cls}
              draggable
              onDragStart={(e) => {
                setDrag(c.key);
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', c.key);
              }}
              onDragEnd={() => {
                setDrag(null);
                setOver(null);
              }}
              onDragOver={(e) => {
                if (!drag) return;
                e.preventDefault();
                const r = e.currentTarget.getBoundingClientRect();
                setOver({ key: c.key, after: e.clientX > r.left + r.width / 2 });
              }}
              onDrop={(e) => {
                e.preventDefault();
                if (drag && over) moveTo(drag, over.key, over.after);
                setDrag(null);
                setOver(null);
              }}
            >
              <button
                className="pagecard__sel"
                aria-pressed={isSel}
                aria-label={__('Sayfa {0}{1}', [i + 1, isSel ? __(', seçili') : ''])}
                onClick={(e) => toggle(c.key, e)}
              >
                {c.kind === 'page' ? (
                  <Thumb doc={doc} index={c.src} width={170} rotate={c.rotate} />
                ) : (
                  <div className="thumb thumb--blank" style={{ aspectRatio: String(doc ? doc.aspect(c.like ?? 0) : 0.707) }}>
                    <span>{__('Boş sayfa')}</span>
                  </div>
                )}
                <span className="pagecard__check" aria-hidden="true">
                  <ToolIcon path="M5 12.5l4.5 4.5L19 7.5" size={14} />
                </span>
              </button>
              <div className="pagecard__foot">
                <span className="pagecard__num">
                  {i + 1}
                  {c.kind === 'page' && c.src !== i && <small> {__('· asıl')} {c.src + 1}</small>}
                </span>
                <span className="pagecard__acts">
                  <button className="icon-btn icon-btn--mini" aria-label={__('Sayfa {0}: sağa döndür', [i + 1])} title={__('Sağa döndür')} onClick={() => rotate(new Set([c.key]), 90)}>
                    <ToolIcon path={ICONS.right} size={16} />
                  </button>
                  <button className="icon-btn icon-btn--mini icon-btn--danger" aria-label={__('Sayfa {0}: sil', [i + 1])} title={__('Sil')} onClick={() => remove(new Set([c.key]))}>
                    <ToolIcon path={ICONS.del} size={16} />
                  </button>
                </span>
              </div>
            </li>
          );
        })}
      </ol>

      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy || !doc} onClick={save}>
          {busy ? __('Hazırlanıyor…') : changed ? __('Değişiklikleri uygula') : __('PDF’i oluştur')}
        </button>
        {changed && (
          <button className="btn btn--ghost" onClick={() => doc && commit(Array.from({ length: doc.pageCount }, (_, i) => ({ kind: 'page' as const, src: i, rotate: 0, key: nk() })))}>
            {__('Sıfırla')}
          </button>
        )}
      </div>
      {result && (
        <ResultPanel
          outputs={result}
          replaceId={fromEditor}
          note={fromEditor ? __('Düzenleyicide açtığında belgenin yerine bu sürüm kaydedilir.') : undefined}
        />
      )}
    </ToolShell>
  );
}
