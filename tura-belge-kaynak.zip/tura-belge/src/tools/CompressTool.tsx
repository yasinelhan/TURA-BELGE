// Tura Belge — PDF sıkıştırma
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useState } from 'react';
import { useEditorPreset, type PdfInput } from './host';
import { compressPdf, pageCountOf, type CompressLevel } from './lib/pdfOps';
import { ErrorNote, FileChip, FilePicker, ResultPanel, Seg, ToolShell, errText, fmtSize, type Output } from './ui';
import { __, N_ } from '../i18n';

const LEVEL_TEXT: Record<CompressLevel, string> = {
  light: N_('Görseller neredeyse hiç bozulmaz; kazanç sınırlı.'),
  recommended: N_('Ekranda ve baskıda iyi görünür; çoğu belge için en iyisi.'),
  strong: N_('En küçük dosya; fotoğraflar belirgin şekilde yumuşar.'),
};

export function CompressTool() {
  const [input, setInput] = useState<PdfInput | null>(null);
  const [level, setLevel] = useState<CompressLevel>('recommended');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ out: Output[]; note: string } | null>(null);
  const [nothing, setNothing] = useState<string | null>(null);
  const [fromEditor] = useEditorPreset(setInput);

  const run = async () => {
    if (!input) return;
    setBusy(true);
    setError(null);
    setNothing(null);
    setResult(null);
    try {
      const r = await compressPdf(input.bytes, level, (d, t) => setProgress(t ? __('Görseller işleniyor: {0} / {1}', [d, t]) : null), input.name);
      const before = input.bytes.byteLength;
      const after = r.bytes.byteLength;
      if (after >= before * 0.97) {
        setNothing(
          r.images === 0
            ? __('Bu belgede küçültülebilecek fotoğraf ya da taranmış görsel bulunamadı; dosya zaten verimli.')
            : __('Belge zaten iyi sıkıştırılmış; anlamlı bir küçülme sağlanamadı. Daha güçlü bir seviye deneyebilirsin.'),
        );
      } else {
        const pct = Math.round((1 - after / before) * 100);
        setResult({
          out: [{ name: __('{0} (sıkıştırılmış)', [input.name]), ext: 'pdf', blob: new Blob([r.bytes], { type: 'application/pdf' }), pages: await pageCountOf(r.bytes) }],
          note: __('{0} → {1} · %{2} küçüldü ({3} görsel yeniden sıkıştırıldı)', [fmtSize(before), fmtSize(after), pct, r.recompressed]),
        });
      }
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
      setProgress(null);
    }
  };

  if (!input) {
    return (
      <ToolShell id="sikistir">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
      </ToolShell>
    );
  }
  return (
    <ToolShell id="sikistir">
      <FileChip name={input.name} detail={fmtSize(input.bytes.byteLength)} onClear={() => (setInput(null), setResult(null), setNothing(null))} />
      <div className="tool__options">
        <Seg<CompressLevel>
          label={__('Sıkıştırma seviyesi')}
          value={level}
          onChange={(v) => (setLevel(v), setResult(null), setNothing(null))}
          options={[
            { v: 'light', t: 'Hafif' },
            { v: 'recommended', t: 'Önerilen' },
            { v: 'strong', t: 'Güçlü' },
          ]}
        />
        <p className="plan">{__(LEVEL_TEXT[level])} {__('Metinler seçilebilir kalır.')}</p>
      </div>
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy} onClick={run}>
          {busy ? progress ?? __('Sıkıştırılıyor…') : __('Sıkıştır')}
        </button>
      </div>
      {nothing && <p className="info">{nothing}</p>}
      <ErrorNote error={error} />
      {result && <ResultPanel outputs={result.out} note={result.note} replaceId={fromEditor} />}
    </ToolShell>
  );
}
