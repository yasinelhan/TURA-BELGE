// Tura Belge — araç kartları (ana ekranda ve araçlar sayfasında)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { TOOLS, type ToolInfo } from './registry';
import { ToolIcon } from './ToolIcon';
import { __ } from '../i18n';

export function ToolGrid({ tools = TOOLS, onPick }: { tools?: ToolInfo[]; onPick: (id: string) => void }) {
  return (
    <ul className="toolgrid">
      {tools.map((t) => (
        <li key={t.id}>
          <a
            className="toolcard"
            href={`#${t.route ?? `arac-${t.id}`}`}
            onClick={(e) => {
              e.preventDefault();
              onPick(t.id);
            }}
          >
            <span className="toolcard__icon">
              <ToolIcon path={t.icon} />
            </span>
            <span className="toolcard__text">
              <b>{__(t.title)}</b>
              <span>{__(t.desc)}</span>
            </span>
          </a>
        </li>
      ))}
    </ul>
  );
}
