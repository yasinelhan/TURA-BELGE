// Tura Belge — Vektöre çevir: pikselli (taranmış, fotoğraf) sayfaları her yakınlaştırmada keskin vektöre dönüştür
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState } from 'react';
import { useToolHost, type PdfInput } from './host';
import { closeOcr, OCR_LANGS, type OcrLang } from './lib/ocr';
import { openRenderDoc } from './lib/render';
import { vectorizeImages, vectorizePdf, type VectorProgress, type VectorRunResult } from './lib/vectorPdf';
import { vectorPageToSvg } from './lib/vectorize';
import { OcrProgressBar, TextPanel } from './OcrTool';
import { ErrorNote, Field, FileChip, FilePicker, ResultPanel, Seg, ToolShell, errText, fmtSize, type Output } from './ui';
import { downloadFile } from '../lib/download';
import { __ } from '../i18n';

type Input = { kind: 'pdf'; pdf: PdfInput } | { kind: 'img'; files: File[] };

export function VectorTool() {
  const host = useToolHost();
  const [input, setInput] = useState<Input | null>(null);
  const [fromEditor, setFromEditor] = useState<string | undefined>();
  const [colors, setColors] = useState<'auto' | 'mono'>('auto');
  const [photos, setPhotos] = useState<'keep' | 'drop'>('keep');
  const [ocr, setOcr] = useState(true);
  const [lang, setLang] = useState<OcrLang>('tur+eng');
  const [keepText, setKeepText] = useState(true);
  const [prog, setProg] = useState<VectorProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ out: Output[]; r: VectorRunResult; before: ArrayBuffer | null } | null>(null);
  const abort = useRef<AbortController | null>(null);

  useEffect(() => {
    if (host.preset) {
      setInput({ kind: 'pdf', pdf: host.preset });
      setFromEditor(host.preset.docId);
      host.clearPreset();
    }
  }, [host]);
  useEffect(
    () => () => {
      abort.current?.abort();
      void closeOcr();
    },
    [],
  );

  const name = input ? (input.kind === 'pdf' ? input.pdf.name : input.files[0].name.replace(/\.[^.]+$/, '')) : '';
  const changed = () => setResult(null);
  const reset = () => {
    setInput(null);
    setResult(null);
    setFromEditor(undefined);
    setError(null);
  };

  const run = async () => {
    if (!input) return;
    setError(null);
    setResult(null);
    const ac = new AbortController();
    abort.current = ac;
    setProg({ page: 0, total: 1, phase: 'okunuyor', progress: 0 });
    try {
      const opts = { colors, photos, ocr: ocr ? lang : null, keepTextPages: keepText };
      const r =
        input.kind === 'pdf'
          ? await vectorizePdf(input.pdf.bytes, opts, setProg, ac.signal, input.pdf.name)
          : await vectorizeImages(input.files, { ...opts, pageSize: 'a4' }, setProg, ac.signal);
      if (!r.converted) {
        setResult({ out: [], r, before: null });
        return;
      }
      setResult({
        out: [
          {
            name: fromEditor ? name : __('{0} (vektör)', [name]),
            ext: 'pdf',
            blob: new Blob([r.bytes], { type: 'application/pdf' }),
            pages: r.converted + r.kept.length,
          },
        ],
        r,
        before: input.kind === 'pdf' ? input.pdf.bytes : null,
      });
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setError(errText(e));
    } finally {
      setProg(null);
      abort.current = null;
    }
  };

  if (!input) {
    return (
      <ToolShell id="vektor">
        <FilePicker
          kind="both"
          multiple
          onPdfs={(f) => setInput({ kind: 'pdf', pdf: f[0] })}
          onImages={(files) => setInput({ kind: 'img', files })}
        />
        <p className="tool__hint">
          {__('Taranmış sayfalar ve fotoğraflar piksellerden oluşur; yakınlaştırınca yazılar bulanıklaşır. Burada yazılar, çizimler ve el yazısı düzgün eğrilere çevrilir: istediğin kadar büyüt, keskin kalır. Kalem renkleri korunur.')}
        </p>
      </ToolShell>
    );
  }

  const busy = prog !== null;
  const pct = prog ? Math.round(((prog.page + (prog.phase === 'taniyor' ? 0.5 + prog.progress / 2 : prog.phase === 'vektor' ? 0.3 : 0)) / prog.total) * 100) : 0;
  const text = result ? result.r.texts.map((t, i) => (result.r.texts.length > 1 ? __('— Sayfa {0} —\n{1}', [i + 1, t]) : t)).join('\n\n').trim() : '';

  return (
    <ToolShell id="vektor">
      <FileChip
        name={name}
        detail={input.kind === 'pdf' ? fmtSize(input.pdf.bytes.byteLength) : __('{0} görsel', [input.files.length])}
        onClear={reset}
      />
      <div className="tool__options">
        <Field label={__('Renkler')} group>
          <Seg
            label={__('Renkler')}
            value={colors}
            onChange={(v) => (setColors(v), changed())}
            options={[
              { v: 'auto', t: 'Kalem renklerini koru' },
              { v: 'mono', t: 'Hepsi siyah' },
            ]}
          />
        </Field>
        <Field label={__('Fotoğraflar ve renkli alanlar')} group hint={__('Fotoğraflar vektöre çevrilemez; arka planda görüntü olarak kalır.')}>
          <Seg
            label={__('Fotoğraflar ve renkli alanlar')}
            value={photos}
            onChange={(v) => (setPhotos(v), changed())}
            options={[
              { v: 'keep', t: 'Koru' },
              { v: 'drop', t: 'Kaldır (yalnızca yazı ve çizim)' },
            ]}
          />
        </Field>
        <label className="check">
          <input type="checkbox" checked={ocr} onChange={(e) => (setOcr(e.target.checked), changed())} />
          {__('Yazıları da tanı (arama ve kopyalama için)')}
        </label>
        {ocr && (
          <Field label={__('Belgenin dili')} group>
            <Seg label={__('Belgenin dili')} value={lang} onChange={(v) => (setLang(v), changed())} options={OCR_LANGS} />
          </Field>
        )}
        {input.kind === 'pdf' && (
          <label className="check">
            <input type="checkbox" checked={keepText} onChange={(e) => (setKeepText(e.target.checked), changed())} />
            {__('Zaten vektör olan (seçilebilir metinli) sayfalara dokunma')}
          </label>
        )}
      </div>
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy} onClick={run}>
          {busy ? __('Vektöre çevriliyor…') : __('Vektöre çevir')}
        </button>
        {busy && (
          <button className="btn btn--ghost" onClick={() => abort.current?.abort()}>
            {__('Durdur')}
          </button>
        )}
      </div>
      {prog && <VectorProgressBar prog={prog} pct={pct} />}
      <ErrorNote error={error} />
      {result && result.out.length === 0 && (
        <p className="info">{__('Bu belgenin bütün sayfaları zaten vektör (seçilebilir metinli); çevirmeye gerek yok.')}</p>
      )}
      {result && result.out.length > 0 && (
        <>
          <ResultPanel
            outputs={result.out}
            replaceId={fromEditor}
            onReset={reset}
            note={
              <>
                {result.r.converted} {__('sayfa vektöre çevrildi')}
                {result.r.kept.length ? __(' · {0} sayfa zaten vektördü, olduğu gibi kaldı', [result.r.kept.length]) : ''}{__('. Yakınlaştırınca yazılar keskin kalır.')}
              </>
            }
          />
          <BeforeAfter before={result.before} after={result.r.bytes} page={firstConverted(result.r)} />
          {result.r.first && (
            <p>
              <button
                className="link-btn"
                onClick={() =>
                  downloadFile(`${name}.svg`, new Blob([vectorPageToSvg(result.r.first!)], { type: 'image/svg+xml' }))
                }
              >
                {__('SVG olarak da indir (çizim programları için)')}
              </button>
            </p>
          )}
          {text && <TextPanel text={text} name={name} />}
        </>
      )}
    </ToolShell>
  );
}

const firstConverted = (r: VectorRunResult) => {
  for (let i = 0; i < r.converted + r.kept.length; i++) if (!r.kept.includes(i)) return i;
  return 0;
};

export function VectorProgressBar({ prog, pct }: { prog: VectorProgress; pct: number }) {
  if (prog.phase === 'yukleniyor' || prog.phase === 'taniyor') {
    return <OcrProgressBar prog={{ ...prog, phase: prog.phase }} pct={pct} />;
  }
  const label =
    prog.phase === 'atlandi'
      ? __('Sayfa {0} / {1}: zaten vektör, olduğu gibi kaldı', [prog.page + 1, prog.total])
      : prog.phase === 'vektor'
        ? __('Sayfa {0} / {1}: kenarlar eğrilere çevriliyor…', [prog.page + 1, prog.total])
        : __('Sayfa {0} / {1} hazırlanıyor…', [prog.page + 1, prog.total]);
  return (
    <div className="ocr-prog" role="status" aria-live="polite">
      <div className="ocr-prog__bar" aria-hidden="true">
        <span style={{ width: `${pct}%` }} />
      </div>
      <p>{label}</p>
    </div>
  );
}

/** Aynı küçük bölgenin büyütülmüş hâli: önce (piksel) / sonra (vektör) */
function BeforeAfter({ before, after, page }: { before: ArrayBuffer | null; after: ArrayBuffer; page: number }) {
  const [urls, setUrls] = useState<{ a: string | null; b: string } | null>(null);
  useEffect(() => {
    let alive = true;
    const made: string[] = [];
    (async () => {
      // Yazının sık olduğu üst bölümden bir parça
      const r = { x: 0.08, y: 0.08, w: 0.28, h: 0.12 };
      const shot = async (bytes: ArrayBuffer) => {
        const d = await openRenderDoc(bytes);
        try {
          const u = URL.createObjectURL(await d.crop(Math.min(page, d.pageCount - 1), r, 900));
          made.push(u);
          return u;
        } finally {
          d.close();
        }
      };
      try {
        const b = await shot(after);
        const a = before ? await shot(before) : null;
        if (alive) setUrls({ a, b });
      } catch {
        /* karşılaştırma olmasa da olur */
      }
    })();
    return () => {
      alive = false;
      made.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [before, after, page]);
  if (!urls) return null;
  return (
    <section className="vcompare" aria-label={__('Yakından karşılaştırma')}>
      <h2>{__('Yakından bak')}</h2>
      <div className="vcompare__row">
        {urls.a && (
          <figure>
            <img src={urls.a} alt={__('Önce: pikselli sayfanın büyütülmüş bölümü')} />
            <figcaption>{__('Önce (piksel)')}</figcaption>
          </figure>
        )}
        <figure>
          <img src={urls.b} alt={__('Sonra: vektör sayfanın büyütülmüş bölümü')} />
          <figcaption>{__('Sonra (vektör)')}</figcaption>
        </figure>
      </div>
    </section>
  );
}
