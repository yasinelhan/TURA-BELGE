// Tura Belge — biçim dönüştürme araçları: PDF → Word/Markdown/web/metin, Markdown → PDF/Word/web/metin
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useMemo, useState } from 'react';
import { useEditorPreset, useToolHost, type PdfInput } from './host';
import { ErrorNote, FileChip, FilePicker, ResultPanel, Seg, ToolShell, errText, fmtSize, type Output } from './ui';
import { NoTextError, exportMarkdown, exportPdfAs, formatInfo, type ExportFormat } from '../convert/exporters';
import { MD_CSS, mdToHtml } from '../convert/markdown';
import { downloadFile, safeFileName } from '../lib/download';
import { __, locale } from '../i18n';

const dec = new TextDecoder();

function Preview({ md }: { md: string }) {
  const html = useMemo(() => mdToHtml(md.length > 20000 ? md.slice(0, 20000) + '\n\n…' : md), [md]);
  return (
    <div className="conv-preview">
      <style>{MD_CSS}</style>
      <article className="md-view" dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  );
}

function SaveResult({ blob, name, fmt, extra }: { blob: Blob; name: string; fmt: ExportFormat; extra?: React.ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null);
  const file = safeFileName(name, formatInfo(fmt).ext);
  return (
    <section className="result" aria-live="polite">
      <div className="result__head">
        <div>
          <h2>{__('Hazır')}</h2>
          <p>
            {file} · {fmtSize(blob.size)}
          </p>
        </div>
      </div>
      <div className="result__actions">
        <button
          className="btn btn--primary"
          onClick={async () => {
            const r = await downloadFile(file, blob);
            setMsg(r === 'saved' ? __('{0} indirildi', [file]) : r === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
          }}
        >
          {__('İndir')}
        </button>
        {extra}
      </div>
      {msg && <p className="muted">{msg}</p>}
    </section>
  );
}

// ---------------------------------------------------------------- PDF → …
export function PdfConvertTool() {
  const host = useToolHost();
  const [input, setInput] = useState<PdfInput | null>(null);
  useEditorPreset(setInput);
  const [fmt, setFmt] = useState<Exclude<ExportFormat, 'pdf'>>('docx');
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [noText, setNoText] = useState(false);
  const [result, setResult] = useState<{ blob: Blob; md: string; empty: number; fmt: ExportFormat } | null>(null);

  const run = async () => {
    if (!input) return;
    setError(null);
    setNoText(false);
    setResult(null);
    setBusy(__('Okunuyor…'));
    try {
      const r = await exportPdfAs(input.bytes, input.name, fmt, (p, t) => setBusy(__('Sayfa {0} / {1}', [p, t])));
      setResult({ blob: r.blob, md: r.md, empty: r.empty, fmt });
    } catch (e) {
      if (e instanceof NoTextError) setNoText(true);
      else setError(errText(e));
    } finally {
      setBusy(null);
    }
  };

  if (!input)
    return (
      <ToolShell id="pdf-donustur">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
      </ToolShell>
    );

  return (
    <ToolShell id="pdf-donustur">
      <FileChip name={input.name} detail={fmtSize(input.bytes.byteLength)} onClear={() => (setInput(null), setResult(null))} />
      <div className="tool-form">
        <Seg
          label={__('Biçim')}
          value={fmt}
          onChange={(v) => (setFmt(v), setResult(null))}
          options={[
            { v: 'docx', t: 'Word (.docx)' },
            { v: 'md', t: 'Markdown (.md)' },
            { v: 'html', t: 'Web sayfası (.html)' },
            { v: 'txt', t: 'Düz metin (.txt)' },
          ]}
        />
        <p className="muted">
          {__('Yazılar başlık, paragraf, liste ve kalın/eğik biçimleriyle aktarılır. Görseller, tablolar ve PDF’e eklenen notlar aktarılmaz.')}
        </p>
        <button className="btn btn--primary" onClick={run} disabled={!!busy}>
          {busy ?? __('{0} olarak çevir', [formatInfo(fmt).label])}
        </button>
      </div>
      <ErrorNote error={error} />
      {noText && (
        <p className="alert" role="alert">
          {__('Bu PDF’te seçilebilir yazı yok (taranmış olabilir).')}{' '}
          <button className="link-btn" onClick={() => host.goTool('ocr')}>
            {__('Önce yazıları tanıt →')}
          </button>
        </p>
      )}
      {result && (
        <>
          <SaveResult
            blob={result.blob}
            name={input.name}
            fmt={result.fmt}
            extra={
              <button className="btn btn--ghost" onClick={() => void host.openMarkdown(input.name, result.md)}>
                {__('Markdown notu olarak aç')}
              </button>
            }
          />
          {result.empty > 0 && <p className="muted">{result.empty} {__('sayfada yazı bulunamadı (taranmış sayfa olabilir).')}</p>}
          <Preview md={result.md} />
        </>
      )}
    </ToolShell>
  );
}

// ---------------------------------------------------------------- Markdown → …
export function MdConvertTool() {
  const host = useToolHost();
  const [input, setInput] = useState<{ name: string; text: string } | null>(null);
  const [fmt, setFmt] = useState<Exclude<ExportFormat, 'md'>>('pdf');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ blob: Blob; fmt: ExportFormat } | null>(null);

  const run = async () => {
    if (!input) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      setResult({ blob: await exportMarkdown(input.text, input.name, fmt), fmt });
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };

  if (!input)
    return (
      <ToolShell id="md-donustur">
        <FilePicker kind="md" onPdfs={(f) => setInput({ name: f[0].name, text: dec.decode(f[0].bytes) })} />
      </ToolShell>
    );

  const pdfOut: Output[] | null = result?.fmt === 'pdf' ? [{ name: input.name, ext: 'pdf', blob: result.blob }] : null;
  return (
    <ToolShell id="md-donustur">
      <FileChip badge="MD" name={input.name} detail={__('{0} karakter', [input.text.length.toLocaleString(locale())])} onClear={() => (setInput(null), setResult(null))} />
      <div className="tool-form">
        <Seg
          label={__('Biçim')}
          value={fmt}
          onChange={(v) => (setFmt(v), setResult(null))}
          options={[
            { v: 'pdf', t: 'PDF' },
            { v: 'docx', t: 'Word (.docx)' },
            { v: 'html', t: 'Web sayfası (.html)' },
            { v: 'txt', t: 'Düz metin (.txt)' },
          ]}
        />
        <div className="tool-form__row">
          <button className="btn btn--primary" onClick={run} disabled={busy}>
            {busy ? __('Çevriliyor…') : __('{0} olarak çevir', [formatInfo(fmt).label])}
          </button>
          <button className="btn btn--ghost" onClick={() => void host.openMarkdown(input.name, input.text)}>
            {__('Notu düzenle')}
          </button>
        </div>
      </div>
      <ErrorNote error={error} />
      {pdfOut && <ResultPanel outputs={pdfOut} />}
      {result && result.fmt !== 'pdf' && <SaveResult blob={result.blob} name={input.name} fmt={result.fmt} />}
      <Preview md={input.text} />
    </ToolShell>
  );
}
