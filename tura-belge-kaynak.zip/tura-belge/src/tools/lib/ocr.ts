// Tura Belge — yazı tanıma (OCR): Tesseract.js, tamamen cihazda çalışır
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { Worker } from 'tesseract.js';
import { degrees, type PDFDocument, type PDFPage } from 'pdf-lib';
import { __, N_ } from '../../i18n';

export type OcrLang = 'tur+eng' | 'tur' | 'eng';
export const OCR_LANGS: { v: OcrLang; t: string }[] = [
  { v: 'tur+eng', t: N_('Türkçe + İngilizce') },
  { v: 'tur', t: N_('Türkçe') },
  { v: 'eng', t: N_('İngilizce') },
];

export type OcrProgress = (p: { phase: 'yukleniyor' | 'taniyor'; progress: number }) => void;

let current: { lang: OcrLang; worker: Promise<Worker> } | null = null;
let listener: OcrProgress | null = null;

/**
 * Dil verileri normalde Tesseract'ın kendisi tarafından .gz olarak indirilir. .gz sunamayan
 * ortamlarda (Claude yapıtı) aynı veri base64 olarak .json içinde gelir; bu durumda veri,
 * Tesseract'ın kendi önbelleğine (idb-keyval varsayılan deposu, "./<dil>.traineddata")
 * önceden yazılır ve Tesseract onu oradan okur.
 */
async function prepareLangs(base: string, codes: string[]) {
  const probe = await fetch(`${base}lang/${codes[0]}.traineddata.gz`, { method: 'HEAD' }).catch(() => null);
  // Ağ yoksa (çevrimdışı) Tesseract kendi önbelleğinden okur
  if (!probe) return;
  if (probe.ok && !(probe.headers.get('content-type') ?? '').includes('text/html')) return;
  const { get, set } = await import('idb-keyval');
  for (const code of codes) {
    const key = `./${code}.traineddata`;
    if (await get(key).catch(() => undefined)) continue;
    const js = await fetch(`${base}lang/${code}.traineddata.json`);
    if (!js.ok) throw new Error(__('Yazı tanıma dil verisi indirilemedi.'));
    const bin = atob((await js.json()).gz as string);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    await set(key, out);
  }
}

function getWorker(lang: OcrLang): Promise<Worker> {
  if (current?.lang === lang) return current.worker;
  if (current) {
    // Dil değişti: eski işçiyi kapat
    current.worker.then((w) => w.terminate()).catch(() => undefined);
    current = null;
  }
  const base = new URL('vendor/tesseract/', document.baseURI).href;
  const worker = (async () => {
    const { createWorker, OEM, PSM } = await import('tesseract.js');
    listener?.({ phase: 'yukleniyor', progress: 0 });
    await prepareLangs(base, lang.split('+'));
    const w = await createWorker(lang.split('+'), OEM.LSTM_ONLY, {
      workerPath: base + 'worker.min.js',
      corePath: base + 'core',
      langPath: base + 'lang',
      gzip: true,
      workerBlobURL: false,
      logger: (m) =>
        listener?.({
          phase: m.status === 'recognizing text' ? 'taniyor' : 'yukleniyor',
          progress: typeof m.progress === 'number' ? m.progress : 0,
        }),
      errorHandler: () => undefined,
    });
    // Taranan sayfalar ~300 dpi; DPI bilgisi olmayan görsellerde Tesseract'ın yanlış tahminini önler
    await w.setParameters({ tessedit_pageseg_mode: PSM.AUTO, user_defined_dpi: '300' });
    return w;
  })();
  current = { lang, worker };
  worker.catch(() => {
    if (current?.worker === worker) current = null;
  });
  return worker;
}

export interface OcrResult {
  text: string;
  /** 0–100 */
  confidence: number;
  /** Yalnızca görünmez metin katmanı içeren tek sayfalık PDF */
  layer: Uint8Array;
}

/** Bir sayfa görüntüsündeki yazıyı tanır; aranabilir PDF için metin katmanını da üretir */
export async function ocrImage(
  image: Blob,
  lang: OcrLang,
  onProgress?: OcrProgress,
  opts: { block?: boolean } = {},
): Promise<OcrResult> {
  listener = onProgress ?? null;
  try {
    const w = await getWorker(lang);
    // El yazısı gibi tek bir metin bloğu: sayfa düzeni çözümlemesi atlanır (PSM 6)
    if (opts.block) await w.setParameters({ tessedit_pageseg_mode: '6' as never });
    const r = await w
      .recognize(image, { pdfTitle: 'Tura Belge', pdfTextOnly: true }, { text: true, pdf: true })
      .finally(() => (opts.block ? w.setParameters({ tessedit_pageseg_mode: '3' as never }) : undefined));
    const pdf = r.data.pdf as unknown as ArrayLike<number> | null;
    if (!pdf) throw new Error(__('Metin katmanı oluşturulamadı.'));
    return { text: (r.data.text ?? '').trim(), confidence: r.data.confidence ?? 0, layer: Uint8Array.from(pdf) };
  } finally {
    listener = null;
  }
}

/** İşçiyi kapatır (bellek iade edilir) */
export async function closeOcr() {
  const c = current;
  current = null;
  if (c) await c.worker.then((w) => w.terminate()).catch(() => undefined);
}

export interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Tesseract'ın metin katmanını sayfaya yerleştirir. Metin görünmezdir (çizim kipi 3) ama
 * seçilebilir, aranabilir ve kopyalanabilir.
 * `box` verilmezse sayfanın görünen alanının (CropBox) tamamı kullanılır; sayfa döndürmesi hesaba katılır.
 */
export async function placeTextLayer(doc: PDFDocument, page: PDFPage, layer: Uint8Array, box?: Box) {
  const [emb] = await doc.embedPdf(layer, [0]);
  if (box) {
    page.drawPage(emb, box);
    return;
  }
  const cb = page.getCropBox();
  const r = (((page.getRotation().angle % 360) + 360) % 360) as 0 | 90 | 180 | 270;
  // Görünen (döndürülmüş) sayfaya göre çizilen katmanı, döndürmenin tersiyle kullanıcı uzayına taşı
  const place = {
    0: { x: cb.x, y: cb.y, width: cb.width, height: cb.height, rotate: 0 },
    90: { x: cb.x + cb.width, y: cb.y, width: cb.height, height: cb.width, rotate: 90 },
    180: { x: cb.x + cb.width, y: cb.y + cb.height, width: cb.width, height: cb.height, rotate: 180 },
    270: { x: cb.x, y: cb.y + cb.height, width: cb.height, height: cb.width, rotate: 270 },
  }[r];
  page.drawPage(emb, { x: place.x, y: place.y, width: place.width, height: place.height, rotate: degrees(place.rotate) });
}
