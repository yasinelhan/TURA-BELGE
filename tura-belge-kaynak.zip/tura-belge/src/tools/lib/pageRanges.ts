// Tura Belge — sayfa aralığı ayrıştırıcı: "1-3, 5, 8-" gibi ifadeler
// SPDX-License-Identifier: AGPL-3.0-or-later
import { __ } from '../../i18n';

export interface RangeResult {
  /** Sıfırdan başlayan sayfa dizinleri, yazıldığı sırayla */
  groups: number[][];
  error?: string;
}

/**
 * Virgülle ayrılmış aralıkları çözer. Her parça ayrı bir grup olur.
 * "3-" sondan, "-4" baştan anlamına gelir; "son" (veya "s") son sayfa demektir.
 */
export function parseRanges(input: string, total: number): RangeResult {
  const text = input.trim().toLocaleLowerCase('tr-TR');
  if (!text) return { groups: [], error: __('Sayfa aralığı yazın (ör. 1-3, 5).') };
  const groups: number[][] = [];
  const toNum = (s: string, fallback: number) => {
    const t = s.trim();
    if (t === '') return fallback;
    if (t === 'son' || t === 's' || t === 'last' || t === 'end') return total;
    const n = Number(t);
    return Number.isInteger(n) ? n : NaN;
  };
  for (const raw of text.split(/[,;]+/)) {
    const part = raw.trim();
    if (!part) continue;
    const m = /^([^-–]*)[-–]([^-–]*)$/.exec(part);
    let a: number;
    let b: number;
    if (m) {
      a = toNum(m[1], 1);
      b = toNum(m[2], total);
    } else {
      a = b = toNum(part, NaN);
    }
    if (Number.isNaN(a) || Number.isNaN(b)) return { groups: [], error: __('“{0}” anlaşılamadı.', [part]) };
    if (a < 1 || b < 1 || a > total || b > total)
      return { groups: [], error: __('“{0}” belgede yok (belge {1} sayfa).', [part, total]) };
    const g: number[] = [];
    if (a <= b) for (let i = a; i <= b; i++) g.push(i - 1);
    else for (let i = a; i >= b; i--) g.push(i - 1);
    groups.push(g);
  }
  if (!groups.length) return { groups: [], error: __('Sayfa aralığı yazın (ör. 1-3, 5).') };
  return { groups };
}

/** Dizin listesini kısa aralık metnine çevirir: [0,1,2,4] → "1-3, 5" */
export function formatRanges(indices: number[]): string {
  const sorted = [...new Set(indices)].sort((x, y) => x - y);
  const out: string[] = [];
  for (let i = 0; i < sorted.length; i++) {
    const start = sorted[i];
    let end = start;
    while (sorted[i + 1] === end + 1) end = sorted[++i];
    out.push(start === end ? `${start + 1}` : `${start + 1}-${end + 1}`);
  }
  return out.join(', ');
}
