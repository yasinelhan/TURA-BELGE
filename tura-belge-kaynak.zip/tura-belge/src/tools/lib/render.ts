// Tura Belge — araçlar için sayfa görüntüsü üretme (PDFium, ayrı bir işçide)
// SPDX-License-Identifier: AGPL-3.0-or-later
import pdfiumWasmUrl from '@embedpdf/pdfium/pdfium.wasm?url';
import type { PdfDocumentObject, PdfEngine, PdfTextRun } from '@embedpdf/models';

type Engine = PdfEngine<Blob>;
let enginePromise: Promise<Engine> | null = null;

const abs = (p: string) => new URL(p, document.baseURI).href;

export function getEngine(): Promise<Engine> {
  if (!enginePromise) {
    enginePromise = (async () => {
      const { createPdfiumEngine } = await import('@embedpdf/engines/pdfium-worker-engine');
      const noto = [
        { url: 'NotoSans-Regular.ttf', weight: 400 },
        { url: 'NotoSans-Bold.ttf', weight: 700 },
      ];
      return createPdfiumEngine(abs(pdfiumWasmUrl), {
        fontFallback: { fonts: {}, defaultFont: noto, baseUrl: abs('vendor/fonts/') },
      });
    })();
    enginePromise.catch(() => (enginePromise = null));
  }
  return enginePromise;
}

export interface RenderDoc {
  pageCount: number;
  /** Sayfanın görüntülenen (döndürme uygulanmış) en/boy oranı */
  aspect: (index: number) => number;
  /** Sayfanın görüntülenen genişliği ve yüksekliği (pt) */
  sizePt: (index: number) => { w: number; h: number };
  /** Belirtilen genişlikte küçük resim üretir */
  thumb: (index: number, width: number) => Promise<Blob>;
  /** Belirtilen çözünürlükte (dpi) sayfa görüntüsü üretir */
  render: (index: number, dpi: number, type: 'image/png' | 'image/jpeg', quality?: number) => Promise<Blob>;
  /** Sayfanın bir bölümünü (oran olarak 0–1) büyütülmüş çizer: önce/sonra karşılaştırması için */
  crop: (index: number, r: { x: number; y: number; w: number; h: number }, widthPx: number) => Promise<Blob>;
  /** Sayfadaki seçilebilir metin (yoksa boş) */
  text: (index: number) => Promise<string>;
  /** Yazı parçaları: konum, yazı tipi, boyut, kalın/eğik (PDF → Markdown/Word için) */
  textRuns: (index: number) => Promise<PdfTextRun[]>;
  close: () => void;
}

let seq = 0;

export async function openRenderDoc(bytes: ArrayBuffer, password?: string): Promise<RenderDoc> {
  const engine = await getEngine();
  const doc: PdfDocumentObject = await engine
    .openDocumentBuffer({ id: `tura-arac-${++seq}`, content: bytes.slice(0) }, { password })
    .toPromise();
  const page = (i: number) => doc.pages[i];
  // Not: PDFium'un bildirdiği sayfa boyutu döndürme uygulanmış (görünen) boyuttur;
  // page.rotation yalnızca bilgi içindir, tekrar döndürülmemeli.
  let closed = false;
  return {
    pageCount: doc.pageCount,
    aspect: (i) => {
      const { width, height } = page(i).size;
      return width / height;
    },
    sizePt: (i) => {
      const { width, height } = page(i).size;
      return { w: width, h: height };
    },
    thumb: (i, width) => {
      const p = page(i);
      const w = p.size.width;
      return engine
        .renderPage(doc, p, {
          scaleFactor: width / w,
          dpr: Math.min(2, window.devicePixelRatio || 1),
          imageType: 'image/webp',
          imageQuality: 0.8,
          withAnnotations: true,
        })
        .toPromise();
    },
    render: (i, dpi, type, quality) =>
      engine
        .renderPage(doc, page(i), { scaleFactor: dpi / 72, dpr: 1, imageType: type, imageQuality: quality, withAnnotations: true })
        .toPromise(),
    crop: (i, r, widthPx) => {
      const p = page(i);
      // Görünen sayfa koordinatında (pt, sol üst köşeden)
      const W = p.size.width;
      const H = p.size.height;
      const rect = { origin: { x: r.x * W, y: r.y * H }, size: { width: r.w * W, height: r.h * H } };
      return engine
        .renderPageRect(doc, p, rect, { scaleFactor: widthPx / rect.size.width, dpr: 1, imageType: 'image/png', withAnnotations: true })
        .toPromise();
    },
    text: async (i) => {
      const n = (await engine.getPageGlyphs(doc, page(i)).toPromise()).length;
      if (!n) return '';
      const [t] = await engine.getTextSlices(doc, [{ pageIndex: i, charIndex: 0, charCount: n }]).toPromise();
      return (t ?? '').replace(/\r\n?/g, '\n').replace(/[\u0000-\u0009\u000b-\u001f]/g, '').trim();
    },
    textRuns: async (i) => (await engine.getPageTextRuns(doc, page(i)).toPromise()).runs ?? [],
    close: () => {
      if (closed) return;
      closed = true;
      engine.closeDocument(doc).wait(
        () => undefined,
        () => undefined,
      );
    },
  };
}
