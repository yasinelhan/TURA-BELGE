// Tura Belge — piksel kenarlarından düzgün Bézier eğrileri (vektörleştirme)
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Yöntem Potrace'ın (P. Selinger, 2003) yayımlanmış algoritmasına dayanır, kod bu proje için
// sıfırdan yazıldı: kenar önce az köşeli bir çokgenle özetlenir; her çokgen köşesinde dönüşün
// keskinliğine göre ya sivri köşe ya da çokgen noktalarından geçen yumuşak bir eğri çizilir.
// Böylece düz kenarlar dümdüz, kavisler pürüzsüz, köşeler keskin olur.

export type V = [number, number];
/** Kübik Bézier: başlangıç, iki kontrol noktası, bitiş */
export type Cubic = [V, V, V, V];


/** Douglas–Peucker: açık zincirin (a, b) arasındaki önemli noktaları */
function dp(p: V[], a: number, b: number, eps: number, out: number[]) {
  const A = p[a];
  const B = p[b];
  const dx = B[0] - A[0];
  const dy = B[1] - A[1];
  const L = Math.hypot(dx, dy) || 1;
  let best = -1;
  let bi = -1;
  for (let i = a + 1; i < b; i++) {
    const d = Math.abs((p[i][0] - A[0]) * dy - (p[i][1] - A[1]) * dx) / L;
    if (d > best) {
      best = d;
      bi = i;
    }
  }
  if (best > eps && bi > 0) {
    dp(p, a, bi, eps, out);
    out.push(bi);
    dp(p, bi, b, eps, out);
  }
}

/** (a,b) ve (c,d) doğrularının kesişimi */
function intersect(a: V, b: V, c: V, d: V): V | null {
  const r = [b[0] - a[0], b[1] - a[1]];
  const q = [d[0] - c[0], d[1] - c[1]];
  const den = r[0] * q[1] - r[1] * q[0];
  if (Math.abs(den) < 1e-9) return null;
  const t = ((c[0] - a[0]) * q[1] - (c[1] - a[1]) * q[0]) / den;
  return [a[0] + r[0] * t, a[1] + r[1] * t];
}

/** Potrace: p0→p2 yönüne göre ızgaraya dik birim ölçü */
function ddenom(p0: V, p2: V) {
  const ry = Math.sign(p2[0] - p0[0]);
  const rx = -Math.sign(p2[1] - p0[1]);
  return ry * (p2[0] - p0[0]) - rx * (p2[1] - p0[1]);
}
/** Üç noktanın oluşturduğu paralelkenarın alanı */
const dpara = (p0: V, p1: V, p2: V) => (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1]);

/**
 * Kapalı bir kenar dizisini (piksel merkezleri) Bézier eğrilerine çevirir.
 * `eps`: çokgen sadeleştirme toleransı (piksel). `alphaMax`: bundan keskin dönüşler köşe olur.
 */
export function fitClosed(raw: V[], eps = 1, alphaMax = 1): Cubic[] {
  const n = raw.length;
  if (n < 3) return [];
  // 1) Basamakları hafifçe yumuşat (dairesel, 5 noktalı); köşeler ~1 piksel yuvarlanır,
  //    aşağıda pah kırma ile yeniden sivriltilir
  const w = [0.1, 0.2, 0.4, 0.2, 0.1];
  const sm: V[] = raw.map((_, i) => {
    let x = 0;
    let y = 0;
    for (let d = -2; d <= 2; d++) {
      const q = raw[(i + d + n) % n];
      x += q[0] * w[d + 2];
      y += q[1] * w[d + 2];
    }
    return [x, y];
  });
  // 2) Özet çokgen: kenara en fazla eps/2 uzak (Potrace'taki ½ piksel ölçütü)
  let far = 0;
  let fd = -1;
  for (let i = 0; i < n; i++) {
    const d = Math.hypot(sm[i][0] - sm[0][0], sm[i][1] - sm[0][1]);
    if (d > fd) {
      fd = d;
      far = i;
    }
  }
  const ring = [...sm, sm[0]];
  const idx: number[] = [0];
  dp(ring, 0, far, eps / 2, idx);
  if (far > 0) idx.push(far);
  dp(ring, far, n, eps / 2, idx);
  let v: V[] = idx.map((i) => [sm[i][0], sm[i][1]]);
  // Çok küçük şekiller (nokta, virgül) en az 6 noktadan geçen yuvarlak bir eğri olsun
  if (v.length < 6 && n >= 6) v = [0, 1, 2, 3, 4, 5].map((t) => [sm[Math.floor((t * n) / 6)][0], sm[Math.floor((t * n) / 6)][1]] as V);

  // 3) Pah kırma: köşede oluşan çok kısa kenarı, komşu kenarların kesişimiyle tek köşeye indir
  for (let pass = 0; pass < 2 && v.length > 4; pass++) {
    const res: V[] = [];
    const m0 = v.length;
    const skip = new Uint8Array(m0);
    for (let j = 0; j < m0; j++) {
      if (skip[j]) continue;
      const k = (j + 1) % m0;
      const a = v[(j - 1 + m0) % m0];
      const b = v[j];
      const c = v[k];
      const d = v[(k + 1) % m0];
      const short = Math.hypot(c[0] - b[0], c[1] - b[1]) < 3.2;
      const longs = Math.hypot(b[0] - a[0], b[1] - a[1]) > 6 && Math.hypot(d[0] - c[0], d[1] - c[1]) > 6;
      // Gerçek köşe mi? İki uzun kenar arasındaki toplam dönüş belirgin olmalı (kavislerde değil)
      const u1 = [b[0] - a[0], b[1] - a[1]];
      const u2 = [d[0] - c[0], d[1] - c[1]];
      const cos = (u1[0] * u2[0] + u1[1] * u2[1]) / (Math.hypot(u1[0], u1[1]) * Math.hypot(u2[0], u2[1]) || 1);
      if (short && longs && k !== 0 && cos < 0.8) {
        const x = intersect(a, b, c, d);
        if (x && Math.hypot(x[0] - b[0], x[1] - b[1]) < 4 && Math.hypot(x[0] - c[0], x[1] - c[1]) < 4) {
          res.push(x);
          skip[k] = 1;
          continue;
        }
      }
      res.push(b);
    }
    if (res.length === v.length) break;
    v = res;
  }
  const m = v.length;
  // 4) Köşeler arasındaki neredeyse yatay/dikey uzun kenarları tam hizaya getir (±2,5°):
  //    taranmış yazıda düz kenarlar dümdüz olur; kavislere dokunulmaz
  const turnCos = (p: V, q: V, r: V) => {
    const a1 = q[0] - p[0];
    const b1 = q[1] - p[1];
    const a2 = r[0] - q[0];
    const b2 = r[1] - q[1];
    return (a1 * a2 + b1 * b2) / (Math.hypot(a1, b1) * Math.hypot(a2, b2) || 1);
  };
  const snaps: [number, 'x' | 'y'][] = [];
  for (let j = 0; j < m; j++) {
    const a = v[j];
    const b = v[(j + 1) % m];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const L = Math.hypot(dx, dy);
    if (L < 16) continue;
    const sharpA = turnCos(v[(j - 1 + m) % m], a, b) < 0.87;
    const sharpB = turnCos(a, b, v[(j + 2) % m]) < 0.87;
    if (!sharpA || !sharpB) continue;
    if (Math.abs(dx) < L * 0.044) snaps.push([j, 'x']);
    else if (Math.abs(dy) < L * 0.044) snaps.push([j, 'y']);
  }
  for (const [j, ax] of snaps) {
    const a = v[j];
    const b = v[(j + 1) % m];
    const c = ax === 'x' ? 0 : 1;
    a[c] = b[c] = (a[c] + b[c]) / 2;
  }

  const out: Cubic[] = [];
  const lerp = (a: V, b: V, t: number): V => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

  // 5a) Küçük şekiller (nokta, virgül, i noktası): noktalardan geçen kapalı Catmull–Rom eğrisi;
  //     köşe ortalarından geçen yöntem bunları küçültürdü
  let per = 0;
  for (let j = 0; j < m; j++) per += Math.hypot(v[(j + 1) % m][0] - v[j][0], v[(j + 1) % m][1] - v[j][1]);
  if (per < 48) {
    // Kenar noktaları piksel merkezinde: şekil yarım piksel küçük çıkar; küçük şekilde bu
    // fark görünür, merkezden dışa doğru telafi edilir
    const cx = v.reduce((t, p) => t + p[0], 0) / m;
    const cy = v.reduce((t, p) => t + p[1], 0) / m;
    v = v.map((p) => {
      const dx = p[0] - cx;
      const dy = p[1] - cy;
      const l = Math.hypot(dx, dy) || 1;
      return [p[0] + (dx / l) * 0.7, p[1] + (dy / l) * 0.7] as V;
    });
    for (let j = 0; j < m; j++) {
      const a = v[(j - 1 + m) % m];
      const b = v[j];
      const c = v[(j + 1) % m];
      const d = v[(j + 2) % m];
      out.push([b, [b[0] + (c[0] - a[0]) / 6, b[1] + (c[1] - a[1]) / 6], [c[0] - (d[0] - b[0]) / 6, c[1] - (d[1] - b[1]) / 6], c]);
    }
    return out;
  }

  // 5b) Potrace eğrisi: her köşede alfa (dönüşün keskinliği) büyükse sivri köşe, değilse
  //     kenar ortalarından geçen yumuşak eğri
  const mid = (j: number) => lerp(v[j], v[(j + 1) % m], 0.5);
  for (let j = 0; j < m; j++) {
    const i = (j - 1 + m) % m;
    const k = (j + 1) % m;
    const start = mid(i);
    const end = mid(j);
    const denom = ddenom(v[i], v[k]);
    let alpha: number;
    if (denom !== 0) {
      const dd = Math.abs(dpara(v[i], v[j], v[k]) / denom);
      alpha = (dd > 1 ? 1 - 1 / dd : 0) / 0.75;
    } else alpha = 4 / 3;
    // Hafif kıvrımlar (≈30°'den az) uzun kenarlarda bile köşe sayılmaz
    if (alpha >= alphaMax && turnCos(v[i], v[j], v[k]) < 0.86) {
      out.push([start, lerp(start, v[j], 1 / 3), lerp(start, v[j], 2 / 3), v[j]]);
      out.push([v[j], lerp(v[j], end, 1 / 3), lerp(v[j], end, 2 / 3), end]);
    } else {
      const a = Math.min(1, Math.max(0.55, alpha));
      out.push([start, lerp(v[i], v[j], 0.5 + 0.5 * a), lerp(v[k], v[j], 0.5 + 0.5 * a), end]);
    }
  }
  return out;
}

const f = (x: number) => {
  const r = Math.round(x * 10) / 10;
  return Number.isInteger(r) ? String(r) : r.toFixed(1);
};

/** Düz parçalar (kontrol noktaları doğru üzerinde) */
function isLine(c: Cubic) {
  const [a, b, d, e] = c;
  const dx = e[0] - a[0];
  const dy = e[1] - a[1];
  const L = Math.hypot(dx, dy) || 1;
  const off = (p: V) => Math.abs((p[0] - a[0]) * dy - (p[1] - a[1]) * dx) / L;
  return off(b) < 0.05 && off(d) < 0.05;
}

/** Eğrileri PDF yol komutlarına yazar (m, l, c, h) */
export function cubicsToPdf(cs: Cubic[]): string {
  if (!cs.length) return '';
  let s = `${f(cs[0][0][0])} ${f(cs[0][0][1])} m\n`;
  for (const c of cs) {
    s += isLine(c)
      ? `${f(c[3][0])} ${f(c[3][1])} l\n`
      : `${f(c[1][0])} ${f(c[1][1])} ${f(c[2][0])} ${f(c[2][1])} ${f(c[3][0])} ${f(c[3][1])} c\n`;
  }
  return s + 'h\n';
}

/** Eğrileri SVG yol verisine yazar */
export function cubicsToSvg(cs: Cubic[]): string {
  if (!cs.length) return '';
  let s = `M${f(cs[0][0][0])} ${f(cs[0][0][1])}`;
  for (const c of cs) {
    s += isLine(c)
      ? `L${f(c[3][0])} ${f(c[3][1])}`
      : `C${f(c[1][0])} ${f(c[1][1])} ${f(c[2][0])} ${f(c[2][1])} ${f(c[3][0])} ${f(c[3][1])}`;
  }
  return s + 'Z';
}
