// Tura Belge — pikselli sayfayı vektöre çevirme
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Yazılar, çizimler ve el yazısı kenarlarından çıkarılıp Bézier eğrisi olarak yeniden çizilir;
// böylece her yakınlaştırmada keskin kalır. Kalem renkleri ayrı katmanlarda korunur.
// Gerçek fotoğraflar ve renkli alanlar vektöre çevrilmez (poster gibi lekelenirdi):
// bunlar arka planda görüntü olarak kalır, yazılar üstte vektör olur.
/* eslint-disable @typescript-eslint/no-explicit-any */
import type { PDFDocument, PDFPage } from 'pdf-lib';
import { blobToCanvas, flatten, loadCv } from './scan';
import { cubicsToPdf, cubicsToSvg, fitClosed, type V } from './bezier';
import { placeTextLayer } from './ocr';

export interface VectorLayer {
  /** 0–1 arası RGB */
  color: [number, number, number];
  /** PDF yol komutları (görüntü pikseli koordinatında, y aşağı) */
  pdf: string;
  /** Aynı yol, SVG olarak */
  svg: string;
}

export interface VectorPage {
  width: number;
  height: number;
  layers: VectorLayer[];
  /** Fotoğraflar ve renkli alanlar (JPEG) — sayfa düz beyazsa yok */
  background: Blob | null;
  stats: { shapes: number; curves: number; imageRegions: number };
}

export interface VectorOptions {
  /** auto: kalem renkleri korunur; mono: hepsi siyah */
  colors: 'auto' | 'mono';
  /** keep: fotoğraflar ve renkli alanlar arka planda kalır; drop: kaldırılır */
  photos: 'keep' | 'drop';
}


/** Renk kümesi anahtarı: koyu (siyah/gri/kurşun kalem) ya da renk tonu dilimi */
function colorKey(r: number, g: number, b: number): string {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  if (max - min < 45 || max < 70) return 'koyu';
  let h: number;
  if (max === r) h = ((g - b) / (max - min)) * 60;
  else if (max === g) h = (2 + (b - r) / (max - min)) * 60;
  else h = (4 + (r - g) / (max - min)) * 60;
  if (h < 0) h += 360;
  if (h < 15 || h >= 335) return 'kirmizi';
  if (h < 70) return 'turuncu';
  if (h < 170) return 'yesil';
  if (h < 265) return 'mavi';
  return 'mor';
}

/**
 * Bir sayfa görüntüsünü vektöre çevirir.
 * `workSide`: işlem çözünürlüğü (uzun kenar, piksel). A4 için 3200 ≈ 275 dpi.
 */
export async function vectorizeImage(src: Blob, opts: VectorOptions, workSide = 3200): Promise<VectorPage> {
  const cv = await loadCv();
  const canvas = await blobToCanvas(src, workSide);
  const mats: any[] = [];
  const keep = <T,>(m: T) => (mats.push(m), m);
  try {
    let rgba = keep(cv.imread(canvas));
    canvas.width = canvas.height = 0;
    // Küçük görseller büyütülerek işlenir: kenarlar daha ince örneklenir, eğriler daha düzgün olur
    const up = workSide / Math.max(rgba.cols, rgba.rows);
    if (up > 1.05) {
      const big = keep(new cv.Mat());
      cv.resize(rgba, big, new cv.Size(Math.round(rgba.cols * up), Math.round(rgba.rows * up)), 0, 0, cv.INTER_CUBIC);
      rgba = big;
    }
    const W = rgba.cols;
    const H = rgba.rows;
    const rgb = keep(new cv.Mat());
    cv.cvtColor(rgba, rgb, cv.COLOR_RGBA2RGB);
    const flat = keep(flatten(cv, rgb, keep));
    const gray = keep(new cv.Mat());
    cv.cvtColor(flat, gray, cv.COLOR_RGB2GRAY);
    // JPEG pürüzü ve büyütme basamakları kenarı dalgalandırmasın
    cv.GaussianBlur(gray, gray, new cv.Size(0, 0), Math.max(0.7, up * 0.55));
    // Düşük çözünürlüklü kaynakta kenarlar daha kaba: eğri toleransı da ölçeklenir
    const tol = Math.max(1, up * 0.85);

    // Mürekkep: ışık düzeltilmiş görüntüde yarı tondan koyu pikseller. Kenar mürekkep ile kâğıt
    // arasındaki yarı tonda olduğu için çizgi kalınlığı korunur; tek eşik kullanıldığından
    // kenarlar komşu yazıların yoğunluğuna göre dalgalanmaz.
    const mask = keep(new cv.Mat());
    cv.threshold(gray, mask, 150, 255, cv.THRESH_BINARY_INV);
    cv.medianBlur(mask, mask, 3);

    // Kâğıdın yerel rengi (mürekkebin çevresindeki en açık renk): fosforlu kalem altındaki yazının
    // gerçek rengini bulmak ve arka plandaki mürekkebi silmek için
    const fill = keep(new cv.Mat());
    cv.dilate(flat, fill, cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(31, 31)));

    // Fotoğraf bölgeleri: mürekkep dışındaki pikseller hem renkli/gri hem de dokulu
    const photoRects = findPhotoRegions(cv, flat, mask, W, H, keep);

    // Bağlı parçalar: her harf/çizgi bir parça; rengi ve türü parça parça belirlenir
    const labels = keep(new cv.Mat());
    const stats = keep(new cv.Mat());
    const cents = keep(new cv.Mat());
    const nLab: number = cv.connectedComponentsWithStats(mask, labels, stats, cents, 8, cv.CV_32S);
    // Dikkat: WASM belleği büyüyünce eski dizi görünümleri boşalır; görünümler her
    // yeni OpenCV ayırmasından sonra yeniden alınır, küçük olanlar kopyalanır.
    let lab: Int32Array = labels.data32S;
    const px: Uint8Array = flat.data;
    const fx: Uint8Array = fill.data;
    const sums = new Float64Array(nLab * 3);
    const bsum = new Float64Array(nLab * 3);
    for (let i = 0, n = W * H; i < n; i++) {
      const l = lab[i];
      if (l > 0) {
        sums[l * 3] += px[i * 3];
        sums[l * 3 + 1] += px[i * 3 + 1];
        sums[l * 3 + 2] += px[i * 3 + 2];
        bsum[l * 3] += fx[i * 3];
        bsum[l * 3 + 1] += fx[i * 3 + 1];
        bsum[l * 3 + 2] += fx[i * 3 + 2];
      }
    }
    const ct: Float64Array = cents.data64F.slice();
    const st: Int32Array = stats.data32S.slice();
    const turd = Math.max(6, W * H * 8e-7);
    // -1: atla (toz), -2: fotoğraf/dolu alan, >=0: renk kümesi
    const cls = new Int32Array(nLab).fill(-1);
    const keys: string[] = [];
    const csum: number[][] = [];
    let imageRegions = photoRects.length;
    for (let l = 1; l < nLab; l++) {
      const bw = st[l * 5 + 2];
      const bh = st[l * 5 + 3];
      const area = st[l * 5 + 4];
      if (area < turd) continue;
      const cx = ct[l * 2];
      const cy = ct[l * 2 + 1];
      if (photoRects.some((r) => cx >= r.x && cx <= r.x + r.w && cy >= r.y && cy <= r.y + r.h)) {
        cls[l] = -2;
        continue;
      }
      if (area > W * H * 0.004 && area / (bw * bh) > 0.45 && bw > W * 0.06 && bh > H * 0.03) {
        cls[l] = -2;
        imageRegions++;
        continue;
      }
      // Mürekkep rengi = görünen renk ÷ altındaki kâğıt rengi (renkli zeminde de doğru renk)
      const r = Math.min(255, (sums[l * 3] / Math.max(1, bsum[l * 3])) * 255);
      const g = Math.min(255, (sums[l * 3 + 1] / Math.max(1, bsum[l * 3 + 1])) * 255);
      const b = Math.min(255, (sums[l * 3 + 2] / Math.max(1, bsum[l * 3 + 2])) * 255);
      const key = opts.colors === 'mono' ? 'koyu' : colorKey(r, g, b);
      let k = keys.indexOf(key);
      if (k < 0) {
        k = keys.push(key) - 1;
        csum.push([0, 0, 0, 0]);
      }
      cls[l] = k;
      csum[k][0] += r * area;
      csum[k][1] += g * area;
      csum[k][2] += b * area;
      csum[k][3] += area;
    }

    // Kenarlar → eğriler
    const contours = keep(new cv.MatVector());
    const hier = keep(new cv.Mat());
    cv.findContours(mask, contours, hier, cv.RETR_CCOMP, cv.CHAIN_APPROX_NONE);
    const hd: Int32Array = hier.data32S.slice();
    const count = contours.size();
    const owner = new Int32Array(count).fill(-1);
    const pdfParts: string[][] = keys.map(() => []);
    const svgParts: string[][] = keys.map(() => []);
    let shapes = 0;
    let curves = 0;
    // Önce dış kenarlar (sahibini belirler), sonra delikler
    for (const pass of [0, 1]) {
      for (let i = 0; i < count; i++) {
        const parent = hd[i * 4 + 3];
        if ((pass === 0) !== (parent < 0)) continue;
        const c = contours.get(i);
        const d: Int32Array = c.data32S;
        let k: number;
        if (parent < 0) {
          lab = labels.data32S;
          k = cls[lab[d[1] * W + d[0]]];
          owner[i] = k;
        } else {
          k = owner[parent];
        }
        if (k >= 0 && d.length >= 6 && !(parent >= 0 && Math.abs(cv.contourArea(c)) < 4)) {
          const dn: Int32Array = c.data32S;
          const pts: V[] = [];
          for (let j = 0; j < dn.length; j += 2) pts.push([dn[j], dn[j + 1]]);
          const cs = fitClosed(pts, tol);
          if (cs.length) {
            pdfParts[k].push(cubicsToPdf(cs));
            svgParts[k].push(cubicsToSvg(cs));
            curves += cs.length;
            if (parent < 0) shapes++;
          }
        }
        c.delete();
      }
    }
    const layers: VectorLayer[] = keys
      .map((key, k) => {
        const [r, g, b, a] = csum[k];
        // Ortalama, kenardaki açık pikselleri de içerir: mürekkebi biraz koyulaştır
        const f = key === 'koyu' ? 0.55 : 0.92;
        const color = [r, g, b].map((v) => Math.min(1, (v / a / 255) * f)) as [number, number, number];
        return { color, pdf: pdfParts[k].join(''), svg: svgParts[k].join('') };
      })
      .filter((l) => l.pdf);

    // Arka plan: fotoğraflar, renkli alanlar, fosforlu kalem… (vektöre çevrilen mürekkep silinir)
    let background: Blob | null = null;
    if (opts.photos === 'keep') {
      const vec = new Uint8Array(W * H);
      lab = labels.data32S;
      for (let i = 0, n = W * H; i < n; i++) if (lab[i] > 0 && cls[lab[i]] >= 0) vec[i] = 255;
      const vecMask = keep(cv.matFromArray(H, W, cv.CV_8UC1, vec));
      cv.dilate(vecMask, vecMask, cv.getStructuringElement(cv.MORPH_ELLIPSE, new cv.Size(7, 7)));
      const vm: Uint8Array = vecMask.data;
      const px2: Uint8Array = flat.data;
      let nonWhite = 0;
      let rest = 0;
      for (let i = 0, n = W * H; i < n; i += 3) {
        if (vm[i]) continue;
        rest++;
        if (Math.min(px2[i * 3], px2[i * 3 + 1], px2[i * 3 + 2]) < 228) nonWhite++;
      }
      if (imageRegions > 0 || nonWhite > rest * 0.004) {
        const bg = keep(new cv.Mat());
        flat.copyTo(bg);
        fill.copyTo(bg, vecMask);
        // Fotoğraf varsa arka plan daha yüksek çözünürlükte tutulur
        const s = Math.min(1, (imageRegions ? 2400 : 1500) / Math.max(W, H));
        const small = keep(new cv.Mat());
        cv.resize(bg, small, new cv.Size(Math.round(W * s), Math.round(H * s)), 0, 0, cv.INTER_AREA);
        const out = document.createElement('canvas');
        cv.imshow(out, small);
        background = await new Promise<Blob | null>((res) => out.toBlob(res, 'image/jpeg', imageRegions ? 0.82 : 0.72));
        out.width = out.height = 0;
      }
    }
    return { width: W, height: H, layers, background, stats: { shapes, curves, imageRegions } };
  } finally {
    mats.forEach((m: any) => m.delete());
  }
}

/** Sayfadaki fotoğraf benzeri bölgeler (piksel dikdörtgenleri) */
function findPhotoRegions(cv: any, flat: any, mask: any, W: number, H: number, keep: <T>(m: T) => T) {
  const CELL = 24;
  const cw = Math.max(1, Math.ceil(W / CELL));
  const ch = Math.max(1, Math.ceil(H / CELL));
  // Not: bu OpenCV derlemesinde clone() veriyi paylaşabiliyor; copyTo kesin kopya verir
  const bgOnly = keep(new cv.Mat());
  flat.copyTo(bgOnly);
  bgOnly.setTo(new cv.Scalar(255, 255, 255, 255), mask);
  const g = keep(new cv.Mat());
  cv.cvtColor(bgOnly, g, cv.COLOR_RGB2GRAY);
  const gf = keep(new cv.Mat());
  g.convertTo(gf, cv.CV_32F);
  const sq = keep(new cv.Mat());
  cv.multiply(gf, gf, sq);
  const mRGB = keep(new cv.Mat());
  const mG = keep(new cv.Mat());
  const mSq = keep(new cv.Mat());
  const size = new cv.Size(cw, ch);
  cv.resize(bgOnly, mRGB, size, 0, 0, cv.INTER_AREA);
  cv.resize(gf, mG, size, 0, 0, cv.INTER_AREA);
  cv.resize(sq, mSq, size, 0, 0, cv.INTER_AREA);
  const rgb: Uint8Array = mRGB.data;
  const mg: Float32Array = mG.data32F;
  const ms: Float32Array = mSq.data32F;
  const cells = new Uint8Array(cw * ch);
  for (let i = 0; i < cw * ch; i++) {
    const minC = Math.min(rgb[i * 3], rgb[i * 3 + 1], rgb[i * 3 + 2]);
    const sd = Math.sqrt(Math.max(0, ms[i] - mg[i] * mg[i]));
    if (minC < 225 && sd > 10) cells[i] = 255;
  }
  const cm = keep(cv.matFromArray(ch, cw, cv.CV_8UC1, cells));
  cv.morphologyEx(cm, cm, cv.MORPH_CLOSE, cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(3, 3)));
  const l = keep(new cv.Mat());
  const st = keep(new cv.Mat());
  const ce = keep(new cv.Mat());
  const n: number = cv.connectedComponentsWithStats(cm, l, st, ce, 8, cv.CV_32S);
  const s: Int32Array = st.data32S;
  const rects: { x: number; y: number; w: number; h: number }[] = [];
  for (let k = 1; k < n; k++) {
    const [x, y, w, h, a] = [s[k * 5], s[k * 5 + 1], s[k * 5 + 2], s[k * 5 + 3], s[k * 5 + 4]];
    if (w >= cw * 0.06 && h >= ch * 0.05 && a >= cw * ch * 0.008) {
      rects.push({ x: (x - 1) * CELL, y: (y - 1) * CELL, w: (w + 2) * CELL, h: (h + 2) * CELL });
    }
  }
  return rects;
}

export interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
}

/** Vektör sayfayı PDF sayfasına çizer: `box` içine, en/boy oranı korunarak */
export async function drawVectorPage(doc: PDFDocument, page: PDFPage, v: VectorPage, box: Box, textLayer?: Uint8Array) {
  const k = Math.min(box.width / v.width, box.height / v.height);
  const w = v.width * k;
  const h = v.height * k;
  const x0 = box.x + (box.width - w) / 2;
  const y0 = box.y + (box.height - h) / 2;
  if (v.background) {
    const img = await doc.embedJpg(await v.background.arrayBuffer());
    page.drawImage(img, { x: x0, y: y0, width: w, height: h });
  }
  if (v.layers.length) {
    const r = (n: number) => (Math.round(n * 1e5) / 1e5).toString();
    let ops = `q\n${r(k)} 0 0 ${r(-k)} ${r(x0)} ${r(y0 + h)} cm\n`;
    for (const l of v.layers) ops += `${l.color.map((c) => c.toFixed(3)).join(' ')} rg\n${l.pdf}f*\n`;
    ops += 'Q\n';
    const ref = doc.context.register(doc.context.flateStream(ops));
    page.node.addContentStream(ref);
  }
  if (textLayer) await placeTextLayer(doc, page, textLayer, { x: x0, y: y0, width: w, height: h });
}

/** Vektör sayfayı tek başına SVG olarak verir */
export function vectorPageToSvg(v: VectorPage): string {
  const paths = v.layers
    .map((l) => `<path fill="rgb(${l.color.map((c) => Math.round(c * 255)).join(',')})" fill-rule="evenodd" d="${l.svg}"/>`)
    .join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${v.width} ${v.height}" width="${v.width}" height="${v.height}"><rect width="100%" height="100%" fill="#fff"/>${paths}</svg>`;
}
