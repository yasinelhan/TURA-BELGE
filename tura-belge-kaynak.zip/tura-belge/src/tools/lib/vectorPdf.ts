// Tura Belge — pikselli PDF'i ve görselleri vektör PDF'e çevirme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { PDFDocument } from 'pdf-lib';
import { finish, loadPdf } from './pdfOps';
import { ocrImage, type OcrLang } from './ocr';
import { openRenderDoc } from './render';
import { drawVectorPage, vectorizeImage, type VectorOptions, type VectorPage } from './vectorize';
import { __ } from '../../i18n';

export interface VectorRunOptions extends VectorOptions {
  /** Yazı tanıma: aranabilir, kopyalanabilir metin katmanı */
  ocr: OcrLang | null;
  /** Zaten seçilebilir metni olan (doğuştan vektör) sayfalara dokunma */
  keepTextPages: boolean;
}

export interface VectorProgress {
  page: number;
  total: number;
  phase: 'okunuyor' | 'vektor' | 'yukleniyor' | 'taniyor' | 'atlandi';
  progress: number;
}

export interface VectorRunResult {
  bytes: ArrayBuffer;
  converted: number;
  kept: number[];
  texts: string[];
  /** Tek sayfa ise SVG olarak indirmek için */
  first: VectorPage | null;
}

const HAS_TEXT = 40;
const SIZES = { a4: [595.28, 841.89], letter: [612, 792] } as const;

/** PDF'in pikselli sayfalarını vektöre çevirir; sayfa boyutları korunur */
export async function vectorizePdf(
  bytes: ArrayBuffer,
  opts: VectorRunOptions,
  onProgress?: (p: VectorProgress) => void,
  signal?: AbortSignal,
  name?: string,
): Promise<VectorRunResult> {
  const src = await loadPdf(bytes, name);
  const out = await PDFDocument.create();
  const rd = await openRenderDoc(bytes);
  const kept: number[] = [];
  const texts: string[] = [];
  let converted = 0;
  let first: VectorPage | null = null;
  try {
    const total = rd.pageCount;
    for (let i = 0; i < total; i++) {
      if (signal?.aborted) throw new DOMException(__('İptal edildi'), 'AbortError');
      onProgress?.({ page: i, total, phase: 'okunuyor', progress: 0 });
      if (opts.keepTextPages) {
        const t = await rd.text(i);
        if (t.length >= HAS_TEXT) {
          const [copy] = await out.copyPages(src, [i]);
          out.addPage(copy);
          kept.push(i);
          texts.push(t);
          onProgress?.({ page: i, total, phase: 'atlandi', progress: 1 });
          continue;
        }
      }
      const { w, h } = rd.sizePt(i);
      // ~300 dpi; telefonda bellek taşmasın diye uzun kenar en fazla 3300 piksel
      const dpi = Math.min(300, 3300 / (Math.max(w, h) / 72));
      const image = await rd.render(i, dpi, 'image/png');
      onProgress?.({ page: i, total, phase: 'vektor', progress: 0 });
      const v = await vectorizeImage(image, opts);
      let layer: Uint8Array | undefined;
      if (opts.ocr) {
        const r = await ocrImage(image, opts.ocr, (p) => onProgress?.({ page: i, total, phase: p.phase, progress: p.progress }));
        if (r.text) layer = r.layer;
        texts.push(r.text);
      } else texts.push('');
      const page = out.addPage([w, h]);
      await drawVectorPage(out, page, v, { x: 0, y: 0, width: w, height: h }, layer);
      if (i === 0) first = v;
      converted++;
    }
  } finally {
    rd.close();
  }
  return { bytes: await finish(out), converted, kept, texts, first: rd.pageCount === 1 ? first : null };
}

/** Görselleri (fotoğraf, ekran görüntüsü, taranmış sayfa) vektör PDF sayfalarına çevirir */
export async function vectorizeImages(
  images: Blob[],
  opts: VectorRunOptions & { pageSize: 'a4' | 'letter' },
  onProgress?: (p: VectorProgress) => void,
  signal?: AbortSignal,
  cache?: Map<Blob, { key: string; v: VectorPage; ocr?: { text: string; layer: Uint8Array } }>,
): Promise<VectorRunResult> {
  const out = await PDFDocument.create();
  const texts: string[] = [];
  let first: VectorPage | null = null;
  const key = `${opts.colors}|${opts.photos}|${opts.ocr ?? ''}`;
  for (const [i, img] of images.entries()) {
    if (signal?.aborted) throw new DOMException(__('İptal edildi'), 'AbortError');
    const total = images.length;
    let entry = cache?.get(img);
    if (!entry || entry.key !== key) {
      onProgress?.({ page: i, total, phase: 'vektor', progress: 0 });
      const v = await vectorizeImage(img, opts);
      let ocr: { text: string; layer: Uint8Array } | undefined;
      if (opts.ocr) {
        const r = await ocrImage(img, opts.ocr, (p) => onProgress?.({ page: i, total, phase: p.phase, progress: p.progress }));
        ocr = { text: r.text, layer: r.layer };
      }
      entry = { key, v, ocr };
      cache?.set(img, entry);
    }
    const { v, ocr } = entry;
    const [a, b] = SIZES[opts.pageSize];
    const [pw, ph] = v.width > v.height ? [b, a] : [a, b];
    const page = out.addPage([pw, ph]);
    await drawVectorPage(out, page, v, { x: 0, y: 0, width: pw, height: ph }, ocr?.text ? ocr.layer : undefined);
    texts.push(ocr?.text ?? '');
    if (i === 0) first = v;
  }
  return { bytes: await finish(out), converted: images.length, kept: [], texts, first: images.length === 1 ? first : null };
}
