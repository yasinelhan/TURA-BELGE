// Tura Belge — belge tarama: kenar bulma, perspektif düzeltme, filtreler (OpenCV.js)
// SPDX-License-Identifier: AGPL-3.0-or-later
/* eslint-disable @typescript-eslint/no-explicit-any */
import { __, N_ } from '../../i18n';

/** Görsele göre 0–1 arası konum */
export type Pt = { x: number; y: number };
/** Sol üst, sağ üst, sağ alt, sol alt */
export type Quad = [Pt, Pt, Pt, Pt];
export type ScanFilter = 'orijinal' | 'belge' | 'gri' | 'sb';
export type Rotation = 0 | 90 | 180 | 270;

export const FILTERS: { v: ScanFilter; t: string }[] = [
  { v: 'belge', t: N_('Belge') },
  { v: 'orijinal', t: N_('Orijinal') },
  { v: 'gri', t: N_('Gri') },
  { v: 'sb', t: N_('Siyah-beyaz') },
];

let cvP: Promise<any> | null = null;

function loadScript(src: string) {
  return new Promise<void>((res, rej) => {
    const s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.onload = () => res();
    s.onerror = () => {
      s.remove();
      rej(new Error(__('Tarama motoru indirilemedi.')));
    };
    document.head.appendChild(s);
  });
}

/**
 * OpenCV yalnızca tarama açılınca yüklenir (~13 MB, sonra önbellekte).
 * Paketleyiciden geçirilmez: klasik betik olarak `globalThis.cv` değerini (bir Promise) kurar.
 */
export function loadCv(): Promise<any> {
  cvP ??= (async () => {
    const g = globalThis as any;
    if (!g.cv) await loadScript(new URL('vendor/opencv/opencv.js', document.baseURI).href);
    let cv = g.cv;
    if (cv && typeof cv.then === 'function' && !cv.Mat) cv = await cv;
    if (!cv?.Mat) await new Promise<void>((res) => (cv.onRuntimeInitialized = () => res()));
    // Sonraki çağrılarda tekrar beklenmesin
    g.cv = cv;
    return cv;
  })();
  cvP.catch(() => (cvP = null));
  return cvP;
}
export const cvReady = () => cvP !== null;

/** Fotoğrafı (EXIF yönüne göre döndürülmüş hâliyle) tuvale çizer; en uzun kenar en fazla `max` piksel */
export async function blobToCanvas(file: Blob, max: number): Promise<HTMLCanvasElement> {
  const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
  const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(bmp.width * s));
  c.height = Math.max(1, Math.round(bmp.height * s));
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close();
  return c;
}

const dist = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y);

/** Dört noktayı sol üst, sağ üst, sağ alt, sol alt sırasına koyar */
export function orderQuad(pts: Pt[]): Quad {
  const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
  const cy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
  // Merkeze göre açıya sırala (saat yönü), sonra sol üste en yakın olandan başlat
  const s = [...pts].sort((a, b) => Math.atan2(a.y - cy, a.x - cx) - Math.atan2(b.y - cy, b.x - cx));
  let start = 0;
  s.forEach((p, i) => {
    if (p.x + p.y < s[start].x + s[start].y) start = i;
  });
  return [0, 1, 2, 3].map((k) => s[(start + k) % 4]) as Quad;
}

export const fullQuad = (): Quad => [
  { x: 0, y: 0 },
  { x: 1, y: 0 },
  { x: 1, y: 1 },
  { x: 0, y: 1 },
];
export const insetQuad = (): Quad => [
  { x: 0.06, y: 0.06 },
  { x: 0.94, y: 0.06 },
  { x: 0.94, y: 0.94 },
  { x: 0.06, y: 0.94 },
];

/** Dörtgen dışbükey ve yeterince büyük mü (köşeler birbirinin üstüne geçmemiş) */
export function quadOk(q: Quad, w = 1, h = 1): boolean {
  let sign = 0;
  for (let i = 0; i < 4; i++) {
    const a = q[i];
    const b = q[(i + 1) % 4];
    const c = q[(i + 2) % 4];
    const cross = (b.x - a.x) * w * ((c.y - b.y) * h) - (b.y - a.y) * h * ((c.x - b.x) * w);
    if (Math.abs(cross) < 1e-9) return false;
    const sg = Math.sign(cross);
    if (sign && sg !== sign) return false;
    sign = sg;
  }
  return true;
}

/**
 * Fotoğraftaki kâğıdın köşelerini bulur. Birkaç yöntem sırayla denenir:
 * kenar çizgileri (iki farklı hassasiyet) ve parlak alan (beyaz kâğıt, koyu zemin).
 */
export async function detectQuad(file: Blob): Promise<{ quad: Quad; found: boolean }> {
  const cv = await loadCv();
  const src = await blobToCanvas(file, 800);
  const W = src.width;
  const H = src.height;
  const mats: any[] = [];
  const keep = <T,>(m: T) => (mats.push(m), m);
  try {
    const img = keep(cv.imread(src));
    const gray = keep(new cv.Mat());
    cv.cvtColor(img, gray, cv.COLOR_RGBA2GRAY);
    cv.GaussianBlur(gray, gray, new cv.Size(5, 5), 0);
    const kernel = keep(cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(5, 5)));
    const area = W * H;

    /** Siyah-beyaz görüntüdeki büyük dörtgen adayları, büyükten küçüğe */
    const fromBinary = (bin: any): { pts: Pt[]; area: number }[] => {
      const contours = new cv.MatVector();
      const hier = new cv.Mat();
      cv.findContours(bin, contours, hier, cv.RETR_LIST, cv.CHAIN_APPROX_SIMPLE);
      const found: { pts: Pt[]; area: number }[] = [];
      for (let i = 0; i < contours.size(); i++) {
        const c = contours.get(i);
        const hull = new cv.Mat();
        cv.convexHull(c, hull);
        const a = cv.contourArea(hull);
        // Kâğıt kenarı dolu bir dörtgendir; yazı bloklarının kenarı girintili çıkıntılıdır
        const solid = a > 0 ? cv.contourArea(c) / a : 0;
        if (a > area * 0.12 && solid > 0.85) {
          const peri = cv.arcLength(hull, true);
          for (const eps of [0.02, 0.03, 0.04]) {
            const approx = new cv.Mat();
            cv.approxPolyDP(hull, approx, eps * peri, true);
            if (approx.rows === 4) {
              const pts: Pt[] = [];
              for (let j = 0; j < 4; j++) pts.push({ x: approx.data32S[j * 2] / W, y: approx.data32S[j * 2 + 1] / H });
              found.push({ pts, area: a });
              approx.delete();
              break;
            }
            approx.delete();
          }
        }
        hull.delete();
        c.delete();
      }
      contours.delete();
      hier.delete();
      return found.sort((x, y) => y.area - x.area);
    };

    const tries: (() => any)[] = [
      () => {
        const e = new cv.Mat();
        cv.Canny(gray, e, 60, 160);
        cv.morphologyEx(e, e, cv.MORPH_CLOSE, kernel);
        return e;
      },
      () => {
        const e = new cv.Mat();
        cv.Canny(gray, e, 20, 70);
        cv.dilate(e, e, kernel);
        return e;
      },
      () => {
        const e = new cv.Mat();
        cv.threshold(gray, e, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU);
        cv.morphologyEx(e, e, cv.MORPH_OPEN, kernel);
        return e;
      },
    ];
    // Bulunan dörtgen gerçekten kâğıdın kenarı mı, yoksa kâğıdın içindeki bir tablo/çerçeve mi?
    // Kenarın hemen içi ile hemen dışı arasındaki parlaklık farkına bakılır.
    const edgeContrast = (q: Quad) => {
      const data: Uint8Array = gray.data;
      const at = (x: number, y: number) => data[Math.round(y) * W + Math.round(x)];
      const cx = q.reduce((a, p) => a + p.x, 0) / 4;
      const cy = q.reduce((a, p) => a + p.y, 0) / 4;
      const d = Math.max(4, Math.min(W, H) * 0.015);
      let edges = 0;
      let strong = 0;
      for (let i = 0; i < 4; i++) {
        const a = { x: q[i].x * W, y: q[i].y * H };
        const b = { x: q[(i + 1) % 4].x * W, y: q[(i + 1) % 4].y * H };
        const len = Math.hypot(b.x - a.x, b.y - a.y) || 1;
        let nx = -(b.y - a.y) / len;
        let ny = (b.x - a.x) / len;
        const mx = (a.x + b.x) / 2;
        const my = (a.y + b.y) / 2;
        if ((mx - cx * W) * nx + (my - cy * H) * ny < 0) {
          nx = -nx;
          ny = -ny;
        }
        let pos = 0;
        let neg = 0;
        let n = 0;
        for (let t = 0.1; t < 0.95; t += 0.1) {
          const px = a.x + (b.x - a.x) * t;
          const py = a.y + (b.y - a.y) * t;
          const ox = px + nx * d;
          const oy = py + ny * d;
          const ix = px - nx * d;
          const iy = py - ny * d;
          if (ox < 0 || oy < 0 || ox > W - 1 || oy > H - 1 || ix < 0 || iy < 0 || ix > W - 1 || iy > H - 1) continue;
          const diff = at(ix, iy) - at(ox, oy);
          if (diff >= 12) pos++;
          else if (diff <= -12) neg++;
          n++;
        }
        if (n >= 4) {
          edges++;
          // Kenar boyunca fark hep aynı yönde olmalı (kâğıt zeminden hep açık ya da hep koyu)
          if (Math.max(pos, neg) >= n * 0.7) strong++;
        }
      }
      // Görünen kenarların çoğu belirgin olmalı (kadraja değen kenarlar sayılmaz)
      return edges === 0 || strong >= Math.max(2, edges - 1);
    };

    for (const t of tries) {
      const bin = t();
      const cands = fromBinary(bin);
      bin.delete();
      for (const c of cands) {
        const quad = orderQuad(c.pts);
        if (quadOk(quad) && edgeContrast(quad)) return { quad, found: true };
      }
    }
    // Bulunamadı: kâğıt büyük olasılıkla kadrajı dolduruyor, fotoğrafın tamamı alınır
    return { quad: fullQuad(), found: false };
  } finally {
    mats.forEach((m: any) => m.delete());
  }
}

/** Dörtgenin düz sayfadaki boyutu (piksel) */
function targetSize(q: Quad, W: number, H: number) {
  const px = q.map((p) => ({ x: p.x * W, y: p.y * H })) as Quad;
  const [tl, tr, br, bl] = px;
  return { px, w: Math.max(dist(tl, tr), dist(bl, br)), h: Math.max(dist(tl, bl), dist(tr, br)) };
}

/**
 * Dörtgeni düz bir sayfaya çevirir, filtreyi uygular ve döndürür.
 * `maxSide`: çıktının en uzun kenarı (A4'te 2480 px ≈ 300 dpi)
 */
export async function processPage(
  file: Blob,
  quad: Quad,
  filter: ScanFilter,
  rotate: Rotation,
  maxSide = 2480,
): Promise<HTMLCanvasElement> {
  const cv = await loadCv();
  // Kaynağı çıktıdan biraz büyük oku (perspektifte uzak kenar küçülür)
  const src = await blobToCanvas(file, Math.round(maxSide * 1.35));
  const { px, w: w0, h: h0 } = targetSize(quad, src.width, src.height);
  const k = Math.min(1, maxSide / Math.max(w0, h0));
  const w = Math.max(1, Math.round(w0 * k));
  const h = Math.max(1, Math.round(h0 * k));
  const [tl, tr, br, bl] = px;
  const mats: any[] = [];
  const keep = <T,>(m: T) => (mats.push(m), m);
  try {
    const img = keep(cv.imread(src));
    src.width = src.height = 0;
    const from = keep(cv.matFromArray(4, 1, cv.CV_32FC2, [tl.x, tl.y, tr.x, tr.y, br.x, br.y, bl.x, bl.y]));
    const to = keep(cv.matFromArray(4, 1, cv.CV_32FC2, [0, 0, w, 0, w, h, 0, h]));
    const M = keep(cv.getPerspectiveTransform(from, to));
    const warped = keep(new cv.Mat());
    cv.warpPerspective(img, warped, M, new cv.Size(w, h), cv.INTER_CUBIC, cv.BORDER_REPLICATE);
    let out: any = warped;

    if (filter !== 'orijinal') {
      // Gölge ve renkli ışık düzeltmesi: kâğıdın aydınlığı büyük ölçekte tahmin edilip bölünür
      const rgb = keep(new cv.Mat());
      cv.cvtColor(warped, rgb, cv.COLOR_RGBA2RGB);
      const flat = keep(flatten(cv, rgb, keep));
      if (filter === 'belge') {
        out = flat;
      } else {
        const g = keep(new cv.Mat());
        cv.cvtColor(flat, g, cv.COLOR_RGB2GRAY);
        if (filter === 'gri') {
          out = g;
        } else {
          const bin = keep(new cv.Mat());
          const block = Math.max(15, Math.round(Math.min(w, h) / 50) | 1);
          cv.adaptiveThreshold(g, bin, 255, cv.ADAPTIVE_THRESH_MEAN_C, cv.THRESH_BINARY, block, 14);
          // Tek tük gürültü noktalarını temizle
          cv.medianBlur(bin, bin, 3);
          out = bin;
        }
      }
    }

    if (filter !== 'orijinal') {
      // Kenardaki ince zemin şeridini (köşe tam oturmadıysa) beyazla örter
      const m = Math.max(2, Math.round(Math.min(w, h) * 0.006));
      const white = out.channels() === 1 ? new cv.Scalar(255) : new cv.Scalar(255, 255, 255, 255);
      cv.rectangle(out, new cv.Point(0, 0), new cv.Point(w - 1, h - 1), white, m * 2);
    }

    if (rotate) {
      const r = keep(new cv.Mat());
      const code = rotate === 90 ? cv.ROTATE_90_CLOCKWISE : rotate === 180 ? cv.ROTATE_180 : cv.ROTATE_90_COUNTERCLOCKWISE;
      cv.rotate(out, r, code);
      out = r;
    }
    const canvas = document.createElement('canvas');
    cv.imshow(canvas, out);
    return canvas;
  } finally {
    mats.forEach((m: any) => m.delete());
  }
}

/** Her renk kanalını kâğıt arka planına bölerek düzleştirir, sonra kontrastı açar */
export function flatten(cv: any, rgb: any, keep: <T>(m: T) => T): any {
  const w = rgb.cols;
  const h = rgb.rows;
  const s = Math.min(1, 256 / Math.max(w, h));
  const small = keep(new cv.Mat());
  cv.resize(rgb, small, new cv.Size(Math.max(8, Math.round(w * s)), Math.max(8, Math.round(h * s))), 0, 0, cv.INTER_AREA);
  // Yazıyı sil (koyu ince çizgiler): genişletme = en parlak komşu
  cv.dilate(small, small, cv.getStructuringElement(cv.MORPH_RECT, new cv.Size(7, 7)));
  cv.medianBlur(small, small, 9);
  cv.GaussianBlur(small, small, new cv.Size(0, 0), 3);
  const bg = keep(new cv.Mat());
  cv.resize(small, bg, new cv.Size(w, h), 0, 0, cv.INTER_LINEAR);
  const div = keep(new cv.Mat());
  cv.divide(rgb, bg, div, 255);
  // Hafif kontrast: kâğıt tam beyaz, yazı daha koyu
  const lut = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
    const t = Math.min(1, Math.max(0, (i - 30) / (245 - 30)));
    lut[i] = Math.round(255 * Math.pow(t, 1.35));
  }
  const lutMat = keep(cv.matFromArray(1, 256, cv.CV_8UC1, Array.from(lut)));
  const out = new cv.Mat();
  cv.LUT(div, lutMat, out);
  return out;
}

export function canvasToBlob(c: HTMLCanvasElement, filter: ScanFilter): Promise<Blob> {
  // Siyah-beyaz sayfalar PNG'de hem daha küçük hem daha net
  const type = filter === 'sb' ? 'image/png' : 'image/jpeg';
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error(__('Görsel oluşturulamadı')))), type, 0.85));
}
