// Tura Belge — PDF araçlarının işlemleri (tamamen tarayıcıda, pdf-lib ile)
// SPDX-License-Identifier: AGPL-3.0-or-later
import {
  PDFArray,
  PDFDocument,
  PDFName,
  PDFPage,
  PDFRawStream,
  StandardFonts,
  decodePDFRawStream,
  degrees,
  rgb,
  type PDFFont,
  type PDFRef,
} from 'pdf-lib';
import { placeTextLayer } from './ocr';
import { __ } from '../../i18n';

export class ToolError extends Error {}

const toAB = (u8: Uint8Array): ArrayBuffer => u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength) as ArrayBuffer;

/** PDF'i açar; parolalı ya da bozuk dosyada anlaşılır bir hata verir. */
export async function loadPdf(bytes: ArrayBuffer, name = 'Belge'): Promise<PDFDocument> {
  try {
    return await PDFDocument.load(bytes, { updateMetadata: false });
  } catch (err) {
    const msg = String((err as Error)?.message ?? err);
    if (/encrypt/i.test(msg))
      throw new ToolError(
        __('“{0}” parolayla korunuyor. Önce düzenleyicide açıp Belge menüsü → Güvenlik bölümünden korumayı kaldırın.', [name]),
      );
    throw new ToolError(__('“{0}” açılamadı; dosya bozuk ya da PDF değil.', [name]));
  }
}

export async function finish(doc: PDFDocument): Promise<ArrayBuffer> {
  doc.setProducer('Tura Belge');
  doc.setModificationDate(new Date());
  return toAB(await doc.save({ useObjectStreams: true }));
}

// ---------------------------------------------------------------- Birleştir
export async function mergePdfs(inputs: { name: string; bytes: ArrayBuffer }[]): Promise<ArrayBuffer> {
  if (inputs.length < 2) throw new ToolError(__('Birleştirmek için en az iki PDF seçin.'));
  const out = await PDFDocument.create();
  for (const input of inputs) {
    const src = await loadPdf(input.bytes, input.name);
    const pages = await out.copyPages(src, src.getPageIndices());
    pages.forEach((p) => out.addPage(p));
  }
  return finish(out);
}

// ---------------------------------------------------------------- Sayfa düzenleme
export type PageItem = { kind: 'page'; src: number; rotate: number } | { kind: 'blank'; rotate: number; like?: number };

/** Sayfaları verilen sırayla, döndürme ve boş sayfa eklemeleriyle yeniden kurar. */
export async function organizePages(bytes: ArrayBuffer, items: PageItem[], name?: string): Promise<ArrayBuffer> {
  if (!items.length) throw new ToolError(__('Belgede en az bir sayfa kalmalı.'));
  const src = await loadPdf(bytes, name);
  const out = await PDFDocument.create();
  const used = [...new Set(items.filter((i) => i.kind === 'page').map((i) => (i as { src: number }).src))];
  const copied = new Map<number, PDFPage>();
  const pages = await out.copyPages(src, used);
  used.forEach((s, i) => copied.set(s, pages[i]));
  const seen = new Set<number>();
  for (const item of items) {
    let page: PDFPage;
    if (item.kind === 'page') {
      // Aynı sayfa iki kez kullanılırsa (çoğaltma) ikinci kopya ayrıca alınır
      if (seen.has(item.src)) [page] = await out.copyPages(src, [item.src]);
      else page = copied.get(item.src)!;
      seen.add(item.src);
    } else {
      const ref = src.getPage(Math.min(item.like ?? 0, src.getPageCount() - 1));
      const { width, height } = ref.getSize();
      page = PDFPage.create(out);
      page.setSize(width, height);
    }
    const base = page.getRotation().angle;
    page.setRotation(degrees((((base + item.rotate) % 360) + 360) % 360));
    out.addPage(page);
  }
  return finish(out);
}

// ---------------------------------------------------------------- Böl / ayıkla
export async function extractGroups(
  bytes: ArrayBuffer,
  groups: number[][],
  name?: string,
): Promise<ArrayBuffer[]> {
  const src = await loadPdf(bytes, name);
  const results: ArrayBuffer[] = [];
  for (const g of groups) {
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, g);
    pages.forEach((p) => out.addPage(p));
    results.push(await finish(out));
  }
  return results;
}

// ---------------------------------------------------------------- Görselden PDF
export interface ImageInput {
  name: string;
  file: Blob;
  /** Yazı tanımadan gelen görünmez metin katmanı (tek sayfalık PDF) */
  textLayer?: Uint8Array;
}
export interface ImagesToPdfOptions {
  pageSize: 'a4' | 'letter' | 'fit';
  orientation: 'auto' | 'portrait' | 'landscape';
  marginMm: number;
}
const MM = 72 / 25.4;
const SIZES = { a4: [595.28, 841.89], letter: [612, 792] } as const;

/** JPEG içindeki EXIF yön bilgisini okur (1 = normal) */
function jpegOrientation(buf: ArrayBuffer): number {
  const v = new DataView(buf);
  if (v.byteLength < 4 || v.getUint16(0) !== 0xffd8) return 1;
  let off = 2;
  while (off + 4 < v.byteLength) {
    const marker = v.getUint16(off);
    const len = v.getUint16(off + 2);
    if (marker === 0xffe1 && v.getUint32(off + 4) === 0x45786966) {
      const tiff = off + 10;
      const le = v.getUint16(tiff) === 0x4949;
      const ifd = tiff + v.getUint32(tiff + 4, le);
      const count = v.getUint16(ifd, le);
      for (let i = 0; i < count; i++) {
        const e = ifd + 2 + i * 12;
        if (e + 10 > v.byteLength) break;
        if (v.getUint16(e, le) === 0x0112) return v.getUint16(e + 8, le);
      }
      return 1;
    }
    if ((marker & 0xff00) !== 0xff00) break;
    off += 2 + len;
  }
  return 1;
}

async function toJpeg(blob: Blob, quality = 0.92): Promise<ArrayBuffer> {
  const bmp = await createImageBitmap(blob, { imageOrientation: 'from-image' });
  const canvas = new OffscreenCanvas(bmp.width, bmp.height);
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, bmp.width, bmp.height);
  ctx.drawImage(bmp, 0, 0);
  bmp.close();
  return (await canvas.convertToBlob({ type: 'image/jpeg', quality })).arrayBuffer();
}

export async function imagesToPdf(images: ImageInput[], opts: ImagesToPdfOptions): Promise<ArrayBuffer> {
  if (!images.length) throw new ToolError(__('En az bir görsel seçin.'));
  const doc = await PDFDocument.create();
  for (const img of images) {
    const buf = await img.file.arrayBuffer();
    const type = img.file.type || (/\.png$/i.test(img.name) ? 'image/png' : /\.jpe?g$/i.test(img.name) ? 'image/jpeg' : '');
    let embedded;
    try {
      if (type === 'image/jpeg' && jpegOrientation(buf) === 1) embedded = await doc.embedJpg(buf);
      else if (type === 'image/png') embedded = await doc.embedPng(buf);
      else embedded = await doc.embedJpg(await toJpeg(img.file));
    } catch {
      throw new ToolError(__('“{0}” okunamadı. JPG, PNG veya WebP görseli seçin.', [img.name]));
    }
    const iw = embedded.width;
    const ih = embedded.height;
    let pw: number;
    let ph: number;
    if (opts.pageSize === 'fit') {
      // Görsel boyutunda: 150 dpi kabul edilir
      pw = (iw * 72) / 150 + opts.marginMm * MM * 2;
      ph = (ih * 72) / 150 + opts.marginMm * MM * 2;
    } else {
      const [a, b] = SIZES[opts.pageSize];
      const landscape = opts.orientation === 'landscape' || (opts.orientation === 'auto' && iw > ih);
      [pw, ph] = landscape ? [b, a] : [a, b];
    }
    const page = doc.addPage([pw, ph]);
    const m = opts.marginMm * MM;
    const scale = Math.min((pw - 2 * m) / iw, (ph - 2 * m) / ih);
    const w = iw * scale;
    const h = ih * scale;
    page.drawImage(embedded, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    if (img.textLayer) await placeTextLayer(doc, page, img.textLayer, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
  }
  return finish(doc);
}

// ---------------------------------------------------------------- Yazı tipi (Türkçe)
const CP1252_EXTRA = new Set('€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ');
export const needsUnicode = (s: string) => [...s].some((c) => c.charCodeAt(0) > 0xff && !CP1252_EXTRA.has(c));

async function textFont(doc: PDFDocument, text: string, bold: boolean, fontBaseUrl: string): Promise<PDFFont> {
  if (!needsUnicode(text)) return doc.embedFont(bold ? StandardFonts.HelveticaBold : StandardFonts.Helvetica);
  const fontkit = (await import('@pdf-lib/fontkit')).default;
  doc.registerFontkit(fontkit);
  const res = await fetch(fontBaseUrl + (bold ? 'NotoSans-Bold.ttf' : 'NotoSans-Regular.ttf'));
  if (!res.ok) throw new ToolError(__('Türkçe yazı tipi yüklenemedi.'));
  // pdf-lib alt kümelemesi Noto Sans'ta bozuk glif ürettiği için yazı tipi tam gömülür
  return doc.embedFont(await res.arrayBuffer(), { subset: false });
}

/** Görsel (döndürülmüş sayfada ekranda görünen) koordinatı sayfa koordinatına çevirir */
function placer(page: PDFPage) {
  const r = ((page.getRotation().angle % 360) + 360) % 360;
  const box = page.getCropBox();
  const W = box.width;
  const H = box.height;
  const vw = r % 180 === 0 ? W : H;
  const vh = r % 180 === 0 ? H : W;
  const map = (vx: number, vy: number) => {
    let x: number;
    let y: number;
    if (r === 90) [x, y] = [W - vy, vx];
    else if (r === 180) [x, y] = [W - vx, H - vy];
    else if (r === 270) [x, y] = [vy, H - vx];
    else [x, y] = [vx, vy];
    return { x: x + box.x, y: y + box.y };
  };
  return { vw, vh, map, r };
}

export function hexToRgb(hex: string) {
  const n = parseInt(hex.replace('#', ''), 16);
  return rgb(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255);
}

// ---------------------------------------------------------------- Filigran
export interface WatermarkOptions {
  text: string;
  sizePct: number; // sayfa genişliğine göre yazı genişliği (%)
  color: string;
  opacity: number;
  angle: number; // görsel açı (derece, saat yönünün tersine)
  tiled: boolean;
  pages: number[] | null; // null = tümü
}

export async function addWatermark(
  bytes: ArrayBuffer,
  opts: WatermarkOptions,
  fontBaseUrl: string,
  name?: string,
): Promise<ArrayBuffer> {
  const text = opts.text.trim();
  if (!text) throw new ToolError(__('Filigran metnini yazın.'));
  const doc = await loadPdf(bytes, name);
  const font = await textFont(doc, text, true, fontBaseUrl);
  const color = hexToRgb(opts.color);
  const targets = opts.pages ?? doc.getPageIndices();
  for (const i of targets) {
    const page = doc.getPage(i);
    const { vw, vh, map, r } = placer(page);
    const unit = font.widthOfTextAtSize(text, 1);
    const size = Math.max(6, ((opts.tiled ? 0.28 : 1) * vw * (opts.sizePct / 100)) / unit);
    const w = unit * size;
    const capH = font.heightAtSize(size, { descender: false }) * 0.72;
    const a = (opts.angle * Math.PI) / 180;
    const draw = (cx: number, cy: number) => {
      const sx = cx - (Math.cos(a) * w) / 2 + (Math.sin(a) * capH) / 2;
      const sy = cy - (Math.sin(a) * w) / 2 - (Math.cos(a) * capH) / 2;
      const p = map(sx, sy);
      page.drawText(text, { x: p.x, y: p.y, size, font, color, opacity: opts.opacity, rotate: degrees(r + opts.angle) });
    };
    if (opts.tiled) {
      const stepX = w * 1.35 + size;
      const stepY = size * 3.2;
      for (let y = -vh * 0.2, row = 0; y < vh * 1.2; y += stepY, row++)
        for (let x = (row % 2) * (stepX / 2) - vw * 0.2; x < vw * 1.2; x += stepX) draw(x, y);
    } else draw(vw / 2, vh / 2);
  }
  return finish(doc);
}

// ---------------------------------------------------------------- Sayfa numarası
export type NumberPos = 'tl' | 'tc' | 'tr' | 'bl' | 'bc' | 'br';
export interface PageNumberOptions {
  position: NumberPos;
  format: string; // {n} ve {toplam}
  start: number;
  skipFirst: boolean;
  size: number;
  marginMm: number;
  color: string;
}

export function formatPageLabel(format: string, n: number, total: number) {
  return format.replaceAll('{n}', String(n)).replaceAll('{toplam}', String(total));
}

export async function addPageNumbers(
  bytes: ArrayBuffer,
  opts: PageNumberOptions,
  fontBaseUrl: string,
  name?: string,
): Promise<ArrayBuffer> {
  const doc = await loadPdf(bytes, name);
  const count = doc.getPageCount();
  const numbered = opts.skipFirst ? count - 1 : count;
  const total = opts.start + numbered - 1;
  const sample = formatPageLabel(opts.format, total, total);
  const font = await textFont(doc, sample, false, fontBaseUrl);
  const color = hexToRgb(opts.color);
  const m = opts.marginMm * MM;
  doc.getPages().forEach((page, i) => {
    if (opts.skipFirst && i === 0) return;
    const n = opts.start + (opts.skipFirst ? i - 1 : i);
    const label = formatPageLabel(opts.format, n, total);
    const { vw, vh, map, r } = placer(page);
    const w = font.widthOfTextAtSize(label, opts.size);
    const h = font.heightAtSize(opts.size, { descender: false });
    const col = opts.position[1];
    const vx = col === 'l' ? m : col === 'c' ? (vw - w) / 2 : vw - m - w;
    const vy = opts.position[0] === 't' ? vh - m - h : m;
    const p = map(vx, vy);
    page.drawText(label, { x: p.x, y: p.y, size: opts.size, font, color, rotate: degrees(r) });
  });
  return finish(doc);
}

// ---------------------------------------------------------------- Sıkıştır
export type CompressLevel = 'light' | 'recommended' | 'strong';
const LEVELS: Record<CompressLevel, { quality: number; maxDim: number }> = {
  light: { quality: 0.85, maxDim: 2600 },
  recommended: { quality: 0.72, maxDim: 1800 },
  strong: { quality: 0.55, maxDim: 1200 },
};

export interface CompressResult {
  bytes: ArrayBuffer;
  images: number;
  recompressed: number;
}

/**
 * Belgedeki JPEG görselleri küçültüp yeniden sıkıştırır, kullanılmayan nesneleri atar.
 * Taranmış ve fotoğraflı PDF'lerde büyük kazanç sağlar; metin seçilebilir kalır.
 */
export async function compressPdf(
  bytes: ArrayBuffer,
  level: CompressLevel,
  onProgress?: (done: number, total: number) => void,
  name?: string,
): Promise<CompressResult> {
  const { quality, maxDim } = LEVELS[level];
  const doc = await loadPdf(bytes, name);
  const ctx = doc.context;
  const isName = (v: unknown, n: string) => v?.toString() === `/${n}`;
  const candidates: [PDFRef, PDFRawStream][] = [];
  for (const [ref, obj] of ctx.enumerateIndirectObjects()) {
    if (!(obj instanceof PDFRawStream)) continue;
    const d = obj.dict;
    if (!isName(d.get(PDFName.of('Subtype')), 'Image')) continue;
    const filter = d.lookup(PDFName.of('Filter'));
    const filters = filter instanceof PDFArray ? filter.asArray().map((x) => x.toString()) : filter ? [filter.toString()] : [];
    // Son süzgeç JPEG (DCTDecode) olmalı; öncesinde ASCII85/Flate gibi katmanlar olabilir
    if (filters[filters.length - 1] !== '/DCTDecode') continue;
    if (filters.slice(0, -1).some((x) => !['/ASCII85Decode', '/ASCIIHexDecode', '/FlateDecode', '/LZWDecode', '/RunLengthDecode'].includes(x))) continue;
    if (d.get(PDFName.of('ImageMask'))?.toString() === 'true' || d.has(PDFName.of('Decode'))) continue;
    const cs = d.get(PDFName.of('ColorSpace'))?.toString() ?? '';
    if (/CMYK/i.test(cs)) continue;
    candidates.push([ref, obj]);
  }
  let recompressed = 0;
  for (let i = 0; i < candidates.length; i++) {
    onProgress?.(i, candidates.length);
    const [ref, obj] = candidates[i];
    const d = obj.dict;
    const hasMask = d.has(PDFName.of('SMask')) || d.has(PDFName.of('Mask'));
    let original = obj.getContents();
    const filterObj = d.lookup(PDFName.of('Filter'));
    if (filterObj instanceof PDFArray && filterObj.size() > 1) {
      // Üst katman süzgeçleri çöz, geriye saf JPEG kalsın
      const outer = d.clone(ctx);
      outer.set(PDFName.of('Filter'), ctx.obj(filterObj.asArray().slice(0, -1)));
      outer.delete(PDFName.of('DecodeParms'));
      try {
        original = decodePDFRawStream(PDFRawStream.of(outer, original)).decode();
      } catch {
        continue;
      }
    }
    const storedSize = obj.getContents().byteLength;
    let bmp: ImageBitmap;
    try {
      bmp = await createImageBitmap(new Blob([original as BlobPart], { type: 'image/jpeg' }));
    } catch {
      continue;
    }
    const scale = hasMask ? 1 : Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const gray = /Gray/i.test(d.get(PDFName.of('ColorSpace'))?.toString() ?? '');
    const canvas = new OffscreenCanvas(w, h);
    const g = canvas.getContext('2d')!;
    g.imageSmoothingQuality = 'high';
    g.drawImage(bmp, 0, 0, w, h);
    bmp.close();
    const out = new Uint8Array(await (await canvas.convertToBlob({ type: 'image/jpeg', quality })).arrayBuffer());
    // Gri görsel RGB'ye dönünce büyüyebilir; ancak belirgin kazanç varsa değiştir
    if (out.byteLength > Math.min(original.byteLength, storedSize) * (gray ? 0.7 : 0.92)) continue;
    const dict: Record<string, unknown> = {
      Type: 'XObject',
      Subtype: 'Image',
      Width: w,
      Height: h,
      ColorSpace: 'DeviceRGB',
      BitsPerComponent: 8,
      Filter: 'DCTDecode',
    };
    const stream = ctx.stream(out, dict as never);
    for (const key of ['SMask', 'Mask', 'Intent', 'Interpolate', 'Alt', 'OC', 'Metadata']) {
      const v = d.get(PDFName.of(key));
      if (v) stream.dict.set(PDFName.of(key), v);
    }
    ctx.assign(ref, stream);
    recompressed++;
  }
  onProgress?.(candidates.length, candidates.length);
  const saved = await finish(doc);
  return { bytes: saved, images: candidates.length, recompressed };
}

export async function pageCountOf(bytes: ArrayBuffer, name?: string) {
  return (await loadPdf(bytes, name)).getPageCount();
}

