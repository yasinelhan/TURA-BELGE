// Tura Belge — taranmış PDF'i aranabilir yapma
// SPDX-License-Identifier: AGPL-3.0-or-later
import { finish, loadPdf } from './pdfOps';
import { ocrImage, placeTextLayer, type OcrLang } from './ocr';
import { openRenderDoc } from './render';
import { __ } from '../../i18n';

export interface OcrPdfProgress {
  page: number; // 0'dan
  total: number;
  phase: 'okunuyor' | 'yukleniyor' | 'taniyor' | 'atlandi';
  progress: number; // sayfa içi 0–1
}

export interface OcrPdfResult {
  bytes: ArrayBuffer;
  /** Sayfa sayfa metin */
  pages: string[];
  recognized: number;
  /** Zaten seçilebilir metni olduğu için atlanan sayfalar (0'dan) */
  skipped: number[];
  confidence: number;
}

/** Bu kadar karakterden fazla seçilebilir metni olan sayfa "metinli" sayılır */
const HAS_TEXT = 40;

export async function ocrPdf(
  bytes: ArrayBuffer,
  opts: { lang: OcrLang; skipTextPages: boolean; pages?: number[]; name?: string },
  onProgress?: (p: OcrPdfProgress) => void,
  signal?: AbortSignal,
): Promise<OcrPdfResult> {
  const doc = await loadPdf(bytes, opts.name);
  const rd = await openRenderDoc(bytes);
  const pages: string[] = [];
  const skipped: number[] = [];
  let recognized = 0;
  let confSum = 0;
  try {
    const list = opts.pages ?? Array.from({ length: rd.pageCount }, (_, i) => i);
    for (const [k, i] of list.entries()) {
      if (signal?.aborted) throw new DOMException(__('İptal edildi'), 'AbortError');
      onProgress?.({ page: k, total: list.length, phase: 'okunuyor', progress: 0 });
      if (opts.skipTextPages) {
        const existing = await rd.text(i);
        if (existing.length >= HAS_TEXT) {
          skipped.push(i);
          pages[i] = existing;
          onProgress?.({ page: k, total: list.length, phase: 'atlandi', progress: 1 });
          continue;
        }
      }
      // ~300 dpi, ama telefonda bellek taşmasın diye uzun kenar en fazla 3400 piksel
      const { w, h } = rd.sizePt(i);
      const dpi = Math.min(300, 3400 / (Math.max(w, h) / 72));
      const image = await rd.render(i, dpi, 'image/png');
      const r = await ocrImage(image, opts.lang, (p) => onProgress?.({ page: k, total: list.length, phase: p.phase, progress: p.progress }));
      if (r.text) {
        await placeTextLayer(doc, doc.getPage(i), r.layer);
        recognized++;
        confSum += r.confidence;
      }
      pages[i] = r.text;
    }
  } finally {
    rd.close();
  }
  return {
    bytes: await finish(doc),
    pages: pages.map((t) => t ?? ''),
    recognized,
    skipped,
    confidence: recognized ? confSum / recognized : 0,
  };
}
