// Tura Belge — Yazı tanıma (OCR): taranmış PDF'i aranabilir yap, metnini çıkar
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState } from 'react';
import { useToolHost, type PdfInput } from './host';
import { pageCountOf } from './lib/pdfOps';
import { OCR_LANGS, closeOcr, type OcrLang } from './lib/ocr';
import { ocrPdf, type OcrPdfProgress, type OcrPdfResult } from './lib/ocrPdf';
import { ErrorNote, Field, FileChip, FilePicker, ResultPanel, Seg, ToolShell, errText, fmtSize, type Output } from './ui';
import { downloadFile } from '../lib/download';
import { __ } from '../i18n';

export function OcrTool() {
  const host = useToolHost();
  const [input, setInput] = useState<PdfInput | null>(null);
  const [fromEditor, setFromEditor] = useState<string | undefined>();
  const [lang, setLang] = useState<OcrLang>('tur+eng');
  const [skip, setSkip] = useState(true);
  const [prog, setProg] = useState<OcrPdfProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ out: Output[]; r: OcrPdfResult } | null>(null);
  const abort = useRef<AbortController | null>(null);

  useEffect(() => {
    if (host.preset) {
      setInput(host.preset);
      setFromEditor(host.preset.docId);
      host.clearPreset();
    }
  }, [host]);
  useEffect(
    () => () => {
      abort.current?.abort();
      // Yazı tanıma işçisi ~100 MB bellek tutar; araçtan çıkınca kapat
      void closeOcr();
    },
    [],
  );

  const reset = () => {
    setInput(null);
    setResult(null);
    setFromEditor(undefined);
    setError(null);
  };

  const run = async () => {
    if (!input) return;
    setError(null);
    setResult(null);
    const ac = new AbortController();
    abort.current = ac;
    setProg({ page: 0, total: 1, phase: 'okunuyor', progress: 0 });
    try {
      const r = await ocrPdf(input.bytes, { lang, skipTextPages: skip, name: input.name }, setProg, ac.signal);
      if (!r.recognized && r.skipped.length) {
        setError(null);
        setResult({ out: [], r });
        return;
      }
      setResult({
        out: [
          {
            name: fromEditor ? input.name : __('{0} (aranabilir)', [input.name]),
            ext: 'pdf',
            blob: new Blob([r.bytes], { type: 'application/pdf' }),
            pages: await pageCountOf(r.bytes),
          },
        ],
        r,
      });
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setError(errText(e));
    } finally {
      setProg(null);
      abort.current = null;
    }
  };

  if (!input) {
    return (
      <ToolShell id="ocr">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
        <p className="tool__hint">
          {__('Fotoğraftan ya da tarayıcıdan gelen PDF’lerdeki yazılar seçilebilir, aranabilir ve kopyalanabilir olur. Her şey cihazında yapılır.')}
        </p>
      </ToolShell>
    );
  }

  const busy = prog !== null;
  const pct = prog ? Math.round(((prog.page + (prog.phase === 'taniyor' ? prog.progress : 0)) / prog.total) * 100) : 0;
  const allText = result
    ? result.r.pages
        .map((t, i) => (result.r.pages.length > 1 ? __('— Sayfa {0} —\n{1}', [i + 1, t]) : t))
        .join('\n\n')
        .trim()
    : '';

  return (
    <ToolShell id="ocr">
      <FileChip name={input.name} detail={fmtSize(input.bytes.byteLength)} onClear={reset} />
      <div className="tool__options">
        <Field label={__('Belgenin dili')} group>
          <Seg label={__('Belgenin dili')} value={lang} onChange={(v) => (setLang(v), setResult(null))} options={OCR_LANGS} />
        </Field>
        <label className="check">
          <input type="checkbox" checked={skip} onChange={(e) => (setSkip(e.target.checked), setResult(null))} />
          {__('Zaten seçilebilir metni olan sayfaları atla')}
        </label>
      </div>
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy} onClick={run}>
          {busy ? __('Yazılar tanınıyor…') : __('Yazıları tanı')}
        </button>
        {busy && (
          <button className="btn btn--ghost" onClick={() => abort.current?.abort()}>
            {__('Durdur')}
          </button>
        )}
      </div>
      {prog && <OcrProgressBar prog={prog} pct={pct} />}
      <ErrorNote error={error} />
      {result && result.out.length === 0 && (
        <p className="info">{__('Bu belgenin bütün sayfalarında zaten seçilebilir metin var; yazı tanımaya gerek yok.')}</p>
      )}
      {result && result.out.length > 0 && (
        <>
          <ResultPanel
            outputs={result.out}
            replaceId={fromEditor}
            onReset={reset}
            note={
              <>
                {result.r.recognized} {__('sayfada yazı tanındı')}
                {result.r.skipped.length ? __(' · {0} sayfa zaten metinliydi', [result.r.skipped.length]) : ''}
                {result.r.recognized ? __(' · ortalama güven %{0}', [Math.round(result.r.confidence)]) : ''}{__('. PDF’te arama yapabilir, yazıları seçip kopyalayabilirsin.')}
              </>
            }
          />
          {allText && <TextPanel text={allText} name={input.name} />}
        </>
      )}
    </ToolShell>
  );
}

export function OcrProgressBar({ prog, pct }: { prog: OcrPdfProgress; pct: number }) {
  const label =
    prog.phase === 'yukleniyor'
      ? __('Yazı tanıma motoru hazırlanıyor… (ilk seferde biraz sürer, sonra çevrimdışı çalışır)')
      : prog.phase === 'atlandi'
        ? __('Sayfa {0} / {1}: zaten metinli, atlandı', [prog.page + 1, prog.total])
        : prog.phase === 'okunuyor'
          ? __('Sayfa {0} / {1} hazırlanıyor…', [prog.page + 1, prog.total])
          : __('Sayfa {0} / {1}: yazılar tanınıyor', [prog.page + 1, prog.total]);
  return (
    <div className="ocr-prog" role="status" aria-live="polite">
      <div className="ocr-prog__bar" aria-hidden="true">
        <span style={{ width: `${pct}%` }} />
      </div>
      <p>{label}</p>
    </div>
  );
}

export function TextPanel({ text, name }: { text: string; name: string }) {
  const [msg, setMsg] = useState<string | null>(null);
  const say = (m: string) => {
    setMsg(m);
    window.setTimeout(() => setMsg((x) => (x === m ? null : x)), 3000);
  };
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      say(__('Metin panoya kopyalandı'));
    } catch {
      say(__('Kopyalanamadı; metni seçip kendin kopyalayabilirsin'));
    }
  };
  const save = async () => {
    const r = await downloadFile(`${name}.txt`, new Blob([text], { type: 'text/plain;charset=utf-8' }));
    say(r === 'saved' ? __('{0}.txt indirildi', [name]) : r === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
  };
  return (
    <section className="ocr-text" aria-labelledby="ocr-text-title">
      <div className="ocr-text__head">
        <h2 id="ocr-text-title">{__('Tanınan metin')}</h2>
        <div className="ocr-text__acts">
          <button className="btn btn--ghost btn--sm" onClick={copy}>
            {__('Metni kopyala')}
          </button>
          <button className="btn btn--ghost btn--sm" onClick={save}>
            {__('.txt indir')}
          </button>
        </div>
      </div>
      <textarea className="ocr-text__area" readOnly value={text} rows={12} aria-labelledby="ocr-text-title" />
      {msg && <p className="result__msg">{msg}</p>}
    </section>
  );
}
