// Tura Belge — PDF birleştirme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useState } from 'react';
import { useEditorPreset, type PdfInput } from './host';
import { mergePdfs, pageCountOf } from './lib/pdfOps';
import { ErrorNote, FilePicker, ResultPanel, Thumb, ToolIcon, ToolShell, errText, fmtSize, useRenderDoc, type Output } from './ui';
import { __ } from '../i18n';

type Item = PdfInput & { key: string; pages: number | null };
let seq = 0;

function MergeRow({
  item,
  index,
  count,
  onMove,
  onRemove,
}: {
  item: Item;
  index: number;
  count: number;
  onMove: (from: number, to: number) => void;
  onRemove: () => void;
}) {
  const { doc } = useRenderDoc(item.bytes);
  return (
    <li className="mergerow">
      <span className="mergerow__n">{index + 1}</span>
      <div className="mergerow__thumb">
        <Thumb doc={doc} index={0} width={64} />
      </div>
      <span className="mergerow__name">
        {item.name}
        <small>
          {item.pages === null ? __('okunamadı') : __('{0} sayfa', [item.pages])} · {fmtSize(item.bytes.byteLength)}
        </small>
      </span>
      <span className="mergerow__acts">
        <button className="icon-btn icon-btn--mini" aria-label={__('Yukarı taşı')} disabled={index === 0} onClick={() => onMove(index, index - 1)}>
          <ToolIcon path="M6 15l6-6 6 6" size={18} />
        </button>
        <button className="icon-btn icon-btn--mini" aria-label={__('Aşağı taşı')} disabled={index === count - 1} onClick={() => onMove(index, index + 1)}>
          <ToolIcon path="M6 9l6 6 6-6" size={18} />
        </button>
        <button className="icon-btn icon-btn--mini icon-btn--danger" aria-label={__('{0} dosyasını çıkar', [item.name])} onClick={onRemove}>
          <ToolIcon path="M6 6l12 12M18 6L6 18" size={18} />
        </button>
      </span>
    </li>
  );
}

export function MergeTool() {
  const [items, setItems] = useState<Item[]>([]);
  const [name, setName] = useState(__('Birleştirilmiş belge'));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Output[] | null>(null);

  const add = async (files: PdfInput[]) => {
    setResult(null);
    const added = await Promise.all(
      files.map(async (f) => ({ ...f, key: `m${++seq}`, pages: await pageCountOf(f.bytes, f.name).catch(() => null) })),
    );
    setItems((prev) => [...prev, ...added]);
    const bad = added.find((a) => a.pages === null);
    setError(bad ? __('“{0}” açılamadı (parolalı ya da bozuk olabilir); birleştirmeden önce çıkarın.', [bad.name]) : null);
  };
  // Belgeden gelindiyse o belge ilk sırada; sonuç aynı belgenin yerine geçer
  const [fromEditor] = useEditorPreset((p) => {
    void add([p]);
    setName(p.name);
  });
  const move = (from: number, to: number) =>
    setItems((prev) => {
      const next = [...prev];
      const [x] = next.splice(from, 1);
      next.splice(to, 0, x);
      return next;
    });

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const bytes = await mergePdfs(items);
      const pages = items.reduce((s, i) => s + (i.pages ?? 0), 0);
      setResult([{ name: name.trim() || __('Birleştirilmiş belge'), ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages }]);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };

  const totalPages = items.reduce((s, i) => s + (i.pages ?? 0), 0);
  return (
    <ToolShell id="birlestir">
      {items.length > 0 && (
        <>
          <ol className="mergelist">
            {items.map((it, i) => (
              <MergeRow
                key={it.key}
                item={it}
                index={i}
                count={items.length}
                onMove={move}
                onRemove={() => setItems((p) => p.filter((x) => x.key !== it.key))}
              />
            ))}
          </ol>
          <p className="tool__hint">{__('Dosyalar bu sırayla birleştirilir; okları kullanarak sırayı değiştir.')}</p>
        </>
      )}
      <FilePicker kind="pdf" multiple compact={items.length > 0} label={items.length ? __('Başka PDF ekle') : undefined} onPdfs={add} />
      <ErrorNote error={error} />
      {items.length > 0 && (
        <div className="tool__options">
          <label className="field">
            <span className="field__label">{__('Yeni dosyanın adı')}</span>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
          </label>
        </div>
      )}
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy || items.length < 2 || items.some((i) => i.pages === null)} onClick={run}>
          {busy ? __('Birleştiriliyor…') : items.length < 2 ? __('En az iki PDF seç') : __('{0} dosyayı birleştir ({1} sayfa)', [items.length, totalPages])}
        </button>
      </div>
      {result && <ResultPanel outputs={result} replaceId={fromEditor} onReset={() => (setItems([]), setResult(null))} />}
    </ToolShell>
  );
}
