// Tura Belge — Belge tara: kamerayla çek ya da fotoğraf seç, kenarları bul, düz A4 PDF yap
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useCallback, useEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';
import { imagesToPdf, type ImagesToPdfOptions } from './lib/pdfOps';
import {
  FILTERS,
  canvasToBlob,
  detectQuad,
  fullQuad,
  loadCv,
  processPage,
  quadOk,
  type Pt,
  type Quad,
  type Rotation,
  type ScanFilter,
} from './lib/scan';
import { OCR_LANGS, closeOcr, ocrImage, type OcrLang, type OcrResult } from './lib/ocr';
import { TextPanel } from './OcrTool';
import { vectorizeImages, type VectorProgress } from './lib/vectorPdf';
import type { VectorPage } from './lib/vectorize';
import { VectorProgressBar } from './VectorTool';
import { ErrorNote, Field, FilePicker, ResultPanel, Seg, ToolIcon, ToolShell, errText, type Output } from './ui';
import { __, N_, locale } from '../i18n';

interface Page {
  key: string;
  /** Çekilen fotoğrafın kendisi */
  file: Blob;
  srcUrl: string;
  quad: Quad;
  found: boolean;
  filter: ScanFilter;
  rotate: Rotation;
  out: Blob | null;
  outUrl: string | null;
  busy: boolean;
}

let seq = 0;
const today = () => new Intl.DateTimeFormat(locale(), { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date());
const coarse = () => typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;

const I = {
  camera: 'M4 8h3l2-3h6l2 3h3v11H4zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  gallery: 'M4 5h16v14H4zM4 15l4-4 4 4 3-3 5 5M15 9.5a1.5 1.5 0 1 0 0-.01',
  crop: 'M7 3v14h14M3 7h14v14',
  left: 'M14 6l-6 6 6 6',
  right: 'M10 6l6 6-6 6',
  close: 'M6 6l12 12M18 6L6 18',
  rotL: 'M9 4L5 8l4 4M5 8h9a5 5 0 0 1 0 10h-3',
  rotR: 'M15 4l4 4-4 4M19 8h-9a5 5 0 0 0 0 10h3',
  auto: 'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M9 12l2 2 4-4',
  full: 'M4 4h16v16H4z',
};

export function ScanTool() {
  const [pages, setPages] = useState<Page[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [engine, setEngine] = useState<'loading' | 'ready' | 'error'>('loading');
  const [size, setSize] = useState<ImagesToPdfOptions['pageSize']>('a4');
  const [name, setName] = useState(__('Tarama {0}', [today()]));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ out: Output[]; text: string; recognized: number } | null>(null);
  const [ocrOn, setOcrOn] = useState(true);
  const [ocrLang, setOcrLang] = useState<OcrLang>('tur+eng');
  const [output, setOutput] = useState<'vektor' | 'gorsel'>('vektor');
  const [prog, setProg] = useState<VectorProgress | null>(null);
  /** Aynı sayfa tekrar tanınmasın / çevrilmesin */
  const ocrCache = useRef(new Map<string, { out: Blob; lang: OcrLang; res: OcrResult }>());
  const vecCache = useRef(new Map<Blob, { key: string; v: VectorPage; ocr?: { text: string; layer: Uint8Array } }>());
  const cam = useRef<HTMLInputElement>(null);
  const gal = useRef<HTMLInputElement>(null);
  const latest = useRef<Page[]>([]);
  latest.current = pages;
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const isTouch = useRef(coarse()).current;

  const startEngine = useCallback(() => {
    setEngine('loading');
    loadCv().then(
      () => setEngine('ready'),
      (e) => {
        console.error('Tarama motoru yüklenemedi', e);
        setEngine('error');
      },
    );
  }, []);
  useEffect(startEngine, [startEngine]);
  useEffect(
    () => () => {
      latest.current.forEach((p) => {
        URL.revokeObjectURL(p.srcUrl);
        if (p.outUrl) URL.revokeObjectURL(p.outUrl);
      });
      void closeOcr();
    },
    [],
  );

  const patch = (key: string, ch: Partial<Page>) =>
    setPages((ps) =>
      ps.map((p) => {
        if (p.key !== key) return p;
        if (ch.outUrl !== undefined && p.outUrl && p.outUrl !== ch.outUrl) URL.revokeObjectURL(p.outUrl);
        return { ...p, ...ch };
      }),
    );

  /** Sayfaları sırayla işler (telefonda bellek taşmasın diye) */
  const enqueue = <T,>(job: () => Promise<T>) => {
    const p = queue.current.then(job, job);
    queue.current = p.catch(() => undefined);
    return p;
  };

  const render = (key: string, file: Blob, quad: Quad, filter: ScanFilter, rotate: Rotation) => {
    patch(key, { busy: true });
    return enqueue(async () => {
      try {
        const canvas = await processPage(file, quad, filter, rotate);
        const out = await canvasToBlob(canvas, filter);
        canvas.width = canvas.height = 0;
        patch(key, { out, outUrl: URL.createObjectURL(out), busy: false });
      } catch (e) {
        patch(key, { busy: false });
        setError(errText(e));
      }
    });
  };

  const add = async (files: File[]) => {
    setResult(null);
    setError(null);
    const filter = latest.current[0]?.filter ?? 'belge';
    const fresh: Page[] = files.map((file) => ({
      key: `s${++seq}`,
      file,
      srcUrl: URL.createObjectURL(file),
      quad: fullQuad(),
      found: false,
      filter,
      rotate: 0,
      out: null,
      outUrl: null,
      busy: true,
    }));
    setPages((ps) => [...ps, ...fresh]);
    for (const p of fresh) {
      try {
        const { quad, found } = await enqueue(() => detectQuad(p.file));
        patch(p.key, { quad, found });
        // Tek fotoğraf çekildiyse köşeleri hemen göster (CamScanner gibi)
        if (fresh.length === 1) setEditing(p.key);
        void render(p.key, p.file, quad, p.filter, p.rotate);
      } catch (e) {
        patch(p.key, { busy: false });
        setError(engine === 'error' ? __('Tarama motoru yüklenemedi.') : errText(e));
      }
    }
  };

  const move = (from: number, to: number) =>
    setPages((p) => {
      const n = [...p];
      const [x] = n.splice(from, 1);
      n.splice(to, 0, x);
      return n;
    });
  const remove = (key: string) => {
    setResult(null);
    setPages((ps) => {
      const x = ps.find((p) => p.key === key);
      if (x) {
        URL.revokeObjectURL(x.srcUrl);
        if (x.outUrl) URL.revokeObjectURL(x.outUrl);
      }
      return ps.filter((p) => p.key !== key);
    });
  };
  const setAllFilters = (f: ScanFilter) => {
    setResult(null);
    for (const p of latest.current) {
      if (p.filter === f) continue;
      patch(p.key, { filter: f });
      void render(p.key, p.file, p.quad, f, p.rotate);
    }
  };

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      await queue.current;
      const ready = latest.current.filter((p) => p.out);
      const fileName = name.trim() || __('Tarama {0}', [today()]);
      if (output === 'vektor') {
        // Siyah-beyaz ya da gri seçildiyse vektör de tek renk olur
        const mono = ready.every((p) => p.filter === 'sb' || p.filter === 'gri');
        const r = await vectorizeImages(
          ready.map((p) => p.out!),
          { colors: mono ? 'mono' : 'auto', photos: 'keep', ocr: ocrOn ? ocrLang : null, keepTextPages: false, pageSize: size === 'letter' ? 'letter' : 'a4' },
          setProg,
          undefined,
          vecCache.current,
        );
        setResult({
          out: [{ name: fileName, ext: 'pdf', blob: new Blob([r.bytes], { type: 'application/pdf' }), pages: ready.length }],
          text: r.texts.map((t, i) => (r.texts.length > 1 ? __('— Sayfa {0} —\n{1}', [i + 1, t]) : t)).join('\n\n').trim(),
          recognized: r.texts.filter(Boolean).length,
        });
        return;
      }
      const layers: (OcrResult | null)[] = [];
      if (ocrOn) {
        for (const [i, p] of ready.entries()) {
          const c = ocrCache.current.get(p.key);
          if (c && c.out === p.out && c.lang === ocrLang) {
            layers.push(c.res);
            continue;
          }
          setProg({ page: i, total: ready.length, phase: 'okunuyor', progress: 0 });
          const res = await ocrImage(p.out!, ocrLang, (x) => setProg({ page: i, total: ready.length, phase: x.phase, progress: x.progress }));
          ocrCache.current.set(p.key, { out: p.out!, lang: ocrLang, res });
          layers.push(res);
        }
        setProg(null);
      }
      const bytes = await imagesToPdf(
        ready.map((p, i) => ({
          name: `sayfa-${i + 1}.${p.filter === 'sb' ? 'png' : 'jpg'}`,
          file: p.out!,
          textLayer: layers[i]?.text ? layers[i]!.layer : undefined,
        })),
        { pageSize: size, orientation: 'auto', marginMm: 0 },
      );
      const texts = layers.map((l) => l?.text ?? '');
      setResult({
        out: [{ name: fileName, ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages: ready.length }],
        text: texts.map((t, i) => (texts.length > 1 ? __('— Sayfa {0} —\n{1}', [i + 1, t]) : t)).join('\n\n').trim(),
        recognized: texts.filter(Boolean).length,
      });
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
      setProg(null);
    }
  };

  const reset = () => {
    latest.current.forEach((p) => {
      URL.revokeObjectURL(p.srcUrl);
      if (p.outUrl) URL.revokeObjectURL(p.outUrl);
    });
    setPages([]);
    setResult(null);
    ocrCache.current.clear();
    vecCache.current.clear();
    setName(__('Tarama {0}', [today()]));
  };

  const edited = pages.find((p) => p.key === editing);
  const working = pages.some((p) => p.busy);
  const commonFilter = pages.length && pages.every((p) => p.filter === pages[0].filter) ? pages[0].filter : null;

  const inputs = (
    <>
      <input
        ref={cam}
        type="file"
        accept="image/*"
        capture="environment"
        hidden
        onChange={(e) => {
          void add(Array.from(e.target.files ?? []));
          e.target.value = '';
        }}
      />
      <input
        ref={gal}
        type="file"
        accept="image/*"
        multiple
        hidden
        onChange={(e) => {
          void add(Array.from(e.target.files ?? []));
          e.target.value = '';
        }}
      />
    </>
  );

  if (edited) {
    return (
      <ToolShell id="tara">
        <CornerEditor
          page={edited}
          index={pages.indexOf(edited)}
          total={pages.length}
          onCancel={() => setEditing(null)}
          onDelete={() => {
            remove(edited.key);
            setEditing(null);
          }}
          onDone={(quad, filter, rotate) => {
            setEditing(null);
            setResult(null);
            const changed =
              filter !== edited.filter || rotate !== edited.rotate || quad.some((q, i) => q.x !== edited.quad[i].x || q.y !== edited.quad[i].y);
            if (!changed) return;
            patch(edited.key, { quad, filter, rotate, found: true });
            void render(edited.key, edited.file, quad, filter, rotate);
          }}
        />
      </ToolShell>
    );
  }

  return (
    <ToolShell id="tara">
      {inputs}
      {engine === 'loading' && (
        <p className="scan-engine" role="status">
          <span className="scan-spin" aria-hidden="true" /> {__('Tarama motoru hazırlanıyor… İlk seferde biraz sürebilir, sonra çevrimdışı da çalışır.')}
        </p>
      )}
      {engine === 'error' && (
        <p className="alert">
          {__('Tarama motoru yüklenemedi. İnternet bağlantını kontrol edip')}{' '}
          <button className="link-btn" style={{ minHeight: 0, margin: 0 }} onClick={startEngine}>
            {__('yeniden dene')}
          </button>
          .
        </p>
      )}

      {pages.length === 0 ? (
        isTouch ? (
          <div className="scan-start">
            <button className="scan-big" onClick={() => cam.current?.click()}>
              <ToolIcon path={I.camera} size={40} />
              <span>{__('Kamerayla çek')}</span>
              <small>{__('Kâğıdı düz bir zemine koy, tamamı görünsün.')}</small>
            </button>
            <button className="btn btn--ghost" onClick={() => gal.current?.click()}>
              <ToolIcon path={I.gallery} size={18} /> {__('Galeriden seç')}
            </button>
          </div>
        ) : (
          <FilePicker kind="image" multiple label={__('Belge fotoğraflarını buraya bırak')} onImages={add} />
        )
      ) : (
        <>
          <ol className="imggrid scan-grid">
            {pages.map((p, i) => (
              <li key={p.key} className="imgcard">
                <button className="imgcard__img scan-card__img" onClick={() => setEditing(p.key)} aria-label={__('{0}. sayfanın köşelerini ayarla', [i + 1])}>
                  {p.outUrl ? <img src={p.outUrl} alt="" /> : <span className="thumb__ph" />}
                  {p.busy && <span className="scan-card__busy" aria-hidden="true"><span className="scan-spin" /></span>}
                  {!p.found && !p.busy && <span className="scan-card__flag">{__('Kenar bulunamadı, kontrol et')}</span>}
                </button>
                <div className="pagecard__foot">
                  <span className="pagecard__num">{i + 1}</span>
                  <span className="pagecard__acts">
                    <button className="icon-btn icon-btn--mini" aria-label={__('Öne al')} disabled={i === 0} onClick={() => move(i, i - 1)}>
                      <ToolIcon path={I.left} size={16} />
                    </button>
                    <button className="icon-btn icon-btn--mini" aria-label={__('Geriye al')} disabled={i === pages.length - 1} onClick={() => move(i, i + 1)}>
                      <ToolIcon path={I.right} size={16} />
                    </button>
                    <button className="icon-btn icon-btn--mini icon-btn--tool" aria-label={__('{0}. sayfayı kırp', [i + 1])} onClick={() => setEditing(p.key)}>
                      <ToolIcon path={I.crop} size={16} />
                    </button>
                    <button className="icon-btn icon-btn--mini icon-btn--danger" aria-label={__('{0}. sayfayı sil', [i + 1])} onClick={() => remove(p.key)}>
                      <ToolIcon path={I.close} size={16} />
                    </button>
                  </span>
                </div>
              </li>
            ))}
          </ol>
          <div className="scan-more">
            {isTouch && (
              <button className="btn btn--primary" onClick={() => cam.current?.click()}>
                <ToolIcon path={I.camera} size={18} /> {__('Sayfa çek')}
              </button>
            )}
            <button className="btn btn--ghost" onClick={() => gal.current?.click()}>
              <ToolIcon path={I.gallery} size={18} /> {isTouch ? __('Galeriden ekle') : __('Fotoğraf ekle')}
            </button>
          </div>

          <div className="tool__options">
            <Field label={__('Görünüm (tüm sayfalar)')} group>
              <Seg label={__('Görünüm')} value={commonFilter ?? ('' as ScanFilter)} onChange={setAllFilters} options={FILTERS} />
            </Field>
            <Field
              label={__('Çıktı')}
              group
              hint={
                output === 'vektor'
                  ? __('Yazılar ve çizimler düzgün eğrilere çevrilir: yakınlaştırınca keskin kalır, dosya küçük olur. Fotoğraflar görüntü olarak kalır.')
                  : __('Sayfa fotoğraf olarak eklenir; yakınlaştırınca pikseller görünür.')
              }
            >
              <Seg
                label={__('Çıktı')}
                value={output}
                onChange={(v) => (setOutput(v), setResult(null))}
                options={[
                  { v: 'vektor', t: 'Vektör (keskin)' },
                  { v: 'gorsel', t: 'Fotoğraf' },
                ]}
              />
            </Field>
            <Field label={__('Sayfa boyutu')} group>
              <Seg
                label={__('Sayfa boyutu')}
                value={size}
                onChange={(v) => (setSize(v), setResult(null))}
                options={[
                  { v: 'a4', t: 'A4' },
                  { v: 'letter', t: 'Letter' },
                ]}
              />
            </Field>
            <Field label={__('Dosya adı')}>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <label className="check">
              <input type="checkbox" checked={ocrOn} onChange={(e) => (setOcrOn(e.target.checked), setResult(null))} />
              {__('Yazıları tanı: PDF’te arama yapılabilsin, metin kopyalanabilsin')}
            </label>
            {ocrOn && (
              <Field label={__('Belgenin dili')} group>
                <Seg label={__('Belgenin dili')} value={ocrLang} onChange={(v) => (setOcrLang(v), setResult(null))} options={OCR_LANGS} />
              </Field>
            )}
          </div>
        </>
      )}
      <ErrorNote error={error} />
      {pages.length > 0 && (
        <div className="tool__cta">
          <button className="btn btn--primary" disabled={busy || working || !pages.some((p) => p.out)} onClick={run}>
            {busy
              ? prog?.phase === 'vektor'
                ? __('Vektöre çevriliyor…')
                : prog
                  ? __('Yazılar tanınıyor…')
                  : __('PDF hazırlanıyor…')
              : working
                ? __('Sayfalar hazırlanıyor…')
                : __('{0} sayfalık PDF oluştur', [pages.length])}
          </button>
        </div>
      )}
      {prog && (
        <VectorProgressBar
          prog={prog}
          pct={Math.round(((prog.page + (prog.phase === 'taniyor' ? 0.5 + prog.progress / 2 : prog.phase === 'vektor' ? 0.3 : 0)) / prog.total) * 100)}
        />
      )}
      {result && (
        <>
          <ResultPanel
            outputs={result.out}
            onReset={reset}
            note={[
              output === 'vektor' ? __('Sayfalar vektöre çevrildi: yakınlaştırınca yazılar keskin kalır.') : '',
              ocrOn
                ? result.recognized
                  ? __('Yazılar tanındı: PDF’te arama yapabilir, metni seçip kopyalayabilirsin.')
                  : __('Sayfalarda tanınabilir yazı bulunamadı.')
                : '',
            ]
              .filter(Boolean)
              .join(' ') || undefined}
          />
          {result.text && <TextPanel text={result.text} name={name.trim() || __('Tarama')} />}
        </>
      )}
    </ToolShell>
  );
}

// ------------------------------------------------------------------ Köşe ayarı
const CORNER_NAMES = [N_('Sol üst'), N_('Sağ üst'), N_('Sağ alt'), N_('Sol alt')];
const clamp = (v: number) => Math.min(1, Math.max(0, v));

function CornerEditor({
  page,
  index,
  total,
  onDone,
  onCancel,
  onDelete,
}: {
  page: Page;
  index: number;
  total: number;
  onDone: (q: Quad, f: ScanFilter, r: Rotation) => void;
  onCancel: () => void;
  onDelete: () => void;
}) {
  const [quad, setQuad] = useState<Quad>(page.quad);
  const [filter, setFilter] = useState<ScanFilter>(page.filter);
  const [rotate, setRotate] = useState<Rotation>(page.rotate);
  const [drag, setDrag] = useState<number | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [note, setNote] = useState<string | null>(page.found ? null : __('Kâğıdın kenarları bulunamadı, fotoğrafın tamamı alındı. Gerekirse köşeleri sürükleyerek ayarla.'));
  const box = useRef<HTMLDivElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const grab = useRef<{ dx: number; dy: number } | null>(null);

  // Telefonda fotoğrafın tamamı ve alttaki düğmeler aynı anda görünsün
  useEffect(() => {
    root.current?.scrollIntoView({ block: 'start' });
  }, [page.key]);

  // Arka planda bulunan köşeler sonradan gelirse güncelle
  useEffect(() => {
    setQuad(page.quad);
    if (page.found) setNote(null);
  }, [page.quad, page.found]);

  const valid = quadOk(quad);

  // Canlı önizleme (sürükleme bitince)
  useEffect(() => {
    if (drag !== null || !valid) return;
    let alive = true;
    let url: string | null = null;
    const t = window.setTimeout(async () => {
      try {
        const c = await processPage(page.file, quad, filter, rotate, 1100);
        const b = await canvasToBlob(c, filter);
        if (!alive) return;
        url = URL.createObjectURL(b);
        setPreview(url);
      } catch {
        /* önizleme olmasa da olur */
      }
    }, 200);
    return () => {
      alive = false;
      window.clearTimeout(t);
      if (url) window.setTimeout(() => URL.revokeObjectURL(url!), 1000);
    };
  }, [page.file, quad, filter, rotate, drag, valid]);

  const posOf = (e: PointerEvent): Pt => {
    const r = box.current!.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
  };
  const down = (i: number) => (e: PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const p = posOf(e);
    grab.current = { dx: quad[i].x - p.x, dy: quad[i].y - p.y };
    setDrag(i);
  };
  const moveTo = (i: number) => (e: PointerEvent<HTMLButtonElement>) => {
    if (drag !== i || !grab.current) return;
    const p = posOf(e);
    const g = grab.current;
    setQuad((q) => q.map((c, k) => (k === i ? { x: clamp(p.x + g.dx), y: clamp(p.y + g.dy) } : c)) as Quad);
  };
  const up = () => {
    grab.current = null;
    setDrag(null);
  };
  const key = (i: number) => (e: KeyboardEvent<HTMLButtonElement>) => {
    const step = e.shiftKey ? 0.02 : 0.004;
    const d = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
    if (!d) return;
    e.preventDefault();
    setQuad((q) => q.map((c, k) => (k === i ? { x: clamp(c.x + d[0]), y: clamp(c.y + d[1]) } : c)) as Quad);
  };

  const auto = async () => {
    setDetecting(true);
    try {
      const r = await detectQuad(page.file);
      setQuad(r.quad);
      setNote(r.found ? null : __('Kenarlar bulunamadı. Köşeleri elle ayarla.'));
    } finally {
      setDetecting(false);
    }
  };

  const pts = quad.map((p) => `${p.x * 1000},${p.y * 1000}`).join(' ');
  const d = drag !== null ? quad[drag] : null;
  const zoom = 2.6;
  const rect = box.current?.getBoundingClientRect();

  return (
    <div className="scan-edit" ref={root}>
      <div className="scan-edit__head">
        <h2>
          {__('{0}. sayfa', [index + 1])} <small>/ {total}</small>
        </h2>
        <p>{__('Köşeleri kâğıdın köşelerine sürükle.')}{coarse() ? '' : __(' Ok tuşlarıyla da ince ayar yapabilirsin.')}</p>
      </div>
      <div className="scan-edit__body">
        <div className="scan-stage">
          <div className="scan-crop" ref={box}>
            <img src={page.srcUrl} alt={__('Çekilen fotoğraf')} draggable={false} />
            <svg className="scan-crop__svg" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true">
              <path className="scan-crop__mask" fillRule="evenodd" d={`M0 0H1000V1000H0Z M${pts.replace(/ /g, ' L')}Z`} />
              <polygon className={valid ? 'scan-crop__line' : 'scan-crop__line scan-crop__line--bad'} points={pts} />
            </svg>
            {quad.map((c, i) => (
              <button
                key={i}
                className={drag === i ? 'scan-handle scan-handle--on' : 'scan-handle'}
                style={{ left: `${c.x * 100}%`, top: `${c.y * 100}%` }}
                aria-label={__('{0} köşe', [__(CORNER_NAMES[i])])}
                onPointerDown={down(i)}
                onPointerMove={moveTo(i)}
                onPointerUp={up}
                onPointerCancel={up}
                onKeyDown={key(i)}
              />
            ))}
            {d && rect && (
              <div
                className="scan-loupe"
                aria-hidden="true"
                style={{
                  // Parmağın üstünde dursun; üst kenara çok yakınsa altına geçsin
                  left: d.x * rect.width - 60,
                  top: d.y * rect.height - 60 + (d.y * rect.height > 150 ? -95 : 95),
                  backgroundImage: `url(${page.srcUrl})`,
                  backgroundSize: `${rect.width * zoom}px ${rect.height * zoom}px`,
                  backgroundPosition: `${60 - d.x * rect.width * zoom}px ${60 - d.y * rect.height * zoom}px`,
                }}
              />
            )}
          </div>
        </div>
        <div className="scan-side">
          <div className="scan-preview">
            {preview ? <img src={preview} alt={__('Sonucun önizlemesi')} /> : <span className="thumb__ph" />}
          </div>
          {!valid && <p className="alert">{__('Köşeler birbirinin üstüne geçmiş. Sırayla sol üst, sağ üst, sağ alt, sol alt olacak şekilde yerleştir.')}</p>}
          {note && valid && <p className="scan-note">{note}</p>}
          <Field label={__('Görünüm')} group>
            <Seg label={__('Görünüm')} value={filter} onChange={setFilter} options={FILTERS} />
          </Field>
          <div className="scan-tools" role="group" aria-label={__('Kırpma araçları')}>
            <button className="btn btn--ghost btn--sm" onClick={() => setRotate((r) => ((r + 270) % 360) as Rotation)}>
              <ToolIcon path={I.rotL} size={18} /> {__('Sola döndür')}
            </button>
            <button className="btn btn--ghost btn--sm" onClick={() => setRotate((r) => ((r + 90) % 360) as Rotation)}>
              <ToolIcon path={I.rotR} size={18} /> {__('Sağa döndür')}
            </button>
            <button className="btn btn--ghost btn--sm" onClick={auto} disabled={detecting}>
              <ToolIcon path={I.auto} size={18} /> {detecting ? __('Aranıyor…') : __('Kenarları bul')}
            </button>
            <button className="btn btn--ghost btn--sm" onClick={() => setQuad(fullQuad())}>
              <ToolIcon path={I.full} size={18} /> {__('Fotoğrafın tamamı')}
            </button>
          </div>
        </div>
      </div>
      <div className="scan-edit__cta">
        <button className="btn btn--primary" disabled={!valid} onClick={() => onDone(quad, filter, rotate)}>
          {__('Tamam')}
        </button>
        <button className="btn btn--ghost" onClick={onCancel}>
          {__('Vazgeç')}
        </button>
        <button className="btn btn--ghost scan-del" onClick={onDelete}>
          {__('Sayfayı sil')}
        </button>
      </div>
    </div>
  );
}
