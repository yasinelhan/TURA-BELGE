// Tura Belge — Filigran ve sayfa numarası (canlı önizlemeli)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useMemo, useState } from 'react';
import { useEditorPreset, type PdfInput } from './host';
import { addPageNumbers, addWatermark, formatPageLabel, pageCountOf, type NumberPos } from './lib/pdfOps';
import { parseRanges } from './lib/pageRanges';
import { ErrorNote, Field, FileChip, FilePicker, ResultPanel, Seg, Thumb, ToolShell, errText, useRenderDoc, type Output } from './ui';
import { __, N_ } from '../i18n';

const fontBase = () => new URL('vendor/fonts/', document.baseURI).href;
const COLORS = [
  { c: '#E5484D', t: N_('Kırmızı') },
  { c: '#9AA0B5', t: N_('Gri') },
  { c: '#0B7A8F', t: N_('Turkuaz') },
  { c: '#142C93', t: N_('Kobalt') },
  { c: '#14205A', t: N_('Lacivert') },
  { c: '#000000', t: N_('Siyah') },
];

function Swatches({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="swatches" role="radiogroup" aria-label={__('Renk')}>
      {COLORS.map((s) => (
        <button
          key={s.c}
          role="radio"
          aria-checked={value === s.c}
          aria-label={__(s.t)}
          title={__(s.t)}
          className={value === s.c ? 'swatch swatch--on' : 'swatch'}
          style={{ background: s.c }}
          onClick={() => onChange(s.c)}
        />
      ))}
    </div>
  );
}

let measureCtx: CanvasRenderingContext2D | null = null;
function emWidth(text: string, bold = true) {
  measureCtx ??= document.createElement('canvas').getContext('2d');
  if (!measureCtx) return text.length * 0.6;
  measureCtx.font = `${bold ? 'bold ' : ''}100px Helvetica, Arial, sans-serif`;
  return measureCtx.measureText(text).width / 100;
}

function useInput() {
  const [input, setInput] = useState<PdfInput | null>(null);
  const [fromEditor] = useEditorPreset(setInput);
  const [result, setResult] = useState<Output[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { doc, error: openError } = useRenderDoc(input?.bytes);
  return { input, setInput, result, setResult, error, setError, busy, setBusy, doc, openError, fromEditor };
}

// ---------------------------------------------------------------- Filigran
export function WatermarkTool() {
  const s = useInput();
  const [text, setText] = useState('TASLAK');
  const [sizePct, setSizePct] = useState(60);
  const [color, setColor] = useState('#E5484D');
  const [opacity, setOpacity] = useState(0.25);
  const [angle, setAngle] = useState<'45' | '0'>('45');
  const [tiled, setTiled] = useState<'single' | 'tiled'>('single');
  const [which, setWhich] = useState<'all' | 'range'>('all');
  const [range, setRange] = useState('');
  const total = s.doc?.pageCount ?? 0;
  const dirty = () => s.setResult(null);

  const ratio = useMemo(() => emWidth(text.trim() || ' '), [text]);
  const fontCqw = (tiled === 'tiled' ? 0.28 : 1) * (sizePct / Math.max(ratio, 0.1));
  const rows = tiled === 'tiled' ? 9 : 1;
  const overlay = (
    <div className="wm" aria-hidden="true">
      <div
        className={tiled === 'tiled' ? 'wm__inner wm__inner--tiled' : 'wm__inner'}
        style={{ transform: `translate(-50%, -50%) rotate(${-Number(angle)}deg)`, color, opacity, fontSize: `${fontCqw}cqw` }}
      >
        {Array.from({ length: rows }, (_, r) => (
          <div key={r} className="wm__row" style={tiled === 'tiled' ? { marginLeft: r % 2 ? '1.6em' : 0 } : undefined}>
            {Array.from({ length: tiled === 'tiled' ? 6 : 1 }, (_, k) => (
              <span key={k}>{text}</span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );

  const run = async () => {
    if (!s.input) return;
    s.setError(null);
    let pages: number[] | null = null;
    if (which === 'range') {
      const r = parseRanges(range, total);
      if (r.error) return s.setError(r.error);
      pages = [...new Set(r.groups.flat())];
    }
    s.setBusy(true);
    try {
      const bytes = await addWatermark(
        s.input.bytes,
        { text, sizePct, color, opacity, angle: Number(angle), tiled: tiled === 'tiled', pages },
        fontBase(),
        s.input.name,
      );
      s.setResult([{ name: __('{0} (filigranlı)', [s.input.name]), ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages: await pageCountOf(bytes) }]);
    } catch (e) {
      s.setError(errText(e));
    } finally {
      s.setBusy(false);
    }
  };

  if (!s.input)
    return (
      <ToolShell id="filigran">
        <FilePicker kind="pdf" onPdfs={(f) => s.setInput(f[0])} />
      </ToolShell>
    );

  return (
    <ToolShell
      id="filigran"
      aside={
        <div className="preview">
          <Thumb doc={s.doc} index={0} width={420} overlay={overlay} />
          <p className="preview__cap">{__('Önizleme · 1. sayfa')}</p>
        </div>
      }
    >
      <FileChip name={s.input.name} detail={total ? __('{0} sayfa', [total]) : __('açılıyor…')} onClear={() => (s.setInput(null), s.setResult(null))} />
      <ErrorNote error={s.openError} />
      <div className="tool__options">
        <Field label={__('Filigran metni')}>
          <input className="input" value={text} maxLength={60} onChange={(e) => (setText(e.target.value), dirty())} />
        </Field>
        <div className="chips">
          {[__('TASLAK'), __('GİZLİ'), __('KOPYA'), __('ÖRNEK'), __('ASLI GİBİDİR')].map((t) => (
            <button key={t} className={text === t ? 'chipbtn chipbtn--on' : 'chipbtn'} onClick={() => (setText(t), dirty())}>
              {t}
            </button>
          ))}
        </div>
        <Field label={__('Yerleşim')} group>
          <Seg label={__('Yerleşim')} value={tiled} onChange={(v) => (setTiled(v), dirty())} options={[{ v: 'single', t: 'Ortada' }, { v: 'tiled', t: 'Döşe' }]} />
        </Field>
        <Field label={__('Açı')} group>
          <Seg label={__('Açı')} value={angle} onChange={(v) => (setAngle(v), dirty())} options={[{ v: '45', t: 'Çapraz' }, { v: '0', t: 'Düz yatay' }]} />
        </Field>
        <Field label={__('Boyut: %{0}', [sizePct])}>
          <input className="range" type="range" min={15} max={95} value={sizePct} onChange={(e) => (setSizePct(Number(e.target.value)), dirty())} />
        </Field>
        <Field label={__('Saydamlık: %{0}', [Math.round(opacity * 100)])}>
          <input className="range" type="range" min={5} max={100} value={Math.round(opacity * 100)} onChange={(e) => (setOpacity(Number(e.target.value) / 100), dirty())} />
        </Field>
        <Field label={__('Renk')} group>
          <Swatches value={color} onChange={(c) => (setColor(c), dirty())} />
        </Field>
        <Field label={__('Sayfalar')} group>
          <Seg label={__('Sayfalar')} value={which} onChange={(v) => (setWhich(v), dirty())} options={[{ v: 'all', t: 'Tümü' }, { v: 'range', t: 'Seçili sayfalar' }]} />
        </Field>
        {which === 'range' && (
          <Field label={__('Sayfa aralığı')} hint={__('Örnek: 1-3, 5')}>
            <input className="input" value={range} onChange={(e) => (setRange(e.target.value), dirty())} placeholder="1-3, 5" />
          </Field>
        )}
      </div>
      <ErrorNote error={s.error} />
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={s.busy || !s.doc || !text.trim()} onClick={run}>
          {s.busy ? __('Uygulanıyor…') : __('Filigranı uygula')}
        </button>
      </div>
      {s.result && <ResultPanel outputs={s.result} replaceId={s.fromEditor} />}
    </ToolShell>
  );
}

// ---------------------------------------------------------------- Sayfa numarası
const FORMATS = [
  { v: '{n}', t: '1' },
  { v: '{n} / {toplam}', t: '1 / 10' },
  { v: N_('Sayfa {n}'), t: N_('Sayfa 1') },
  { v: N_('Sayfa {n} / {toplam}'), t: N_('Sayfa 1 / 10') },
  { v: '- {n} -', t: '- 1 -' },
];
const POSITIONS: { v: NumberPos; t: string }[] = [
  { v: 'tl', t: N_('Üst sol') },
  { v: 'tc', t: N_('Üst orta') },
  { v: 'tr', t: N_('Üst sağ') },
  { v: 'bl', t: N_('Alt sol') },
  { v: 'bc', t: N_('Alt orta') },
  { v: 'br', t: N_('Alt sağ') },
];

export function PageNumbersTool() {
  const s = useInput();
  const [position, setPosition] = useState<NumberPos>('bc');
  const [format, setFormat] = useState('{n} / {toplam}');
  const [start, setStart] = useState(1);
  const [skipFirst, setSkipFirst] = useState(false);
  const [size, setSize] = useState(11);
  const [color, setColor] = useState('#14205A');
  const margin = 12;
  const total = s.doc?.pageCount ?? 0;
  const dirty = () => s.setResult(null);

  const previewIndex = skipFirst && total > 1 ? 1 : 0;
  const pt = s.doc && total ? s.doc.sizePt(previewIndex) : { w: 595, h: 842 };
  const numbered = skipFirst ? total - 1 : total;
  const label = formatPageLabel(format, start, start + Math.max(numbered, 1) - 1);
  const mx = ((margin * 72) / 25.4 / pt.w) * 100;
  const my = ((margin * 72) / 25.4 / pt.h) * 100;
  const overlay = (
    <div
      className="pn"
      aria-hidden="true"
      style={{
        fontSize: `${(size / pt.w) * 100}cqw`,
        color,
        [position[0] === 't' ? 'top' : 'bottom']: `${my}%`,
        ...(position[1] === 'l' ? { left: `${mx}%` } : position[1] === 'r' ? { right: `${mx}%` } : { left: '50%', transform: 'translateX(-50%)' }),
      }}
    >
      {label}
    </div>
  );

  const run = async () => {
    if (!s.input) return;
    s.setError(null);
    s.setBusy(true);
    try {
      const bytes = await addPageNumbers(s.input.bytes, { position, format, start, skipFirst, size, marginMm: margin, color }, fontBase(), s.input.name);
      s.setResult([{ name: __('{0} (numaralı)', [s.input.name]), ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages: total }]);
    } catch (e) {
      s.setError(errText(e));
    } finally {
      s.setBusy(false);
    }
  };

  if (!s.input)
    return (
      <ToolShell id="sayfa-numarasi">
        <FilePicker kind="pdf" onPdfs={(f) => s.setInput(f[0])} />
      </ToolShell>
    );

  return (
    <ToolShell
      id="sayfa-numarasi"
      aside={
        <div className="preview">
          <Thumb doc={s.doc} index={previewIndex} width={420} overlay={overlay} />
          <p className="preview__cap">{__('Önizleme · {0}. sayfa', [previewIndex + 1])}</p>
        </div>
      }
    >
      <FileChip name={s.input.name} detail={total ? __('{0} sayfa', [total]) : __('açılıyor…')} onClear={() => (s.setInput(null), s.setResult(null))} />
      <ErrorNote error={s.openError} />
      <div className="tool__options">
        <Field label={__('Konum')} group>
          <div className="posgrid" role="radiogroup" aria-label={__('Konum')}>
            {POSITIONS.map((p) => (
              <button
                key={p.v}
                role="radio"
                aria-checked={position === p.v}
                className={position === p.v ? 'posgrid__b posgrid__b--on' : 'posgrid__b'}
                onClick={() => (setPosition(p.v), dirty())}
              >
                {__(p.t)}
              </button>
            ))}
          </div>
        </Field>
        <Field label={__('Biçim')}>
          <select className="input" value={format} onChange={(e) => (setFormat(e.target.value), dirty())}>
            {FORMATS.map((f) => (
              <option key={f.v} value={__(f.v)}>
                {__(f.t)}
              </option>
            ))}
          </select>
        </Field>
        <div className="row2">
          <Field label={__('Başlangıç numarası')}>
            <input className="input input--num" type="number" min={0} value={start} onChange={(e) => (setStart(Math.max(0, Number(e.target.value) || 0)), dirty())} />
          </Field>
          <Field label={__('Yazı boyutu (pt)')}>
            <input className="input input--num" type="number" min={6} max={36} value={size} onChange={(e) => (setSize(Math.min(36, Math.max(6, Number(e.target.value) || 11))), dirty())} />
          </Field>
        </div>
        <label className="check">
          <input type="checkbox" checked={skipFirst} onChange={(e) => (setSkipFirst(e.target.checked), dirty())} />
          <span>{__('Kapak sayfasını (1. sayfa) numaralandırma')}</span>
        </label>
        <Field label={__('Renk')} group>
          <Swatches value={color} onChange={(c) => (setColor(c), dirty())} />
        </Field>
      </div>
      <ErrorNote error={s.error} />
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={s.busy || !s.doc} onClick={run}>
          {s.busy ? __('Ekleniyor…') : __('Numaraları ekle')}
        </button>
      </div>
      {s.result && <ResultPanel outputs={s.result} replaceId={s.fromEditor} />}
    </ToolShell>
  );
}
