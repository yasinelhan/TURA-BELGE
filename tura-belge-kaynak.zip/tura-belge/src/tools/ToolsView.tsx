// Tura Belge — araçlar sayfası ve araç yönlendirmesi
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { ReactElement } from 'react';
import { TopNav } from '../components/TopNav';
import { useToolHost } from './host';
import { TOOLS, toolById } from './registry';
import { ToolGrid } from './ToolGrid';
import { OrganizeTool } from './OrganizeTool';
import { MergeTool } from './MergeTool';
import { SplitTool } from './SplitTool';
import { CompressTool } from './CompressTool';
import { ImagesToPdfTool } from './ImagesToPdfTool';
import { PdfToImagesTool } from './PdfToImagesTool';
import { PageNumbersTool, WatermarkTool } from './StampTools';
import { ScanTool } from './ScanTool';
import { OcrTool } from './OcrTool';
import { VectorTool } from './VectorTool';
import { MdConvertTool, PdfConvertTool } from './ConvertTools';
import { __, N_ } from '../i18n';

const VIEWS: Record<string, () => ReactElement> = {
  tara: ScanTool,
  ocr: OcrTool,
  vektor: VectorTool,
  sayfalar: OrganizeTool,
  birlestir: MergeTool,
  bol: SplitTool,
  sikistir: CompressTool,
  'gorselden-pdf': ImagesToPdfTool,
  'pdften-gorsel': PdfToImagesTool,
  filigran: WatermarkTool,
  'sayfa-numarasi': PageNumbersTool,
  'pdf-donustur': PdfConvertTool,
  'md-donustur': MdConvertTool,
};

const GROUPS = [
  { id: 'olustur', title: N_('Yeni PDF oluştur') },
  { id: 'duzen', title: N_('Sayfa ve dosya') },
  { id: 'donustur', title: N_('Dönüştür') },
  { id: 'ekle', title: N_('Sayfalara ekle') },
] as const;

export function ToolsView({ toolId, onNavigate }: { toolId: string | null; onNavigate: (hash: string) => void }) {
  const host = useToolHost();
  const View = toolId && toolById(toolId) ? (VIEWS[toolId] ?? null) : null;
  const pick = (id: string) => {
    const route = toolById(id)?.route;
    if (route === 'yeni-not') host.newNote();
    else if (route) onNavigate(route);
    else host.goTool(id);
  };
  return (
    <div className="home">
      <TopNav active="araclar" onNavigate={onNavigate} />
      <main className="tools-main">
        {View ? (
          <View key={toolId} />
        ) : (
          <>
            <h1 className="tools-title">{__('PDF araçları')}</h1>
            <p className="open__lead">
              {__('Hepsi tarayıcında çalışır; dosyaların hiçbir sunucuya gönderilmez. Açık bir belgedeyken aynı araçlar belgenin “Sayfalar” ve “PDF araçları” sekmelerinde de var.')}
            </p>
            {GROUPS.map((g) => (
              <section key={g.id} className="toolgroup">
                <h2>{__(g.title)}</h2>
                <ToolGrid tools={TOOLS.filter((t) => t.group === g.id)} onPick={pick} />
              </section>
            ))}
          </>
        )}
      </main>
    </div>
  );
}
