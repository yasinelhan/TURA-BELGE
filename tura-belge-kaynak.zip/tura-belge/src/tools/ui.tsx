// Tura Belge — araçların ortak arayüz parçaları
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { zipSync } from 'fflate';
import { downloadFile, pdfFileName } from '../lib/download';
import { useToolHost, type PdfInput } from './host';
import { openRenderDoc, type RenderDoc } from './lib/render';
import { toolById } from './registry';
import { ToolError } from './lib/pdfOps';
import { ToolIcon } from './ToolIcon';
import { __, fmtNum } from '../i18n';

export const fmtSize = (n: number) =>
  n >= 1024 * 1024 ? `${fmtNum(n / 1024 / 1024)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;

export { ToolIcon };

// ------------------------------------------------------------------ Kabuk
export function ToolShell({ id, children, aside }: { id: string; children: ReactNode; aside?: ReactNode }) {
  const host = useToolHost();
  const info = toolById(id)!;
  return (
    <div className="tool">
      <div className="tool__head">
        <div className="tool__nav">
          {host.backToDoc && (
            <button className="btn btn--ghost btn--sm" onClick={host.backToDoc}>
              <ToolIcon path="M15 5l-7 7 7 7" size={18} /> {__('Belgeye dön')}
            </button>
          )}
          <button className="btn btn--ghost btn--sm" onClick={() => host.goTool(null)}>
            {!host.backToDoc && <ToolIcon path="M15 5l-7 7 7 7" size={18} />} {__('Tüm araçlar')}
          </button>
        </div>
        <div className="tool__title">
          <span className="tool__icon">
            <ToolIcon path={info.icon} size={26} />
          </span>
          <div>
            <h1>{__(info.title)}</h1>
            <p>{__(info.desc)}</p>
          </div>
        </div>
      </div>
      <div className={aside ? 'tool__body tool__body--split' : 'tool__body'}>
        <div className="tool__main">{children}</div>
        {aside && <aside className="tool__aside">{aside}</aside>}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ Dosya seçme
interface PickerProps {
  kind: 'pdf' | 'image' | 'both' | 'md';
  multiple?: boolean;
  compact?: boolean;
  label?: string;
  onPdfs?: (files: PdfInput[]) => void;
  onImages?: (files: File[]) => void;
}

const isPdf = (f: File) => /pdf$/i.test(f.type) || /\.pdf$/i.test(f.name);
const isImage = (f: File) => /^image\//.test(f.type) || /\.(jpe?g|png|webp|gif|bmp)$/i.test(f.name);
const isMd = (f: File) => /\.(md|markdown|txt)$/i.test(f.name) || /^text\/(markdown|x-markdown|plain)/.test(f.type);

export function FilePicker({ kind, multiple, compact, label, onPdfs, onImages }: PickerProps) {
  const host = useToolHost();
  const input = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [showDocs, setShowDocs] = useState(false);
  const [busy, setBusy] = useState(false);

  const accept = async (list: File[]) => {
    if (kind === 'both') {
      // PDF varsa PDF, yoksa görseller
      const pdf = list.find(isPdf);
      if (!pdf) {
        const imgs = list.filter(isImage);
        if (imgs.length) onImages?.(multiple ? imgs : imgs.slice(0, 1));
        return;
      }
      list = [pdf];
    }
    const files = list.filter(kind === 'image' ? isImage : kind === 'md' ? isMd : isPdf);
    if (!files.length) return;
    const chosen = multiple ? files : files.slice(0, 1);
    if (kind === 'image') return onImages?.(chosen);
    setBusy(true);
    try {
      onPdfs?.(
        await Promise.all(chosen.map(async (f) => ({ name: f.name.replace(/\.(pdf|md|markdown|txt)$/i, ''), bytes: await f.arrayBuffer() }))),
      );
    } finally {
      setBusy(false);
    }
  };

  const text =
    label ??
    (kind === 'both'
      ? __('PDF’i ya da görselleri buraya bırak')
      : kind === 'md'
        ? __('Markdown (.md) dosyasını buraya bırak')
        : kind === 'pdf'
        ? multiple
          ? __('PDF dosyalarını buraya bırak')
          : __('PDF dosyasını buraya bırak')
        : __('Görselleri buraya bırak (JPG, PNG, WebP)'));

  return (
    <div className={compact ? 'picker picker--compact' : 'picker'}>
      <div
        className={drag ? 'drop drop--tool drop--active' : 'drop drop--tool'}
        role="button"
        tabIndex={0}
        onClick={() => input.current?.click()}
        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), input.current?.click())}
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setDrag(false);
          void accept(Array.from(e.dataTransfer.files));
        }}
      >
        <p className="drop__title">{busy ? __('Okunuyor…') : text}</p>
        <span className="btn btn--primary btn--sm">{multiple ? __('Dosyaları seç') : __('Dosya seç')}</span>
      </div>
      <input
        ref={input}
        type="file"
        hidden
        multiple={multiple}
        accept={
          kind === 'pdf'
            ? 'application/pdf,.pdf'
            : kind === 'both'
              ? 'application/pdf,.pdf,image/*'
              : kind === 'md'
                ? '.md,.markdown,.txt,text/markdown,text/plain'
                : 'image/*'
        }
        onChange={(e) => {
          void accept(Array.from(e.target.files ?? []));
          e.target.value = '';
        }}
      />
      {kind !== 'image' && host.storageOk && host.docs.some((d) => (d.kind ?? 'pdf') === (kind === 'md' ? 'md' : 'pdf')) && (
        <div className="picker__docs">
          <button className="link-btn" onClick={() => setShowDocs((v) => !v)} aria-expanded={showDocs}>
            {showDocs ? __('Belgelerim listesini kapat') : __('Belgelerim’den seç')}
          </button>
          {showDocs && (
            <ul className="mini-docs">
              {host.docs.filter((d) => (d.kind ?? 'pdf') === (kind === 'md' ? 'md' : 'pdf')).map((d) => (
                <li key={d.id}>
                  <button
                    onClick={async () => {
                      const doc = await host.loadStored(d);
                      onPdfs?.([doc]);
                      if (!multiple) setShowDocs(false);
                    }}
                  >
                    <span className="doc__icon doc__icon--sm">{d.kind === 'md' ? __('MD') : __('PDF')}</span>
                    <span className="mini-docs__name">{d.name}</span>
                    <span className="mini-docs__size">{fmtSize(d.size)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ Küçük resim
export function useRenderDoc(bytes: ArrayBuffer | null | undefined) {
  const [doc, setDoc] = useState<RenderDoc | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (!bytes) {
      setDoc(null);
      return;
    }
    let alive = true;
    let opened: RenderDoc | null = null;
    setError(null);
    openRenderDoc(bytes)
      .then((d) => {
        opened = d;
        if (alive) setDoc(d);
        else d.close();
      })
      .catch(() => alive && setError(__('Belge önizlemesi açılamadı (parolalı ya da bozuk olabilir).')));
    return () => {
      alive = false;
      opened?.close();
      setDoc(null);
    };
  }, [bytes]);
  return { doc, error };
}

export function Thumb({
  doc,
  index,
  width = 150,
  rotate = 0,
  overlay,
}: {
  doc: RenderDoc | null;
  index: number;
  width?: number;
  rotate?: number;
  overlay?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setVisible(true), { rootMargin: '400px' });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  useEffect(() => {
    if (!doc || !visible || index >= doc.pageCount) return;
    let alive = true;
    let made: string | null = null;
    doc
      .thumb(index, width)
      .then((b) => {
        made = URL.createObjectURL(b);
        if (alive) setUrl(made);
        else URL.revokeObjectURL(made);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
      if (made) URL.revokeObjectURL(made);
    };
  }, [doc, index, width, visible]);
  const aspect = doc && index < doc.pageCount ? doc.aspect(index) : 0.707;
  const turned = Math.abs(rotate) % 180 === 90;
  const boxAspect = turned ? 1 / aspect : aspect;
  return (
    <div className="thumb" ref={ref} style={{ aspectRatio: String(boxAspect) }}>
      <div
        className="thumb__page"
        style={{
          width: turned ? `${(1 / boxAspect) * 100}%` : '100%',
          aspectRatio: String(aspect),
          transform: `translate(-50%, -50%) rotate(${rotate}deg)`,
        }}
      >
        {url ? <img src={url} alt="" draggable={false} /> : <span className="thumb__ph" />}
        {overlay}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ Sonuç
export interface Output {
  name: string; // uzantısız
  ext: 'pdf' | 'png' | 'jpg';
  blob: Blob;
  pages?: number;
}

export function ResultPanel({
  outputs,
  zipName,
  note,
  replaceId,
  onReset,
}: {
  outputs: Output[];
  zipName?: string;
  note?: ReactNode;
  replaceId?: string;
  onReset?: () => void;
}) {
  const host = useToolHost();
  const [msg, setMsg] = useState<string | null>(null);
  const [previews, setPreviews] = useState<string[]>([]);
  useEffect(() => {
    const urls = outputs.map((o) => (o.ext !== 'pdf' ? URL.createObjectURL(o.blob) : ''));
    setPreviews(urls);
    return () => urls.forEach((u) => u && URL.revokeObjectURL(u));
  }, [outputs]);

  const total = outputs.reduce((s, o) => s + o.blob.size, 0);
  const fileName = (o: Output) => (o.ext === 'pdf' ? pdfFileName(o.name) : `${o.name}.${o.ext}`);
  const say = (r: string) => {
    setMsg(r);
    window.setTimeout(() => setMsg((m) => (m === r ? null : m)), 3500);
  };
  const dl = async (o: Output) => {
    const r = await downloadFile(fileName(o), o.blob);
    say(r === 'saved' ? __('{0} indirildi', [fileName(o)]) : r === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
  };
  const dlZip = async () => {
    const entries: Record<string, Uint8Array> = {};
    for (const o of outputs) {
      let n = fileName(o);
      for (let k = 2; entries[n]; k++) n = fileName({ ...o, name: `${o.name} (${k})` });
      entries[n] = new Uint8Array(await o.blob.arrayBuffer());
    }
    const zip = zipSync(entries, { level: 0 });
    const r = await downloadFile(`${zipName ?? 'Tura Belge'}.zip`, new Blob([zip as BlobPart], { type: 'application/zip' }));
    say(r === 'saved' ? __('ZIP indirildi') : r === 'declined' ? __('İndirme iptal edildi') : __('Bu görünümde indirme kullanılamıyor'));
  };
  const open = async (o: Output) => host.openInEditor(o.name, await o.blob.arrayBuffer(), replaceId);
  const save = async (o: Output) => {
    await host.saveToDocs(o.name, await o.blob.arrayBuffer());
    say(__('Belgelerim’e kaydedildi'));
  };

  const single = outputs.length === 1 ? outputs[0] : null;
  return (
    <section className="result" aria-live="polite">
      <div className="result__head">
        <span className="result__check" aria-hidden="true">
          <ToolIcon path="M5 12.5l4.5 4.5L19 7.5" size={20} />
        </span>
        <div>
          <h2>{__('Hazır')}</h2>
          <p>
            {outputs.length > 1 ? __('{0} dosya · ', [outputs.length]) : ''}
            {single?.pages ? __('{0} sayfa · ', [single.pages]) : ''}
            {fmtSize(total)}
          </p>
        </div>
      </div>
      {note && <div className="result__note">{note}</div>}

      {single && single.ext === 'pdf' ? (
        <div className="result__actions">
          <button className="btn btn--primary" onClick={() => open(single)}>
            {__('Düzenleyicide aç')}
          </button>
          <button className="btn btn--ghost" onClick={() => dl(single)}>
            {__('İndir')}
          </button>
          {host.storageOk && !replaceId && (
            <button className="btn btn--ghost" onClick={() => save(single)}>
              {__('Belgelerim’e kaydet')}
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="result__actions">
            <button className="btn btn--primary" onClick={dlZip}>
              {__('Hepsini ZIP olarak indir')}
            </button>
          </div>
          <ul className="result__list">
            {outputs.map((o, i) => (
              <li key={i}>
                {o.ext === 'pdf' ? (
                  <span className="doc__icon doc__icon--sm">{__('PDF')}</span>
                ) : (
                  previews[i] && <img className="result__img" src={previews[i]} alt="" />
                )}
                <span className="result__name">
                  {fileName(o)}
                  <small>
                    {o.pages ? __('{0} sayfa · ', [o.pages]) : ''}
                    {fmtSize(o.blob.size)}
                  </small>
                </span>
                {o.ext === 'pdf' && (
                  <button className="btn btn--ghost btn--sm" onClick={() => open(o)}>
                    {__('Aç')}
                  </button>
                )}
                <button className="btn btn--ghost btn--sm" onClick={() => dl(o)}>
                  {__('İndir')}
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
      {onReset && (
        <button className="link-btn" onClick={onReset}>
          {__('Yeni bir dosyayla baştan başla')}
        </button>
      )}
      {msg && <p className="result__msg">{msg}</p>}
    </section>
  );
}

// ------------------------------------------------------------------ Seçili dosya şeridi
export function FileChip({ name, detail, onClear, badge = 'PDF' }: { name: string; detail?: string; onClear: () => void; badge?: string }) {
  return (
    <div className="filechip">
      <span className="doc__icon doc__icon--sm">{badge}</span>
      <span className="filechip__name">
        {name}
        {detail && <small>{detail}</small>}
      </span>
      <button className="btn btn--ghost btn--sm" onClick={onClear}>
        {__('Değiştir')}
      </button>
    </div>
  );
}

export function Seg<T extends string>({
  value,
  options,
  onChange,
  label,
}: {
  value: T;
  options: { v: T; t: string }[];
  onChange: (v: T) => void;
  label: string;
}) {
  return (
    <div className="seg" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.v}
          role="radio"
          aria-checked={value === o.v}
          className={value === o.v ? 'seg__opt seg__opt--on' : 'seg__opt'}
          onClick={() => onChange(o.v)}
        >
          {__(o.t)}
        </button>
      ))}
    </div>
  );
}

/**
 * Form alanı. Tek bir giriş kutusu için <label> kullanılır; düğme grupları
 * (Seg, renkler, konum ızgarası) için `group` verilir, böylece etiket ilk düğmenin
 * adı olarak okunmaz.
 */
export function Field({ label, children, hint, group }: { label: string; children: ReactNode; hint?: string; group?: boolean }) {
  const inner = (
    <>
      <span className="field__label">{label}</span>
      {children}
      {hint && <span className="field__hint">{hint}</span>}
    </>
  );
  return group ? (
    <div className="field" role="group" aria-label={label}>
      {inner}
    </div>
  ) : (
    <label className="field">{inner}</label>
  );
}

export function ErrorNote({ error }: { error: string | null }) {
  return error ? (
    <p className="alert" role="alert">
      {error}
    </p>
  ) : null;
}

export const errText = (e: unknown) => {
  if (e instanceof ToolError) return e.message;
  console.error('[Tura Belge]', e);
  return __('İşlem tamamlanamadı. Dosya bozuk ya da desteklenmeyen bir yapıda olabilir.');
};
