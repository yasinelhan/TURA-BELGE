// Tura Belge — Görselden PDF
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useEffect, useState } from 'react';
import { imagesToPdf, type ImagesToPdfOptions } from './lib/pdfOps';
import { ErrorNote, Field, FilePicker, ResultPanel, Seg, ToolIcon, ToolShell, errText, type Output } from './ui';
import { __ } from '../i18n';

interface Img {
  key: string;
  file: File;
  url: string;
}
let seq = 0;

export function ImagesToPdfTool() {
  const [imgs, setImgs] = useState<Img[]>([]);
  const [size, setSize] = useState<ImagesToPdfOptions['pageSize']>('a4');
  const [orient, setOrient] = useState<ImagesToPdfOptions['orientation']>('auto');
  const [margin, setMargin] = useState<'0' | '10' | '20'>('10');
  const [name, setName] = useState(__('Görsellerden PDF'));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Output[] | null>(null);

  useEffect(() => () => imgs.forEach((i) => URL.revokeObjectURL(i.url)), []); // eslint-disable-line react-hooks/exhaustive-deps

  const add = (files: File[]) => {
    setResult(null);
    setImgs((p) => [...p, ...files.map((file) => ({ key: `i${++seq}`, file, url: URL.createObjectURL(file) }))]);
  };
  const move = (from: number, to: number) =>
    setImgs((p) => {
      const n = [...p];
      const [x] = n.splice(from, 1);
      n.splice(to, 0, x);
      return n;
    });
  const remove = (key: string) =>
    setImgs((p) => {
      const x = p.find((i) => i.key === key);
      if (x) URL.revokeObjectURL(x.url);
      return p.filter((i) => i.key !== key);
    });

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const bytes = await imagesToPdf(
        imgs.map((i) => ({ name: i.file.name, file: i.file })),
        { pageSize: size, orientation: orient, marginMm: Number(margin) },
      );
      setResult([{ name: name.trim() || __('Görsellerden PDF'), ext: 'pdf', blob: new Blob([bytes], { type: 'application/pdf' }), pages: imgs.length }]);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <ToolShell id="gorselden-pdf">
      {imgs.length > 0 && (
        <ol className="imggrid">
          {imgs.map((im, i) => (
            <li key={im.key} className="imgcard">
              <div className="imgcard__img">
                <img src={im.url} alt={im.file.name} />
              </div>
              <div className="pagecard__foot">
                <span className="pagecard__num">{i + 1}</span>
                <span className="pagecard__acts">
                  <button className="icon-btn icon-btn--mini" aria-label={__('Öne al')} disabled={i === 0} onClick={() => move(i, i - 1)}>
                    <ToolIcon path="M14 6l-6 6 6 6" size={16} />
                  </button>
                  <button className="icon-btn icon-btn--mini" aria-label={__('Geriye al')} disabled={i === imgs.length - 1} onClick={() => move(i, i + 1)}>
                    <ToolIcon path="M10 6l6 6-6 6" size={16} />
                  </button>
                  <button className="icon-btn icon-btn--mini icon-btn--danger" aria-label={__('{0} görselini çıkar', [im.file.name])} onClick={() => remove(im.key)}>
                    <ToolIcon path="M6 6l12 12M18 6L6 18" size={16} />
                  </button>
                </span>
              </div>
            </li>
          ))}
        </ol>
      )}
      <FilePicker kind="image" multiple compact={imgs.length > 0} label={imgs.length ? __('Başka görsel ekle') : undefined} onImages={add} />
      {imgs.length > 0 && (
        <div className="tool__options">
          <Field label={__('Sayfa boyutu')} group>
            <Seg
              label={__('Sayfa boyutu')}
              value={size}
              onChange={(v) => (setSize(v), setResult(null))}
              options={[
                { v: 'a4', t: 'A4' },
                { v: 'letter', t: 'Letter' },
                { v: 'fit', t: 'Görsel boyutunda' },
              ]}
            />
          </Field>
          {size !== 'fit' && (
            <Field label={__('Yön')} group>
              <Seg
                label={__('Yön')}
                value={orient}
                onChange={(v) => (setOrient(v), setResult(null))}
                options={[
                  { v: 'auto', t: 'Otomatik' },
                  { v: 'portrait', t: 'Dikey' },
                  { v: 'landscape', t: 'Yatay' },
                ]}
              />
            </Field>
          )}
          <Field label={__('Kenar boşluğu')} group>
            <Seg
              label={__('Kenar boşluğu')}
              value={margin}
              onChange={(v) => (setMargin(v), setResult(null))}
              options={[
                { v: '0', t: 'Yok' },
                { v: '10', t: 'Dar' },
                { v: '20', t: 'Normal' },
              ]}
            />
          </Field>
          <Field label={__('Dosya adı')}>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
        </div>
      )}
      <ErrorNote error={error} />
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={busy || !imgs.length} onClick={run}>
          {busy ? __('Hazırlanıyor…') : imgs.length ? __('{0} görselden PDF oluştur', [imgs.length]) : __('Görsel seç')}
        </button>
      </div>
      {result && <ResultPanel outputs={result} />}
    </ToolShell>
  );
}
