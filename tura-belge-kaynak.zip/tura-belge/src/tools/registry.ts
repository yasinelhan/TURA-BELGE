// Tura Belge — PDF araçları listesi
// SPDX-License-Identifier: AGPL-3.0-or-later
import { N_ } from '../i18n';

export interface ToolInfo {
  id: string;
  title: string;
  desc: string;
  /** 24×24 SVG yolu */
  icon: string;
  group: 'olustur' | 'duzen' | 'donustur' | 'ekle';
  /** Araç sayfası yerine başka bir bölüme gider (ör. LaTeX düzenleyici) */
  route?: string;
}

export const TOOLS: ToolInfo[] = [
  {
    id: 'tara',
    title: N_('Belge tara'),
    desc: N_('Kamerayla çek ya da fotoğraf seç; kenarları bulup düz bir A4 sayfaya çevirir.'),
    icon: 'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M7 12h10',
    group: 'olustur',
  },
  {
    id: 'latex',
    title: N_('LaTeX ile oluştur'),
    desc: N_('Ödev, rapor, özgeçmiş, dilekçe… Hazır Türkçe şablonlarla yaz, canlı önizlemeyle PDF al.'),
    icon: 'M4 6h7M7.5 6v12M13 6l6 12M19 6l-6 12',
    group: 'olustur',
    route: 'tex',
  },
  {
    id: 'sayfalar',
    title: N_('Sayfaları düzenle'),
    desc: N_('Sürükleyerek sırala, döndür, sil, çoğalt, boş sayfa ekle.'),
    icon: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM16.5 13v7M13 16.5h7',
    group: 'duzen',
  },
  {
    id: 'birlestir',
    title: N_('Birleştir'),
    desc: N_('Birden çok PDF’i istediğin sırayla tek dosya yap.'),
    icon: 'M6 3h7l5 5v5M6 3v18h6M13 3v5h5M15 17h6M18 14v6',
    group: 'duzen',
  },
  {
    id: 'bol',
    title: N_('Böl ve ayıkla'),
    desc: N_('Sayfaları ayrı dosyalara böl ya da seçtiklerini çıkar.'),
    icon: 'M6 3h12v7H6zM6 14h12v7H6zM3 12h18',
    group: 'duzen',
  },
  {
    id: 'sikistir',
    title: N_('Sıkıştır'),
    desc: N_('Fotoğraflı ve taranmış PDF’lerin boyutunu küçült.'),
    icon: 'M12 3v6m0 0l-3-3m3 3l3-3M12 21v-6m0 0l-3 3m3-3l3 3M4 12h16',
    group: 'duzen',
  },
  {
    id: 'ocr',
    title: N_('Yazı tanıma (OCR)'),
    desc: N_('Taranmış PDF’teki yazıları aranabilir ve kopyalanabilir yap.'),
    icon: 'M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M8 8h8M12 8v8',
    group: 'donustur',
  },
  {
    id: 'vektor',
    title: N_('Vektöre çevir'),
    desc: N_('Taranmış ya da pikselli sayfaları her yakınlaştırmada keskin kalan vektöre dönüştür.'),
    icon: 'M5 19C8 7 16 17 19 5M3 17h4v4H3zM17 3h4v4h-4z',
    group: 'donustur',
  },
  {
    id: 'md-yeni',
    title: N_('Markdown notu yaz'),
    desc: N_('Başlık, liste, yapılacaklar ve tablolarla not al; PDF, Word ya da Markdown olarak kaydet.'),
    icon: 'M4 5h16v14H4zM7 15V9l2.5 3L12 9v6M16.5 9v6M14.5 13l2 2 2-2',
    group: 'olustur',
    route: 'yeni-not',
  },
  {
    id: 'gorselden-pdf',
    title: N_('Görselden PDF'),
    desc: N_('Fotoğrafları ve ekran görüntülerini A4 PDF’e çevir.'),
    icon: 'M4 5h16v14H4zM4 15l4-4 4 4 3-3 5 5M15 9.5a1.5 1.5 0 1 0 0-.01',
    group: 'olustur',
  },
  {
    id: 'pdf-donustur',
    title: N_('PDF’ten Word / Markdown'),
    desc: N_('PDF’in yazısını başlık, paragraf ve listeleriyle Word, Markdown, web sayfası ya da düz metne çevir.'),
    icon: 'M6 3h8l4 4v14H6zM14 3v5h4M8.5 11l1.5 6 2-4.5 2 4.5 1.5-6',
    group: 'donustur',
  },
  {
    id: 'md-donustur',
    title: N_('Markdown’dan PDF / Word'),
    desc: N_('.md dosyasını düzgün sayfalanmış PDF’e, Word’e ya da web sayfasına çevir.'),
    icon: 'M3 6h18v12H3zM6 15V9l2.5 3L11 9v6M15.5 9v6M13.5 13l2 2 2-2',
    group: 'donustur',
  },
  {
    id: 'pdften-gorsel',
    title: N_('PDF’ten görsel'),
    desc: N_('Sayfaları PNG ya da JPG olarak dışa aktar.'),
    icon: 'M6 3h8l4 4v14H6zM9 16l2-2 2 2 2-3 2 3M10 10.5a1 1 0 1 0 0-.01',
    group: 'donustur',
  },
  {
    id: 'filigran',
    title: 'Filigran',
    desc: N_('“TASLAK”, “GİZLİ” gibi bir yazıyı sayfalara bas.'),
    icon: 'M6 3h12v18H6zM8.5 16l7-8M9 9h3M12 15h3',
    group: 'ekle',
  },
  {
    id: 'sayfa-numarasi',
    title: N_('Sayfa numarası'),
    desc: N_('Sayfaların altına ya da üstüne numara ekle.'),
    icon: 'M6 3h12v18H6zM11 17h2M10.5 14.5l1.5-1.5v4',
    group: 'ekle',
  },
];

export const toolById = (id: string) => TOOLS.find((t) => t.id === id);
