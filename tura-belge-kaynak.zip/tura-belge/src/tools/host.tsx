// Tura Belge — araçların uygulamayla konuştuğu ortak bağlam
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createContext, useContext, useEffect, useRef, useState } from 'react';
import type { DocMeta } from '../lib/storage';
import {  } from '../i18n';

export interface PdfInput {
  name: string;
  bytes: ArrayBuffer;
  /** Belgelerim'den geldiyse kimliği */
  docId?: string;
}

export interface ToolHostApi {
  storageOk: boolean;
  docs: DocMeta[];
  loadStored: (meta: DocMeta) => Promise<PdfInput>;
  /** Sonucu Belgelerim'e kaydeder ve düzenleyicide açar */
  openInEditor: (name: string, bytes: ArrayBuffer, replaceId?: string) => Promise<void>;
  /** Sonucu Belgelerim'e kaydeder */
  saveToDocs: (name: string, bytes: ArrayBuffer) => Promise<void>;
  goTool: (id: string | null) => void;
  /** Başka bir ekrandan (ör. düzenleyici) araca hazır gelen dosya */
  preset: PdfInput | null;
  clearPreset: () => void;
  /** Araca bir belgeden gelindiyse o belgeye geri döner */
  backToDoc?: () => void;
  /** Markdown metnini yeni not olarak açar */
  openMarkdown: (name: string, text: string) => Promise<void>;
  /** Boş bir Markdown notu açar */
  newNote: () => void;
}

export const ToolHost = createContext<ToolHostApi | null>(null);

export function useToolHost(): ToolHostApi {
  const v = useContext(ToolHost);
  if (!v) throw new Error('ToolHost yok');
  return v;
}

/**
 * Düzenleyiciden araca gelen belgeyi bir kez alır.
 * Döndürdüğü kimlik, sonucun aynı belgenin yerine geçmesi için ResultPanel'e verilir.
 */
export function useEditorPreset(onInput: (p: PdfInput) => void): [string | undefined, () => void] {
  const host = useToolHost();
  const [fromEditor, setFromEditor] = useState<string | undefined>();
  const cb = useRef(onInput);
  cb.current = onInput;
  useEffect(() => {
    if (host.preset) {
      cb.current(host.preset);
      setFromEditor(host.preset.docId);
      host.clearPreset();
    }
  }, [host]);
  return [fromEditor, () => setFromEditor(undefined)];
}
