// Tura Belge — PDF'ten görsel
// SPDX-License-Identifier: AGPL-3.0-or-later
import { useState } from 'react';
import { useEditorPreset, type PdfInput } from './host';
import { parseRanges } from './lib/pageRanges';
import { ErrorNote, Field, FileChip, FilePicker, ResultPanel, Seg, ToolShell, errText, useRenderDoc, type Output } from './ui';
import { __ } from '../i18n';

export function PdfToImagesTool() {
  const [input, setInput] = useState<PdfInput | null>(null);
  useEditorPreset(setInput);
  const { doc, error: openError } = useRenderDoc(input?.bytes);
  const [fmt, setFmt] = useState<'png' | 'jpg'>('jpg');
  const [dpi, setDpi] = useState<'96' | '150' | '300'>('150');
  const [which, setWhich] = useState<'all' | 'range'>('all');
  const [range, setRange] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Output[] | null>(null);

  const total = doc?.pageCount ?? 0;
  const run = async () => {
    if (!doc || !input) return;
    setError(null);
    setResult(null);
    let pages = Array.from({ length: total }, (_, i) => i);
    if (which === 'range') {
      const r = parseRanges(range, total);
      if (r.error) return setError(r.error);
      pages = r.groups.flat();
    }
    const outs: Output[] = [];
    const pad = String(total).length;
    try {
      for (let k = 0; k < pages.length; k++) {
        setBusy(__('Sayfa {0} / {1} işleniyor…', [k + 1, pages.length]));
        const i = pages[k];
        const blob = await doc.render(i, Number(dpi), fmt === 'png' ? 'image/png' : 'image/jpeg', 0.9);
        outs.push({ name: __('{0} - sayfa {1}', [input.name, String(i + 1).padStart(pad, '0')]), ext: fmt, blob });
      }
      setResult(outs);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(null);
    }
  };

  if (!input) {
    return (
      <ToolShell id="pdften-gorsel">
        <FilePicker kind="pdf" onPdfs={(f) => setInput(f[0])} />
      </ToolShell>
    );
  }
  return (
    <ToolShell id="pdften-gorsel">
      <FileChip name={input.name} detail={total ? __('{0} sayfa', [total]) : __('açılıyor…')} onClear={() => (setInput(null), setResult(null))} />
      <ErrorNote error={openError} />
      <div className="tool__options">
        <Field label={__('Biçim')} hint={fmt === 'png' ? __('Kayıpsız, metin ve çizimler için.') : __('Daha küçük dosya, fotoğraflar için.')} group>
          <Seg label={__('Biçim')} value={fmt} onChange={(v) => (setFmt(v), setResult(null))} options={[{ v: 'jpg', t: 'JPG' }, { v: 'png', t: 'PNG' }]} />
        </Field>
        <Field label={__('Çözünürlük')} group>
          <Seg
            label={__('Çözünürlük')}
            value={dpi}
            onChange={(v) => (setDpi(v), setResult(null))}
            options={[
              { v: '96', t: 'Ekran (96 dpi)' },
              { v: '150', t: 'Standart (150 dpi)' },
              { v: '300', t: 'Baskı (300 dpi)' },
            ]}
          />
        </Field>
        <Field label={__('Sayfalar')} group>
          <Seg label={__('Sayfalar')} value={which} onChange={(v) => (setWhich(v), setResult(null))} options={[{ v: 'all', t: 'Tümü' }, { v: 'range', t: 'Seçili sayfalar' }]} />
        </Field>
        {which === 'range' && (
          <Field label={__('Sayfa aralığı')} hint={__('Örnek: 1-3, 5')}>
            <input className="input" value={range} onChange={(e) => (setRange(e.target.value), setResult(null))} placeholder="1-3, 5" />
          </Field>
        )}
      </div>
      <ErrorNote error={error} />
      <div className="tool__cta">
        <button className="btn btn--primary" disabled={!!busy || !doc} onClick={run}>
          {busy ?? __('Görsellere dönüştür')}
        </button>
      </div>
      {result && <ResultPanel outputs={result} zipName={__('{0} (görseller)', [input.name])} />}
    </ToolShell>
  );
}
