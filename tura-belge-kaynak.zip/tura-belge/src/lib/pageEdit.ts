// Tura Belge — belge içinden sayfa ekleme (renkli, çizgili, kareli, noktalı) ve sayfa silme
// SPDX-License-Identifier: AGPL-3.0-or-later
import { rgb } from 'pdf-lib';
import { finish, hexToRgb, loadPdf, ToolError } from '../tools/lib/pdfOps';
import { __ } from '../i18n';

export type PagePattern = 'duz' | 'cizgili' | 'kareli' | 'noktali';
export type PageSize = 'ayni' | 'a4' | 'a4-yatay' | 'a5' | 'letter';

export interface BlankPageOptions {
  /** Yeni sayfaların ekleneceği sıra (0 = en başa) */
  at: number;
  count: number;
  size: PageSize;
  /** "ayni" seçiliyse ölçüsü alınacak sayfa */
  like: number;
  color: string;
  pattern: PagePattern;
}

const MM = 72 / 25.4;
const SIZES: Record<Exclude<PageSize, 'ayni'>, [number, number]> = {
  a4: [595.28, 841.89],
  'a4-yatay': [841.89, 595.28],
  a5: [419.53, 595.28],
  letter: [612, 792],
};

/** Arka plan koyu mu? (çizgiler açık renkte çizilir) */
export function isDark(hex: string) {
  const n = parseInt(hex.replace('#', ''), 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  return 0.2126 * r + 0.7152 * g + 0.0722 * b < 110;
}

export async function insertBlankPages(bytes: ArrayBuffer, o: BlankPageOptions, name?: string): Promise<ArrayBuffer> {
  const doc = await loadPdf(bytes, name);
  const total = doc.getPageCount();
  let [w, h] = o.size === 'ayni' ? [595.28, 841.89] : SIZES[o.size];
  if (o.size === 'ayni' && total) {
    const ref = doc.getPage(Math.min(Math.max(0, o.like), total - 1));
    const s = ref.getSize();
    const turned = ref.getRotation().angle % 180 !== 0;
    [w, h] = turned ? [s.height, s.width] : [s.width, s.height];
  }
  const dark = isDark(o.color);
  const white = o.color.toLowerCase() === '#ffffff';
  const ink = dark ? rgb(1, 1, 1) : rgb(0.36, 0.5, 0.72);
  const inkOpacity = dark ? 0.28 : 0.45;
  const at = Math.min(Math.max(0, o.at), total);

  for (let k = 0; k < Math.min(Math.max(1, o.count), 50); k++) {
    const page = doc.insertPage(at + k, [w, h]);
    if (!white) page.drawRectangle({ x: 0, y: 0, width: w, height: h, color: hexToRgb(o.color) });
    if (o.pattern === 'cizgili') {
      const step = 8 * MM;
      for (let y = h - 25 * MM; y > 12 * MM; y -= step) {
        page.drawLine({ start: { x: 10 * MM, y }, end: { x: w - 10 * MM, y }, thickness: 0.6, color: ink, opacity: inkOpacity });
      }
      // Sol kenar boşluğu çizgisi
      page.drawLine({
        start: { x: 25 * MM, y: h },
        end: { x: 25 * MM, y: 0 },
        thickness: 0.7,
        color: dark ? rgb(1, 0.6, 0.6) : rgb(0.86, 0.35, 0.35),
        opacity: 0.5,
      });
    } else if (o.pattern === 'kareli') {
      const step = 5 * MM;
      for (let x = (w % step) / 2; x <= w; x += step) {
        page.drawLine({ start: { x, y: 0 }, end: { x, y: h }, thickness: 0.35, color: ink, opacity: inkOpacity * 0.8 });
      }
      for (let y = (h % step) / 2; y <= h; y += step) {
        page.drawLine({ start: { x: 0, y }, end: { x: w, y }, thickness: 0.35, color: ink, opacity: inkOpacity * 0.8 });
      }
    } else if (o.pattern === 'noktali') {
      const step = 5 * MM;
      for (let x = (w % step) / 2; x <= w; x += step) {
        for (let y = (h % step) / 2; y <= h; y += step) {
          page.drawCircle({ x, y, size: 0.55, color: ink, opacity: Math.min(1, inkOpacity * 1.6) });
        }
      }
    }
  }
  return finish(doc);
}

/** Verilen sayfaları (0'dan başlayan) siler; en az bir sayfa kalmalı. */
export async function deletePages(bytes: ArrayBuffer, indices: number[], name?: string): Promise<ArrayBuffer> {
  const doc = await loadPdf(bytes, name);
  const total = doc.getPageCount();
  const list = [...new Set(indices)].filter((i) => i >= 0 && i < total).sort((a, b) => b - a);
  if (!list.length) throw new ToolError(__('Silinecek sayfa seçilmedi.'));
  if (list.length >= total) throw new ToolError(__('Belgede en az bir sayfa kalmalı.'));
  for (const i of list) doc.removePage(i);
  return finish(doc);
}
