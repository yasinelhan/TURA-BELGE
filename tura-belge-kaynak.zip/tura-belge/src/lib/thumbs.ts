// Tura Belge — kitaplık kapak resimleri (belgenin ilk sayfası)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { getThumb, loadDocBytes, saveThumb, type DocMeta } from './storage';

const urls = new Map<string, { url: string; at: number }>();
let queue: Promise<void> = Promise.resolve();

/** Kapak resminin adresini verir; yoksa ya da eskiyse arka planda üretir. */
export async function thumbUrl(meta: DocMeta): Promise<string | null> {
  const cached = urls.get(meta.id);
  if (cached && cached.at >= meta.updatedAt) return cached.url;
  const stored = await getThumb(meta.id);
  if (stored && stored.at >= meta.updatedAt) return remember(meta.id, stored.blob, stored.at);
  // Üretim sırayla yapılır; PDF motoru tek tek çalışsın
  const job = queue.then(() => makeThumb(meta));
  queue = job.then(() => undefined, () => undefined);
  const blob = await job.catch(() => null);
  return blob ? remember(meta.id, blob, meta.updatedAt) : stored ? remember(meta.id, stored.blob, stored.at) : null;
}

function remember(id: string, blob: Blob, at: number) {
  const old = urls.get(id);
  if (old) URL.revokeObjectURL(old.url);
  const url = URL.createObjectURL(blob);
  urls.set(id, { url, at });
  return url;
}

async function makeThumb(meta: DocMeta): Promise<Blob | null> {
  const bytes = await loadDocBytes(meta.id);
  if (!bytes) return null;
  const { openRenderDoc } = await import('../tools/lib/render');
  const doc = await openRenderDoc(bytes);
  try {
    const blob = await doc.thumb(0, 220);
    await saveThumb(meta.id, { blob, at: meta.updatedAt });
    return blob;
  } finally {
    doc.close();
  }
}
