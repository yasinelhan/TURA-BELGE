// Tura Belge — mobil uygulamada (Android/iOS) dosyayı yerinde açma ve aynı dosyaya kaydetme
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Web'de File System Access API'nin FileSystemFileHandle'ı ne yapıyorsa, mobil uygulamada
// NativeFileHandle aynısını yerel "TuraDosya" eklentisiyle yapar. Böylece uygulamanın geri kalanı
// (otomatik kaydetme, çakışma uyarısı, kitaplık) iki ortamda da aynı kodla çalışır.
import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core';

export interface NativeFileInfo {
  uri: string;
  name: string;
  size: number;
  lastModified: number;
  writable?: boolean;
}

interface TuraDosyaPlugin {
  getLaunchFile(): Promise<Partial<NativeFileInfo>>;
  pick(): Promise<NativeFileInfo>;
  stat(o: { uri: string }): Promise<NativeFileInfo>;
  read(o: { uri: string }): Promise<NativeFileInfo & { data: string }>;
  write(o: { uri: string; data: string }): Promise<NativeFileInfo>;
  saveAs(o: { name: string; mime: string; data: string }): Promise<NativeFileInfo>;
  share(o: { name: string; mime: string; data: string }): Promise<void>;
  addListener(event: 'dosyaAcildi', cb: (f: NativeFileInfo) => void): Promise<PluginListenerHandle>;
}

export const TuraDosya = registerPlugin<TuraDosyaPlugin>('TuraDosya');

export const isNative = () => Capacitor.isNativePlatform();

const fromBase64 = (b64: string) => {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
};
export const toBase64 = (blob: Blob) =>
  new Promise<string>((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).replace(/^data:[^,]*,/, ''));
    r.onerror = () => rej(r.error);
    r.readAsDataURL(blob);
  });

/** IndexedDB'de saklanan biçim */
export interface StoredNativeHandle {
  __native: true;
  uri: string;
  name: string;
}

/** FileSystemFileHandle gibi davranan yerel dosya tutamacı */
export class NativeFileHandle {
  readonly kind = 'file' as const;
  readonly __native = true as const;
  readonly uri: string;
  readonly name: string;
  constructor(uri: string, name: string) {
    this.uri = uri;
    this.name = name;
  }

  static from(info: NativeFileInfo) {
    return new NativeFileHandle(info.uri, info.name || 'Belge.pdf');
  }

  async getFile(): Promise<File> {
    const r = await TuraDosya.read({ uri: this.uri });
    return new File([fromBase64(r.data)], r.name || this.name, { type: 'application/pdf', lastModified: r.lastModified || 0 });
  }

  async createWritable() {
    let parts: BlobPart[] = [];
    return {
      write: async (b: BlobPart) => {
        parts.push(b);
      },
      close: async () => {
        await TuraDosya.write({ uri: this.uri, data: await toBase64(new Blob(parts)) });
        parts = [];
      },
      abort: async () => {
        parts = [];
      },
    };
  }

  async queryPermission(): Promise<'granted'> {
    return 'granted';
  }
  async requestPermission(): Promise<'granted'> {
    return 'granted';
  }
  async isSameEntry(other: unknown): Promise<boolean> {
    return !!other && (other as { uri?: string }).uri === this.uri;
  }
  toStored(): StoredNativeHandle {
    return { __native: true, uri: this.uri, name: this.name };
  }
}

export const isStoredNative = (x: unknown): x is StoredNativeHandle => !!x && (x as StoredNativeHandle).__native === true;

/** Mobilde "İndir": sistemin "Farklı kaydet" ekranı */
export async function nativeSaveAs(filename: string, blob: Blob): Promise<'saved' | 'declined'> {
  try {
    await TuraDosya.saveAs({ name: filename, mime: blob.type || 'application/octet-stream', data: await toBase64(blob) });
    return 'saved';
  } catch (err) {
    if ((err as { code?: string })?.code === 'CANCELLED') return 'declined';
    throw err;
  }
}

/** Mobilde "Paylaş": WhatsApp, e-posta, Drive… */
export async function nativeShare(filename: string, blob: Blob) {
  await TuraDosya.share({ name: filename, mime: blob.type || 'application/pdf', data: await toBase64(blob) });
}
