// Tura Belge — görüntüleyiciye eklenen komutlar: seçili metni asistana sor, çevir, internette ara
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { CommandsPlugin, PluginRegistry, SelectionPlugin, UIPlugin } from '@embedpdf/react-pdf-viewer';
import { __ } from '../i18n';

const TURKISH = /[çğıöşüÇĞİÖŞÜ]/;

/** Seçili metin ve bulunduğu sayfa (1'den başlar) */
export interface PickedText {
  text: string;
  page: number;
}
/** Düzenleyicinin seçim menüsüne verdiği işler (asistan paneli) */
export interface SelectionHandlers {
  ask: (t: PickedText) => void;
  translate: (t: PickedText) => void;
}

async function picked(registry: PluginRegistry, documentId: string): Promise<PickedText | null> {
  const scope = registry.getPlugin<SelectionPlugin>('selection')?.provides().forDocument(documentId);
  if (!scope) return null;
  const text = await selectedText(registry, documentId);
  if (!text) return null;
  const page = (scope.getFormattedSelection()[0]?.pageIndex ?? 0) + 1;
  return { text, page };
}

async function selectedText(registry: PluginRegistry, documentId: string): Promise<string> {
  const scope = registry.getPlugin<SelectionPlugin>('selection')?.provides().forDocument(documentId);
  if (!scope) return '';
  const parts = await scope.getSelectedText().toPromise();
  return parts.join(' ').replace(/\s+/g, ' ').trim().slice(0, 4000);
}

// Yeni sekmede açar; düzenleyiciden asla ayrılmaz ("noopener" window.open'ı null döndürdüğü için bağlantıyla açılır)
function openExternal(url: string) {
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** Metin seçim menüsüne "Asistana sor", "Çevir" ve "İnternette ara" düğmelerini ekler */
export function addSelectionActions(registry: PluginRegistry, handlers: () => SelectionHandlers | null) {
  const commands = registry.getPlugin<CommandsPlugin>('commands')?.provides();
  const ui = registry.getPlugin<UIPlugin>('ui')?.provides();
  if (!commands || !ui) return;

  commands.registerCommand({
    id: 'tura:ask',
    label: __('Asistana sor'),
    icon: 'turaAsk',
    categories: ['selection', 'tura-ask'],
    action: async ({ documentId }) => {
      const p = await picked(registry, documentId);
      if (p) handlers()?.ask(p);
    },
  });
  commands.registerCommand({
    id: 'tura:translate',
    label: __('Çevir'),
    icon: 'turaTranslate',
    categories: ['selection', 'tura-translate'],
    action: async ({ documentId }) => {
      const p = await picked(registry, documentId);
      if (!p) return;
      const h = handlers();
      if (h) {
        h.translate(p);
        return;
      }
      // Türkçe metin İngilizceye, diğer diller Türkçeye çevrilir
      const target = TURKISH.test(p.text) ? 'en' : 'tr';
      openExternal(`https://translate.google.com/?sl=auto&tl=${target}&text=${encodeURIComponent(p.text)}&op=translate`);
    },
  });
  commands.registerCommand({
    id: 'tura:web-search',
    label: __('İnternette ara'),
    icon: 'turaWebSearch',
    categories: ['selection', 'tura-web-search'],
    action: async ({ documentId }) => {
      const text = await selectedText(registry, documentId);
      if (text) openExternal(`https://www.google.com/search?q=${encodeURIComponent(text.slice(0, 300))}`);
    },
  });

  const menu = ui.getSchema().selectionMenus.selection;
  if (!menu || menu.items.some((i) => i.id === 'tura-ask')) return;
  ui.mergeSchema({
    selectionMenus: {
      ...ui.getSchema().selectionMenus,
      selection: {
        ...menu,
        items: [
          { type: 'command-button', id: 'tura-ask', commandId: 'tura:ask', variant: 'icon-text', categories: ['selection'] },
          { type: 'divider', id: 'tura-divider-0' },
          ...menu.items,
          { type: 'divider', id: 'tura-divider' },
          { type: 'command-button', id: 'tura-translate', commandId: 'tura:translate', variant: 'icon', categories: ['selection'] },
          { type: 'command-button', id: 'tura-web-search', commandId: 'tura:web-search', variant: 'icon', categories: ['selection'] },
        ],
        visibilityDependsOn: menu.visibilityDependsOn
          ? { ...menu.visibilityDependsOn, itemIds: [...(menu.visibilityDependsOn.itemIds ?? []), 'tura-ask', 'tura-translate', 'tura-web-search'] }
          : undefined,
      },
    },
  });
}
