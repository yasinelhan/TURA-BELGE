// Tura Belge — "asıl dosyaya kaydet": cihazdaki bir dosyayı açıp değişiklikleri aynı dosyaya yazar.
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// OneDrive, Google Drive, Dropbox gibi uygulamaların bilgisayardaki klasörlerinden açılan
// dosyalar bu yolla yerinde güncellenir; eşitleme uygulaması değişikliği diğer cihazlara taşır.
// Tarayıcı desteği: Chrome/Edge (Windows, macOS, Linux, ChromeOS) ve Android'de Chrome 132+.
// Safari (iPhone/iPad) ve Firefox desteklemez; orada dosya kopyası açılır.
import { isEmbedded } from './download';
import { NativeFileHandle, TuraDosya, isNative } from './native';
import { __ } from '../i18n';

type Perm = 'granted' | 'denied' | 'prompt';
interface PermHandle {
  queryPermission?: (d: { mode: 'read' | 'readwrite' }) => Promise<Perm>;
  requestPermission?: (d: { mode: 'read' | 'readwrite' }) => Promise<Perm>;
}
type Picker = (o: {
  id?: string;
  types: { description: string; accept: Record<string, string[]> }[];
  excludeAcceptAllOption?: boolean;
  multiple?: boolean;
}) => Promise<FileSystemFileHandle[]>;

/** Bu tarayıcıda dosyayı yerinde güncelleyebilir miyiz? */
export function canLinkFiles(): boolean {
  if (isNative()) return true;
  return typeof (window as unknown as { showOpenFilePicker?: Picker }).showOpenFilePicker === 'function' && !isEmbedded();
}

export class PickCancelled extends Error {}

/** Dosya seçtirir ve dosya tutamacını (handle) döndürür. */
export async function pickPdfHandle(): Promise<FileSystemFileHandle> {
  if (isNative()) {
    try {
      return NativeFileHandle.from(await TuraDosya.pick()) as unknown as FileSystemFileHandle;
    } catch (err) {
      if ((err as { code?: string })?.code === 'CANCELLED') throw new PickCancelled();
      throw err;
    }
  }
  const picker = (window as unknown as { showOpenFilePicker: Picker }).showOpenFilePicker;
  try {
    const [handle] = await picker({
      id: 'tura-belge-pdf',
      types: [{ description: __('PDF ya da Markdown'), accept: { 'application/pdf': ['.pdf'], 'text/markdown': ['.md', '.markdown'] } }],
      excludeAcceptAllOption: true,
    });
    return handle;
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') throw new PickCancelled();
    throw err;
  }
}

/** İzin durumunu sorar; `ask` true ise (kullanıcı tıklamasıyla) izin ister. */
export async function ensurePermission(
  handle: FileSystemFileHandle,
  mode: 'read' | 'readwrite',
  ask: boolean,
): Promise<boolean> {
  const h = handle as unknown as PermHandle;
  try {
    if (!h.queryPermission) return true; // eski uygulamalar: izin, yazarken sorulur
    if ((await h.queryPermission({ mode })) === 'granted') return true;
    if (!ask || !h.requestPermission) return false;
    return (await h.requestPermission({ mode })) === 'granted';
  } catch {
    return false;
  }
}

export async function readHandle(handle: FileSystemFileHandle): Promise<{ bytes: ArrayBuffer; modified: number; name: string }> {
  const file = await handle.getFile();
  return { bytes: await file.arrayBuffer(), modified: file.lastModified, name: file.name };
}

export async function handleModified(handle: FileSystemFileHandle): Promise<number> {
  // Mobilde dosyanın tamamını okumadan yalnızca bilgisini sor
  if (handle instanceof NativeFileHandle) return (await TuraDosya.stat({ uri: handle.uri })).lastModified || 0;
  return (await handle.getFile()).lastModified;
}

/** Baytları asıl dosyaya yazar; dosyanın yeni değiştirilme zamanını döndürür. */
export async function writeHandle(handle: FileSystemFileHandle, bytes: ArrayBuffer): Promise<number> {
  const w = await handle.createWritable();
  try {
    await w.write(bytes);
    await w.close();
  } catch (err) {
    await w.abort().catch(() => undefined);
    throw err;
  }
  return handleModified(handle);
}

/** Sürükle-bırakta (Chrome/Edge) bırakılan dosyanın tutamacını alır */
export async function handleFromDrop(items: DataTransferItemList): Promise<FileSystemFileHandle | null> {
  for (const item of Array.from(items)) {
    if (item.kind !== 'file') continue;
    const get = (item as unknown as { getAsFileSystemHandle?: () => Promise<FileSystemHandle | null> }).getAsFileSystemHandle;
    if (typeof get !== 'function') return null;
    const h = await get.call(item);
    if (h && h.kind === 'file' && DOC_RE.test(h.name)) return h as FileSystemFileHandle;
  }
  return null;
}

/** Kurulu uygulama "Birlikte aç" ile başlatıldıysa gelen dosyaları dinler */
export function onLaunchFiles(cb: (handle: FileSystemFileHandle) => void) {
  if (isNative()) {
    // Android: "Birlikte aç → Tura Belge" (uygulama kapalıyken ve açıkken)
    void TuraDosya.getLaunchFile().then((f) => {
      if (f.uri) cb(NativeFileHandle.from(f as Parameters<typeof NativeFileHandle.from>[0]) as unknown as FileSystemFileHandle);
    });
    void TuraDosya.addListener('dosyaAcildi', (f) => cb(NativeFileHandle.from(f) as unknown as FileSystemFileHandle));
    return;
  }
  const lq = (window as unknown as { launchQueue?: { setConsumer(fn: (p: { files: FileSystemHandle[] }) => void): void } }).launchQueue;
  lq?.setConsumer((params) => {
    const file = params.files?.find((f) => f.kind === 'file' && DOC_RE.test(f.name));
    if (file) cb(file as FileSystemFileHandle);
  });
}

/** Açılabilen belgeler: PDF ve Markdown */
export const DOC_RE = /\.(pdf|md|markdown)$/i;
export const isMarkdownName = (n: string) => /\.(md|markdown|txt)$/i.test(n);
export const baseName = (fileName: string) => fileName.replace(/\.(pdf|md|markdown|txt)$/i, '');
