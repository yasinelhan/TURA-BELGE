// Tura Belge — belgeleri yalnızca kullanıcının tarayıcısında (IndexedDB) saklar.
// Hiçbir dosya sunucuya gönderilmez.
// SPDX-License-Identifier: AGPL-3.0-or-later
import { createStore, del, get, keys, set } from 'idb-keyval';
import { NativeFileHandle, isStoredNative } from './native';

export interface DocMeta {
  id: string;
  name: string;
  size: number;
  createdAt: number;
  updatedAt: number;
  /** Cihazdaki bir dosyaya bağlıysa o dosyanın adı (ör. OneDrive klasöründeki "Ders notu.pdf") */
  linkedFile?: string;
  /** Bağlı dosyanın en son eşitlendiği andaki değiştirilme zamanı */
  fileModified?: number;
  /** Kitaplıktaki klasörü (ör. "Ders notları") */
  folderId?: string;
  /** Belge türü: PDF (varsayılan) ya da Markdown */
  kind?: DocKind;
  /** Kitaplıktaki defter kabının renk sırası */
  cover?: number;
}

export type DocKind = 'pdf' | 'md';

export interface Folder {
  id: string;
  name: string;
  createdAt: number;
}

let metaStore: ReturnType<typeof createStore> | null = null;
let fileStore: ReturnType<typeof createStore> | null = null;
let handleStore: ReturnType<typeof createStore> | null = null;
let folderStore: ReturnType<typeof createStore> | null = null;
let thumbStore: ReturnType<typeof createStore> | null = null;

function stores() {
  if (!metaStore || !fileStore || !handleStore || !folderStore || !thumbStore) {
    metaStore = createStore('tura-belge-meta', 'docs');
    fileStore = createStore('tura-belge-files', 'files');
    handleStore = createStore('tura-belge-handles', 'handles');
    folderStore = createStore('tura-belge-folders', 'folders');
    thumbStore = createStore('tura-belge-thumbs', 'thumbs');
  }
  return { metaStore, fileStore, handleStore, folderStore, thumbStore };
}

// ------------------------------------------------------------------ Klasörler
export async function listFolders(): Promise<Folder[]> {
  const { folderStore } = stores();
  const ids = (await keys(folderStore)) as string[];
  const all = await Promise.all(ids.map((id) => get<Folder>(id, folderStore)));
  return all.filter((f): f is Folder => !!f).sort((a, b) => a.createdAt - b.createdAt);
}
export async function saveFolder(folder: Folder): Promise<void> {
  await set(folder.id, folder, stores().folderStore);
}
/** Klasörü siler; içindeki belgeler silinmez, "Tümü"ne döner */
export async function deleteFolder(id: string): Promise<void> {
  const { folderStore, metaStore } = stores();
  await del(id, folderStore);
  for (const d of await listDocs()) if (d.folderId === id) await set(d.id, { ...d, folderId: undefined }, metaStore);
}
export async function moveDocToFolder(docId: string, folderId: string | undefined): Promise<void> {
  const { metaStore } = stores();
  const meta = await get<DocMeta>(docId, metaStore);
  if (meta) await set(docId, { ...meta, folderId }, metaStore);
}

// ------------------------------------------------------------------ Kapak resimleri
export interface Thumb {
  blob: Blob;
  /** Hangi kayda ait olduğu (DocMeta.updatedAt) */
  at: number;
}
export async function getThumb(id: string): Promise<Thumb | undefined> {
  try {
    return await get<Thumb>(id, stores().thumbStore);
  } catch {
    return undefined;
  }
}
export async function saveThumb(id: string, thumb: Thumb): Promise<void> {
  await set(id, thumb, stores().thumbStore);
}

/** Dosya tutamaçları (asıl dosyaya geri yazmak için). Mobil uygulamada yerel tutamaç düz nesne olarak saklanır. */
export async function saveHandle(id: string, handle: FileSystemFileHandle): Promise<void> {
  const h = handle as unknown as NativeFileHandle;
  await set(id, h instanceof NativeFileHandle ? h.toStored() : handle, stores().handleStore);
}
const revive = (h: unknown): FileSystemFileHandle | undefined =>
  isStoredNative(h) ? (new NativeFileHandle(h.uri, h.name) as unknown as FileSystemFileHandle) : (h as FileSystemFileHandle | undefined);
export async function getHandle(id: string): Promise<FileSystemFileHandle | undefined> {
  try {
    return revive(await get(id, stores().handleStore));
  } catch {
    return undefined;
  }
}
/** Aynı dosya daha önce açıldıysa o belgenin kimliğini bulur */
export async function findDocByHandle(handle: FileSystemFileHandle): Promise<string | null> {
  const { handleStore } = stores();
  for (const id of (await keys(handleStore)) as string[]) {
    const h = revive(await get(id, handleStore));
    try {
      if (h && (isStoredNative(h) || h instanceof NativeFileHandle) !== (handle instanceof NativeFileHandle)) continue;
      if (h && (await h.isSameEntry(handle))) return id;
    } catch {
      /* erişilemeyen tutamaç */
    }
  }
  return null;
}
export async function getMeta(id: string): Promise<DocMeta | undefined> {
  return get<DocMeta>(id, stores().metaStore);
}

/** IndexedDB bu tarayıcıda kullanılabiliyor mu? (gizli sekme veya gömülü görünümde olmayabilir) */
export async function storageAvailable(): Promise<boolean> {
  try {
    const { metaStore } = stores();
    await set('__probe__', 1, metaStore);
    await del('__probe__', metaStore);
    return true;
  } catch {
    return false;
  }
}

export function newDocId(): string {
  return `doc-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export async function listDocs(): Promise<DocMeta[]> {
  const { metaStore } = stores();
  const ids = (await keys(metaStore)) as string[];
  const metas = await Promise.all(ids.map((id) => get<DocMeta>(id, metaStore)));
  return metas
    .filter((m): m is DocMeta => !!m && typeof m.id === 'string')
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function saveDoc(meta: DocMeta, bytes: ArrayBuffer): Promise<void> {
  const { metaStore, fileStore } = stores();
  await set(meta.id, bytes, fileStore);
  await set(meta.id, meta, metaStore);
}

export async function loadDocBytes(id: string): Promise<ArrayBuffer | undefined> {
  const { fileStore } = stores();
  return get<ArrayBuffer>(id, fileStore);
}

export async function deleteDoc(id: string): Promise<void> {
  const { metaStore, fileStore, handleStore, thumbStore } = stores();
  await del(id, metaStore);
  await del(id, fileStore);
  await del(id, handleStore);
  await del(id, thumbStore);
}
