// Tura Belge — EmbedPDF görüntüleyici ayarları (tema, Türkçe, kendi sunucumuzdaki motor)
// SPDX-License-Identifier: AGPL-3.0-or-later
import { getLang } from '../i18n';
import { SignatureMode, type PDFViewerConfig } from '@embedpdf/react-pdf-viewer';
import pdfiumWasmUrl from '@embedpdf/pdfium/pdfium.wasm?url';
import { turkishLocale } from '../i18n/tr';
import { TOOLS } from '../tools/registry';

const assetUrl = (path: string) => new URL(path, document.baseURI).href;

const NOTO = [
  { url: 'NotoSans-Regular.ttf', weight: 400 },
  { url: 'NotoSans-Bold.ttf', weight: 700 },
  { url: 'NotoSans-Italic.ttf', weight: 400, italic: true },
  { url: 'NotoSans-BoldItalic.ttf', weight: 700, italic: true },
];

// Windows yazı karakter kümeleri: 0 ANSI, 1 DEFAULT, 161 Yunanca, 162 Türkçe,
// 163 Vietnamca, 186 Baltık, 204 Kiril, 238 Orta Avrupa
const LATIN_CHARSETS = [0, 1, 161, 162, 163, 186, 204, 238];

export const TURA_HIGHLIGHT_COLORS = [
  '#FFE066', // fosforlu sarı
  '#8EE4C8', // nane
  '#8CCFF7', // gök
  '#FFB3C1', // pembe
  '#0B7A8F', // Tura turkuazı
  '#142C93', // kobalt
  '#D4943F', // çini altını
  '#E5484D', // kırmızı
  '#14205A', // lacivert
  '#000000',
];

export interface ViewerDoc {
  id: string;
  name: string;
  bytes: ArrayBuffer;
  /** Cihazdaki asıl dosya (OneDrive klasörü vb.); varsa değişiklikler oraya da yazılır */
  handle?: FileSystemFileHandle;
  /** Asıl dosyanın açıldığı andaki değiştirilme zamanı */
  fileModified?: number;
  /** Açılır açılmaz kaydedilmesi gereken değişiklik var mı (ör. sayfa düzenlemeden dönüş) */
  dirty?: boolean;
  /** Aynı belge yeniden yüklendiğinde düzenleyiciyi baştan kurmak için */
  rev?: number;
  /** Açılınca gidilecek sayfa (1'den başlar; ör. sayfa ekledikten sonra) */
  startPage?: number;
  /** Açılınca seçilecek belge sekmesi (ör. "mode:annotate") */
  startMode?: string;
  /** Belge türü: PDF (varsayılan) ya da Markdown */
  kind?: 'pdf' | 'md';
}

// Açılır menü düğmelerinin sağ altındaki küçük ok
const CHEVRON = { d: 'M17.5 19l2.25 2.25L22 19', stroke: 'currentColor', fill: 'none', strokeWidth: 1.6 };
const line = (d: string) => ({ d, stroke: 'currentColor', fill: 'none' });
const icon = (paths: { d: string; stroke?: string; fill?: string; strokeWidth?: number }[]) => ({
  viewBox: '0 0 24 24',
  paths,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  strokeWidth: 1.8,
});

const TURA_ICONS = {
  turaShapes: icon([line('M3 3h8.5v8.5H3z'), line('M8.5 13.5a5 5 0 1 0 10 0a5 5 0 1 0-10 0'), CHEVRON]),
  turaInsert: icon([line('M4 2.5h7l4 4V18H4z'), line('M11 2.5v4h4M9.5 8.5v6M6.5 11.5h6'), CHEVRON]),
  turaForm: icon([line('M2.5 4h14v4.5h-14zM2.5 11.5h14V16h-14z'), line('M5 6.25h5M5 13.75h3'), CHEVRON]),
  turaRedact: icon([line('M3 4h13M3 16h8'), { d: 'M3 7.5h13v5H3z', fill: 'currentColor', stroke: 'currentColor' }, CHEVRON]),
  turaPageAdd: icon([line('M5 3h9l5 5v13H5z'), line('M14 3v5h5M12 11v7M8.5 14.5h7')]),
  turaPageDelete: icon([line('M5 3h9l5 5v13H5z'), line('M14 3v5h5M9.5 12l5 5M14.5 12l-5 5')]),
  ...Object.fromEntries(TOOLS.map((t) => [`turaTool-${t.id}`, icon([line(t.icon)])])),
  'turaTool-donustur-word': icon([line('M6 3h8l4 4v14H6zM14 3v5h4M8.5 11l1.5 6 2-4.5 2 4.5 1.5-6')]),
  'turaTool-donustur-md': icon([line('M3 6h18v12H3zM6 15V9l2.5 3L11 9v6M15.5 9v6M13.5 13l2 2 2-2')]),
};

export function buildViewerConfig(doc: ViewerDoc, author: string): PDFViewerConfig {
  const fontBase = assetUrl('vendor/fonts/');
  return {
    wasmUrl: assetUrl(pdfiumWasmUrl),
    worker: true,
    fontFallback: {
      fonts: Object.fromEntries(LATIN_CHARSETS.map((c) => [c, NOTO])),
      defaultFont: NOTO,
      baseUrl: fontBase,
    },
    tabBar: 'never',
    // Belge açma/kapama ve dışa aktarma Tura Belge'nin kendi üst çubuğunda.
    // Form ve Karart sekmeleri "Not al" içindeki açılır menülere taşındı; EmbedPDF kalemi yerine Tura Kalem var.
    disabledCategories: ['document-open', 'document-close', 'document-export', 'mode-form', 'mode-redact', 'annotation-ink'],
    documentManager: {
      maxDocuments: 1,
      // Motor arabelleği işçiye (worker) aktarabildiği için kopyasını veriyoruz.
      initialDocuments: [{ buffer: doc.bytes.slice(0), name: doc.name, documentId: doc.id }],
    },
    // İngilizcede EmbedPDF'in kendi dilleri kalır; Türkçede çevirimiz kullanılır
    i18n:
      getLang() === 'tr'
        ? { defaultLocale: 'tr', fallbackLocale: 'en', locales: [turkishLocale] }
        : { defaultLocale: 'en', fallbackLocale: 'en' },
    theme: {
      preference: 'system',
      light: {
        background: {
          app: '#EDE3D1',
          surface: '#FFFCF6',
          surfaceAlt: '#F8EFDF',
          elevated: '#FFFFFF',
          overlay: 'rgba(14, 26, 79, 0.45)',
          input: '#FFFFFF',
        },
        foreground: {
          primary: '#14205A',
          secondary: '#3D4670',
          muted: '#626A8C',
          disabled: '#A9ADBF',
          onAccent: '#FFFFFF',
        },
        border: { default: '#E2D3B8', subtle: '#EEE3CF', strong: '#C9B48F' },
        accent: {
          primary: '#0B7A8F',
          primaryHover: '#096A7C',
          primaryActive: '#075A69',
          primaryLight: '#D5EEF1',
          primaryForeground: '#FFFFFF',
        },
        interactive: {
          hover: '#F3E8D5',
          active: '#E9DAC0',
          selected: '#D5EEF1',
          focus: '#0B7A8F',
          focusRing: '#9FD8E0',
        },
      },
      dark: {
        background: {
          app: '#080D28',
          surface: '#101943',
          surfaceAlt: '#0D153A',
          elevated: '#172156',
          overlay: 'rgba(0, 0, 0, 0.6)',
          input: '#0D153A',
        },
        foreground: {
          primary: '#F6E9D3',
          secondary: '#D5C8B2',
          muted: '#9CA1C0',
          disabled: '#5E6488',
          onAccent: '#06222A',
        },
        border: { default: '#26306A', subtle: '#1C2558', strong: '#3A4590' },
        accent: {
          primary: '#3CC4D6',
          primaryHover: '#5BD1E0',
          primaryActive: '#2AAFC1',
          primaryLight: '#123B52',
          primaryForeground: '#06222A',
        },
        interactive: {
          hover: '#1A2560',
          active: '#222E70',
          selected: '#123B52',
          focus: '#3CC4D6',
          focusRing: '#1F6C7A',
        },
      },
    },
    annotations: {
      annotationAuthor: author,
      colorPresets: TURA_HIGHLIGHT_COLORS,
      // Kalemle yazarken bir önceki çizgi seçili kalmasın; yoksa sonraki dokunuş onu taşır
      selectAfterCreate: false,
      deactivateToolAfterCreate: false,
    },
    icons: {
      ...TURA_ICONS,
      turaAsk: {
        viewBox: '0 0 24 24',
        paths: [
          { d: 'M11 3.5l1.9 5.1 5.1 1.9-5.1 1.9L11 17.5l-1.9-5.1L4 10.5l5.1-1.9z', stroke: 'currentColor', fill: 'none' },
          { d: 'M18.5 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z', stroke: 'none', fill: 'currentColor' },
        ],
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        strokeWidth: 1.7,
      },
      turaTranslate: {
        viewBox: '0 0 24 24',
        paths: [
          { d: 'M4 5h8M8 3v2M10 5c-1 4-3.5 7-6 8.5M6.5 9c1.2 2 3 3.6 5 4.5', stroke: 'currentColor', fill: 'none' },
          { d: 'M13 21l4-9 4 9M14.5 17.5h5', stroke: 'currentColor', fill: 'none' },
        ],
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        strokeWidth: 1.8,
      },
      turaWebSearch: {
        viewBox: '0 0 24 24',
        paths: [
          { d: 'M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zM15.5 15.5L20 20', stroke: 'currentColor', fill: 'none' },
          { d: 'M4.2 10.5h12.6M10.5 4c-1.8 2-2.6 4.2-2.6 6.5s.8 4.5 2.6 6.5c1.8-2 2.6-4.2 2.6-6.5S12.3 6 10.5 4z', stroke: 'currentColor', fill: 'none', strokeWidth: 1.2 },
        ],
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        strokeWidth: 1.8,
      },
    },
    signature: {
      mode: SignatureMode.SignatureAndInitials,
    },
    // Hazır damga kütüphanesi bir CDN'den indiriliyor; gizlilik ve çevrimdışı
    // çalışma için kapalı. Kullanıcı "Damgalarım" kütüphanesine kendi damgalarını ekleyebilir.
    stamp: { manifests: [] },
    export: { defaultFileName: doc.name },
  };
}
