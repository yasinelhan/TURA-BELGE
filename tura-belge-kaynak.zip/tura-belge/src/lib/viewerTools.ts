// Tura Belge — belge içi sekmeler ve araç çubukları:
// Görüntüle | Not al (Şekiller, Ekle, Form, Karart açılır menüleri) | Sayfalar | PDF araçları
// SPDX-License-Identifier: AGPL-3.0-or-later
import type { AnnotationPlugin, CommandsPlugin, PluginRegistry, UIPlugin } from '@embedpdf/react-pdf-viewer';
import { __, N_ } from '../i18n';

/** Düzenleyicinin (React) belge içi komutlara verdiği işler */
export interface DocActions {
  openTool: (toolId: string) => void;
  addPage: () => void;
  deletePage: () => void;
}

/** Sekmelerde gösterilen araçlar: [araç kimliği, kısa ad] */
export const PAGE_TOOLS: [string, string][] = [
  ['sayfalar', N_('Sırala ve döndür')],
  ['bol', N_('Böl / ayıkla')],
  ['birlestir', N_('Birleştir')],
];
export const DOC_TOOLS: [string, string][] = [
  ['donustur-word', N_('Word’e çevir')],
  ['donustur-md', N_('Markdown’a çevir')],
  ['ocr', N_('Yazıyı tanı')],
  ['vektor', N_('Vektöre çevir')],
  ['sikistir', N_('Sıkıştır')],
  ['filigran', 'Filigran'],
  ['sayfa-numarasi', N_('Sayfa numarası')],
  ['pdften-gorsel', N_('Görsele çevir')],
];

type State = { plugins?: Record<string, any> }; // eslint-disable-line @typescript-eslint/no-explicit-any
type Item = Record<string, unknown> & { id: string; type: string };

const secondaryIs = (state: State, documentId: string, toolbarId: string) => {
  const slot = state.plugins?.ui?.documents?.[documentId]?.activeToolbars?.['top-secondary'];
  return !!slot?.isOpen && slot.toolbarId === toolbarId;
};
const menuOpen = (state: State, documentId: string, menuId: string) =>
  state.plugins?.ui?.documents?.[documentId]?.openMenus?.[menuId] !== undefined;
const activeTool = (state: State, documentId: string): string | undefined =>
  state.plugins?.annotation?.documents?.[documentId]?.activeToolId ?? undefined;

const btn = (id: string, commandId: string, variant: 'icon' | 'icon-text' = 'icon'): Item => ({
  type: 'command-button',
  id,
  commandId,
  variant,
  categories: ['tura'],
});
const cmd = (commandId: string): Item => ({ type: 'command', id: `m-${commandId}`, commandId });
const div = (id: string): Item => ({ type: 'divider', id, orientation: 'vertical' });
const menuDiv = (id: string): Item => ({ type: 'divider', id });

/** Görüntüleyicinin arayüzünü Tura Belge düzenine getirir. */
export function setupDocumentUi(registry: PluginRegistry, actions: () => DocActions | null) {
  const commands = registry.getPlugin<CommandsPlugin>('commands')?.provides();
  const ui = registry.getPlugin<UIPlugin>('ui')?.provides();
  const annotation = registry.getPlugin<AnnotationPlugin>('annotation')?.provides();
  if (!commands || !ui) return;

  const enterMode = (documentId: string, toolbarId: string) => {
    ui.setActiveToolbar('top', 'secondary', toolbarId, documentId);
    const scope = annotation?.forDocument(documentId);
    scope?.setActiveTool(null);
    // Not al sekmesindeki gibi: form alanları doldurulabilir kalsın
    scope?.setLocked({ type: 'include', categories: ['form'] } as never);
  };

  // Eski "Şekiller" ve "Ekle" sekmeleri Sayfalar ve PDF araçları olur (dar ekrandaki sekme seçici de bunları gösterir)
  commands.registerCommand({
    id: 'mode:shapes',
    label: 'Sayfalar',
    categories: ['mode', 'mode-tura-pages'],
    action: ({ documentId }) => enterMode(documentId, 'tura-pages-toolbar'),
    active: ({ state, documentId }) => secondaryIs(state as State, documentId, 'tura-pages-toolbar'),
  });
  commands.registerCommand({
    id: 'mode:insert',
    label: __('PDF araçları'),
    categories: ['mode', 'mode-tura-tools'],
    action: ({ documentId }) => enterMode(documentId, 'tura-tools-toolbar'),
    active: ({ state, documentId }) => secondaryIs(state as State, documentId, 'tura-tools-toolbar'),
  });

  // Not al içindeki açılır menüler
  const MENUS: { id: string; label: string; icon: string; tools: string[] }[] = [
    { id: 'shapes', label: __('Şekiller'), icon: 'turaShapes', tools: ['square', 'circle', 'line', 'lineArrow', 'polygon', 'polyline'] },
    { id: 'insert', label: __('Ekle: görsel, imza, damga, sayfa'), icon: 'turaInsert', tools: ['stamp'] },
    { id: 'form', label: __('Form alanları'), icon: 'turaForm', tools: ['formTextField', 'formCheckbox', 'formRadioButton', 'formCombobox', 'formListbox'] },
    { id: 'redact', label: 'Karart', icon: 'turaRedact', tools: [] },
  ];
  for (const m of MENUS) {
    commands.registerCommand({
      id: `tura:menu-${m.id}`,
      label: m.label,
      icon: m.icon,
      categories: ['tura'],
      action: ({ documentId }) => ui.forDocument(documentId).toggleMenu(`tura-${m.id}-menu`, `tura:menu-${m.id}`, `tura-${m.id}-button`),
      active: ({ state, documentId }) => {
        const s = state as State;
        const t = activeTool(s, documentId);
        return menuOpen(s, documentId, `tura-${m.id}-menu`) || (!!t && m.tools.includes(t));
      },
    });
  }

  // Form araçları: alanı yerleştirip taşıyabilmek için form kilidi açılır
  const FORM: [string, string, string, string][] = [
    ['textfield', 'formTextField', __('Metin alanı'), 'formTextfield'],
    ['checkbox', 'formCheckbox', __('Onay kutusu'), 'formCheckbox'],
    ['radio', 'formRadioButton', __('Seçenek düğmesi'), 'formRadio'],
    ['select', 'formCombobox', __('Açılır liste'), 'formSelect'],
    ['listbox', 'formListbox', __('Liste kutusu'), 'formListbox'],
  ];
  for (const [key, tool, label, icon] of FORM) {
    commands.registerCommand({
      id: `tura:form-${key}`,
      label,
      icon,
      categories: ['tura', 'form'],
      action: ({ documentId }) => {
        const scope = annotation?.forDocument(documentId);
        if (!scope) return;
        if (scope.getActiveTool()?.id === tool) {
          scope.setActiveTool(null);
          return;
        }
        scope.setLocked({ type: 'none' } as never);
        scope.setActiveTool(tool);
      },
      active: ({ state, documentId }) => activeTool(state as State, documentId) === tool,
    });
  }

  commands.registerCommand({
    id: 'tura:page-add',
    label: __('Sayfa ekle'),
    icon: 'turaPageAdd',
    categories: ['tura'],
    action: () => actions()?.addPage(),
  });
  commands.registerCommand({
    id: 'tura:page-delete',
    label: __('Sayfa sil'),
    icon: 'turaPageDelete',
    categories: ['tura'],
    action: () => actions()?.deletePage(),
  });
  for (const [id, label] of [...PAGE_TOOLS, ...DOC_TOOLS]) {
    commands.registerCommand({
      id: `tura:tool-${id}`,
      label: __(label),
      icon: `turaTool-${id}`,
      categories: ['tura'],
      action: () => actions()?.openTool(id),
    });
  }

  // ---------------------------------------------------------------- şema
  const schema = ui.getSchema();
  const annot = schema.toolbars['annotation-toolbar'];
  const group = annot?.items.find((i) => i.id === 'annotation-tools') as (Item & { items: Item[] }) | undefined;
  const toolbars: Record<string, unknown> = {};
  const MARKUP_MORE = ['add-strikeout', 'add-underline', 'add-squiggly'];
  const TEXT_TOOLS = ['add-text', 'add-insert-text', 'add-replace-text', 'add-comment', 'add-callout'];

  if (annot && group) {
    // Tura Kalem zaten var: EmbedPDF'in kendi kalem ve fosforlu kalemi kaldırılır
    const items = group.items.filter((i) => i.id !== 'add-ink' && i.id !== 'add-ink-highlighter');
    const at = items.findIndex((i) => i.id === 'annotation-tools-divider-1');
    const menuButtons = [
      div('tura-note-div'),
      btn('tura-shapes-button', 'tura:menu-shapes'),
      btn('tura-insert-button', 'tura:menu-insert'),
      btn('tura-form-button', 'tura:menu-form'),
      btn('tura-redact-button', 'tura:menu-redact'),
    ];
    items.splice(at < 0 ? items.length : at, 0, ...menuButtons);
    toolbars['annotation-toolbar'] = {
      ...annot,
      items: annot.items.map((i) => (i.id === 'annotation-tools' ? { ...group, items } : i)),
      responsive: {
        breakpoints: {
          xs: { maxWidth: 480, hide: [...MARKUP_MORE, ...TEXT_TOOLS], show: ['overflow-annotation-tools'] },
          sm: { minWidth: 480, maxWidth: 1100, hide: TEXT_TOOLS, show: ['overflow-annotation-tools', ...MARKUP_MORE] },
          md: { minWidth: 1100, hide: ['overflow-annotation-tools'], show: [...MARKUP_MORE, ...TEXT_TOOLS] },
        },
      },
    };
  }

  const strip = (id: string, tools: [string, string][], extra: Item[] = []) => ({
    id,
    position: { placement: 'top', slot: 'secondary', order: 0 },
    permanent: false,
    categories: ['tura'],
    items: [
      { type: 'spacer', id: `${id}-s1`, flex: true },
      {
        type: 'group',
        id: `${id}-group`,
        alignment: 'start',
        gap: 2,
        items: [...extra, ...tools.map(([t]) => btn(`${id}-${t}`, `tura:tool-${t}`, 'icon-text'))],
      },
      { type: 'spacer', id: `${id}-s2`, flex: true },
    ],
  });
  toolbars['tura-pages-toolbar'] = strip('tura-pages-toolbar', PAGE_TOOLS, [
    btn('tura-pages-add', 'tura:page-add', 'icon-text'),
    btn('tura-pages-delete', 'tura:page-delete', 'icon-text'),
    div('tura-pages-div'),
  ]);
  toolbars['tura-tools-toolbar'] = strip('tura-tools-toolbar', DOC_TOOLS);

  const oldMore = schema.menus['annotation-tools-menu'];
  const menus: Record<string, unknown> = {
    'tura-shapes-menu': {
      id: 'tura-shapes-menu',
      items: ['annotation:add-rectangle', 'annotation:add-circle', 'annotation:add-line', 'annotation:add-arrow', 'annotation:add-polygon', 'annotation:add-polyline'].map(cmd),
    },
    'tura-insert-menu': {
      id: 'tura-insert-menu',
      items: [cmd('insert:add-image'), cmd('insert:add-signature'), cmd('insert:add-rubber-stamp'), menuDiv('tura-insert-div'), cmd('tura:page-add'), cmd('tura:page-delete')],
    },
    'tura-form-menu': {
      id: 'tura-form-menu',
      items: [...FORM.map(([k]) => cmd(`tura:form-${k}`)), menuDiv('tura-form-div'), cmd('form:toggle-fill-mode')],
    },
    'tura-redact-menu': {
      id: 'tura-redact-menu',
      items: [cmd('redaction:redact-area'), cmd('redaction:redact-text'), menuDiv('tura-redact-div'), cmd('panel:toggle-redaction')],
    },
  };
  if (oldMore) {
    // Dar ekranda araç çubuğundan düşenler "Diğer araçlar" menüsünde
    const kept = (oldMore.items as unknown as Item[]).filter((i) => !String(i.id).includes('ink'));
    const extra = ['annotation:add-strikeout', 'annotation:add-underline', 'annotation:add-squiggly'].map((c) => ({
      type: 'command',
      id: c,
      commandId: c,
    }));
    menus['annotation-tools-menu'] = {
      ...oldMore,
      items: [...extra, ...kept],
      responsive: {
        breakpoints: {
          xs: { maxWidth: 480, show: extra.map((e) => e.id) },
          sm: { minWidth: 480, hide: extra.map((e) => e.id) },
        },
      },
    };
  }

  ui.mergeSchema({ toolbars, menus } as never);
  // Yeni öğelerin ekran genişliğine göre görünürlük kuralları da işlensin
  const plugin = registry.getPlugin('ui') as unknown as { invalidateStylesheet?: () => void; stylesheetInvalidated$?: { emit: () => void } };
  plugin.invalidateStylesheet?.();
  plugin.stylesheetInvalidated$?.emit();
}

// Dar ekranda belge araç çubukları sığmazsa yana kaydırılabilir; sekme seçici biraz daha geniş
const VIEWER_CSS = `
[data-epdf-i="mode-tabs"], [data-epdf-i="mode-select-button"], [data-epdf-i="overflow-tabs-button"] { display: none !important; }
/* Geniş ekranda sekmenin araçları ana simgelerin hemen yanında, tek satırda */
@media (min-width: 700px) {
  div[data-epdf] { flex-direction: row; flex-wrap: wrap; align-content: flex-start; align-items: center; column-gap: 8px; background: var(--color-bg-surface, #fffcf6); }
  div[data-epdf]::before { content: ''; order: 0; width: 0; height: 48px; margin-right: 8px; }
  div[data-epdf] > [data-epdf-i="main-toolbar"] { display: contents; }
  div[data-epdf] > [data-epdf-i="main-toolbar"] > [data-epdf-i^="spacer"] { display: none; }
  div[data-epdf] > [data-epdf-i="main-toolbar"] > [data-epdf-i="right-group"] { order: 2; margin-left: auto; margin-right: 16px; }
  div[data-epdf] > [data-epdf-i]:not([data-epdf-i="main-toolbar"]) {
    order: 1; flex: 1 1 0; min-width: 0; height: 48px; padding: 0 4px 0 10px; border-bottom: 0; background: transparent;
    border-left: 1px solid var(--color-border-default, #e2d3b8); border-radius: 0;
  }
  div[data-epdf] > [data-epdf-i]:not([data-epdf-i="main-toolbar"]) > [data-epdf-i^="spacer"],
  div[data-epdf] > [data-epdf-i]:not([data-epdf-i="main-toolbar"]) > [data-epdf-i$="-s1"],
  div[data-epdf] > [data-epdf-i]:not([data-epdf-i="main-toolbar"]) > [data-epdf-i$="-s2"] { display: none; }
  div[data-epdf] > #document-content { order: 3; flex: 0 0 100%; height: calc(100% - 49px); border-top: 1px solid var(--color-border-default, #e2d3b8); }
}
[data-epdf-i="annotation-toolbar"], [data-epdf-i="tura-pages-toolbar"], [data-epdf-i="tura-tools-toolbar"] {
  overflow-x: auto; overscroll-behavior-x: contain; scrollbar-width: none;
}
[data-epdf-i="annotation-toolbar"]::-webkit-scrollbar, [data-epdf-i="tura-pages-toolbar"]::-webkit-scrollbar,
[data-epdf-i="tura-tools-toolbar"]::-webkit-scrollbar { display: none; }
[data-epdf-i="tura-pages-toolbar"] button, [data-epdf-i="tura-tools-toolbar"] button { white-space: nowrap; }
@media (max-width: 480px) {
  [data-epdf-i="annotation-toolbar"], [data-epdf-i="tura-pages-toolbar"], [data-epdf-i="tura-tools-toolbar"] { padding-inline: 8px; }
  [data-epdf-i="annotation-tools"], [data-epdf-i="tura-pages-toolbar-group"], [data-epdf-i="tura-tools-toolbar-group"] { gap: 4px; }
  [data-epdf-i="main-toolbar"] { padding-inline: 6px; gap: 4px; }
  [data-epdf-i="mode-select-button"] > div { width: 118px !important; max-width: 118px !important; }
  [data-epdf-i="mode-select-button"] button { padding-left: 8px; padding-right: 4px; gap: 2px; }
}
@media (max-width: 359px) {
  [data-epdf-i="mode-select-button"] > div { width: 100px !important; max-width: 100px !important; }
}
`;

/** Görüntüleyicinin gölge DOM'una Tura Belge'nin küçük stil eklerini koyar */
export function styleViewer(host: HTMLElement | null) {
  const root = host?.querySelector('embedpdf-container')?.shadowRoot;
  if (!root || root.querySelector('style[data-tura]')) return;
  const style = document.createElement('style');
  style.setAttribute('data-tura', '');
  style.textContent = VIEWER_CSS;
  root.appendChild(style);
}
