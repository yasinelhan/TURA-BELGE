// Tura Belge — PDF'i cihaza indirme.
// Normal tarayıcıda <a download> kullanılır. Uygulama Claude yapıtı (artifact)
// içinde çalışıyorsa, oradaki "downloads" yeteneği üzerinden indirir.
// SPDX-License-Identifier: AGPL-3.0-or-later

import { isNative, nativeSaveAs } from './native';
import { __, N_ } from '../i18n';

export type DownloadResult = 'saved' | 'declined' | 'unavailable';

interface ClaudeDownloads {
  save(req: { filename: string; data: Blob }): Promise<{ status: string }>;
}
interface ClaudeHost {
  use(name: string): Promise<unknown>;
}

type SaveFilePicker = (opts: {
  suggestedName: string;
  types: { description: string; accept: Record<string, string[]> }[];
}) => Promise<{ createWritable(): Promise<{ write(b: Blob): Promise<void>; close(): Promise<void> }> }>;

function claudeHost(): ClaudeHost | null {
  const c = (window as unknown as { claude?: ClaudeHost }).claude;
  return c && typeof c.use === 'function' ? c : null;
}

/** Gömülü görünümde miyiz? (iframe içinde, Claude ana sayfası etrafında) */
export function isEmbedded(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function pdfFileName(name: string): string {
  const base = name.replace(/\.pdf$/i, '').replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'belge';
  return `${base}.pdf`;
}

export async function downloadPdf(name: string, bytes: ArrayBuffer): Promise<DownloadResult> {
  return downloadFile(pdfFileName(name), new Blob([bytes], { type: 'application/pdf' }));
}

const PICKER_TYPES: Record<string, { description: string; accept: Record<string, string[]> }> = {
  pdf: { description: N_('PDF belgesi'), accept: { 'application/pdf': ['.pdf'] } },
  zip: { description: N_('ZIP arşivi'), accept: { 'application/zip': ['.zip'] } },
  png: { description: N_('PNG görseli'), accept: { 'image/png': ['.png'] } },
  jpg: { description: N_('JPEG görseli'), accept: { 'image/jpeg': ['.jpg', '.jpeg'] } },
  docx: { description: N_('Word belgesi'), accept: { 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] } },
  md: { description: N_('Markdown belgesi'), accept: { 'text/markdown': ['.md'] } },
  html: { description: N_('Web sayfası'), accept: { 'text/html': ['.html'] } },
  txt: { description: N_('Düz metin'), accept: { 'text/plain': ['.txt'] } },
};

/** Dosya adı olarak kullanılamayan işaretleri ayıklar */
export const safeFileName = (name: string, ext: string) =>
  `${name.replace(/\.(pdf|md|markdown|txt|docx|html)$/i, '').replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'belge'}.${ext}`;

/** Herhangi bir dosyayı (PDF, ZIP, PNG, JPG) cihaza indirir. */
export async function downloadFile(filename: string, blob: Blob): Promise<DownloadResult> {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';

  // Mobil uygulama: WebView indirme yapamaz; sistemin "Farklı kaydet" ekranı açılır
  if (isNative()) return nativeSaveAs(filename, blob);

  const host = claudeHost();
  if (host) {
    try {
      const downloads = (await host.use('downloads')) as ClaudeDownloads | null;
      if (downloads) {
        await downloads.save({ filename, data: blob });
        return 'saved';
      }
    } catch (err) {
      const code = (err as { code?: string })?.code;
      if (code === 'declined' || code === 'rate_limited') return 'declined';
      return 'unavailable';
    }
    if (isEmbedded()) return 'unavailable';
  }

  // Masaüstü Chrome/Edge: "Farklı kaydet" penceresi (dosya adı ve klasör seçilir)
  const picker = (window as unknown as { showSaveFilePicker?: SaveFilePicker }).showSaveFilePicker;
  if (!isEmbedded() && typeof picker === 'function') {
    try {
      const handle = await picker({
        suggestedName: filename,
        types: PICKER_TYPES[ext === 'jpeg' ? 'jpg' : ext]
          ? [{ ...PICKER_TYPES[ext === 'jpeg' ? 'jpg' : ext], description: __(PICKER_TYPES[ext === 'jpeg' ? 'jpg' : ext].description) }]
          : [],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return 'saved';
    } catch (err) {
      if ((err as { name?: string })?.name === 'AbortError') return 'declined';
      // başka bir hata: klasik indirmeye düş
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
  return 'saved';
}
