// Tura Belge — Metin kutularındaki Türkçe karakter düzeltmesi
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Sorun: PDF motoru (PDFium) metin kutusu (FreeText) notlarının görünümünü
// standart Helvetica yazı tipiyle ve WinAnsi kodlamasıyla üretiyor. Bu kodlamada
// ı, ğ, ş, İ, Ğ, Ş harfleri yok; Tura Belge içinde doğru görünseler de indirilen
// PDF başka bir programda (Acrobat, Chrome, telefonun PDF görüntüleyicisi) açılınca
// bu harfler kayboluyor.
//
// Çözüm: PDF'i dışa aktarırken, WinAnsi dışında karakter içeren metin kutularının
// görünüm akışını (appearance stream) Noto Sans gömülü yazı tipiyle yeniden yazıyoruz.
// Arka plan, kenarlık ve kırpma gibi diğer çizimler olduğu gibi korunur.
import type { PDFDocument, PDFFont, PDFDict as PDFDictT, PDFNumber as PDFNumberT, PDFRef as PDFRefT } from 'pdf-lib';

// WinAnsi (cp1252) içinde olan, 0xFF üstündeki karakterler
const CP1252_EXTRA = new Set('€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ');
const needsUnicodeFont = (s: string) => [...s].some((c) => c.charCodeAt(0) > 0xff && !CP1252_EXTRA.has(c));

const FONT_FILES = {
  regular: 'NotoSans-Regular.ttf',
  bold: 'NotoSans-Bold.ttf',
  italic: 'NotoSans-Italic.ttf',
  boldItalic: 'NotoSans-BoldItalic.ttf',
} as const;
type Variant = keyof typeof FONT_FILES;

// DA'daki standart yazı tipi adından kalın/eğik bilgisini çıkar
function variantFromDA(fontName: string): Variant {
  const n = fontName.toLowerCase();
  const bold = /bo|bold|bd/.test(n.replace(/^helv$/, ''));
  const italic = /ob|it|italic|oblique/.test(n);
  return bold && italic ? 'boldItalic' : bold ? 'bold' : italic ? 'italic' : 'regular';
}

function parseDA(da: string) {
  const size = Number(/([\d.]+)\s+Tf/.exec(da)?.[1] ?? 12) || 12;
  const font = /\/([A-Za-z0-9_+-]+)\s+[\d.]+\s+Tf/.exec(da)?.[1] ?? 'Helv';
  const rgb = /([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+rg/.exec(da);
  const gray = /([\d.]+)\s+g(\s|$)/.exec(da);
  const color = rgb ? `${rgb[1]} ${rgb[2]} ${rgb[3]} rg` : gray ? `${gray[1]} g` : '0 g';
  return { size, font, color };
}

function wrap(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
  const width = (t: string) => font.widthOfTextAtSize(t, size);
  const out: string[] = [];
  for (const para of text.replace(/\r\n?/g, '\n').split('\n')) {
    let line = '';
    for (const word of para.split(' ')) {
      const candidate = line ? `${line} ${word}` : word;
      if (width(candidate) <= maxWidth) {
        line = candidate;
        continue;
      }
      if (line) out.push(line);
      // kutudan geniş tek kelimeyi harf harf böl
      let chunk = '';
      for (const ch of word) {
        if (chunk && width(chunk + ch) > maxWidth) {
          out.push(chunk);
          chunk = ch;
        } else chunk += ch;
      }
      line = chunk;
    }
    out.push(line);
  }
  return out;
}

// Büyük PDF'lerde her otomatik kayıtta dosyayı ayrıştırmamak için hızlı bayt taraması
function containsFreeText(bytes: ArrayBuffer): boolean {
  const hay = new Uint8Array(bytes);
  const needle = [...'/FreeText'].map((c) => c.charCodeAt(0));
  outer: for (let i = hay.indexOf(needle[0]); i !== -1 && i <= hay.length - needle.length; i = hay.indexOf(needle[0], i + 1)) {
    for (let j = 1; j < needle.length; j++) if (hay[i + j] !== needle[j]) continue outer;
    return true;
  }
  return false;
}

const num = (n: number) => (Math.round(n * 1000) / 1000).toString();

/**
 * Dışa aktarılan PDF'teki Türkçe karakterli metin kutularının görünümünü düzeltir.
 * Bir hata olursa PDF'i değiştirmeden geri verir.
 */
export async function fixTurkishFreeText(bytes: ArrayBuffer, fontBaseUrl: string): Promise<ArrayBuffer> {
  if (!containsFreeText(bytes)) return bytes;
  try {
    const lib = await import('pdf-lib');
    const { PDFName, PDFDict, PDFRawStream, PDFString, PDFHexString, decodePDFRawStream } = lib;

    let doc: PDFDocument | null = null;
    const fonts = new Map<Variant, PDFFont>();
    const fontBytes = new Map<Variant, ArrayBuffer>();
    let changed = 0;

    // Önce hızlı tarama: düzeltilecek kutu yoksa dosyaya hiç dokunma
    doc = await lib.PDFDocument.load(bytes, { updateMetadata: false });
    const pages = doc.getPages();
    const targets: { annot: PDFDictT; text: string }[] = [];
    for (const page of pages) {
      const annots = page.node.Annots();
      if (!annots) continue;
      for (let i = 0; i < annots.size(); i++) {
        const annot = annots.lookup(i, PDFDict);
        if (annot.get(PDFName.of('Subtype'))?.toString() !== '/FreeText') continue;
        const c = annot.lookup(PDFName.of('Contents'));
        const text = c instanceof PDFString || c instanceof PDFHexString ? c.decodeText() : '';
        if (text && needsUnicodeFont(text)) targets.push({ annot, text });
      }
    }
    if (targets.length === 0) return bytes;

    const fontkit = (await import('@pdf-lib/fontkit')).default;
    doc.registerFontkit(fontkit);
    const getFont = async (v: Variant) => {
      if (!fonts.has(v)) {
        if (!fontBytes.has(v)) {
          const res = await fetch(fontBaseUrl + FONT_FILES[v]);
          if (!res.ok) throw new Error(`yazı tipi yüklenemedi: ${FONT_FILES[v]}`);
          fontBytes.set(v, await res.arrayBuffer());
        }
        // Not: fontkit alt kümelemesi (subset) Noto Sans'ta bozuk glif üretiyor; yazı tipi tam gömülür.
        fonts.set(v, await doc!.embedFont(fontBytes.get(v)!, { subset: false }));
      }
      return fonts.get(v)!;
    };

    for (const { annot, text } of targets) {
      const ap = annot.lookup(PDFName.of('AP'), PDFDict);
      const nRef = ap?.get(PDFName.of('N'));
      const normal = nRef ? doc.context.lookup(nRef) : undefined;
      if (!(normal instanceof PDFRawStream)) continue;

      const src = new TextDecoder('latin1').decode(decodePDFRawStream(normal).decode());
      const bt = src.indexOf('BT');
      const et = src.lastIndexOf('ET');
      if (bt < 0 || et < bt) continue;

      const daObj = annot.lookup(PDFName.of('DA'));
      const da = daObj instanceof PDFString || daObj instanceof PDFHexString ? daObj.decodeText() : '';
      const { size, font: daFont, color } = parseDA(da);
      const font = await getFont(variantFromDA(daFont));

      const bbox = normal.dict.lookup(PDFName.of('BBox'));
      const box = (bbox as unknown as { asArray(): unknown[] })
        .asArray()
        .map((n) => (n as PDFNumberT).asNumber());
      const [x0, y0, x1, y1] = [Math.min(box[0], box[2]), Math.min(box[1], box[3]), Math.max(box[0], box[2]), Math.max(box[1], box[3])];
      const pad = 2;
      const width = x1 - x0 - pad * 2;
      const lineH = size * 1.362;
      const ascent = size * 1.069;
      const q = (annot.lookup(PDFName.of('Q')) as PDFNumberT | undefined)?.asNumber() ?? 0;
      const vaObj = annot.lookup(PDFName.of('EPDF:VerticalAlignment')) as PDFNumberT | undefined;
      const va = vaObj?.asNumber?.() ?? 0;

      const lines = wrap(text, font, size, Math.max(width, size));
      const blockH = lines.length * lineH;
      const top =
        va === 1 ? y0 + (y1 - y0 + blockH) / 2 : va === 2 ? y0 + blockH + pad : y1 - pad;

      let ops = `BT\n${color}\n/TuraNoto ${num(size)} Tf\n`;
      lines.forEach((line, i) => {
        const w = font.widthOfTextAtSize(line, size);
        const x = q === 1 ? x0 + (x1 - x0 - w) / 2 : q === 2 ? x1 - pad - w : x0 + pad;
        const y = top - ascent - i * lineH;
        ops += `1 0 0 1 ${num(x)} ${num(y)} Tm\n${font.encodeText(line).toString()} Tj\n`;
      });
      ops += 'ET';

      const content = src.slice(0, bt) + ops + src.slice(et + 2);
      const resources =
        (normal.dict.lookup(PDFName.of('Resources')) as PDFDictT | undefined) ?? doc.context.obj({});
      const fontDict = (resources.lookup(PDFName.of('Font')) as PDFDictT | undefined) ?? doc.context.obj({});
      fontDict.set(PDFName.of('TuraNoto'), font.ref as PDFRefT);
      resources.set(PDFName.of('Font'), fontDict);

      const dict = normal.dict.clone(doc.context);
      dict.delete(PDFName.of('Filter'));
      dict.delete(PDFName.of('DecodeParms'));
      dict.set(PDFName.of('Resources'), resources);
      const stream = doc.context.flateStream(content, {});
      for (const [k, v] of dict.entries()) if (k.toString() !== '/Length' && k.toString() !== '/Filter') stream.dict.set(k, v);
      ap!.set(PDFName.of('N'), doc.context.register(stream));
      changed++;
    }

    if (!changed) return bytes;
    const out = await doc.save({ useObjectStreams: false, updateFieldAppearances: false });
    return out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength) as ArrayBuffer;
  } catch (err) {
    console.warn('[Tura Belge] metin kutusu düzeltmesi atlandı', err);
    return bytes;
  }
}
