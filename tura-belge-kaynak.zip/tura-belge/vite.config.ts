// SPDX-License-Identifier: AGPL-3.0-or-later
import react from '@vitejs/plugin-react';
import { readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

// "artifact" modu: Claude yapıtı (artifact) olarak yayınlanan canlı demo içindir.
// Orada servis çalışanı (service worker) kullanılamadığı için PWA kapalıdır.
// "native" modu: Android/iOS uygulamasının içine gömülen sürüm; dosyalar zaten cihazda
// olduğu için PWA (servis çalışanı) gerekmez.
export default defineConfig(({ mode }) => ({
  // Göreli yollar: uygulama herhangi bir alt klasörde (ör. GitHub Pages) çalışabilir.
  base: './',
  plugins: [
    react(),
    // LaTeX motoru (~120 MB) mobil pakete varsayılan olarak konmaz (istenirse TURA_TEX_MOBIL=1);
    // Claude yapıtındaki canlı demoya hiç konmaz (64 MB sınırı)
    ((mode === 'native' && !process.env.TURA_TEX_MOBIL) || mode === 'artifact') && {
      name: 'tura-tex-motoru-disla',
      closeBundle() {
        rmSync(`${mode === 'native' ? 'dist-native' : 'dist-artifact'}/tex/busytex`, { recursive: true, force: true });
      },
    },
    // Claude yapıtı .gz dosyası sunmuyor: yazı tanıma dil verileri base64 .json olarak konur
    mode === 'artifact' && {
      name: 'tura-ocr-dil-json',
      closeBundle() {
        const dir = 'dist-artifact/vendor/tesseract/lang';
        for (const f of readdirSync(dir).filter((x) => x.endsWith('.gz'))) {
          writeFileSync(`${dir}/${f.replace(/\.gz$/, '.json')}`, JSON.stringify({ gz: readFileSync(`${dir}/${f}`).toString('base64') }));
          rmSync(`${dir}/${f}`);
        }
      },
    },
    mode !== 'artifact' &&
    mode !== 'native' &&
    VitePWA({
      registerType: 'autoUpdate',
      injectRegister: 'script-defer',
      includeAssets: ['icons/*.png', 'brand/*.png'],
      manifest: {
        id: './',
        name: 'Tura Belge',
        short_name: 'Tura Belge',
        description: 'PDF görüntüleme, not alma, imzalama, belge tarama ve LaTeX. Açık kaynak, çevrimdışı çalışır.',
        lang: 'tr',
        start_url: './',
        scope: './',
        display: 'standalone',
        background_color: '#f6e8cf',
        theme_color: '#0b7a8f',
        categories: ['productivity', 'education'],
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
        // Kurulu uygulamada "Birlikte aç → Tura Belge" (Windows, macOS, ChromeOS)
        file_handlers: [
          { action: './', accept: { 'application/pdf': ['.pdf'], 'text/markdown': ['.md', '.markdown'] } },
        ],
        launch_handler: { client_mode: ['navigate-existing', 'auto'] },
      },
      workbox: {
        // PDF motoru (WASM) ve yazı tipleri de önbelleğe alınır; uygulama internetsiz açılır.
        globPatterns: ['**/*.{js,css,html,png,svg,wasm,ttf,woff2,pdf,webp}'],
        // LaTeX, tarama ve yazı tanıma motorları büyük; ilk kullanımda indirilir ve ayrı önbelleğe alınır
        globIgnores: ['tex/busytex/**', 'vendor/opencv/**', 'vendor/tesseract/**'],
        maximumFileSizeToCacheInBytes: 12 * 1024 * 1024,
        runtimeCaching: [
          {
            urlPattern: /\/tex\/busytex\/.*\.(?:wasm|js)$/,
            handler: 'CacheFirst',
            options: { cacheName: 'tura-tex-motor', expiration: { maxEntries: 20 } },
          },
          {
            urlPattern: /\/vendor\/opencv\/opencv\.js$/,
            handler: 'CacheFirst',
            options: { cacheName: 'tura-tarama-motor', expiration: { maxEntries: 2 } },
          },
          {
            // Yazı tanıma: işçi, çekirdek ve dil verileri
            urlPattern: /\/vendor\/tesseract\/.+$/,
            handler: 'CacheFirst',
            options: { cacheName: 'tura-ocr-motor', expiration: { maxEntries: 12 } },
          },
        ],
      },
    }),
  ],
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 4000,
    outDir: mode === 'artifact' ? 'dist-artifact' : mode === 'native' ? 'dist-native' : 'dist',
  },
}));
