// Tura Belge — Android: dosyayı yerinde açma ve aynı dosyaya kaydetme
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// Dosyalar, OneDrive, Google Drive gibi uygulamalardan "Birlikte aç → Tura Belge" ile ya da
// uygulama içindeki "Dosya aç" ile (Android depolama erişim çerçevesi) açılır. Yazma izni
// alınabilen dosyalarda değişiklikler aynı dosyaya yazılır; bulut uygulaması eşitler.
package com.nahle.turabelge;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

@CapacitorPlugin(name = "TuraDosya")
public class TuraDosyaPlugin extends Plugin {

    /** Uygulama bir dosyayla açıldıysa (henüz web tarafına verilmemiş) */
    private JSObject pendingLaunch = null;

    @Override
    public void load() {
        Intent intent = getActivity().getIntent();
        JSObject f = fileFromIntent(intent);
        if (f != null) pendingLaunch = f;
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        JSObject f = fileFromIntent(intent);
        if (f != null) notifyListeners("dosyaAcildi", f, true);
    }

    /** VIEW / EDIT / SEND ile gelen PDF'i çözer, mümkünse kalıcı izin alır */
    private JSObject fileFromIntent(Intent intent) {
        if (intent == null) return null;
        String action = intent.getAction();
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(action) || Intent.ACTION_EDIT.equals(action)) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(action)) {
            Object extra = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) uri = (Uri) extra;
        }
        if (uri == null) return null;
        int flags = intent.getFlags();
        boolean canWrite = (flags & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0;
        try {
            int take = Intent.FLAG_GRANT_READ_URI_PERMISSION | (canWrite ? Intent.FLAG_GRANT_WRITE_URI_PERMISSION : 0);
            getContext().getContentResolver().takePersistableUriPermission(uri, take);
        } catch (Exception ignored) {
            // Kalıcı izin verilmeyen kaynaklar: bu oturum boyunca geçici izin geçerli
        }
        // Intent'i tüket: ekran dönünce aynı dosya yeniden açılmasın
        intent.setAction(Intent.ACTION_MAIN);
        intent.setData(null);
        JSObject o = describe(uri);
        o.put("writable", canWrite || Intent.ACTION_EDIT.equals(action) || isWritable(uri));
        return o;
    }

    private JSObject describe(Uri uri) {
        JSObject o = new JSObject();
        o.put("uri", uri.toString());
        String name = "Belge.pdf";
        long size = -1;
        long modified = 0;
        ContentResolver cr = getContext().getContentResolver();
        try (Cursor c = cr.query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                int mi = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                if (mi >= 0 && !c.isNull(mi)) modified = c.getLong(mi);
            }
        } catch (Exception ignored) {
        }
        o.put("name", name);
        o.put("size", size);
        o.put("lastModified", modified);
        return o;
    }

    private boolean isWritable(Uri uri) {
        try (Cursor c = getContext().getContentResolver().query(uri, new String[] { DocumentsContract.Document.COLUMN_FLAGS }, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                return (c.getInt(0) & DocumentsContract.Document.FLAG_SUPPORTS_WRITE) != 0;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    @PluginMethod
    public void getLaunchFile(PluginCall call) {
        JSObject r = pendingLaunch != null ? pendingLaunch : new JSObject();
        pendingLaunch = null;
        call.resolve(r);
    }

    /** Sistem dosya seçicisi: yazma izni kalıcı alınır, değişiklikler aynı dosyaya yazılabilir */
    @PluginMethod
    public void pick(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // PDF ve Markdown (.md) belgeleri
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] { "application/pdf", "text/markdown", "text/x-markdown", "text/plain" });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("İptal edildi", "CANCELLED");
            return;
        }
        Uri uri = result.getData().getData();
        boolean writable = false;
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            writable = true;
        } catch (Exception e) {
            try {
                getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
        }
        JSObject o = describe(uri);
        o.put("writable", writable || isWritable(uri));
        call.resolve(o);
    }

    @PluginMethod
    public void stat(PluginCall call) {
        String u = call.getString("uri");
        if (u == null) {
            call.reject("uri yok");
            return;
        }
        call.resolve(describe(Uri.parse(u)));
    }

    @PluginMethod
    public void read(PluginCall call) {
        String u = call.getString("uri");
        if (u == null) {
            call.reject("uri yok");
            return;
        }
        Uri uri = Uri.parse(u);
        getBridge().execute(() -> {
            try (InputStream in = getContext().getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("Dosya açılamadı");
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[1 << 16];
                int n;
                while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n);
                JSObject o = describe(uri);
                o.put("data", Base64.encodeToString(buf.toByteArray(), Base64.NO_WRAP));
                call.resolve(o);
            } catch (SecurityException e) {
                call.reject("Bu dosyaya erişim izni yok. Dosyayı yeniden açın.", "PERMISSION", e);
            } catch (Exception e) {
                call.reject("Dosya okunamadı: " + e.getMessage(), "READ", e);
            }
        });
    }

    /** Baytları aynı dosyaya yazar ("wt": önce boşalt, sonra yaz) */
    @PluginMethod
    public void write(PluginCall call) {
        String u = call.getString("uri");
        String data = call.getString("data");
        if (u == null || data == null) {
            call.reject("uri ya da veri yok");
            return;
        }
        Uri uri = Uri.parse(u);
        getBridge().execute(() -> {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            try (OutputStream out = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new Exception("Dosya yazılamadı");
                out.write(bytes);
                out.flush();
            } catch (SecurityException e) {
                call.reject("Bu dosyaya yazma izni yok. Değişiklikler uygulamada saklandı; “İndir” ile kaydedebilirsiniz.", "PERMISSION", e);
                return;
            } catch (Exception e) {
                call.reject("Dosya yazılamadı: " + e.getMessage(), "WRITE", e);
                return;
            }
            call.resolve(describe(uri));
        });
    }

    /** "Farklı kaydet": sistemin kaydetme ekranı (İndirilenler, Drive, OneDrive…) */
    @PluginMethod
    public void saveAs(PluginCall call) {
        String name = call.getString("name", "Belge.pdf");
        String mime = call.getString("mime", "application/pdf");
        if (call.getString("data") == null) {
            call.reject("veri yok");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "saveAsResult");
    }

    @ActivityCallback
    private void saveAsResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("İptal edildi", "CANCELLED");
            return;
        }
        Uri uri = result.getData().getData();
        String data = call.getString("data");
        getBridge().execute(() -> {
            try (OutputStream out = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new Exception("Dosya yazılamadı");
                out.write(Base64.decode(data, Base64.DEFAULT));
            } catch (Exception e) {
                call.reject("Kaydedilemedi: " + e.getMessage(), "WRITE", e);
                return;
            }
            call.resolve(describe(uri));
        });
    }

    /** Paylaş: dosya önbelleğe yazılıp paylaşım ekranı açılır */
    @PluginMethod
    public void share(PluginCall call) {
        String name = call.getString("name", "Belge.pdf").replaceAll("[\\/:*?\"<>|]", " ");
        String mime = call.getString("mime", "application/pdf");
        String data = call.getString("data");
        if (data == null) {
            call.reject("veri yok");
            return;
        }
        getBridge().execute(() -> {
            try {
                java.io.File dir = new java.io.File(getContext().getCacheDir(), "paylas");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Önbellek klasörü oluşturulamadı");
                java.io.File f = new java.io.File(dir, name);
                try (OutputStream out = new java.io.FileOutputStream(f)) {
                    out.write(Base64.decode(data, Base64.DEFAULT));
                }
                Uri uri = androidx.core.content.FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, null);
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getActivity().runOnUiThread(() -> getActivity().startActivity(chooser));
                call.resolve();
            } catch (Exception e) {
                call.reject("Paylaşılamadı: " + e.getMessage(), "SHARE", e);
            }
        });
    }

    /** Android 13 ve öncesinde "wt" desteklemeyen sağlayıcılar için bilgi */
    @PluginMethod
    public void info(PluginCall call) {
        JSObject o = new JSObject();
        o.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(o);
    }
}
