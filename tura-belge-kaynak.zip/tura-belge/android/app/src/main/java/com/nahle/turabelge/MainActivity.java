// Tura Belge — Android ana etkinlik
// SPDX-License-Identifier: AGPL-3.0-or-later
package com.nahle.turabelge;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Yerel eklentiler super.onCreate'ten önce kaydedilmeli
        registerPlugin(TuraDosyaPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
