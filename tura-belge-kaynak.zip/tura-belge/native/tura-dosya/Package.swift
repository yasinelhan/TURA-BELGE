// swift-tools-version: 5.9
// Tura Belge — TuraDosya eklentisi (iOS)
// SPDX-License-Identifier: AGPL-3.0-or-later
import PackageDescription

let package = Package(
    name: "TuraDosya",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "TuraDosya", targets: ["TuraDosyaPlugin"])
    ],
    dependencies: [
        .package(url: "https://github.com/ionic-team/capacitor-swift-pm.git", from: "8.0.0")
    ],
    targets: [
        .target(
            name: "TuraDosyaPlugin",
            dependencies: [
                .product(name: "Capacitor", package: "capacitor-swift-pm"),
                .product(name: "Cordova", package: "capacitor-swift-pm")
            ],
            path: "ios/Sources/TuraDosyaPlugin"
        )
    ]
)
