// Tura Belge — iPhone/iPad: dosyayı yerinde açma ve aynı dosyaya kaydetme
// SPDX-License-Identifier: AGPL-3.0-or-later
//
// "Dosyalar" uygulamasından (iCloud Drive, OneDrive, Google Drive sağlayıcıları dahil) açılan
// PDF'ler kopyalanmadan, yerinde açılır. Dosyaya erişim, güvenlik kapsamlı yer imi (bookmark)
// ile saklanır; uygulama yeniden açıldığında da aynı dosyaya yazılabilir.
// JavaScript tarafında "uri" alanı: "bm:<base64 yer imi>" ya da "file://…".

import Capacitor
import Foundation
import UIKit
import UniformTypeIdentifiers

@objc(TuraDosyaPlugin)
public class TuraDosyaPlugin: CAPPlugin, CAPBridgedPlugin, UIDocumentPickerDelegate {
    public let identifier = "TuraDosyaPlugin"
    public let jsName = "TuraDosya"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "getLaunchFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "pick", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stat", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "read", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "write", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "saveAs", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "share", returnType: CAPPluginReturnPromise),
    ]

    private var pendingLaunch: [String: Any]?
    private var pickCall: CAPPluginCall?
    private var exportCall: CAPPluginCall?
    private var exportURL: URL?

    override public func load() {
        NotificationCenter.default.addObserver(self, selector: #selector(onOpenURL(_:)), name: .capacitorOpenURL, object: nil)
    }

    // MARK: - Dosyalar uygulamasından gelen PDF

    @objc private func onOpenURL(_ note: Notification) {
        guard let obj = note.object as? [String: Any], let url = obj["url"] as? URL, url.isFileURL else { return }
        guard url.pathExtension.lowercased() == "pdf" else { return }
        guard let info = describe(url: url, keepAccess: true) else { return }
        if hasListeners("dosyaAcildi") {
            notifyListeners("dosyaAcildi", data: info, retainUntilConsumed: true)
        } else {
            pendingLaunch = info
        }
    }

    @objc func getLaunchFile(_ call: CAPPluginCall) {
        call.resolve(pendingLaunch ?? [:])
        pendingLaunch = nil
    }

    // MARK: - Seçici

    @objc func pick(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf, UTType(filenameExtension: "md") ?? UTType.plainText], asCopy: false)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            self.pickCall = call
            self.bridge?.viewController?.present(picker, animated: true)
        }
    }

    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let call = exportCall {
            exportCall = nil
            cleanupExport()
            if let url = urls.first {
                call.resolve(["uri": url.absoluteString, "name": url.lastPathComponent, "size": -1, "lastModified": 0])
            } else {
                call.reject("İptal edildi", "CANCELLED")
            }
            return
        }
        guard let call = pickCall else { return }
        pickCall = nil
        guard let url = urls.first, let info = describe(url: url, keepAccess: true) else {
            call.reject("Dosya açılamadı", "READ")
            return
        }
        call.resolve(info)
    }

    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        if let call = exportCall {
            exportCall = nil
            cleanupExport()
            call.reject("İptal edildi", "CANCELLED")
            return
        }
        pickCall?.reject("İptal edildi", "CANCELLED")
        pickCall = nil
    }

    // MARK: - Okuma, yazma

    @objc func stat(_ call: CAPPluginCall) {
        guard let url = resolve(call.getString("uri")) else {
            call.reject("Dosya bulunamadı", "PERMISSION")
            return
        }
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        var info = attributes(url)
        info["uri"] = call.getString("uri") ?? ""
        call.resolve(info)
    }

    @objc func read(_ call: CAPPluginCall) {
        guard let uri = call.getString("uri"), let url = resolve(uri) else {
            call.reject("Bu dosyaya erişim izni yok. Dosyayı yeniden açın.", "PERMISSION")
            return
        }
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = url.startAccessingSecurityScopedResource()
            defer { if ok { url.stopAccessingSecurityScopedResource() } }
            var data: Data?
            var coordErr: NSError?
            NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordErr) { u in
                data = try? Data(contentsOf: u)
            }
            guard let d = data else {
                call.reject("Dosya okunamadı: \(coordErr?.localizedDescription ?? "")", "READ")
                return
            }
            var info = self.attributes(url)
            info["uri"] = uri
            info["data"] = d.base64EncodedString()
            call.resolve(info)
        }
    }

    @objc func write(_ call: CAPPluginCall) {
        guard let uri = call.getString("uri"), let url = resolve(uri),
              let b64 = call.getString("data"), let data = Data(base64Encoded: b64) else {
            call.reject("Bu dosyaya yazma izni yok.", "PERMISSION")
            return
        }
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = url.startAccessingSecurityScopedResource()
            defer { if ok { url.stopAccessingSecurityScopedResource() } }
            var writeErr: Error?
            var coordErr: NSError?
            NSFileCoordinator().coordinate(writingItemAt: url, options: .forReplacing, error: &coordErr) { u in
                do { try data.write(to: u, options: .atomic) } catch { writeErr = error }
            }
            if let e = writeErr ?? coordErr {
                call.reject("Dosya yazılamadı: \(e.localizedDescription)", "WRITE")
                return
            }
            var info = self.attributes(url)
            info["uri"] = uri
            call.resolve(info)
        }
    }

    // MARK: - Farklı kaydet, paylaş

    private func tempFile(_ call: CAPPluginCall) -> URL? {
        guard let b64 = call.getString("data"), let data = Data(base64Encoded: b64) else { return nil }
        let raw = call.getString("name") ?? "Belge.pdf"
        let name = raw.components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|")).joined(separator: " ")
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("tura", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(name)
        do { try data.write(to: url, options: .atomic) } catch { return nil }
        return url
    }

    private func cleanupExport() {
        if let u = exportURL { try? FileManager.default.removeItem(at: u) }
        exportURL = nil
    }

    @objc func saveAs(_ call: CAPPluginCall) {
        guard let url = tempFile(call) else {
            call.reject("Kaydedilemedi", "WRITE")
            return
        }
        DispatchQueue.main.async {
            let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
            picker.delegate = self
            self.exportCall = call
            self.exportURL = url
            self.bridge?.viewController?.present(picker, animated: true)
        }
    }

    @objc func share(_ call: CAPPluginCall) {
        guard let url = tempFile(call) else {
            call.reject("Paylaşılamadı", "SHARE")
            return
        }
        DispatchQueue.main.async {
            guard let vc = self.bridge?.viewController else {
                call.reject("Paylaşılamadı", "SHARE")
                return
            }
            let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            // iPad: açılır pencere ekranın ortasından açılsın
            sheet.popoverPresentationController?.sourceView = vc.view
            sheet.popoverPresentationController?.sourceRect = CGRect(x: vc.view.bounds.midX, y: vc.view.bounds.midY, width: 1, height: 1)
            sheet.popoverPresentationController?.permittedArrowDirections = []
            vc.present(sheet, animated: true)
            call.resolve()
        }
    }

    // MARK: - Yardımcılar

    /// Dosyayı tanımlar; kalıcı erişim için yer imi oluşturur
    private func describe(url: URL, keepAccess: Bool) -> [String: Any]? {
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        var uri = url.absoluteString
        if keepAccess, let bm = try? url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
            uri = "bm:" + bm.base64EncodedString()
        }
        var info = attributes(url)
        info["uri"] = uri
        info["writable"] = FileManager.default.isWritableFile(atPath: url.path)
        return info
    }

    private func resolve(_ uri: String?) -> URL? {
        guard let uri = uri else { return nil }
        if uri.hasPrefix("bm:"), let data = Data(base64Encoded: String(uri.dropFirst(3))) {
            var stale = false
            return try? URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
        }
        return URL(string: uri)
    }

    private func attributes(_ url: URL) -> [String: Any] {
        let v = try? url.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey, .nameKey])
        return [
            "name": v?.name ?? url.lastPathComponent,
            "size": v?.fileSize ?? -1,
            "lastModified": Int64((v?.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000),
        ]
    }
}
