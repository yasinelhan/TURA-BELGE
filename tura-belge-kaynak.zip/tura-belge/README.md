# Tura Belge

**Tura ailesinin ilk uygulaması.** Öğrenciler için açık kaynak bir ofis aracı: PDF görüntüleme, not alma, imza, belge tarama, yazı tanıma, vektöre çevirme ve LaTeX. Tamamen cihazda çalışır, internetsiz de açılır. NAHLE tarafından geliştirilmektedir.

## Özellikler

- **Tura Asistan (yapay zeka):** belgede bir kelime ya da cümle seçince **✨ Asistana sor** çıkar; yanda açılan panelde *Açıkla · Nereden geliyor? · Örnek ver · Özetle · Çevir* ya da serbest soru. Kitaplıkta her klasörde **“Asistana sor”** kartı: o klasördeki bütün PDF ve notlara dayanarak sohbet. Cevaplar önce notlara dayanır ve **[1]** gibi kaynak numaraları verir (tıklayınca belge o sayfada açılır); notlarda eksik kalan yeri (ör. adı geçen ama açıklanmayan bir yöntem, gerekçesiz bir formül) modelin kendi bilgisiyle açıklar ve bunu **“Notlarında yok:”** diye ayrı renkte belirtir. Formüller KaTeX ile çizilir; sohbet Markdown notu olarak klasöre kaydedilebilir. **Bağlantı seçenekleri:** claude.ai içinde açıkken kullanıcının kendi Claude hesabı (kurulumsuz); kullanıcının kendi API anahtarıyla **Google Gemini** (ücretsiz katman, önerilen), **Groq** ve **OpenRouter** (ücretsiz katman), **OpenAI (ChatGPT)**, **Anthropic (Claude API)**, **DeepSeek**; bilgisayarda ücretsiz çalışan **Ollama**, **LM Studio**, **Open WebUI**, **AnythingLLM**, **Jan** ya da herhangi bir OpenAI uyumlu adres; isteğe bağlı ekip sunucusu. Notlar yalnızca seçilen servise gider
- **Çeviri:** seçili metin önce tarayıcının cihaz içi çevirmeniyle (Chrome/Edge masaüstü, ücretsiz, internetsiz) çevrilir; yoksa bağlı model çevirir, kısa ifadelerde anlamını ve örnek cümleyi de verir
- **Türkçe ve İngilizce:** dil üst çubuktaki **TR | EN** düğmesiyle değişir (ilk açılışta tarayıcının dili). Kaynakta metinler Türkçe yazılır, İngilizceleri `src/i18n/en.ts` sözlüğündedir
- **Markdown notları:** .md dosyalarını aç ya da “+ Yeni not” ile yaz; **Görüntüle** (biçimli okuma, yapılacak kutuları tıklanır) ve **Düzenle** (biçim çubuğu, yan yana canlı önizleme). Not adı ilk başlıktan kendiliğinden alınır; otomatik kaydedilir, asıl .md dosyasına geri yazılır
- **Farklı kaydet:** İndir düğmesinin yanındaki ok ile **PDF, Word (.docx), Markdown (.md), web sayfası (.html), düz metin (.txt)**. PDF’ten Word/Markdown’a çevirmede yazı başlık, paragraf, liste ve kalın/eğik biçimleriyle aktarılır; Markdown’dan PDF’e çevirme vektördür (Noto yazı tipleri gömülü, Türkçe karakterler tam). “Markdown notu olarak aç” ve “PDF olarak aç” ile iki biçim arasında gidip gelinir
- **Defter kapları:** kitaplıktaki her belge deri görünümlü, dikişli ve kayışlı bir defter kabıyla görünür; renk her yeni belgeye sırayla kendiliğinden verilir
- **Belge içi sekmeler:** belgenin üst çubuğunda **Görüntüle · Not al · Sayfalar · PDF araçları** (telefonda açılır liste); seçilen sekmenin araçları ana simgelerin hemen yanında, aynı satırda. Bütün araçlar belgenin içinden kullanılır; aracın sonucu aynı belgenin yerine geçer, “Belgeye dön” ile kalınan sayfaya ve sekmeye dönülür
- **Not al:** vurgula, altını/üstünü çiz, metin kutusu, yorum, açıklama balonu; tek dokunuşla açılan menüler: **Şekiller** (dikdörtgen, daire, çizgi, ok, çokgen), **Ekle** (görsel, imza, damga, sayfa ekle, sayfa sil), **Form** (metin alanı, onay kutusu, seçenek, liste) ve **Karart**
- **Sayfa ekle / sil:** belgenin içinden boş sayfa ekle; nereye (bu sayfadan önce/sonra, en sona), kâğıt (bu sayfa gibi, A4, A4 yatay, A5), desen (düz, çizgili, kareli, noktalı), **sayfa rengi** (hazır renkler, yeşil/kara tahta ya da istediğin renk) ve adet seçilir. Tek sayfa ya da aralık (ör. 2, 5-7) silinir
- **Tura Kalem (el yazısı):** basınca duyarlı kalem (M-Pencil, Apple Pencil, S Pen, Wacom); yazı vektör olarak kaydedilir. **Beş kalem:** tükenmez, dolma (mürekkepli), kurşun, keçeli ve fosforlu. **Silgi** kalem gibi çalışır: boyutu ayarlanır (küçük/orta/büyük ya da kaydırıcıyla), dokunduğu yeri siler (çizgiyi böler) ya da istersen bütün çizgiyi; silgi halkası ekranda görünür. Her kalemin **uç kalınlığı**, **basınç hassasiyeti** (bastırdıkça ne kadar kalınlaşsın), **titreme düzeltme**, **mürekkep yoğunluğu** ve **uç biçimi** (yuvarlak ya da keski: hat yazısı, fosforlunun düz ucu) ayrı ayrı ayarlanır; örnek çizgiyle önizlenir ve cihazda hatırlanır. **50 renklik skala**, özel renk ve son kullanılan renkler. Kalem kullanılınca parmak ve avuç içi yazmaz, yalnızca sayfayı kaydırır; yazarken sayfa kaymaz. Silgi (kalemin arka ucu da siler), **kement** ile seçip taşıma, boyutlandırma ve renk değiştirme. **Güzelleştir:** titremeyi alır; kabaca çizilen çizgi, daire ve dikdörtgeni düzgün şekle çevirir. **El yazısını tanı:** yazıyı metne çevirir ya da kopyalar; kalem kapatılınca o oturumda yazılan sayfaların el yazısı tanınıp nota eklenir (Acrobat gibi uygulamalarda notlarda aranabilir)
- **İmzala:** imzanı çiz, yaz ya da görsel yükle; paraf ekle; imzaların cihazda saklanır
- **Seçili metin:** asistana sor, çevir (Türkçe ↔ İngilizce) ve internette ara; belgede arama
- **Karart:** gizli bilgiyi kalıcı olarak sil
- **Belge tara:** kamerayla çek ya da fotoğraf seç; kâğıdın kenarları otomatik bulunur, köşeler büyüteçle elle düzeltilebilir, perspektif düzeltilir, gölge temizlenir (Belge, Orijinal, Gri, Siyah-beyaz). Çok sayfalı A4 PDF
- **Yazı tanıma (OCR):** taranmış sayfadaki Türkçe ve İngilizce yazı tanınır; PDF'e görünmez metin katmanı eklenir, böylece arama, seçme ve kopyalama çalışır. Tanınan metin kopyalanabilir ya da .txt indirilebilir
- **Vektöre çevir:** pikselli (taranmış, fotoğraf) sayfalardaki yazı, çizim ve el yazısı kenarlarından çıkarılıp düzgün eğrilere çevrilir; istenildiği kadar yakınlaştırılsa da keskin kalır. Kalem renkleri korunur. Gerçek fotoğraflar vektöre çevrilemeyeceği için arka planda görüntü olarak kalır. Tek sayfa SVG olarak da indirilebilir
- **PDF araçları:** sayfaları düzenle (sürükle-bırak, döndürme, silme, çoğaltma, boş sayfa), birleştir, böl ve ayıkla, sıkıştır, görselden PDF, PDF'ten görsel, filigran, sayfa numarası. Üst çubuktaki “PDF araçları” sayfasında ve açık belgenin sekmelerinde
- **LaTeX ile oluştur:** (PDF araçları içinde) tarayıcıda çalışan LaTeX düzenleyicisi; Türkçe şablonlar (ödev, laboratuvar raporu, staj defteri, CV, sınav, ders notu, dilekçe, sunum), kendi şablonunu kaydetme, canlı önizleme, Türkçe hata açıklamaları
- **Kitaplığım:** açılışta ilk görünen ekran. İlk kart A4 sayfa biçiminde **“+”**: dokun ve PDF seç ya da PDF'i üstüne sürükleyip bırak (birden çok PDF bırakılırsa hepsi kitaplığa eklenir; açık klasör varsa oraya). Belgeleri klasörlere ayır (ders notları bir yere, hikâye kitapları bir yere); dosyalar cihazda farklı yerlerde olsa da uygulamada bir arada
- **Asıl dosyaya kaydetme:** cihazdan açılan PDF'teki değişiklikler aynı dosyaya otomatik yazılır. OneDrive ya da Google Drive klasöründen açılan dosya diğer cihazlarda da güncel olur
- **Paylaş:** Android, iPhone/iPad ve Windows paylaşım penceresiyle
- **Gizlilik:** dosyalar hiçbir sunucuya gönderilmez (asistanı kullanırsan soruyla ilgili not parçaları yalnızca senin bağladığın modele gider). PDF motoru (PDFium), tarama (OpenCV), yazı tanıma (Tesseract) ve LaTeX (TeX Live) WebAssembly olarak cihazda çalışır
- **Çevrimdışı çalışır (PWA)**; **mobil uygulama** (Android, iPhone/iPad) için aşağıya bakın

## Çalıştırma

Gereken: [Node.js](https://nodejs.org) 20 veya üstü.

```bash
npm install        # bağımlılıkları kurar; yazı tiplerini, tarama ve yazı tanıma motorlarını public/vendor'a kopyalar
npm run tex:indir  # (isteğe bağlı) LaTeX motorunu indirir: --paket temel|genis|tam
npm run dev        # geliştirme sunucusu: http://localhost:5173
npm run build      # yayın için dist/ klasörünü üretir
npm run preview    # dist/ klasörünü yerelde dener
```

`dist/` klasörü düz statik dosyalardan oluşur; GitHub Pages, Netlify, Cloudflare Pages ya da herhangi bir web sunucusunda yayınlanabilir. Yollar göreli olduğu için alt klasörde de çalışır.

- PWA (kurulum ve çevrimdışı çalışma) yalnızca **HTTPS** üzerinden ya da `localhost`'ta etkinleşir.
- Büyük motorlar ilk kullanımda indirilip ayrı önbelleğe alınır, sonra internetsiz çalışır: tarama ~13 MB, yazı tanıma ~7 MB (çekirdek + Türkçe + İngilizce), LaTeX ~120 MB (temel paket).
- LaTeX motorunun `genis` ve `tam` paketleri tek dosyada 100 MB'ı aşar; GitHub Pages yalnızca `temel` paketi taşır, ötekiler için kendi sunucunuz gerekir.

## Tura Asistan’ı bağlama

Belgede **Asistan** → **Bağla**. “Asistan bağlantısı” penceresinde üç yol var:

**1. Hazır bağlantı (kurulum yok)**
- **Claude (claude.ai hesabın):** Tura Belge claude.ai içinde (canlı demo, Claude masaüstü uygulaması) açıkken görünür ve varsayılandır. Cevaplar kullanıcının kendi Claude hesabının kullanımından düşer; ilk soruda claude.ai izin ister. Bunun için yapıta `sample` yeteneği bildirilmiştir.
- **Tura sunucusu:** ekip bir sunucu kurduysa (aşağıya bakın) derlemede tanımlanır ve kullanıcı hiçbir şey ayarlamadan kullanır.

**2. İnternetten, API anahtarıyla** — anahtarı al, pencereye yapıştır, model kendiliğinden seçilir:

| Servis | Ücret | Anahtar |
|---|---|---|
| Google Gemini (önerilen) | Kartsız ücretsiz katman (günlük/dakikalık sınırlı; ücretsiz katmanda Google verileri ürün geliştirmede kullanabilir) | [aistudio.google.com/apikey](https://aistudio.google.com/apikey) |
| Groq | Kartsız ücretsiz katman (dakikalık sınır düşük) | [console.groq.com/keys](https://console.groq.com/keys) |
| OpenRouter | `:free` modeller ücretsiz (günlük sınırlı) | [openrouter.ai/settings/keys](https://openrouter.ai/settings/keys) |
| OpenAI (ChatGPT) | Kullandıkça ödenir (ChatGPT Plus API’yi kapsamaz) | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) |
| Anthropic (Claude API) | Kullandıkça ödenir (Claude Pro API’yi kapsamaz) | [console.anthropic.com](https://console.anthropic.com/settings/keys) |
| DeepSeek | Çok ucuz, kullandıkça ödenir | [platform.deepseek.com](https://platform.deepseek.com/api_keys) |

Anahtar yalnızca kullanıcının cihazında saklanır ve istekler doğrudan o servise gider (Tura Belge’nin sunucusu yoktur). Mistral gibi tarayıcıdan doğrudan isteğe izin vermeyen servisler listede yok. claude.ai canlı demosu dış adreslere bağlanamadığı için bu servisler orada çalışmaz; uygulamayı kendi adresinde ya da mobil uygulamada açınca çalışır.

**3. Bilgisayarımda (ücretsiz, notlar bilgisayardan çıkmaz)**

1. [Ollama](https://ollama.com/download)’yı kur ve bir model indir: `ollama pull gemma4:e4b` (8 GB bellekte `gemma4:e2b` ya da `qwen3.5:4b`; 16 GB ve üstünde `qwen3.5:9b` ya da `gemma4:12b`).
2. Tura Belge’yi `localhost`’tan (ör. `npm run dev`) ya da mobil uygulamadan açıyorsan ek ayar gerekmez. Başka bir adreste yayınladıysan (ör. GitHub Pages) Ollama’ya o adresten bağlanma izni ver: `OLLAMA_ORIGINS=https://kullanici.github.io` (Windows: `setx`, macOS: `launchctl setenv`, Linux: systemd `Environment=`), sonra Ollama’yı yeniden başlat. Pencere bu komutları o anki adresle hazır gösterir.

- **LM Studio:** sunucuyu başlat, “Enable CORS”u aç; adres `http://localhost:1234/v1`.
- **Open WebUI:** Ayarlar → Hesap → API anahtarı; adres `http://localhost:3000/api`.
- **AnythingLLM:** Ayarlar → Geliştirici API → anahtar; adres `http://localhost:3001/api/v1/openai`; model listesinde çalışma alanları görünür.
- **Telefon:** bilgisayarda `OLLAMA_HOST=0.0.0.0`, iki cihaz aynı Wi-Fi’de; mobil uygulamada adres `http://<bilgisayarın-IP’si>:11434`. (Web sürümü güvenlik gereği başka cihazdaki `http` adresine bağlanamaz.)
- Open Notebook ve SurfSense gibi araçlar da arkada Ollama gibi bir model kullanır; Tura Belge’yi aynı Ollama’ya bağlamak yeterlidir.

### Ekip sunucusu (isteğe bağlı, “Tura sunucusu”)

Bütün kullanıcıların kurulumsuz kullanması için ekip OpenAI uyumlu bir sunucu kurabilir; derlemede şu değişkenler verilince pencerede “Hazır bağlantı” olarak görünür ve varsayılan olur:

```
VITE_TURA_AI_URL=https://yz.ornek.org/v1   # OpenAI uyumlu adres (https olmalı)
VITE_TURA_AI_MODEL=gemma4:e4b              # varsayılan model
VITE_TURA_AI_KEY=...                       # isteğe bağlı: HERKESE AÇIK, sınırlı bir anahtar
VITE_TURA_AI_NAME=Kmu hiTechTeam sunucusu   # pencerede görünen ad
```

Dikkat edilmesi gerekenler:
- Uygulama açık kaynak ve tarayıcıda çalıştığı için **derlemeye konan anahtar herkes tarafından okunabilir.** Asıl hesabın (Open WebUI yöneticisi, Gemini/OpenAI anahtarı) anahtarını asla koyma. Sunucuda kullanıcı ya da IP başına günlük istek sınırı, bütçe sınırı ve yalnızca sohbet uç noktalarına izin ver. [LiteLLM proxy](https://github.com/BerriAI/litellm) (sanal anahtar, bütçe, hız sınırı) bunun için uygundur. Open WebUI kullanılacaksa ayrı, yetkisiz bir kullanıcı aç ve “API Key Endpoint Restrictions” ile yalnızca `/api/models` ve `/api/chat/completions`’a izin ver.
- Arkada kendi bilgisayarındaki Ollama varsa: bilgisayar sürekli açık ve https ile erişilebilir olmalı (ör. Cloudflare Tunnel); bir ekran kartı aynı anda birkaç öğrenciye cevap yazar, kalabalıkta sıra oluşur.
- Arkada ücretli bir API varsa bütün kullanıcıların kullanımını sen ödersin; ücretsiz katmanın sınırı (ör. Gemini’nin günlük isteği) bütün kullanıcılar arasında paylaşılır ve hızla dolar.
- Öğrencilerin notları sunucudan geçeceği için kişisel verilerin korunması (KVKK) yükümlülükleri doğar: aydınlatma metni, kayıt tutmama ya da saklama süresi. CORS’u yalnızca Tura Belge’nin adresine aç.

Asistan, klasördeki belgelerin yazısını cihazda sayfa sayfa çıkarıp önbelleğe alır (`src/ai/sources.ts`), soruyla en ilgili parçaları sözcük temelli aramayla (BM25, Türkçe eklere dayanıklı kök eşleştirme) seçer ve kaynak numaralarıyla modele verir. Sohbetler ve bağlantı ayarı yalnızca bu cihazda saklanır.

## Asıl dosyaya kaydetme (OneDrive klasörü)

Xodo'daki gibi: dosyayı OneDrive klasöründen aç, not al; değişiklikler (otomatik kayıtla) aynı dosyaya yazılır, OneDrive uygulaması da dosyayı diğer cihazlara eşitler. Tura Belge OneDrive'a bağlanmaz, hesap istemez; yalnızca cihazdaki dosyayı yerinde günceller.

| Cihaz | Durum |
|---|---|
| Windows, macOS, Linux, ChromeOS: Chrome veya Edge | ✅ Çalışır. Uygulama olarak kurulursa Dosya Gezgini'nde PDF'e sağ tık → **Birlikte aç → Tura Belge**. |
| Android: **Tura Belge uygulaması** | ✅ Dosyalar, OneDrive, Drive: **Birlikte aç / Düzenle → Tura Belge** ya da uygulamada "Dosya seç". Yazma izni veren dosyalarda değişiklikler aynı dosyaya yazılır. |
| iPhone, iPad: **Tura Belge uygulaması** | ✅ Dosyalar uygulamasından yerinde açma (iCloud Drive, OneDrive, Drive sağlayıcıları). |
| Android Chrome 132+ (tarayıcı) | ⚠️ Tarayıcı destekliyor; dosyayı sunan uygulamaya bağlı. |
| iPhone/iPad tarayıcıları, Firefox | ❌ Tarayıcı izin vermiyor; dosya kopyası açılır. Mobil uygulama kullanın. |

Nasıl çalışır: `src/lib/fileLink.ts` (web: File System Access API) ve `src/lib/native.ts` (mobil: yerel TuraDosya eklentisi) aynı arayüzü sunar. Her değişiklikten ~1,5 saniye sonra PDF hem uygulamaya hem asıl dosyaya yazılır. Dosya başka cihazda değiştiyse "Yeni sürümü aç" bandı çıkar; iki tarafta da değişiklik varsa hangisinin kalacağı sorulur, hiçbir değişiklik sessizce ezilmez.

## Mobil uygulama (Android, iPhone/iPad)

Web uygulaması [Capacitor](https://capacitorjs.com) ile aynı kodla mobil uygulamaya dönüşür. Projeler `android/` ve `ios/` klasörlerindedir.

```bash
npm run mobil:hazirla   # web uygulamasını dist-native/'e derler ve yerel projelere kopyalar
npm run mobil:android   # + Android Studio'da açar (Run ▶ ile telefona/emülatöre kurulur)
npm run mobil:ios       # + Xcode'da açar (yalnızca macOS)
```

Gerekenler: Android için [Android Studio](https://developer.android.com/studio) (JDK 21 ve Android SDK 36 birlikte gelir); iOS için macOS'ta Xcode 16+.

Mobilde ek olarak:

- **Birlikte aç / Paylaş → Tura Belge:** başka uygulamadaki PDF doğrudan açılır.
- **Yerinde kaydetme:** `android/app/src/main/java/com/nahle/turabelge/TuraDosyaPlugin.java` (Android depolama erişim çerçevesi, kalıcı okuma/yazma izni) ve `native/tura-dosya/ios/…/TuraDosyaPlugin.swift` (güvenlik kapsamlı yer imleri, NSFileCoordinator).
- **İndir:** sistemin "Farklı kaydet" ekranı (İndirilenler, Drive, OneDrive…). **Paylaş:** WhatsApp, e-posta…
- **Kamera:** tarama için telefonun kamerası.
- LaTeX motoru uygulama paketine varsayılan olarak konmaz (~120 MB). Koymak için: `TURA_TEX_MOBIL=1 npm run mobil:hazirla`.

> **Not:** Yerel eklentiler bu depoda derlenip cihazda denenmedi (derleme ortamında Android SDK ve Xcode yoktu). İlk derlemede küçük düzeltmeler gerekebilir.
>
### Huawei tabletler (HarmonyOS 4.x)

HarmonyOS 2–4 (ör. HarmonyOS 4.3) Android uygulamalarını çalıştırır; Tura Belge Google Play hizmetlerine ihtiyaç duymaz. Kurulum:

1. Projeyi GitHub'a yükleyin; **Actions → Android APK → Run workflow** (`.github/workflows/android-apk.yml`). Birkaç dakika sonra sayfanın altındaki **tura-belge-apk** dosyasını indirin. (Ya da bilgisayarda Android Studio ile `npm run mobil:android`.)
2. APK'yı tablete aktarın (USB, Huawei Share ya da bulut), dosyaya dokunun ve kurulum sırasında çıkan uyarıdan bilinmeyen kaynaktan yüklemeye izin verin. HarmonyOS'ta **Saf mod** açıksa kurulumu engeller; Ayarlar'da arayıp geçici olarak kapatmak gerekebilir.
3. M-Pencil basınç bilgisi uygulama içindeki tarayıcı bileşeni üzerinden gelir; ilk kalem dokunuşunda "Yalnızca kalem" kendiliğinden açılır.

HarmonyOS NEXT / 5 ise Android uygulaması çalıştırmaz; orada tarayıcıdan (PWA) kullanılır.

## Proje yapısı

```
src/
  App.tsx                 Uygulama kabuğu: Kitaplığım, PDF araçları, LaTeX ve düzenleyici arası geçiş, belge açma
  components/
    Home.tsx              Ana ekran: Kitaplığım ve dosya bırakma
    Library.tsx           Kitaplığım: "+" PDF ekle kartı, klasörler, kapak resimleri, taşıma
    Editor.tsx            Düzenleyici: EmbedPDF görüntüleyici, otomatik kayıt, asıl dosya, paylaş, indir
    PageDialogs.tsx       Belge içi "Sayfa ekle" (renk, desen, boyut) ve "Sayfa sil" pencereleri
    DocTabs.tsx           Üst çubuktaki belge sekmeleri
    SaveMenu.tsx          İndir + Farklı kaydet menüsü
    Notebook.tsx          Kitaplıktaki deri defter kapları
  md/MdEditor.tsx         Markdown görüntüleyici ve düzenleyici
  ai/                     Tura Asistan
    settings.ts           Bağlantı ayarları: claude.ai, ekip sunucusu, Gemini, Groq, OpenRouter, OpenAI, Anthropic, DeepSeek, Ollama, LM Studio, Open WebUI, AnythingLLM, Jan
    client.ts             Modele bağlanma: Ollama, OpenAI uyumlu, Anthropic, Gemini ve claude.ai (sample) lehçeleri; akış, model süzme, hata mesajları
    sources.ts            Belge yazısını sayfa sayfa çıkarma (önbellekli), BM25 arama, kaynak numaraları
    prompt.ts             İstem: önce notlar, eksikse genel bilgi (“Notlarında yok:”), hızlı sorular, çeviri
    translate.ts          Tarayıcının cihaz içi çevirmeni (Translator API), dil tahmini
    AssistantPanel.tsx    Sohbet paneli: seçili metin, hızlı düğmeler, kaynak düğmeleri, not olarak kaydet
    AssistantPage.tsx     Klasör sayfası (#asistan-<klasör>)
    AiSettingsDialog.tsx  “Asistan bağlantısı” penceresi ve kurulum adımları
    chats.ts              Sohbetlerin cihazda saklanması
  convert/                Biçim dönüştürme: markdown.ts (marked), mathView.ts (formüller, KaTeX), pdfToMd.ts (PDF yazı parçalarından yapı),
                          mdToPdf.ts (pdfmake), mdToDocx.ts (docx), exporters.ts (Farklı kaydet)
  i18n/                   Dil desteği: index.ts (__(), dil seçimi), en.ts (İngilizce sözlük), tr.ts (görüntüleyicinin Türkçesi)
    TopNav.tsx, Brand.tsx Üst çubuk, Tura logosu ve NAHLE imzası
  lib/
    viewerConfig.ts       Görüntüleyici ayarları: Tura teması, Türkçe, yerel WASM ve yazı tipleri
    viewerExtras.ts       Seçili metin menüsü: asistana sor, çevir, internette ara
    viewerTools.ts        Belge içi sekmeler: Not al menüleri (Şekiller, Ekle, Form, Karart), Sayfalar, PDF araçları
    pageEdit.ts           Renkli/desenli boş sayfa ekleme, sayfa silme (pdf-lib)
    storage.ts            Belgeler, klasörler, kapaklar, dosya tutamaçları (IndexedDB)
    fileLink.ts           Asıl dosyaya kaydetme (web)
    native.ts             Mobil uygulama köprüsü: yerinde açma/kaydetme, farklı kaydet, paylaş
    download.ts           İndirme
    thumbs.ts             Kapak resimleri
    turkishText.ts        Metin kutularında Türkçe karakter düzeltmesi
  i18n/tr.ts              Görüntüleyicinin Türkçe çevirisi
  pen/                    Tura Kalem
    PenLayer.tsx          Kalem araç çubuğu ve girdi: kalem türleri, renk skalası, ayarlar, basınç, avuç içi engelleme, silgi, kement, tanıma
    penSettings.ts        Kalem türleri, renk skalası, kullanıcı ayarları (cihazda saklanır)
    geometry.ts           Basınca göre kalınlık (perfect-freehand), keski uç, sadeleştirme, şekil tanıma, güzelleştirme
    viewerBridge.ts       Ekran noktası → sayfa noktası, notları ekleme/güncelleme
    handwriting.ts        El yazısını temiz görüntüye çizip Tesseract ile okuma
  tools/                  PDF araçları (#araclar, #arac-<ad>)
    ScanTool.tsx          Belge tara: kamera, köşe düzeltme (büyüteçli), filtreler, vektör/fotoğraf çıktı
    OcrTool.tsx           Yazı tanıma: aranabilir PDF, metni kopyala/indir
    VectorTool.tsx        Vektöre çevir: önce/sonra karşılaştırması, SVG
    OrganizeTool.tsx, MergeTool.tsx, SplitTool.tsx, CompressTool.tsx,
    ImagesToPdfTool.tsx, PdfToImagesTool.tsx, StampTools.tsx
    lib/scan.ts           Kenar bulma, perspektif, gölge temizleme (OpenCV.js)
    lib/ocr.ts            Tesseract.js işçisi, görünmez metin katmanı
    lib/ocrPdf.ts         PDF'i sayfa sayfa tanıma
    lib/vectorize.ts      Mürekkep ayırma, renk kümeleri, fotoğraf bölgeleri, arka plan
    lib/bezier.ts         Kenarı köşe/eğri olarak Bézier'e çevirme (Potrace yöntemi, sıfırdan yazıldı)
    lib/vectorPdf.ts      Vektör PDF oluşturma
    lib/pdfOps.ts         PDF işlemleri (pdf-lib)
    lib/render.ts         Sayfa görüntüsü ve metin (PDFium, ayrı işçide)
  tex/                    LaTeX ile oluştur: düzenleyici (CodeMirror), derleyici (BusyTeX), şablonlar, projeler (#tex)
  config.ts               Kaynak kod adresi ve sürüm
native/tura-dosya/        iOS yerel eklentisi (Swift Package)
android/, ios/            Capacitor mobil projeleri
scripts/
  copy-vendor.mjs         Yazı tiplerini, OpenCV.js'i, Tesseract dosyalarını ve KaTeX'i public/vendor'a kopyalar
  tex-assets.mjs          LaTeX motorunu public/tex/busytex'e indirir
```

## Bilinen sınırlamalar

- **Vektöre çevirme** yazıları yeniden yazmaz, şekillerini eğriye çevirir: çok düşük çözünürlüklü kaynakta (≈150 dpi altı) küçük harflerin ince ayrıntıları ve nokta işaretleri kaba çıkabilir. Fotoğraflar arka planda görüntü olarak kalır. Çok açık kurşun kalem izleri vektöre alınmaz, arka planda kalır.
- **Yazı tanıma** basılı metinde iyidir. **El yazısı** tanıma, düzgün ve ayrık yazıda iyi, bitişik el yazısında zayıftır (Tesseract basılı yazı için eğitilmiş); sonuç düzeltilebilir bir pencerede gösterilir. Google ML Kit Digital Ink gibi hazır modeller Google Play hizmetleri olmayan Huawei cihazlarda güvenilir çalışmayabileceği için cihazda çalışan açık kaynak bir el yazısı modeli araştırılıyor.
- **Tura Kalem izleri** PDF'e dolu çokgen not olarak kaydedilir (basınçla değişen kalınlık böylece her uygulamada görünür); seçiliyken görüntüleyici çevresine mavi bir seçim parıltısı çizer. Kurşun kalem dokulu değil, yarı saydam gri çizer.
- **Sayfa ekle / sil** belgeyi yeniden kurar: o ana kadarki notlar korunur ama “Geri al” geçmişi sıfırlanır.
- **PDF → Word/Markdown** yazıyı yapısıyla aktarır; tablolar, görseller ve PDF’e eklenen notlar (kalem, vurgu) aktarılmaz. Taranmış PDF’te önce “Yazıyı tanı” gerekir. Markdown’daki matematik ($…$) uygulamada formül olarak çizilir ama PDF/Word/HTML’e aktarılırken LaTeX yazısı olarak kalır.
- **Tura Asistan** kullanıcının bağladığı modelin bilgisi (yerel modelde bilgisayarının gücü) kadar iyidir; küçük modeller yanlış ya da eksik cevap verebilir. Asistan sözcük temelli arar: eşanlamlı ama farklı kelimeyle yazılmış yeri kaçırabilir. Taranmış PDF’lerin yazısı ancak “Yazıyı tanı”dan sonra okunur; çizimler, el yazısı notlar ve görseller okunmaz. Tarayıcının cihaz içi çevirmeni yalnızca Chrome/Edge masaüstünde vardır. claude.ai canlı demosunda yalnızca “Claude (claude.ai hesabın)” çalışır; diğer servisler ve yerel model için uygulama kendi adresinde açılmalı (gömülü sayfa dış adreslere bağlanamaz).
- **Dil değişimi** ana ekranda ya da araçlar sayfasında yapılır; LaTeX şablonlarının içeriği Türkçedir.
- **Metin kutusu ve Türkçe karakterler:** PDF motoru metin kutusu görünümünü Helvetica ile üretiyor; bu yazı tipinde ı, ğ, ş, İ yok. `src/lib/turkishText.ts` dışa aktarırken görünümü gömülü Noto Sans ile yeniden yazar (dosya ~300 KB büyür).
- **Ekrana çizilen imza görsel imzadır;** 5070 sayılı Kanun'daki güvenli elektronik imza değildir.
- **Birleştirme ve bölme** sayfaları ve notları korur; yer imleri ve form alanları taşınmaz. **Vektöre çevrilen** sayfalarda eski notlar ve bağlantılar korunmaz (sayfa yeniden çizilir).
- Arayüz yazı tipleri (Montserrat, Open Sans, imza yazı tipleri) şimdilik Google Fonts'tan yükleniyor; ileride projeye gömülmeli.
- claude.ai içindeki canlı demoda dosya seçici, asıl dosyaya kaydetme ve LaTeX motoru yoktur (gömülü sayfa sınırları).

## Yol haritası

| Aşama | İçerik | Durum |
|---|---|---|
| 0.1 | PDF açma, not alma, imza, karartma, otomatik kayıt, PWA | ✅ |
| 0.2 | PDF araçları | ✅ |
| 0.3 | Asıl dosyaya kaydetme, Kitaplığım (klasörler), paylaş, seçili metni çevir/ara, LaTeX düzenleyici | ✅ |
| 0.4 | Belge tarama, yazı tanıma (aranabilir PDF), vektöre çevirme, Android/iOS uygulama iskeleti | ✅ |
| 0.5 | Tura Kalem: basınca duyarlı kalem, avuç içi engelleme, kement ile seçip taşıma/boyutlandırma/renk, güzelleştirme ve şekil düzeltme, el yazısı tanıma; GitHub'da APK derleme | ✅ |
| 0.6 | Kitaplık önde (“+” sayfa kartı), belge içi sekmeler (Not al menüleri, Sayfalar, PDF araçları), renkli/desenli sayfa ekleme ve sayfa silme, beş kalem türü, basınç/uç ayarları, 50 renklik skala, “LaTeX ile oluştur” | ✅ |
| 0.7 | Markdown notları (görüntüle/düzenle), PDF/Word/Markdown/HTML/TXT olarak kaydetme ve dönüştürme, sekmeler üst çubukta, kalem gibi silgi, deri defter kapları, Türkçe/İngilizce | ✅ |
| 0.8.1 | Asistan bağlantıları: Gemini, Groq, OpenRouter, ChatGPT, Claude API, DeepSeek (kullanıcının anahtarıyla), claude.ai içinde kurulumsuz Claude, ekip sunucusu ön ayarı | ✅ |
| 0.8 | Tura Asistan: seçili metne ve klasördeki notlara dayalı soru-cevap, kaynak numaraları, notlarda eksik kalanı açıklama, formüller (KaTeX), çeviri; ücretsiz yerel modeller (Ollama, LM Studio, Open WebUI, AnythingLLM, Jan) | ✅ |
| 0.9 | Asistan: anlamca arama (yerel gömme modeli), formül/şekil alanını görsel olarak sorma, el yazısı notları okuma; Word (DOCX) görüntüleme, PDF → Word’de tablo ve görseller | sırada |
| sonra | İsteğe bağlı Stirling-PDF sunucusu, nitelikli e-imza, internetsiz tarayıcı içi model | |

## Lisans

Tura Belge, **GNU Affero Genel Kamu Lisansı sürüm 3 veya sonrası (AGPL-3.0-or-later)** ile lisanslanmıştır; tam metin [LICENSE](LICENSE) dosyasındadır.

Kısaca: kodu kullanabilir, değiştirebilir ve dağıtabilirsiniz; ancak değiştirilmiş bir sürümü dağıtır **ya da internette hizmet olarak sunarsanız**, kaynak kodunu da aynı lisansla kullanıcılara açmanız gerekir. Uygulamayı yayınlarken `src/config.ts` içindeki `SOURCE_URL` değerine deponun adresini yazın; alt bilgide kaynak kod bağlantısı görünür.

Kullanılan açık kaynak bileşenler ve lisansları: [THIRD-PARTY.md](THIRD-PARTY.md).

Tura ve NAHLE adları ile logoları ekibe aittir; lisans, kodu kapsar, marka kullanım hakkı vermez.
